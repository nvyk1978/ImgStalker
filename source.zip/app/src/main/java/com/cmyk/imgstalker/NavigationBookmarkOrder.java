package com.cmyk.imgstalker;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/** Reorder visible bookmark slots while keeping every hidden mode at its existing slot. */
final class NavigationBookmarkOrder {
    private NavigationBookmarkOrder() { }

    static List<String> merge(List<String> existing, List<String> visibleOrder) {
        ArrayList<String> result = new ArrayList<>();
        if (existing == null) return result;
        HashSet<String> known = new HashSet<>(existing);
        ArrayList<String> reordered = new ArrayList<>();
        HashSet<String> selected = new HashSet<>();
        if (visibleOrder != null) for (String url : visibleOrder) {
            if (known.contains(url) && selected.add(url)) reordered.add(url);
        }
        Iterator<String> replacement = reordered.iterator();
        for (String url : existing)
            result.add(selected.contains(url) ? replacement.next() : url);
        return result;
    }
}
