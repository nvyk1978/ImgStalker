package com.cmyk.imgstalker;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import java.io.File;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Navigation-only inventory of files that STILL EXIST in the user's save folders.
 *
 * This is deliberately independent of the saved-success ledgers: old SNS ledgers only
 * hold opaque media keys and cannot reliably identify either a media type or a file
 * which the user later deleted. No crawler, download callback or green-check state is
 * modified by these lookups. Run from the navigation IO executor, never the UI thread.
 */
final class NavigationSavedFileInventory {
    static final class Counts {
        final Integer images; // null = cannot inspect, NOT zero
        final Integer videos;
        Counts(Integer images, Integer videos) { this.images = images; this.videos = videos; }
    }

    private static final class MediaBase {
        final String volume, relative;
        MediaBase(String volume, String relative) { this.volume = volume; this.relative = relative; }
    }

    private static final class Files {
        final Set<String> imagePaths = new HashSet<>();
        final Set<String> videoPaths = new HashSet<>();
        boolean imagesKnown, videosKnown;
    }

    private NavigationSavedFileInventory() { }

    static Counts forUrl(Context context, String url) {
        if (context == null) return new Counts(null, null);
        String folder = folderForUrl(url);
        if (folder.isEmpty()) return new Counts(null, null);
        try {
            Files found = new Files();
            // SAF lists the actual DocumentsProvider contents even when MediaStore cannot
            // see them. The same path+filename key merges the two views without double counting.
            if (SavePrefs.hasTreeAccess(context)) readSaf(context, folder, found);

            MediaBase selected = mediaBase(context, SavePrefs.directory(context));
            if (selected != null) {
                queryMedia(context, selected.volume,
                        append(append(selected.relative, folder), ""), true, found);
                queryMedia(context, selected.volume,
                        append(append(selected.relative, folder), "videos"), false, found);
            }

            // The three downloaders fall back here for videos if the selected Pictures
            // tree cannot be used via SAF. This is not underneath SavePrefs.directory().
            MediaBase fallback = mediaBase(context, new File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "ImgStalker"));
            if (fallback != null) {
                String videoPath = append(append(fallback.relative, folder), "videos");
                if (selected == null || !selected.volume.equals(fallback.volume)
                        || !videoPath.equalsIgnoreCase(append(append(selected.relative, folder), "videos"))) {
                    queryMedia(context, fallback.volume, videoPath, false, found);
                }
            }
            DiagnosticLog.log("NAVIGATION_FILE_INVENTORY folder=" + folder
                    + " images=" + (found.imagesKnown ? found.imagePaths.size() : "unknown")
                    + " videos=" + (found.videosKnown ? found.videoPaths.size() : "unknown"));
            return new Counts(found.imagesKnown ? found.imagePaths.size() : null,
                    found.videosKnown ? found.videoPaths.size() : null);
        } catch (Throwable t) {
            DiagnosticLog.logException("NAVIGATION_FILE_INVENTORY_FAIL folder=" + folder, t);
            return new Counts(null, null);
        }
    }

    /** Pure URL-to-folder mapping: match the existing downloader folder, never the CDN host. */
    static String folderForUrl(String url) {
        SnsResumeStore.Target target = SnsResumeStore.targetForUrl(url);
        if (target != null) return target.relativeFolder();
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.NORMAL) return "";
        return NormalSiteFolder.forPage(url);
    }

    private static String append(String left, String right) {
        String a = left == null ? "" : left.replace('\\', '/').replaceAll("^/+|/+$", "");
        String b = right == null ? "" : right.replace('\\', '/').replaceAll("^/+|/+$", "");
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        return a + "/" + b;
    }

    private static String directoryPath(String relative) { return relative + "/"; }

    private static String pathKey(String directory, String name) {
        return append(directory, name).toLowerCase(Locale.ROOT);
    }

    /** Android 10+ MediaStore paths must be relative to their own storage volume. */
    private static MediaBase mediaBase(Context context, File directory) {
        if (directory == null) return null;
        try {
            File primary = Environment.getExternalStorageDirectory();
            String rel = within(primary, directory);
            if (rel != null) return new MediaBase(MediaStore.VOLUME_EXTERNAL_PRIMARY, rel);
            StorageManager sm = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
            if (sm != null) for (StorageVolume volume : sm.getStorageVolumes()) {
                if (volume.getDirectory() == null || volume.getMediaStoreVolumeName() == null) continue;
                rel = within(volume.getDirectory(), directory);
                if (rel != null) return new MediaBase(volume.getMediaStoreVolumeName(), rel);
            }
        } catch (Throwable t) {
            DiagnosticLog.logException("NAVIGATION_FILE_VOLUME_FAIL", t);
        }
        return null;
    }

    private static String within(File root, File file) throws Exception {
        String a = root.getCanonicalPath();
        String b = file.getCanonicalPath();
        if (a.equals(b)) return "";
        return b.startsWith(a + File.separator) ? b.substring(a.length() + 1).replace(File.separatorChar, '/') : null;
    }

    private static void queryMedia(Context context, String volume, String directory,
                                   boolean image, Files output) {
        String relPath = directoryPath(directory);
        Uri collection = image ? MediaStore.Images.Media.getContentUri(volume)
                : MediaStore.Video.Media.getContentUri(volume);
        String[] projection = {MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE};
        try (Cursor cursor = context.getContentResolver().query(collection, projection,
                MediaStore.MediaColumns.RELATIVE_PATH + " = ? AND "
                        + MediaStore.MediaColumns.IS_PENDING + " = 0", new String[]{relPath}, null)) {
            if (cursor == null) return; // null cannot be reported as zero
            if (image) output.imagesKnown = true; else output.videosKnown = true;
            int nameCol = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
            int sizeCol = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE);
            while (cursor.moveToNext()) {
                String name = nameCol >= 0 ? cursor.getString(nameCol) : null;
                long size = sizeCol >= 0 ? cursor.getLong(sizeCol) : -1;
                if (name == null || name.isEmpty() || size == 0) continue;
                (image ? output.imagePaths : output.videoPaths).add(pathKey(relPath, name));
            }
        } catch (Throwable t) {
            DiagnosticLog.logException("NAVIGATION_FILE_MEDIASTORE_FAIL path=" + relPath, t);
            // Keep any successful SAF or other volume results; never turn a failed query into a fake zero.
        }
    }

    private static void readSaf(Context context, String folder, Files found) {
        Uri tree = SavePrefs.treeUri(context);
        File treeBase = SavePrefs.fileFromTreeUri(tree);
        File saveBase = SavePrefs.directory(context);
        if (tree == null || treeBase == null || saveBase == null) return;
        try {
            String relative = within(treeBase, saveBase);
            if (relative == null) return; // grant does not cover this save destination
            ContentResolver resolver = context.getContentResolver();
            Uri root = DocumentsContract.buildDocumentUriUsingTree(tree,
                    DocumentsContract.getTreeDocumentId(tree));
            Uri mediaDir = findDirectory(resolver, tree, root, append(relative, folder));
            // A missing directory is known empty if its parent could be inspected.
            if (mediaDir == null) return;
            String rootRelative = append(append(relativePathInsideVolume(treeBase), relative), folder);
            readSafFiles(resolver, tree, mediaDir, rootRelative, true, found);
            Uri videoDir = findDirectory(resolver, tree, mediaDir, "videos");
            if (videoDir != null)
                readSafFiles(resolver, tree, videoDir, append(rootRelative, "videos"), false, found);
        } catch (Throwable t) {
            DiagnosticLog.logException("NAVIGATION_FILE_SAF_FAIL folder=" + folder, t);
        }
    }

    // SAF parent names can be based on primary or removable volume; only use this for
    // comparison with the MediaStore relative path, not for resolving an absolute path.
    private static String relativePathInsideVolume(File root) {
        try {
            String path = root.getCanonicalPath();
            String primary = Environment.getExternalStorageDirectory().getCanonicalPath();
            if (path.equals(primary)) return "";
            if (path.startsWith(primary + File.separator)) return path.substring(primary.length() + 1);
            int colon = path.indexOf("/storage/");
            if (colon >= 0) {
                int slash = path.indexOf('/', colon + 9);
                return slash >= 0 ? path.substring(slash + 1) : "";
            }
        } catch (Exception ignored) { }
        return "";
    }

    private static Uri findDirectory(ContentResolver resolver, Uri tree, Uri parent, String relative)
            throws Exception {
        Uri current = parent;
        if (relative.isEmpty()) return current;
        for (String part : relative.split("/")) {
            if (part.isEmpty()) continue;
            Uri next = null;
            try (Cursor cursor = resolver.query(children(tree, current), new String[]{
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID}, null, null, null)) {
                if (cursor == null) return null;
                int name = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int mime = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                int id = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                while (cursor.moveToNext()) {
                    if (name >= 0 && part.equalsIgnoreCase(cursor.getString(name)) && mime >= 0
                            && DocumentsContract.Document.MIME_TYPE_DIR.equals(cursor.getString(mime)) && id >= 0) {
                        next = DocumentsContract.buildDocumentUriUsingTree(tree, cursor.getString(id));
                        break;
                    }
                }
            }
            if (next == null) return null;
            current = next;
        }
        return current;
    }

    private static Uri children(Uri tree, Uri parent) {
        return DocumentsContract.buildChildDocumentsUriUsingTree(tree,
                DocumentsContract.getDocumentId(parent));
    }

    private static void readSafFiles(ContentResolver resolver, Uri tree, Uri directory,
                                     String relative, boolean images, Files result) throws Exception {
        String[] projection = {DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE};
        try (Cursor cursor = resolver.query(children(tree, directory), projection, null, null, null)) {
            if (cursor == null) return;
            if (images) result.imagesKnown = true; else result.videosKnown = true;
            int name = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mime = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
            int size = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);
            while (cursor.moveToNext()) {
                String filename = name < 0 ? null : cursor.getString(name);
                String mimeType = mime < 0 ? "" : cursor.getString(mime);
                long bytes = size < 0 || cursor.isNull(size) ? -1 : cursor.getLong(size);
                if (filename == null || filename.isEmpty() || bytes == 0) continue;
                if (matchesMedia(filename, mimeType, images))
                    (images ? result.imagePaths : result.videoPaths).add(pathKey(relative, filename));
            }
        }
    }

    static boolean matchesMedia(String name, String mime, boolean image) {
        if (name == null || DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) return false;
        String n = name.toLowerCase(Locale.ROOT);
        String type = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (image) return type.startsWith("image/") || n.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|heic|heif|avif|tif|tiff|svg)$");
        return type.startsWith("video/") || n.matches(".*\\.(mp4|m4v|mov|webm|mkv|avi|3gp|ts|mpeg|mpg)$");
    }
}
