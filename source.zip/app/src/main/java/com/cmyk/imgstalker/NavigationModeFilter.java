package com.cmyk.imgstalker;

/** Navigation-list display selection only; never switches or creates a crawler engine. */
final class NavigationModeFilter {
    private NavigationModeFilter() { }

    /** null denotes all modes. Tapping the selected mode clears the filter. */
    static AnalysisModeRouter.Mode next(AnalysisModeRouter.Mode active, AnalysisModeRouter.Mode tapped) {
        return active == tapped ? null : tapped;
    }

    static boolean matches(AnalysisModeRouter.Mode active, AnalysisModeRouter.Mode candidate) {
        return active == null || active == candidate;
    }

    static boolean matchesUrl(AnalysisModeRouter.Mode active, String url) {
        return matches(active, AnalysisModeRouter.fromUrl(url));
    }
}
