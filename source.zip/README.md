# ImgStalker v0.1.73 (74)

## Base
- Functional base: v0.1.72 (73).
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.

## Instagram CDN URL-hash fix
- Resolver candidates from Instagram post HTML are no longer accepted merely because they look like valid fbcdn/cdninstagram media URLs.
- IMAGE/VIDEO candidates on Meta CDN must include the expiring `oh` and `oe` hash parameters before the resolver may complete the post.
- A candidate missing either hash is treated as incomplete and immediately enters the existing browser/WebView fallback for that same post.
- The browser fallback continues to read post media from the live DOM/current WebView session, where Instagram supplies the complete signed CDN URL actually used by the page.
- This targets the v0.1.72 failure where direct thumbnail/video requests returned HTTP 403 with a 12-byte text response while the visible Instagram page itself could display the media.

## Ordered inline fallback
- The profile is still processed in order, one post at a time.
- An invalid/partial resolver URL does not get queued as finished media and discovery does not advance past that post.
- Browser fallback is completed for the current post before the next profile post is selected.
- Existing inline retry behavior remains: one browser retry after profile restoration, then skip and continue if the same post still cannot be resolved.

## Preserved behavior
- Reel completion still requires playable video/stream media.
- Regular `/p/` posts are not rejected solely because `videoHint` is present.
- Carousel-hinted resolver results with fewer than two candidates still use browser fallback.
- Reel/video cover JPEGs remain excluded as standalone IMAGE results.
- Video thumbnails still use bounded local MP4 download followed by local frame extraction.
- Completed/discovered post URLs and profile-order display ordering remain unchanged.

## Diagnostics
- `SNS_IG_RESOLVER_SIGNATURE_FALLBACK`: resolver returned an IMAGE/VIDEO CDN URL missing Meta `oh`/`oe` hash parameters, so the post is handed to browser fallback instead of emitting the broken URL.
- Existing `SNS_IG_RESOLVER_INLINE_FALLBACK`, `SNS_IG_STREAM_RETRY_INLINE`, `THUMB_HTTP`, and `VIDEO_THUMB_HTTP` diagnostics remain.

## Package
- versionCode: 74
- versionName: 0.1.73
