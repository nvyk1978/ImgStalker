package com.cmyk.imgstalker;

public final class InstagramRecoveryPolicyTest {
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        check(InstagramRecoveryPolicy.sourceNeedsBrowser(0, 0, 0, 0), "redirect/fatal empty");
        check(InstagramRecoveryPolicy.sourceNeedsBrowser(100, 0, 0, 0), "discovery without media");
        check(InstagramRecoveryPolicy.sourceNeedsBrowser(100, 99, 1, 99), "skipped posts");
        check(InstagramRecoveryPolicy.sourceNeedsBrowser(100, 100, 0, 0), "no emitted media");
        check(!InstagramRecoveryPolicy.sourceNeedsBrowser(100, 100, 0, 102), "all resolved");
        check(InstagramRecoveryPolicy.mayReloadGrid(true, 1, 2), "one retry remaining");
        check(!InstagramRecoveryPolicy.mayReloadGrid(true, 2, 2), "bounded retry");
        check(!InstagramRecoveryPolicy.mayReloadGrid(false, 0, 2), "already complete");
        check("login".equals(InstagramRecoveryPolicy.authGateType("https://www.instagram.com/accounts/login/?next=%2F")), "login");
        check("challenge".equals(InstagramRecoveryPolicy.authGateType("https://instagram.com/challenge/")), "challenge");
        check("suspended".equals(InstagramRecoveryPolicy.authGateType("https://m.instagram.com/accounts/suspended/")), "suspended");
        check("none".equals(InstagramRecoveryPolicy.authGateType("https://www.instagram.com/p/ABC/")), "post allowed");
        check("none".equals(InstagramRecoveryPolicy.authGateType("https://evilinstagram.com/accounts/login")), "lookalike rejected");
        check("none".equals(InstagramRecoveryPolicy.authGateType("https://x.com/accounts/login")), "X unaffected");
        check("none".equals(InstagramRecoveryPolicy.authGateType("https://example.org/instagram.com/accounts/login")), "NORMAL unaffected");
        System.out.println("PASS: 15 Instagram-only recovery policy cases");
    }
}
