# ImgStalker v0.1.66 (67)

## Base
- Functional base: v0.1.65 (66).
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.

## Instagram streaming traversal
- Instagram profile traversal remains progressive: open one post, emit its media immediately, then continue.
- The readiness-discovered post order is retained and used as a fallback queue, so posts already known from the profile DOM are not abandoned just because the visible-cell scan reaches a bottom stall.
- Post open timeout is 15 seconds. One native fallback tap is used after the DOM-anchor click path; a wrong/non-opening post is then deferred instead of blocking the current pass.
- Empty image/video readiness polling is extended to 15 seconds before the post is treated as failed.

## Deferred failure recovery
- A post that fails on the first pass is added to a deferred retry queue and traversal immediately continues with later posts.
- After the normal profile pass finishes, only deferred failures are retried.
- If the deferred retry also fails, that post is recorded as a final acquisition failure and the whole run is still allowed to finish rather than showing a continuation requirement solely for that exhausted failure.
- Final acquisition failures are shown in the completion status as `取得失敗 N件`.

## Stable result order
- Each Instagram post receives a stable profile-order index when first discovered.
- Emitted media carry a display-order value derived from post order plus per-post media order.
- Result cells are inserted by that display order, so a post recovered later is inserted back at its original profile position instead of being appended to the end.

## Floating debug browser
- The crawler WebView keeps its full logical mobile viewport for Instagram behavior, while its visible rendering is scaled to 30%.
- The debug browser floats above the media-cell grid instead of consuming vertical layout space.
- Default position is bottom-left, directly above the bottom selection controls.
- User input remains blocked from reaching Instagram. Long-press and drag moves the floating debug window; movement is clamped inside the media grid.

## Retained behavior
- Existing carousel traversal, image URL normalization, duplicate suppression, target-size filtering, Reel/network video capture, cover-frame exclusion, background foreground-service/WakeLock support, diagnostics and signing remain in place.

## Package
- versionCode: 67
- versionName: 0.1.66
