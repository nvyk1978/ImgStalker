package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Navigation artwork only. No crawler WebView, login cookies or provider session access. */
final class NavigationIconLoader {
    private static final int MAX_BYTES = 1_500_000;
    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> memory = new LruCache<>(64);
    private final Set<String> inProgress = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Map<String, Long> failed = new ConcurrentHashMap<>();
    private final Map<String, ArrayList<ImageView>> listeners = new ConcurrentHashMap<>();
    // Weak bindings let a completed avatar update currently visible history/bookmark rows
    // without retaining detached Activity views or updating recycled row identities.
    private final Map<ImageView, String> boundViews = Collections.synchronizedMap(new WeakHashMap<>());
    private static final Pattern TAG = Pattern.compile("<(?:link|meta)\\b[^>]*>", Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR = Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");

    NavigationIconLoader(Context ctx) {
        context = ctx.getApplicationContext();
        // Earlier caches contained generic OG artwork instead of verified account photos.
        // Keep v3 strictly separate; remove obsolete icon caches asynchronously.
        try {
            io.execute(() -> {
                for (String name : new String[]{"navigation_icons", "navigation_icons_circle_v2", "navigation_icons_circle_v3"}) {
                    File obsolete = new File(context.getCacheDir(), name);
                    File[] oldFiles = obsolete.listFiles();
                    if (oldFiles != null) for (File old : oldFiles) if (old.isFile()) old.delete();
                    obsolete.delete();
                }
            });
        } catch (RuntimeException ignored) { }
    }

    static String iconIdentity(String url) {
        String normalized = SiteVisitStore.normalize(url);
        if (normalized.isEmpty()) return "";
        try {
            URI uri = URI.create(normalized);
            String host = uri.getHost();
            if (host == null) return "";
            String social = SiteVisitStore.socialHandleForUrl(normalized);
            if (!social.isEmpty()) {
                AnalysisModeRouter.Mode socialMode = AnalysisModeRouter.fromUrl(normalized);
                String canonical = socialMode == AnalysisModeRouter.Mode.INSTAGRAM ? "instagram"
                        : socialMode == AnalysisModeRouter.Mode.THREADS ? "threads" : "x";
                return canonical + ":" + social.toLowerCase(java.util.Locale.ROOT);
            }
            return uri.getScheme().toLowerCase(java.util.Locale.ROOT) + "://" + host.toLowerCase(java.util.Locale.ROOT);
        } catch (RuntimeException e) { return ""; }
    }

    void bind(ImageView view, String url) {
        String key = iconIdentity(url);
        view.setTag(key);
        if (key.isEmpty()) boundViews.remove(view);
        else boundViews.put(view, key);
        int mode = AnalysisModeRouter.fromUrl(url).ordinal();
        if (url == null || url.trim().isEmpty()) view.setImageResource(R.drawable.ic_nav_normal);
        else if (mode == AnalysisModeRouter.Mode.X.ordinal()) view.setImageResource(R.drawable.ic_nav_x);
        // A missing account photo shows the provider logo, never the generic globe.
        // This fallback is always applied before the cache lookup so it also works
        // after a prior network failure, a recreated view or an offline start.
        else if (mode == AnalysisModeRouter.Mode.INSTAGRAM.ordinal()) view.setImageResource(R.drawable.ic_nav_instagram);
        else if (mode == AnalysisModeRouter.Mode.THREADS.ordinal()) view.setImageResource(R.drawable.ic_nav_threads);
        else view.setImageResource(R.drawable.ic_nav_normal);
        if (key.isEmpty()) return;
        // Search/navigation destinations are provider branded, not account photos.
        // In particular X's /search used to share the generic domain favicon
        // cache, overriding ic_nav_x in the URL field, history and bookmarks.
        // Return before ALL cache/network lookups so stale artwork cannot win.
        if (isProviderSearchUrl(url)) return;
        Bitmap cached = memory.get(key);
        if (cached != null) { view.setImageBitmap(cached); return; }
        File file = cacheFile(key);
        if (file.isFile()) {
            Bitmap disk = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (disk != null) { memory.put(key, disk); view.setImageBitmap(disk); return; }
            file.delete();
        }
        // Instagram and Threads may only use a verified account-owner photo from
        // the authenticated profile DOM. Public OG images can be brand artwork.
        // Never cache them under a social account's persistent icon identity.
        if (mode == AnalysisModeRouter.Mode.INSTAGRAM.ordinal()
                || mode == AnalysisModeRouter.Mode.THREADS.ordinal()) return;
        long now = System.currentTimeMillis();
        Long retryAt = failed.get(key);
        if (retryAt != null && now < retryAt) return;
        synchronized (listeners) {
            ArrayList<ImageView> views = listeners.get(key);
            if (views == null) { views = new ArrayList<>(); listeners.put(key, views); }
            views.add(view);
        }
        if (!inProgress.add(key)) return;
        try {
            io.execute(() -> {
                Bitmap found = null;
                try { found = loadRemote(url); }
                catch (Throwable e) { DiagnosticLog.logException("NAVIGATION_ICON_FETCH_FAIL", e); }
                if (found != null) {
                    memory.put(key, found);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        found.compress(Bitmap.CompressFormat.PNG, 95, out);
                    } catch (Exception ignored) { }
                } else failed.put(key, System.currentTimeMillis() + 10L * 60_000L);
                final Bitmap result = found;
                main.post(() -> {
                    ArrayList<ImageView> waiters;
                    synchronized (listeners) { waiters = listeners.remove(key); }
                    inProgress.remove(key);
                    if (waiters != null && result != null) for (ImageView image : waiters) {
                        if (key.equals(image.getTag())) image.setImageBitmap(result);
                    }
                });
            });
        } catch (RuntimeException rejected) {
            inProgress.remove(key);
            synchronized (listeners) { listeners.remove(key); }
        }
    }

    static boolean isProviderSearchUrl(String url) {
        if (url == null || url.isEmpty()) return false;
        AnalysisModeRouter.Mode mode = AnalysisModeRouter.fromUrl(url);
        if (mode != AnalysisModeRouter.Mode.X && mode != AnalysisModeRouter.Mode.THREADS
                && mode != AnalysisModeRouter.Mode.INSTAGRAM) return false;
        try {
            URI uri = URI.create(SiteVisitStore.normalize(url));
            String path = uri.getPath();
            if (path == null) return false;
            if (mode == AnalysisModeRouter.Mode.INSTAGRAM)
                return path.equals("/explore/search/keyword/") || path.equals("/explore/search/keyword");
            return path.equals("/search") || path.equals("/search/");
        } catch (RuntimeException e) { return false; }
    }

    boolean hasCachedIcon(String url) {
        String key = iconIdentity(url);
        if (key.isEmpty()) return false;
        if (memory.get(key) != null) return true;
        File f = cacheFile(key);
        return f.isFile() && f.length() > 80;
    }

    private void publishProfileAvatar(String key, Bitmap found) {
        if (found == null) return;
        memory.put(key, found);
        try (FileOutputStream out = new FileOutputStream(cacheFile(key))) {
            found.compress(Bitmap.CompressFormat.PNG, 95, out);
        } catch (Exception e) { DiagnosticLog.logException("NAVIGATION_PROFILE_AVATAR_CACHE_FAIL", e); }
        failed.remove(key);
        main.post(() -> {
            synchronized (listeners) {
                ArrayList<ImageView> waiting = listeners.remove(key);
                if (waiting != null) for (ImageView image : waiting)
                    if (key.equals(image.getTag())) image.setImageBitmap(found);
            }
            synchronized (boundViews) {
                for (Map.Entry<ImageView,String> entry : boundViews.entrySet()) {
                    ImageView image = entry.getKey();
                    if (image != null && key.equals(entry.getValue()) && key.equals(image.getTag()))
                        image.setImageBitmap(found);
                }
            }
        });
    }

    /** An image decoded in the actual SNS WebView when its CDN permits canvas CORS.
     * It is only accepted for the same trusted profile URL and trusted image host. */
    void offerProfileAvatarData(String profileUrl, String avatarUrl, String dataUri) {
        String key = iconIdentity(profileUrl);
        if (!trustedAvatar(profileUrl, avatarUrl) || key.isEmpty() || dataUri == null
                || dataUri.length() > 350_000 || !dataUri.startsWith("data:image/png;base64,")) return;
        if (hasCachedIcon(profileUrl)) return;
        try {
            byte[] bytes = Base64.getDecoder().decode(dataUri.substring("data:image/png;base64,".length()));
            if (bytes.length == 0 || bytes.length > 260_000) return;
            Bitmap image = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (image == null) return;
            Bitmap round = circleCrop(image);
            image.recycle();
            publishProfileAvatar(key, round);
            DiagnosticLog.log("NAVIGATION_PROFILE_AVATAR_WEBVIEW_OK key=" + key);
        } catch (Exception e) { DiagnosticLog.logException("NAVIGATION_PROFILE_AVATAR_WEBVIEW_DECODE_FAIL", e); }
    }

    private static boolean trustedAvatar(String profileUrl, String avatarUrl) {
        AnalysisModeRouter.Mode mode = AnalysisModeRouter.fromUrl(profileUrl);
        if ((mode != AnalysisModeRouter.Mode.INSTAGRAM && mode != AnalysisModeRouter.Mode.THREADS)
                || SiteVisitStore.socialHandleForUrl(profileUrl).isEmpty()
                || avatarUrl == null || !avatarUrl.startsWith("https://")) return false;
        try {
            URI avatar = URI.create(avatarUrl);
            String host = avatar.getHost();
            return host != null && (host.endsWith(".cdninstagram.com") || host.equals("cdninstagram.com")
                    || host.endsWith(".fbcdn.net") || host.equals("fbcdn.net")
                    || host.endsWith(".instagram.com") || host.equals("instagram.com")
                    || host.endsWith(".threads.net") || host.equals("threads.net")
                    || host.endsWith(".threads.com") || host.equals("threads.com"));
        } catch (Exception e) { return false; }
    }

    /** A profile-header image observed in the actual Instagram/Threads WebView.
     * Do not treat a navigation/favicon image or a post author's image as an avatar. */
    void offerProfileAvatar(String profileUrl, String avatarUrl) {
        if (!trustedAvatar(profileUrl, avatarUrl) || hasCachedIcon(profileUrl)) return;
        String key = iconIdentity(profileUrl);
        if (!inProgress.add(key)) {
            // A public-page preview request may still be running; retry the actual avatar.
            main.postDelayed(() -> offerProfileAvatar(profileUrl, avatarUrl), 3500L);
            return;
        }
        try { io.execute(() -> {
            String referer = AnalysisModeRouter.fromUrl(profileUrl) == AnalysisModeRouter.Mode.THREADS
                    ? "https://www.threads.com/" : "https://www.instagram.com/";
            Bitmap found = downloadBitmap(avatarUrl, referer);
            if (found != null) {
                publishProfileAvatar(key, found);
                DiagnosticLog.log("NAVIGATION_PROFILE_AVATAR_OK key=" + key);
            } else DiagnosticLog.log("NAVIGATION_PROFILE_AVATAR_DOWNLOAD_FAILED key=" + key);
            main.post(() -> inProgress.remove(key));
        }); } catch (RuntimeException e) { inProgress.remove(key); }
    }

    private Bitmap loadRemote(String url) throws Exception {
        URI original = URI.create(url);
        String host = original.getHost();
        if (host == null) return null;
        boolean social = !SiteVisitStore.socialHandleForUrl(url).isEmpty();
        String origin = original.getScheme() + "://" + host;
        // Threads requires the @ prefix; Instagram and X use bare handles.
        String handle = SiteVisitStore.socialHandleForUrl(url);
        String page = social ? origin + "/" +
                (AnalysisModeRouter.fromUrl(url) == AnalysisModeRouter.Mode.THREADS ? handle : handle.substring(1)) + "/" : origin + "/";
        String html = downloadText(page);
        if (html != null) {
            String meta = social ? findProfileImage(html) : null;
            if (meta == null) meta = findMetaImage(html, social);
            if (meta != null) {
                Bitmap bitmap = downloadBitmap(resolve(page, meta));
                if (bitmap != null) return bitmap;
            }
        }
        // An account icon must be the account's own photo, never Instagram/Threads site branding.
        if (social) return null;
        for (String candidate : new String[]{origin + "/apple-touch-icon.png", origin + "/favicon.png", origin + "/favicon.ico"}) {
            Bitmap bitmap = downloadBitmap(candidate);
            if (bitmap != null) return bitmap;
        }
        return null;
    }

    static String findProfileImage(String html) {
        if (html == null) return null;
        // JSON-LD/embedded server state can expose the profile photo even if OG
        // tags only show platform branding. The WebView observer remains preferred.
        Pattern p = Pattern.compile("\"(?:profile_pic_url_hd|profile_pic_url|profilePictureUrl|profile_picture_url|avatar_url)\"\\s*:\\s*\"([^\"]+)\"");
        Matcher m = p.matcher(html);
        while (m.find()) {
            String candidate = m.group(1).replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&");
            if (candidate.startsWith("https://") && !candidate.contains("/static/")) return candidate;
        }
        return null;
    }

    static String findMetaImage(String html, boolean social) {
        if (html == null) return null;
        Matcher tags = TAG.matcher(html);
        String favicon = null;
        while (tags.find()) {
            String tag = tags.group();
            java.util.HashMap<String, String> a = new java.util.HashMap<>();
            Matcher attrs = ATTR.matcher(tag);
            while (attrs.find()) {
                String value = attrs.group(2) != null ? attrs.group(2) : attrs.group(3) != null ? attrs.group(3) : attrs.group(4);
                a.put(attrs.group(1).toLowerCase(java.util.Locale.ROOT), value);
            }
            String rel = a.get("rel");
            String property = a.containsKey("property") ? a.get("property") : a.get("name");
            if (social && property != null && (property.equalsIgnoreCase("og:image") || property.equalsIgnoreCase("twitter:image"))) {
                String content = a.get("content");
                if (content != null && !content.isEmpty()) return unescape(content);
            }
            if (rel != null && rel.toLowerCase(java.util.Locale.ROOT).contains("icon") && favicon == null)
                favicon = unescape(a.get("href"));
        }
        // A social-account icon cannot silently degrade to a site favicon/logo.
        return social ? null : favicon;
    }

    private static String unescape(String s) { return s == null ? null : s.replace("&amp;", "&").replace("&#38;", "&"); }
    private static String resolve(String base, String value) {
        try {
            URI u = URI.create(base).resolve(value);
            if (!"https".equalsIgnoreCase(u.getScheme()) && !"http".equalsIgnoreCase(u.getScheme())) return null;
            return u.toString();
        } catch (Exception ignored) { return null; }
    }

    private String downloadText(String url) {
        try {
            byte[] data = get(url, 2_500_000, "text/html");
            return data == null ? null : new String(data, StandardCharsets.UTF_8);
        } catch (Exception ignored) { return null; }
    }
    private Bitmap downloadBitmap(String url) { return downloadBitmap(url, null); }
    private Bitmap downloadBitmap(String url, String referer) {
        try {
            byte[] data = get(url, MAX_BYTES, "image/*", referer);
            if (data == null) return null;
            // Decode large images down to a modest working size before cropping.
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            while (Math.max(bounds.outWidth / options.inSampleSize,
                    bounds.outHeight / options.inSampleSize) > 256) options.inSampleSize *= 2;
            Bitmap source = BitmapFactory.decodeByteArray(data, 0, data.length, options);
            if (source == null) return null; // Unsupported ICO or invalid image.
            try { return circleCrop(source); }
            finally { source.recycle(); }
        } catch (Exception failure) {
            if (referer != null) DiagnosticLog.log("NAVIGATION_PROFILE_AVATAR_FETCH_ERROR type="
                    + failure.getClass().getSimpleName());
            return null;
        }
    }
    /** Aspect-preserving center crop into a transparent circular bitmap (never stretches). */
    static Bitmap circleCrop(Bitmap source) {
        final int size = 96;
        Bitmap result = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Path circle = new Path();
        circle.addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW);
        canvas.clipPath(circle);
        float sw = source.getWidth(), sh = source.getHeight();
        float crop = Math.min(sw, sh);
        Rect src = new Rect(Math.round((sw - crop) / 2f), Math.round((sh - crop) / 2f),
                Math.round((sw + crop) / 2f), Math.round((sh + crop) / 2f));
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmap(source, src, new RectF(0, 0, size, size), paint);
        return result;
    }

    private static byte[] get(String source, int cap, String accept) throws Exception {
        return get(source, cap, accept, null);
    }
    private static byte[] get(String source, int cap, String accept, String originReferer) throws Exception {
        if (source == null) return null;
        URL url = new URL(source);
        if (!"https".equalsIgnoreCase(url.getProtocol()) && !"http".equalsIgnoreCase(url.getProtocol())) return null;
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(4000);
        connection.setReadTimeout(4500);
        connection.setRequestProperty("Accept", accept);
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36");
        // Some image CDNs reject otherwise public profile pictures without a
        // source-page referer. Do not forward login cookies to third-party hosts.
        if (originReferer != null) connection.setRequestProperty("Referer", originReferer);
        else if (url.getHost() != null && (url.getHost().endsWith(".fbcdn.net")
                || url.getHost().endsWith(".cdninstagram.com")))
            connection.setRequestProperty("Referer", "https://www.instagram.com/");
        connection.setInstanceFollowRedirects(true);
        try {
            int responseCode = connection.getResponseCode();
            if (responseCode != 200 || connection.getContentLengthLong() > cap) {
                if (originReferer != null) DiagnosticLog.log("NAVIGATION_PROFILE_AVATAR_HTTP_FAIL host="
                        + url.getHost() + " status=" + responseCode);
                return null;
            }
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int n;
                while ((n = input.read(buffer)) != -1) {
                    if (out.size() + n > cap) return null;
                    out.write(buffer, 0, n);
                }
                return out.toByteArray();
            }
        } finally { connection.disconnect(); }
    }

    private File cacheFile(String key) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(key.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : hash) out.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
            File root = new File(context.getCacheDir(), "navigation_icons_circle_v4");
            if (!root.exists()) root.mkdirs();
            return new File(root, out + ".png");
        } catch (Exception e) { return new File(context.getCacheDir(), "nav_icon_failure.png"); }
    }

    void shutdown() { io.shutdownNow(); }
}
