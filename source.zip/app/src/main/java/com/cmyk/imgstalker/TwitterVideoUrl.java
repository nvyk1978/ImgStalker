package com.cmyk.imgstalker;

import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Compatibility helpers for X/Twitter CDN video URLs.
 *
 * Some video.twimg.com MP4 variants currently return HTTP 403 when the legacy
 * `tag` query parameter is present, while the same asset path remains usable
 * without that parameter. Keep the discovered/original URL untouched for
 * identity/dedup purposes and only derive a transport fallback URL when needed.
 */
public final class TwitterVideoUrl {
    private static final ConcurrentHashMap<String, String> RECOVERED = new ConcurrentHashMap<>();

    private TwitterVideoUrl() {}

    /** Reuse a transport URL that already recovered successfully during this app process. */
    public static String resolvedOrOriginal(String raw) {
        if (raw == null) return null;
        String recovered = RECOVERED.get(raw);
        return recovered == null || recovered.isEmpty() ? raw : recovered;
    }

    public static void markRecovered(String original, String recovered) {
        if (original == null || recovered == null || original.equals(recovered)) return;
        RECOVERED.put(original, recovered);
    }

    public static boolean isTwitterVideoMp4(String raw) {
        if (raw == null || raw.trim().isEmpty()) return false;
        try {
            URL url = new URL(raw);
            String host = url.getHost() == null ? "" : url.getHost().toLowerCase(Locale.ROOT);
            String path = url.getPath() == null ? "" : url.getPath().toLowerCase(Locale.ROOT);
            return (host.equals("video.twimg.com") || host.endsWith(".video.twimg.com"))
                    && path.endsWith(".mp4");
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Return the same URL unless it is a video.twimg.com MP4 carrying a tag query parameter. */
    public static String stripTag(String raw) {
        if (!isTwitterVideoMp4(raw)) return raw;
        int hash = raw.indexOf('#');
        String fragment = hash >= 0 ? raw.substring(hash) : "";
        String base = hash >= 0 ? raw.substring(0, hash) : raw;
        int q = base.indexOf('?');
        if (q < 0 || q == base.length() - 1) return raw;

        String prefix = base.substring(0, q);
        String query = base.substring(q + 1);
        String[] parts = query.split("&", -1);
        List<String> kept = new ArrayList<>(parts.length);
        boolean removed = false;
        for (String part : parts) {
            int eq = part.indexOf('=');
            String encodedName = eq >= 0 ? part.substring(0, eq) : part;
            String name = encodedName;
            try { name = URLDecoder.decode(encodedName, StandardCharsets.UTF_8.name()); }
            catch (Exception ignored) {}
            if ("tag".equalsIgnoreCase(name)) {
                removed = true;
                continue;
            }
            kept.add(part);
        }
        if (!removed) return raw;
        StringBuilder out = new StringBuilder(prefix);
        if (!kept.isEmpty()) out.append('?').append(String.join("&", kept));
        out.append(fragment);
        return out.toString();
    }
}
