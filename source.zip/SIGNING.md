# ImgStalker signing key

This private-use project intentionally includes a stable local signing key so APK updates keep the same signature across GitHub Actions runs.

- Alias: imgstalker
- Store/key password: ImgStalkerLocalKey2026
- Keystore: keystore/imgstalker.jks

Do not regenerate the keystore for future versions if overwrite installation must continue to work.
