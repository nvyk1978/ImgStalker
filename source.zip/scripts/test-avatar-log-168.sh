#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node tests/sns_avatar_probe_test.cjs
python3 - <<'PY'
from pathlib import Path
src=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
icons=Path('app/src/main/java/com/cmyk/imgstalker/NavigationIconLoader.java').read_text()
assert 'LOG_RESET_BEFORE_PAGE_LOAD' in src
assert src.count('DiagnosticLog.clear();') == 2 # new analysis and manual clear button
reset=src.index('DiagnosticLog.log("LOG_RESET_BEFORE_PAGE_LOAD')
assert src.index('if (!restoringInterruptedAnalysis)') < reset < src.index('crawler.start(url,')
assert 'startAnalysis(true);' in src
assert 'LOG_PRESERVED_ACTIVITY_RESTORE' in src
assert 'navigationIconHandler.postDelayed(snsAvatarProbeTick' in src
assert 'offerProfileAvatarData' in src and 'offerProfileAvatarData' in icons
assert 'WeakHashMap' in icons and 'boundViews.put(view, key)' in icons
assert 'navigation_icons_circle_v4' in icons
assert 'if (mode == AnalysisModeRouter.Mode.INSTAGRAM.ordinal()' in icons
assert 'hasCachedIcon' in icons and 'publishProfileAvatar' in icons
print('PASS: avatar polling, weak live bindings, brand fallback when no account photo; diagnostic once before load, restore preserves')
PY
bash scripts/test-navigation-android-stubs.sh
