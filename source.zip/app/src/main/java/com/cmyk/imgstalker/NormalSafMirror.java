package com.cmyk.imgstalker;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** NORMAL-only SAF sidecar under the user's save directory /Normal/<host>/<target>.json. */
final class NormalSafMirror {
    private NormalSafMirror() { }
    private static final String DIR_MIME = DocumentsContract.Document.MIME_TYPE_DIR;
    private static Uri tree(Context c) {
        return SavePrefs.hasTreeAccess(c) ? SavePrefs.treeUri(c) : null;
    }

    private static Uri child(ContentResolver resolver, Uri tree, Uri parent, String name) {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parent));
        try (Cursor cursor = resolver.query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME},
                null, null, null)) {
            if (cursor == null) return null;
            while (cursor.moveToNext()) {
                if (name.equals(cursor.getString(1)))
                    return DocumentsContract.buildDocumentUriUsingTree(tree, cursor.getString(0));
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Uri folder(Context c, Uri tree, String url, boolean create) throws Exception {
        ContentResolver resolver = c.getContentResolver();
        Uri dir = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
        String host = NormalCheckpointStore.checkpoint(c, url).getParentFile().getName();
        for (String segment : new String[]{"Normal", host}) {
            Uri next = child(resolver, tree, dir, segment);
            if (next == null && create) next = DocumentsContract.createDocument(resolver, dir, DIR_MIME, segment);
            if (next == null) return null;
            dir = next;
        }
        return dir;
    }
    static void write(Context c, String url, byte[] bytes) {
        Uri tree = tree(c);
        if (tree == null || bytes == null) return;
        try {
            ContentResolver resolver = c.getContentResolver();
            Uri dir = folder(c, tree, url, true);
            if (dir == null) return;
            String name = NormalCheckpointStore.checkpoint(c, url).getName();
            Uri tmp = child(resolver, tree, dir, name + ".tmp");
            if (tmp != null) DocumentsContract.deleteDocument(resolver, tmp);
            tmp = DocumentsContract.createDocument(resolver, dir, "application/json", name + ".tmp");
            if (tmp == null) return;
            try (OutputStream out = resolver.openOutputStream(tmp, "wt")) {
                if (out == null) throw new IllegalStateException("Missing output stream");
                out.write(bytes);
                out.flush();
            }
            Uri old = child(resolver, tree, dir, name);
            if (old != null) DocumentsContract.deleteDocument(resolver, old);
            Uri renamed = null;
            try { renamed = DocumentsContract.renameDocument(resolver, tmp, name); }
            catch (Throwable ignored) { /* Provider may not support rename. */ }
            if (renamed == null) {
                Uri dest = DocumentsContract.createDocument(resolver, dir, "application/json", name);
                if (dest == null) throw new IllegalStateException("Failed to commit JSON");
                try (OutputStream out = resolver.openOutputStream(dest, "wt")) {
                    if (out == null) throw new IllegalStateException("Missing JSON output");
                    out.write(bytes);
                }
                DocumentsContract.deleteDocument(resolver, tmp);
            }
            DiagnosticLog.log("NORMAL_SAF_CHECKPOINT_WRITE host=" + dir + " file=" + name);
        } catch (Throwable t) { DiagnosticLog.logException("NORMAL_SAF_CHECKPOINT_WRITE_FAIL", t); }
    }
    static byte[] read(Context c, String url) {
        Uri tree = tree(c);
        if (tree == null) return null;
        try {
            Uri dir = folder(c, tree, url, false);
            if (dir == null) return null;
            ContentResolver resolver = c.getContentResolver();
            String name = NormalCheckpointStore.checkpoint(c, url).getName();
            Uri target = child(resolver, tree, dir, name);
            if (target == null) target = child(resolver, tree, dir, name + ".tmp");
            if (target == null) return null;
            try (InputStream in = resolver.openInputStream(target)) {
                if (in == null) return null;
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] b = new byte[8192]; int n;
                while ((n = in.read(b)) != -1) out.write(b, 0, n);
                DiagnosticLog.log("NORMAL_SAF_CHECKPOINT_LOAD url=" + url);
                return out.toByteArray();
            }
        } catch (Throwable t) { DiagnosticLog.logException("NORMAL_SAF_CHECKPOINT_LOAD_FAIL", t); return null; }
    }
    static void delete(Context c, String url) {
        Uri tree = tree(c);
        if (tree == null) return;
        try {
            Uri dir = folder(c, tree, url, false);
            if (dir == null) return;
            String name = NormalCheckpointStore.checkpoint(c, url).getName();
            ContentResolver resolver = c.getContentResolver();
            for (String file : new String[]{name, name + ".tmp"}) {
                Uri target = child(resolver, tree, dir, file);
                if (target != null) DocumentsContract.deleteDocument(resolver, target);
            }
            DiagnosticLog.log("NORMAL_SAF_CHECKPOINT_DELETE url=" + url);
        } catch (Throwable t) { DiagnosticLog.logException("NORMAL_SAF_CHECKPOINT_DELETE_FAIL", t); }
    }
}
