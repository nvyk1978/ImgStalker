# ImgStalker v0.1.132 (133)

## Cache clearing and retained-worker recovery
- Replaces the red force-stop button with キャッシュ削除. Aligned at the bottom of the background toggle row.
- Disabled during this Activity's analysis/download and when no disposable cache exists. The exception is an Activity blocked by another retained background owner: the button remains available as a recovery action.
- Retained worker is stopped, detached and its queued writes drained, then the current URL's external SNS sidecar JSON, matching private checkpoint, thumbnail/WebView caches and app temp files are cleared without deleting downloaded media or login cookies.
- Cache operation diagnostics: CACHE_CLEAR_BEGIN / CACHE_CLEAR_RESULT; cache availability is probed in a background executor.
- APK name and signing key retained from v0.1.131; versionCode 133.

# ImgStalker v0.1.131 (132)

## v0.1.131 — X image partial completion must not block video discovery
- When image search stops at an unverified boundary, retain the image window as incomplete and continue to the separately requested X video search. Do not label the image set fully collected.
- Retry pending X image probes with a bounded drain interval; unresolved probes are checkpointed for later continuation, not treated as successful images.
- On a completed partial run, the saved crawler cursor targets the unfinished image window, with the previously discovered image/status sets retained for deduplication.
- Persist incomplete reasons and deferred image search cursors through process restart and lifecycle changes.
- Preserve fixed signing, package ID, and normal-site/Instagram logic.

# ImgStalker v0.1.128 (129)

Android 16 / SDK 36 source package for ImgStalker.

## v0.1.128 — shared background and analysis resume recovery
- Adds an internal atomic checkpoint for all analysis URLs and media types. The existing per-account X/Instagram external sidecar stays unchanged.
- Checkpoints include selected analysis options, discovered media, queued/active pages, X image/video phase, deferred detail URLs, pending image probes and visited URLs.
- After a process restart, incomplete recent checkpoints are re-opened using the ordinary crawler rather than a separate background parser. Activity recreation resumes analysis as well.
- The foreground-service heartbeat now records the actual crawler state and checkpoints it every 15 seconds; an Activity reopened during retained work shows the live worker results instead of launching a duplicate scan.
- The ordinary web/X crawler keeps a renderer-attached WebView when background processing is on, attempts bounded stall recovery, and preserves incomplete state instead of reporting a stalled phase as complete.
- The background toggle asks the OS for battery-optimization exemption when needed; the user may decline.
- Completed Instagram source-pipeline/media-resolver/SNS account/parser implementations are unchanged. Their existing account-level resume path is preserved.
- Limitations: Android may terminate the app or foreground service. Restarting requires an intact checkpoint; real device behavior, network restrictions and APK assembly still require GitHub Actions/device validation.


## v0.1.127 — X video playback + background analysis cleanup
- X video preview now starts with the actual X status URL as Referer and no synthetic Origin; it falls back to X-root browser headers only when needed, then re-resolves a fresh MP4.
- X video download uses the same request order as preview. Refreshed MP4 URLs are retried with the status Referer first and X-root Origin only as fallback.
- Stream manifests are never saved as MP4. Downloaded videos are validated with Android MediaMetadataRetriever before being published as successful files.
- `バックグラウンドでも解析` OFF no longer owns a foreground service/wake lock; when the Activity leaves the foreground, crawler WebView execution is paused and resumes on return.
- ON keeps the foreground service + partial wake lock behavior and can continue through task removal.
- Added a N-red `強制停止` button on the right of the background-analysis row. It immediately cancels preparation/crawler/download/WebView work and releases the foreground service while preserving already received media cells.


## v0.1.126 — X image-then-video search pipeline
- X profile media collection starts with `from:user filter:images` in Latest search and harvests canonical `/status/<id>` links plus direct `pbs.twimg.com/media` images.
- The old 28-pass X profile cutoff is bypassed. X search finishes only after repeated no-progress at the actual scroll boundary; a 600-pass guard is retained only as runaway protection and marks the run incomplete if hit.
- Pending maximum-resolution image probes are drained before the crawler switches to `from:user filter:native_video`.
- Video search harvests canonical status IDs first, then opens those status details to resolve `video.twimg.com` MP4/HLS resources.
- X video detail loads temporarily allow programmatic media playback so the existing warm-up path can trigger playable media requests.
- X search navigation matching keys on the search query, tolerating X redirects that rewrite auxiliary search parameters.
- Added `SNS_X_SEARCH_*` diagnostics for phase, progress, boundary/stall completion, status counts, and phase switching.


## v0.1.105 — adaptive normal-site lazy scrolling
- Replaced the fixed three-pass generic-page scroll with adaptive continuation.
- Continue while page height or image/media DOM count grows; finish after three stable checks.
- Keep an 80-pass safety ceiling to avoid endless pages.
- Maximum-resolution image probing remains unchanged.





## v0.1.104 — pagination cap removal
- Removed the fixed 30-page pagination cap from generic same-article pagination traversal.
- Same-host restriction, duplicate suppression, intelligent pagination classification, cancellation, and existing traversal safeguards remain active.
- Maximum-resolution image selection from v0.1.103 is unchanged.

## v0.1.103 — X image maximum-resolution probe
- `pbs.twimg.com/media` images no longer stop at `:large` by assumption.
- For X/Twitter image candidates, probe `orig`, `large`, the current URL, and the original page URL when distinct.
- Select the candidate with the largest decoded pixel area; use max side as the tie-breaker.
- Added `IMAGE_MAX_CANDIDATE`, `IMAGE_MAX_CANDIDATE_FAIL`, and `IMAGE_MAX_SELECTED` diagnostics.
- Site-internal article filtering is intentionally unchanged.

## v0.1.102 — paginated direct-image classification fix

- Keeps `/mirihanai` pagination at the real 7-page boundary; no synthetic `/page/8` traversal is added.
- Splits strong related/navigation context (aside/nav/header/footer, related/recommend/ranking/popular/recent/widget/sidebar/menu/breadcrumb) from generic `entry/post/article-card` ancestry.
- A thumbnail whose link resolves to the exact same direct image may pass through when the only negative signal is a generic card wrapper.
- Strong related/sidebar/navigation contexts still reject direct-image links before probing, so unrelated site-card filtering remains active.
- Adds `INTELLIGENT_DIRECT_IMAGE_ALLOW reason=card_only_same_image` diagnostics for the rescued path.
- This targets the diagnostic case where `/page/2`–`/page/7` exposed 238 valid `pbs.twimg.com/media` direct-image links that were all suppressed before `IMAGE_PROBE_QUEUE`.

## v0.1.101 — paginated main-image rescue

- Keeps v0.1.100 maximum-resolution/direct-image handling and related-card filtering.
- Stops treating the page-global `archive` class as a related-content signal, preventing `/page/N` main images from being suppressed.
- Same-article `/page/N` navigation is classified before generic related/navigation context so wrapper markup cannot downgrade it.
- Local related/recommend/sidebar/card/menu/breadcrumb filters remain active, so unrelated site-article cards stay excluded.

## v0.1.100 — large direct-image preservation / related-card filtering

- Keeps explicit `pbs.twimg.com/...jpg:large` and `:orig` hrefs as real fetch URLs instead of stripping the size suffix.
- Upgrades `:thumb` / `:small` / `:medium` image candidates to `:large`, while deduplication uses a separate size-neutral image identity.
- Direct-image detection accepts Twitter-style `:large` / `:orig` suffixes.
- Related/sidebar/recommend/ranking/recent/widget/card images are filtered by DOM ancestry even when the image has no ordinary article link.
- Related-card classification now runs before the direct-image fast path, preventing image hrefs inside related cards from leaking into results.
- Main article/content images remain eligible.

## v0.1.99 — external CDN direct-image recovery
- Thumbnail/detail links are normalized through the existing maximum-resolution image URL logic before direct-image classification.
- X/Twitter CDN image links such as `pbs.twimg.com/media/...jpg:large` are recognized as direct image assets instead of being misclassified as unrelated external navigation.
- Direct external image assets now enter the normal image probe/replacement path; unrelated external pages, advertisements, affiliate links, and related-article navigation remain filtered by the existing intelligent traversal rules.
- Adds `THUMB_LINK_IMAGE_TARGET_REWRITE` diagnostics when a linked image target is promoted to its canonical maximum-resolution URL.
- Existing in-page maximum-size UI detection, pagination/content-family traversal, SNS handling, applicationId, and stable signing key are retained.


## v0.1.97 — generic in-page maximum image size selection
- Before generic web-page media collection, ImgStalker scans image-size / resolution / quality controls and selects the maximum-looking choice when the image context is sufficiently clear.
- Supports radio groups, select menus, buttons and tabs; recognizes Japanese/English choices including 大 / 最大 / 原寸 / 高解像度 / Large / Original / Full / High and explicit pixel dimensions.
- Uses the page's normal click/input/change event path, waits 800 ms for DOM/image updates, then starts media collection.
- Adds `IMAGE_SIZE_UI_SCAN` and `IMAGE_SIZE_UI_VERIFY` diagnostics, including whether image URLs/natural dimensions actually changed.
- After a size switch, collector compares live `currentSrc` / `naturalWidth` against `srcset`, `<picture><source>`, `data-full-url`, `data-original`, and related candidates so a stale medium `srcset` cannot mask a larger selected image.
- The detector is deliberately conservative: controls must be in an image/photo size, resolution or quality context; ordinary navigation is not clicked and normal links are not followed as size controls.
- Existing intelligent content-family traversal, maximum URL normalization, SNS/X/Instagram handling, and fixed signing identity remain active.

## v0.1.96 — content-family traversal + maximum-resolution images
- Intelligent traversal now uses one canonical image identity for X/Twitter size variants, so unrelated same-site article cards suppress the matching full-size image as well as their thumbnail form.
- Page families such as `/mirihanai` + `/mirihanai/page/N` remain the pagination lane while different article slugs stay excluded.
- Generic pages expose `全N件` to diagnostics as `INTELLIGENT_CONTENT_TOTAL`; `bi-girl.net/mirihanai` is expected to report 207.
- Generic `srcset` / `data-srcset` / `<picture><source>` selection now always chooses the largest advertised candidate, not merely the first candidate meeting the resolution threshold.
- Added `data-orig-file`, `data-large-file`, and `data-full-url` as original-image candidates.
- X/Twitter `pbs.twimg.com/media` `:small/:medium/:large/:thumb` and `name=small/...` variants are rewritten to the original-size endpoint before probe/save.
- WordPress `/wp-content/uploads/` `-WIDTHxHEIGHT` derivatives are promoted to the original filename, with automatic fallback to the discovered derivative when the original cannot be probed.
- Existing SNS/X/Instagram traversal, animated-GIF behavior, ad/affiliate filtering, fixed applicationId and stable signing key are retained.

## v0.1.95 — intelligent traversal restored
- Restored the default-ON 「インテリジェント巡回」 toggle.
- Intelligent ON forces page/detail traversal ON and greys those two toggles.
- Restored link classification logs: INTELLIGENT_CLASSIFY / FOLLOW / SKIP.
- Same-site unrelated article cards are skipped and their linked thumbnail images are suppressed.
- Same-article pagination remains followable. Gallery/photo/image-detail URLs remain followable.
- Tightened image-detail classification so generic WordPress resized thumbnails alone no longer qualify as image-detail pages.
- Existing v0.1.94 SNS/X/Instagram, ad-tracker and affiliate filtering paths are retained.

## v0.1.94 — standby / forced-stop diagnostics and detail-load pressure reduction

- Android 11+ の `ApplicationExitInfo` を診断ログへ追加し、前回プロセスの終了理由・status・timestamp・importance・PSS/RSS・descriptionを最大5件記録。
- 診断レポートへ現在のバックグラウンド制限、バッテリー最適化除外状態、App Standby Bucketを追加。
- バックグラウンド解析Serviceの `onTrimMemory` / `onLowMemory` を記録。
- 実機ログで大量発生していた `ad-nex.com` 詳細リンクと `img-ad-nex.com` 広告サムネイルを詳細解析／画像probe対象から除外。
- `pics.dmm.co.jp` サムネイル＋`al.dmm.co.jp` の典型的なアフィリエイト広告ペアは詳細追跡から除外。その他の `al.dmm.co.jp` 経由リンクは `lurl` をDMM本体URLへ展開して不要なリダイレクトを削減。
- v0.1.93 のX/Twitter動画403再解決・失敗キャッシュ・animated GIF保存仕様は維持。

## v0.1.93 — X/Twitter video 403 recovery

- `video.twimg.com` MP4のHTTP 403対策を再設計。`?tag=` 除去による推測リトライは廃止。
- 403時は、まず通常ブラウザ相当のUser-Agent / X Referer / Originで同一URLを1回だけ再試行。
- それでも403なら元ページを再取得し、同一media IDの新しい `video.twimg.com` MP4候補を探索。
- 元ページ内にX/Twitter statusリンクがある場合は最大6件まで辿り、同じmedia IDの新URLを再解決。
- 解決成功URLは解析セッション内で再利用。失敗も用途別にキャッシュし、サムネイル／プレビュー／保存処理が同じ403 URLを連打しない。
- X animated GIFのGIF保存仕様は維持。GIF変換失敗時にMP4へフォールバックしない。

## v0.1.92 — X/Twitter video tag retry (superseded)

- `video.twimg.com` MP4の403時に `tag` queryだけを外す方式を試したが、実機ログでtag有無どちらも403になるケースを確認。
- v0.1.93ではこの方式を廃止。

## v0.1.91 — X GIF decoder fallback

- Xの動画GIFをGIF保存する経路で、Android標準 `MediaMetadataRetriever` がduration/frameを取得できないMP4にMedia3 Inspectorをフォールバック使用。
- durationは platform extractor → Media3 metadata の順でも補完。
- 通常動画のMP4保存経路は変更しない。
- GIF選択時にGIF変換へ失敗した場合はMP4へフォールバック保存せず、従来どおり失敗（赤チェック）として扱う。

## v0.1.90 — X GIF save conversion

- SNS設定の「リポストを取得」直下に「動画GIFをGIFとして保存」Nトグルを追加（デフォルトON）。
- Xのanimated GIF/tweet_video MP4だけを保存時に実GIFへ変換。通常動画は従来どおりMP4保存。
- 追加ネイティブ依存なしのGIF89a/LZW変換を内蔵。

## v0.1.89 — X media-candidate resolver

Based on v0.1.88 (89).

### X / Twitter video + animated GIF
- Profile/timeline harvesting still discovers canonical status URLs, but status-detail analysis is now queued only for posts that visibly contain video/GIF indicators.
- `pbs.twimg.com/tweet_video_thumb/...` is treated as an animated-GIF media signal instead of a disposable non-post image.
- For `tweet_video_thumb`, ImgStalker derives the corresponding `https://video.twimg.com/tweet_video/<id>.mp4` candidate immediately and registers it as VIDEO against the owning status.
- `ext_tw_video_thumb`, live `<video>`/`<source>` nodes, X video-player test IDs, and GIF accessibility labels also mark a status as a media candidate.
- Only candidate statuses are deferred to the existing detail resolver; ordinary text/image statuses are no longer opened one-by-one just to prove they contain no video.
- Existing v0.1.88 detail-page fallback remains for candidate posts: animated_gif / video_info.variants parsing, Performance Resource Timing, WebView network capture, and bounded late-media polling.
- Added diagnostics: `SNS_X_MEDIA_CANDIDATES`, `SNS_X_TWEET_VIDEO_DIRECT`, and `SNS_X_STATUS_DEFER reason=media_candidate`.

### Retained from v0.1.88
- X detail pages keep the primary tweet near the viewport and can wait up to five 600 ms passes for late video/GIF materialization.
- Automatic gradual SNS thumbnail sweep with visible-cell priority.
- Instagram timeline-direct media path and existing rate-limit/resume behavior.
- Saved media circular green check / selection blocked; failed media circular dark-red check / retry selectable.
- N White #A9A999 title.
- SAF-first video saving with MediaStore Movies fallback.
- Fixed applicationId and stable signing keystore for overwrite install.

Package: versionName 0.1.127 / versionCode 128.

## v0.1.113 — install versionCode correction

- Raised versionCode to 114 so this build can overwrite the previously generated 0.1.112-beta build (versionCode 113).
- No crawler, SNS search, UI, applicationId, or signing-key behavior changes from v0.1.111.

## v0.1.111 — SNS search + account identity display

- Added X / Instagram radio buttons and a keyword / hashtag search field at the bottom of the SNS section.
- X searches use the latest-search timeline while preserving the user's query; Instagram routes single-token/hashtag input to its hashtag timeline and multi-word input to the Instagram keyword-search surface.
- Search discovery remains inside each SNS dedicated lane. It never falls through to generic intelligent traversal.
- X / Instagram account rows no longer show slot labels such as `X 1` / `X 2` or the text `ログイン済み`. Logged-in rows show the N-standard green circle + white geometric check at the left and the resolved `@user_id`.
- Existing logged-in profiles with no stored user ID attempt to resolve and cache the visible account handle from their isolated WebView profile.

## v0.1.110 — Intelligent related-card suppression + dedicated SNS lanes

- Intelligent traversal now gives `strongRelatedLike` priority over direct-image allow. A real direct image URL is suppressed when DOM ownership says it belongs to related/sidebar content.
- Images inherit related ownership from another internal-article link in the same compact DOM card. This is generic DOM-based filtering, not a bi-girl.net-specific URL rule.
- Related ownership learned on a later page is applied retroactively by normalized image identity; an already displayed media cell is removed from the UI and the final image count is corrected.
- Pending image probes and late probe completions re-check suppression, so page order and network timing cannot re-introduce a rejected related image.
- X and Instagram remain isolated dedicated SNS crawler lanes. SNS routing is now explicitly registered by `DedicatedSnsLogic`; any future SNS icon must get its own dedicated traversal/collector logic before being enabled and must not fall through to generic intelligent traversal.
- Explicit page-list traversal and maximum-resolution image selection remain unchanged.

## v0.1.109 — Page-list deadlock fix

- Explicit page lists remain authoritative for normal sites; X and Instagram traversal are unchanged.
- The already-open current page is never re-enqueued from a synthesized page-list entry.
- Navigation callback matching treats only trailing-path-slash differences as equivalent, so `/name` and `/name/` cannot deadlock a load.
- Normal non-SNS page loads have bounded start/finish watchdogs; a broken callback lane is skipped so remaining queued pages continue.
- Maximum-resolution image selection and existing related-article filtering are unchanged.

## v0.1.107 — Authoritative page-list traversal

- Normal sites treat an explicit page list as authoritative and queue those page URLs directly.
- Page-list URLs bypass intelligent/SNS-style traversal decisions; X/Instagram-specific traversal is unchanged.
- Numeric pager links, rel=next, page-select options and common pager containers are detected before any generic scroll fallback.
- If the pager exposes a numeric URL family, missing page numbers inside the visible range are reconstructed and queued.



## v0.1.115 — verified SNS accounts and dedicated X search harvesting

- X / Instagram account rows now show the saved user ID and only show the N green check after both an auth cookie and the signed-in account ID are verified.
- Reserved service paths such as X `/login` can no longer be stored as user IDs; legacy invalid values are rejected automatically.
- Account identity resolution retries the SPA DOM before declaring the session unverified. Logged-out profiles are not used for SNS analysis; cookie-only legacy profiles are fallback-only until verified.
- X keyword/hashtag search harvests media per tweet card and keeps each image tied to its canonical status URL instead of treating the whole search page as the referrer.
- X search remains isolated from generic intelligent traversal and from Instagram logic.

## v0.1.121 — X account ID resolution via twid

- X account verification now reads the authenticated `twid` numeric user ID and resolves it through `https://x.com/i/user/<id>` before falling back to DOM heuristics.
- The resolver accepts only the final one-segment X profile URL as the username, with canonical/og:URL/UserName fallback restricted to the numeric-ID profile route.
- Added diagnostic events `SNS_X_ID_RESOLVE`, `SNS_X_ID_RESOLVE_NAV`, and `SNS_X_ID_RESOLVE_REDIRECT` without logging auth tokens.
- Instagram account verification is unchanged.


## v0.1.122 — Instagram search post navigation / SNS dialog stack fix

- Instagram search treats query-decorated post URLs such as `/p/<shortcode>/?q=...` as the same root post navigation.
- Post-card tapping now matches the exact `/p|reel|tv/<shortcode>/` pathname and rejects child routes such as `/liked_by/`.
- Instagram stream recovery no longer waits forever on a post/child route; it returns to the search/profile stream with a bounded recovery path.
- SNS account dialogs are single-instance. Opening an account browser dismisses the parent account dialog first, then recreates exactly one refreshed account dialog on return.

## v0.1.123 — X normal video capture

- X normal-video network candidates from `video.twimg.com` are no longer filtered out by the animated-GIF-only drain.
- Normal X video and animated GIF selection use separate paths; GIF behavior is preserved.
- When multiple X MP4 candidates are observed, the candidate with the largest URL-advertised resolution is preferred; stream is fallback when no MP4 wins.
- X detail pages keep waiting when a `<video>` element exists but the playable MP4/stream has not materialized yet, even if the poster image is already visible.
- Performance Resource Timing now observes normal `video.twimg.com` MP4/stream resources in addition to animated-GIF resources.
- Added `SNS_X_VIDEO_SELECTED`, `SNS_X_VIDEO_NETWORK_DRAIN`, and `SNS_X_VIDEO_RESOLVE` diagnostics.

