package com.cmyk.imgstalker;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.WebSettings;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class MediaDownloader {
    public interface Listener {
        void onProgress(int done, int total, String message);
        void onFinished(String folderName, int success, int failed);
    }

    private final Context context;
    private final Listener listener;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private final String userAgent;

    public MediaDownloader(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        String ua;
        try {
            ua = WebSettings.getDefaultUserAgent(this.context) + " ImgStalker/0.1.57";
        } catch (Exception e) {
            ua = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36 ImgStalker/0.1.57";
        }
        userAgent = ua;
    }

    public void cancel() {
        DiagnosticLog.log("DOWNLOADER_CANCEL");
        cancelled.set(true);
        pool.shutdownNow();
    }

    public void download(List<MediaItem> source, String pageTitle) {
        ArrayList<MediaItem> items = new ArrayList<>();
        for (MediaItem i : source) if (i.selected && i.kind != MediaItem.Kind.STREAM) items.add(i);
        final int total = items.size();
        DiagnosticLog.log("DOWNLOADER_BEGIN total=" + total + " title=" + pageTitle);
        if (total == 0) {
            listener.onFinished("", 0, 0);
            return;
        }
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.JAPAN).format(new Date());
        String base = sanitize(pageTitle);
        if (base.isEmpty()) base = "WebMedia";
        final String folder = base + "_" + stamp;
        AtomicInteger done = new AtomicInteger();
        AtomicInteger ok = new AtomicInteger();
        AtomicInteger ng = new AtomicInteger();

        for (int idx = 0; idx < items.size(); idx++) {
            final int index = idx + 1;
            final MediaItem item = items.get(idx);
            pool.submit(() -> {
                if (!cancelled.get()) {
                    try {
                        long bytes = downloadOne(item, folder, index);
                        ok.incrementAndGet();
                        DiagnosticLog.log("DOWNLOAD_OK kind=" + item.kind + " bytes=" + bytes + " url=" + item.url);
                    } catch (Exception e) {
                        ng.incrementAndGet();
                        DiagnosticLog.logException("DOWNLOAD_FAIL kind=" + item.kind + " url=" + item.url, e);
                    }
                } else {
                    ng.incrementAndGet();
                }
                int d = done.incrementAndGet();
                if (cancelled.get()) return;
                listener.onProgress(d, total, item.url);
                if (d == total) {
                    pool.shutdown();
                    listener.onFinished(folder, ok.get(), ng.get());
                }
            });
        }
    }

    private long downloadOne(MediaItem item, String folder, int index) throws Exception {
        String accept = item.kind == MediaItem.Kind.IMAGE
                ? "image/avif,image/webp,image/apng,image/*,*/*;q=0.8"
                : "video/*,*/*;q=0.8";
        HttpURLConnection con = item.kind == MediaItem.Kind.IMAGE
                ? openImageLikeThumbnail(item, 0)
                : openFollowingRedirects(item.url, item.referrer, accept);
        Uri uri = null;
        boolean success = false;
        long written = 0L;
        try {
            int code = con.getResponseCode();
            String finalUrl = con.getURL().toString();
            String contentType = normalizeMime(con.getContentType());
            long contentLength = con.getContentLengthLong();
            DiagnosticLog.log("DOWNLOAD_HTTP_RESPONSE code=" + code
                    + " type=" + contentType
                    + " length=" + contentLength
                    + " finalUrl=" + finalUrl);
            if (item.kind == MediaItem.Kind.IMAGE && code == 403) {
                con.disconnect();
                DiagnosticLog.log("DOWNLOAD_RETRY reason=HTTP403 url=" + item.url);
                try { Thread.sleep(250L); } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw interrupted;
                }
                con = openImageLikeThumbnail(item, 1);
                code = con.getResponseCode();
                finalUrl = con.getURL().toString();
                contentType = normalizeMime(con.getContentType());
                contentLength = con.getContentLengthLong();
                DiagnosticLog.log("DOWNLOAD_HTTP_RESPONSE retry=1 code=" + code
                        + " type=" + contentType
                        + " length=" + contentLength
                        + " finalUrl=" + finalUrl);
            }
            if (code < 200 || code >= 300) throw new FileNotFoundException("HTTP " + code);
            if (contentType != null && (contentType.startsWith("text/html") || contentType.startsWith("application/json"))) {
                throw new IOException("media response is " + contentType);
            }

            String original = filenameFromUrl(finalUrl);
            String ext = extension(original);
            if (ext.isEmpty()) ext = extensionForMime(contentType, item.kind);
            if (original.isEmpty() || extension(original).isEmpty()) {
                original = (item.kind == MediaItem.Kind.IMAGE ? "image" : "video")
                        + "_" + String.format(Locale.US, "%03d", index) + ext;
            }
            original = sanitizeFilename(original);
            String displayName = String.format(Locale.US, "%03d_", index) + original;
            String relPath = Environment.DIRECTORY_DOWNLOADS + "/ImgStalker/" + folder + "/";
            if (item.kind == MediaItem.Kind.VIDEO) relPath += "videos/";

            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, contentType != null ? contentType : fallbackMime(item.kind, ext));
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, relPath);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            ContentResolver resolver = context.getContentResolver();
            uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new FileNotFoundException("MediaStore insert failed");
            DiagnosticLog.log("DOWNLOAD_SAVE_URI uri=" + uri + " path=" + relPath + " name=" + displayName);

            try (BufferedInputStream in = new BufferedInputStream(con.getInputStream());
                 OutputStream raw = resolver.openOutputStream(uri, "w")) {
                if (raw == null) throw new FileNotFoundException("openOutputStream returned null");
                try (BufferedOutputStream out = new BufferedOutputStream(raw)) {
                    DiagnosticLog.log("DOWNLOAD_WRITE_BEGIN uri=" + uri);
                    byte[] buf = new byte[128 * 1024];
                    int n;
                    while (!cancelled.get() && (n = in.read(buf)) >= 0) {
                        if (n == 0) continue;
                        out.write(buf, 0, n);
                        written += n;
                    }
                    out.flush();
                }
            }
            if (cancelled.get()) throw new InterruptedException("cancelled");
            if (written <= 0L) throw new IOException("empty response body");
            DiagnosticLog.log("DOWNLOAD_WRITE_DONE uri=" + uri + " bytes=" + written);

            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            int updated = resolver.update(uri, done, null, null);
            DiagnosticLog.log("DOWNLOAD_PUBLISH uri=" + uri + " rows=" + updated + " bytes=" + written);
            success = true;
            return written;
        } finally {
            con.disconnect();
            if (!success && uri != null) {
                try {
                    context.getContentResolver().delete(uri, null, null);
                    DiagnosticLog.log("DOWNLOAD_PARTIAL_DELETE uri=" + uri);
                } catch (Exception e) {
                    DiagnosticLog.logException("DOWNLOAD_PARTIAL_DELETE_FAIL uri=" + uri, e);
                }
            }
        }
    }

    private HttpURLConnection openImageLikeThumbnail(MediaItem item, int attempt) throws Exception {
        if (cancelled.get()) throw new InterruptedException("cancelled");
        URL url = new URL(item.url);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(12000);
        con.setReadTimeout(16000);
        con.setRequestProperty("User-Agent", userAgent);
        con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
        con.setRequestProperty("Accept-Encoding", "identity");
        con.setRequestProperty("Sec-Fetch-Dest", "image");
        con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
        if (item.referrer != null && !item.referrer.isEmpty()) {
            con.setRequestProperty("Referer", item.referrer);
        }
        String cookie = SessionCookies.getCookie(item.url);
        if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
        DiagnosticLog.log("DOWNLOAD_HTTP_BEGIN mode=thumbnail_like attempt=" + attempt
                + " url=" + item.url
                + " ref=" + item.referrer
                + " cookie=" + (cookie == null ? 0 : cookie.length()));
        con.connect();
        return con;
    }

    private HttpURLConnection openFollowingRedirects(String startUrl, String referrer, String accept) throws Exception {
        URL current = new URL(startUrl);
        for (int hop = 0; hop <= 6; hop++) {
            if (cancelled.get()) throw new InterruptedException("cancelled");
            HttpURLConnection con = (HttpURLConnection) current.openConnection();
            con.setInstanceFollowRedirects(false);
            con.setConnectTimeout(15000);
            con.setReadTimeout(45000);
            con.setRequestProperty("User-Agent", userAgent);
            con.setRequestProperty("Accept", accept);
            con.setRequestProperty("Accept-Language", Locale.getDefault().toLanguageTag() + ",ja;q=0.9,en;q=0.7");
            con.setRequestProperty("Accept-Encoding", "identity");
            con.setRequestProperty("Cache-Control", "no-cache");
            con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
            con.setRequestProperty("Sec-Fetch-Dest", accept.startsWith("image/") ? "image" : "video");
            if (referrer != null && !referrer.isEmpty()) con.setRequestProperty("Referer", referrer);
            String cookie = SessionCookies.getCookie(current.toString());
            if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
            DiagnosticLog.log("DOWNLOAD_HTTP_BEGIN hop=" + hop + " url=" + current + " ref=" + referrer
                    + " cookie=" + (cookie == null ? 0 : cookie.length()));
            con.connect();
            int code = con.getResponseCode();
            if (isRedirect(code)) {
                String location = con.getHeaderField("Location");
                if (location == null || location.trim().isEmpty()) return con;
                URL next = new URL(current, location);
                DiagnosticLog.log("DOWNLOAD_REDIRECT code=" + code + " from=" + current + " to=" + next);
                con.disconnect();
                current = next;
                continue;
            }
            return con;
        }
        throw new IOException("too many redirects");
    }

    private static boolean isRedirect(int code) {
        return code == HttpURLConnection.HTTP_MOVED_PERM
                || code == HttpURLConnection.HTTP_MOVED_TEMP
                || code == HttpURLConnection.HTTP_SEE_OTHER
                || code == 307 || code == 308;
    }

    private static String normalizeMime(String mime) {
        if (mime == null) return null;
        int semi = mime.indexOf(';');
        if (semi >= 0) mime = mime.substring(0, semi);
        mime = mime.trim().toLowerCase(Locale.ROOT);
        return mime.isEmpty() ? null : mime;
    }

    private static String filenameFromUrl(String s) {
        try {
            String p = new URL(s).getPath();
            int slash = p.lastIndexOf('/');
            String f = slash >= 0 ? p.substring(slash + 1) : p;
            return URLDecoder.decode(f, StandardCharsets.UTF_8.name());
        } catch (Exception e) { return ""; }
    }

    private static String extension(String f) {
        if (f == null) return "";
        int dot = f.lastIndexOf('.');
        if (dot < 0 || dot < f.length() - 8) return "";
        String e = f.substring(dot).toLowerCase(Locale.ROOT);
        return e.matches("\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif|mp4|webm|mov|m4v|3gp)") ? e : "";
    }

    private static String extensionForMime(String mime, MediaItem.Kind kind) {
        if (mime == null) return kind == MediaItem.Kind.IMAGE ? ".jpg" : ".mp4";
        switch (mime.toLowerCase(Locale.ROOT)) {
            case "image/jpeg": return ".jpg";
            case "image/png": return ".png";
            case "image/gif": return ".gif";
            case "image/webp": return ".webp";
            case "image/avif": return ".avif";
            case "image/heic": return ".heic";
            case "image/heif": return ".heif";
            case "video/webm": return ".webm";
            case "video/quicktime": return ".mov";
            case "video/3gpp": return ".3gp";
            default: return kind == MediaItem.Kind.IMAGE ? ".jpg" : ".mp4";
        }
    }

    private static String fallbackMime(MediaItem.Kind kind, String ext) {
        if (kind == MediaItem.Kind.IMAGE) {
            if (".png".equals(ext)) return "image/png";
            if (".gif".equals(ext)) return "image/gif";
            if (".webp".equals(ext)) return "image/webp";
            if (".avif".equals(ext)) return "image/avif";
            if (".heic".equals(ext)) return "image/heic";
            if (".heif".equals(ext)) return "image/heif";
            return "image/jpeg";
        }
        if (".webm".equals(ext)) return "video/webm";
        if (".mov".equals(ext)) return "video/quicktime";
        if (".3gp".equals(ext)) return "video/3gpp";
        return "video/mp4";
    }

    private static String sanitize(String s) {
        if (s == null) return "";
        s = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (s.length() > 60) s = s.substring(0, 60).trim();
        return s;
    }

    private static String sanitizeFilename(String s) {
        String x = sanitize(s);
        return x.isEmpty() ? "media" : x;
    }
}
