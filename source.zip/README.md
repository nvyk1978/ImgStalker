# ImgStalker v0.1.69 (70)

## Base
- Functional base: v0.1.68 (69).
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.

## Instagram acquire-as-discovered traversal
- Restores the intended streaming traversal used before the v0.1.68 discover-first regression.
- The crawler scans the currently visible profile cells in visual top-to-bottom / left-to-right order.
- It opens the first not-yet-processed post immediately, walks its carousel / video media, emits result cells immediately, returns to the saved profile scroll position, then continues with the next visible post.
- The crawler only scrolls the profile after every currently visible post has been processed.
- It no longer waits to discover up to 300 post URLs before opening the first post.
- The profile post count is retained only as a progress/reference value and the existing 300-post safety limit remains.

## WebView viewport / lazy-grid fix
- The hidden crawler host now uses `INVISIBLE` instead of `GONE`, preserving measurement/layout while keeping the diagnostic browser off-screen to the user.
- Instagram viewport scripts fall back through `window.innerHeight`, document client height, `visualViewport.height`, and `screen.height`, avoiding the v0.1.68 `vh=0` failure mode.
- Instagram profile/detail images remain enabled so the virtualized profile grid and detail DOM can materialize normally.

## Recovery and continuation
- Existing deferred retry behavior is retained for posts whose media cannot be acquired on the first pass.
- Failed posts still keep the reload/continuation cell available.
- Existing manual-stop continuation behavior is retained.

## Stable result order
- Visible profile cells define the authoritative post order.
- Emitted media retain per-post display ordering so carousel media and delayed/retried results return to the correct profile position.

## Retained behavior
- Existing carousel traversal, image URL normalization, duplicate suppression, target-size filtering, Reel/network video capture, cover-frame exclusion, background foreground-service/WakeLock support, diagnostics, signing, and normal hidden-browser behavior remain in place.

## Package
- versionCode: 70
- versionName: 0.1.69
