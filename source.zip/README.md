# ImgStalker 0.1.2 (3)

WebページをWebViewで実際に読み込み、画像・動画・ページ送り・画像付き詳細リンクを追跡して一括保存する個人用Androidアプリ。

## 初回実装
- URL直接入力
- Android共有メニューからURL受け取り
- JavaScript実行後DOMを解析
- img/currentSrc/src/srcset/data-src/data-original/data-lazy-src
- CSS background-image
- og:image / twitter:image
- video/source / og:video
- MP4 / WebM / MOV / M4V / 3GP直接ファイル
- HLS(.m3u8) / DASH(.mpd)は検出表示のみ（0.1.2では結合保存しない）
- rel=next、Next/次へ、pagination内数字リンクを追跡
- 画像を含むリンク先を詳細ページ候補として追跡
- lazy-load対策としてページを複数回自動スクロール
- 同一ホスト内のみ自動巡回
- URL重複除外
- 画像・動画の選択保存
- Downloads/ImgStalker/<ページタイトル_日時>/images と /videos に一括保存
- Cookie / Referer / User-Agentを引き継いで直接ファイルを取得

## N規格
- BG #303030
- D.Gray #252020
- Gray #454040
- L.Gray #656060
- Blue #223355
- L.Blue #445577
- Orange #775500
- N White #A9A999（非テキストUI）
- 通常テキスト #FFFFFF
- NToggleSwitch同系統のカプセル型トグル

## ビルド
リポジトリ直下に `source.zip` を置き、`.github/workflows/ImgStalker.yml` として同梱のworkflowを配置する。
workflow_dispatch または source.zip 更新でビルドされる。

APK出力名: `ImgStalker-v0.1.2.apk`

## 署名
`keystore/imgstalker.jks` を固定署名として使用する。今後の上書きインストールのため、このkeystoreを変更・紛失しないこと。

## 0.1.2の制限
- DRM保護コンテンツの回避は行わない。
- blob: URL、MediaSource、暗号化ストリームは直接保存対象外。
- HLS/DASHは検出のみ。
- onclickだけで遷移しhrefを持たない独自ギャラリーはサイト依存で未検出の場合がある。
- ログイン済みCookieはWebViewから直接ファイル取得時に引き継ぐが、サイト固有の追加認証ヘッダが必要な場合は失敗することがある。


## 0.1.1 修正
- Android ListViewに存在しない setDividerColor(int) 呼び出しを修正。ColorDrawableを setDivider() へ渡す実装に変更。


## 0.1.2 追加
- 解析結果の画像行にサムネイル表示を追加。Cookie / Referer / User-Agentを引き継いで非同期読込し、メモリキャッシュする。
- 動画・ストリーム行では画像サムネイル欄を表示しない。
- 右上の三点メニューから「診断ログ」を表示可能。
- 診断ログにアプリ起動、解析条件、ページ巡回、DOM解析、メディア検出、追跡キュー、WebView読込エラー、ダウンロードHTTP応答、保存成否、サムネイル失敗、未処理例外を記録。
- 診断ログはコピー／共有可能。端末・Android・アプリバージョンをレポート先頭に付加。
