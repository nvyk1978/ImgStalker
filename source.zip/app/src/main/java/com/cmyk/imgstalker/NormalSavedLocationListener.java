package com.cmyk.imgstalker;

/** NORMAL-only callback. X/Instagram downloaders continue to use onSaved. */
interface NormalSavedLocationListener extends MediaDownloader.Listener {
    void onNormalSavedAtUri(MediaItem item, long bytes, String contentUri);
}
