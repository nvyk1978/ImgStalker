#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" app/src/main/java/com/cmyk/imgstalker/AnalysisModeRouter.java app/src/main/java/com/cmyk/imgstalker/NavigationModeFilter.java tests/NavigationModeFilterTest.java
java -cp "$TMP" com.cmyk.imgstalker.NavigationModeFilterTest
python3 - <<'PY'
from pathlib import Path
from xml.etree import ElementTree as ET
u=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
i=Path('app/src/main/java/com/cmyk/imgstalker/NavigationIconLoader.java').read_text()
d=Path('app/src/main/java/com/cmyk/imgstalker/BookmarkReorderTouch.java').read_text()
assert 'new HeaderIconView(this, HeaderIconKind.NORMAL)' in u
assert 'new HeaderIconView(this, HeaderIconKind.X)' in u
assert 'new HeaderIconView(this, HeaderIconKind.INSTAGRAM)' in u
assert 'NavigationModeFilter.next(activeFilter[0], mode)' in u
assert 'filterIcons[j].setFilterSelected(activeFilter[0] == filterModes[j])' in u
assert 'showStableNavigationDialog(dialog, shell, width, height)' in u
assert 'navigationGroups.remove(group);' in u
assert 'group.getVisibility() == View.VISIBLE' in u
assert 'v.getVisibility() != View.VISIBLE' in d
assert 'normalGlobe.setTint(foreground)' in u
assert 'Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)' in i
assert 'canvas.clipPath(circle)' in i
assert 'Math.min(sw, sh)' in i
assert 'options.inSampleSize = 1' in i
assert 'navigation_icons_circle_v2' in i
assert 'Bitmap.createScaledBitmap(source, 96, 96, true)' not in i
ET.parse('app/src/main/res/drawable/ic_nav_normal.xml')
print('PASS: filter UI, fixed dialog, circular source-respecting crop, vector XML')
PY
