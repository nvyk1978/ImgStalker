package com.cmyk.imgstalker;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
/** v0.1.86 Instagram source graph discovery smoke; never sends requests. */
public final class Instagram429RecoveryTest {
  static final class Listener implements InstagramInstagramSourcePipeline.Listener {
    final List<String> posts = new ArrayList<>();
    public void onProfileMeta(String u,int n){}
    public void onPostDiscovered(int i,String url){posts.add(url);}
    public void onPostResolved(String u,List<InstagramInstagramSourcePipeline.ResolvedMedia> ms){}
    public void onPostRetry(String u,int a,String r,long d){}
    public void onPostSkipped(String u,String r){}
    public void onRateLimited(String scope,int status,long delay){}
    public void onComplete(int a,int b,int c,int d,boolean m){}
    public void onFatal(String m){}
  }
  public static void main(String[] args)throws Exception{
    Listener listener=new Listener();
    InstagramInstagramSourcePipeline p=new InstagramInstagramSourcePipeline("","test",listener);
    Method m=InstagramInstagramSourcePipeline.class.getDeclaredMethod("discoverProfileSourcePosts",String.class);
    m.setAccessible(true);
    Object num=m.invoke(p,"{\"shortcode\":\"ABCde1234\"} /reel/ZZZZZ9876/");
    if(!Integer.valueOf(2).equals(num) || listener.posts.size()!=2) throw new AssertionError("v0.1.86 source discovery");
    if(!Integer.valueOf(0).equals(m.invoke(p,"/reel/ZZZZZ9876/"))) throw new AssertionError("duplicate discovery");
    System.out.println("PASS: v0.1.86 source post discovery and deduplication");
  }
}
