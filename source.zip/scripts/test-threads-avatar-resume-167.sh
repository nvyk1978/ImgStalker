#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
root=Path('app/src/main/java/com/cmyk/imgstalker')
threads=(root/'ThreadsCrawlerEngine.java').read_text()
parser=Path('app/src/main/assets/threads_feed.js').read_text()
main=(root/'MainActivity.java').read_text()
icons=(root/'NavigationIconLoader.java').read_text()
resume=(root/'SnsResumeStore.java').read_text()
assert 'beginDetails(token)' in threads and 'openNextDetail(token)' in threads
assert 'THREADS_DETAIL_PASS' in threads and 'detailPhase' in threads
assert 'webView.evaluateJavascript' in main and 'probeSnsProfileAvatar' in main
assert 'SNS_PROFILE_AVATAR|' in threads and 'SNS_PROFILE_AVATAR|' in main
assert 'offerProfileAvatar' in main and 'offerProfileAvatar' in icons
assert 'navigation_icons_circle_v3' in icons
assert 'output.avatar' in parser and 'requested = location.origin + location.pathname' in parser
assert 'this.savedLedgerTempFileName = this.savedLedgerFileName + ".tmp.json"' in resume
assert 'this.tempFileName = this.fileName + ".tmp.json"' in resume
assert 'readSavedDocument' in resume and 'mergeState' in resume
assert 'saved_redundant_temp' in resume and 'resume_redundant_temp' in resume
assert 'saved_temp_after_verified_final' in resume
print('PASS: Threads detail + profile avatar + SAF temp recovery wiring')
PY
bash scripts/test-threads-engine-compile.sh
bash scripts/test-sns-resume-compile.sh
