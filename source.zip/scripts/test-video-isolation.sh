#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
DIR="$(mktemp -d)"
trap 'rm -rf "$DIR"' EXIT
javac -d "$DIR" \
  app/src/main/java/com/cmyk/imgstalker/NormalVideoUrl.java \
  app/src/main/java/com/cmyk/imgstalker/InstagramVideoUrl.java \
  tests/ModeVideoIsolationTest.java
java -cp "$DIR" com.cmyk.imgstalker.ModeVideoIsolationTest
# Ensure no Normal/Instagram transport class calls X's global video cache again.
if grep -l 'TwitterVideoUrl\.' app/src/main/java/com/cmyk/imgstalker/Normal*.java \
    app/src/main/java/com/cmyk/imgstalker/Instagram*.java; then
    echo 'ERROR: legacy processing calls X URL recovery' >&2
    exit 1
fi
sha256sum -c mode-locks.sha256
