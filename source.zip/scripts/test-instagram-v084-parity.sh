#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'TEST'
from pathlib import Path
import hashlib
root=Path('app/src/main/java/com/cmyk/imgstalker')
p=(root/'InstagramInstagramSourcePipeline.java').read_text().replace('InstagramInstagramSourcePipeline','InstagramSourcePipeline')
assert "SNS_IG_SOURCE_PROFILE_HTML_READY" in p and "no_profile_info_v1=true" in p, 'HTML-first discovery missing'
c=(root/'InstagramCrawlerEngine.java').read_text()
assert 'startInstagramInstagramSourcePipeline(normalized)' in c
assert 'fallback=source_only browser=false' in c
assert 'SNS_IG_086_BROWSER_PROFILE_START' not in c
assert 'if (isInstagramLikeHost(rootHost))' in c
assert 'InstagramSessionCookies.getCookie(' in c
r=(root/'InstagramInstagramMediaResolver.java').read_text().replace('InstagramInstagramMediaResolver','InstagramMediaResolver')
assert hashlib.sha256(r.encode()).hexdigest()=="c6002e65971f665e8615bac6cc24ed961d8b074073f467da00135fcebf570a39", 'Instagram 0.1.86 media resolver mismatch'
assert "versionCode 146" in Path('app/build.gradle').read_text()
assert "versionName '0.1.145'" in Path('app/build.gradle').read_text()
print('PASS: Instagram v0.1.86 base, HTML-first 429 resilience and browser-free route')
TEST
sha256sum -c mode-locks.sha256
