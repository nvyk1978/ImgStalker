package com.cmyk.imgstalker;

public final class InstagramRecoveryPolicyTest {
    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        check(InstagramRecoveryPolicy.sourceNeedsBrowser(0, 0, 0, 0), "redirect/fatal empty");
        check(InstagramRecoveryPolicy.sourceNeedsBrowser(100, 0, 0, 0), "discovery without media");
        check(InstagramRecoveryPolicy.sourceNeedsBrowser(100, 99, 1, 99), "skipped posts");
        check(InstagramRecoveryPolicy.sourceNeedsBrowser(100, 100, 0, 0), "no emitted media");
        check(!InstagramRecoveryPolicy.sourceNeedsBrowser(100, 100, 0, 102), "all resolved");
        check(InstagramRecoveryPolicy.mayReloadGrid(true, 1, 2), "one retry remaining");
        check(!InstagramRecoveryPolicy.mayReloadGrid(true, 2, 2), "bounded retry");
        check(!InstagramRecoveryPolicy.mayReloadGrid(false, 0, 2), "already complete");
        check("login".equals(InstagramRecoveryPolicy.authGateType("https://www.instagram.com/accounts/login/?next=%2F")), "login");
        check("challenge".equals(InstagramRecoveryPolicy.authGateType("https://instagram.com/challenge/")), "challenge");
        check("suspended".equals(InstagramRecoveryPolicy.authGateType("https://m.instagram.com/accounts/suspended/")), "suspended");
        check("none".equals(InstagramRecoveryPolicy.authGateType("https://www.instagram.com/p/ABC/")), "post allowed");
        check("none".equals(InstagramRecoveryPolicy.authGateType("https://evilinstagram.com/accounts/login")), "lookalike rejected");
        check("none".equals(InstagramRecoveryPolicy.authGateType("https://x.com/accounts/login")), "X unaffected");
        check("none".equals(InstagramRecoveryPolicy.authGateType("https://example.org/instagram.com/accounts/login")), "NORMAL unaffected");
        check(InstagramRecoveryPolicy.browserFirstForAnonymousProfile("https://www.instagram.com/siraseaiko0421?rpxt=abc", false), "anonymous IG profile chooses browser");
        check(!InstagramRecoveryPolicy.browserFirstForAnonymousProfile("https://instagram.com/siraseaiko0421/", true), "authenticated IG stays on legacy source");
        check(!InstagramRecoveryPolicy.browserFirstForAnonymousProfile("https://www.instagram.com/reel/CDE123/", false), "reels use direct-post source");
        check(!InstagramRecoveryPolicy.browserFirstForAnonymousProfile("https://www.instagram.com/p/ABC123/", false), "post uses direct-post source");
        check(!InstagramRecoveryPolicy.browserFirstForAnonymousProfile("https://x.com/example", false), "X mode untouched");
        check(!InstagramRecoveryPolicy.browserFirstForAnonymousProfile("https://example.org/instagram.com", false), "NORMAL mode untouched");
        check(!InstagramRecoveryPolicy.browserFirstForAnonymousProfile("https://fakeinstagram.com/example/", false), "lookalike blocked");
        System.out.println("PASS: 22 Instagram-only recovery policy cases");
    }
}
