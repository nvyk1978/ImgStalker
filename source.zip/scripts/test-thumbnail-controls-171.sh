#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
import re
import xml.etree.ElementTree as ET
base=Path('app/src/main/res/drawable')
ns='{http://schemas.android.com/apk/res/android}'
for name in ('ic_thumbnail_zoom_plus','ic_image_close_circle'):
    node=ET.parse(base/(name+'.xml')).getroot()
    assert node.tag == 'vector'
    paths=node.findall('path')
    assert paths
    for path in paths:
        fill=path.attrib.get(ns+'fillColor', '')
        stroke=path.attrib.get(ns+'strokeColor', '')
        assert fill in ('#A9A999','#00000000')
        assert not stroke or stroke == '#A9A999'
        assert path.attrib.get(ns+'pathData')
ui=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
assert 'R.drawable.ic_thumbnail_zoom_plus' in ui
zoom=ui[ui.index('private final class EyeIconView'):]
assert 'zoomPlus.draw(canvas)' in zoom
assert 'getDrawable(R.drawable.ic_nav_normal)' not in zoom
viewer=ui[ui.index('private void showOriginalImage('):ui.index('private void dismissKeyboardAndFocus()')]
assert 'ImageView closeAction = new ImageView(this);' in viewer
assert 'closeAction.setImageResource(R.drawable.ic_image_close_circle);' in viewer
assert 'closeAction.setContentDescription("閉じる");' in viewer
assert 'closeAction.setOnClickListener(v -> dialog.dismiss());' in viewer
assert 'actions.addView(closeAction, new LinearLayout.LayoutParams(dp(78), dp(48)));' in viewer
assert "versionCode 173" in Path('app/build.gradle').read_text()
assert "versionName '0.1.172'" in Path('app/build.gradle').read_text()
print('PASS: zoom-plus / circle-X VectorDrawable, N-white, original close hitbox, preserved behavior, version')
PY
