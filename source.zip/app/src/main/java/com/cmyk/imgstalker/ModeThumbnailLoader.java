package com.cmyk.imgstalker;
import android.widget.ImageView;
interface ModeThumbnailLoader {
    void prefetch(MediaItem item);
    boolean isCachedOrPending(MediaItem item);
    int pendingCount();
    void load(ImageView view, MediaItem item);
    void cancelPending();
    void clearCache();
    void shutdown();
}
