package com.cmyk.imgstalker;

import java.util.Collection;
import java.util.List;
import org.json.JSONObject;

/** One-way UI contract. Implementations never call or construct another provider engine. */
interface ModeCrawler {
    void start(String url, boolean pages, boolean details, boolean intelligent, boolean images, boolean videos, int minPx);
    void cancel();
    void requestGracefulStop();
    boolean recoverFromStall();
    boolean hasPendingWork();
    String progressSnapshot();
    void seedExternalResumeMedia(List<MediaItem> items);
    void seedContinuationResults(List<MediaItem> items);
    void seedInstagramContinuationState(Collection<String> done, Collection<String> discovered);
    List<String> getCompletedInstagramPostUrls();
    List<String> getDiscoveredInstagramPostUrls();
    int getInstagramFailedPostCount();
    boolean isIncompleteCompletion();
    String getIncompleteCompletionReason();
    JSONObject checkpointCursor();
    void seedQueueCursor(JSONObject cursor);
    void setIncludeXReposts(boolean enabled);
    void setXSearchExecutionAllowed(boolean enabled, String reason);
}
