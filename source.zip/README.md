# ImgStalker v0.1.58 (59)

## v0.1.58
- Instagram detail traversal is rate-limited in batches of 12 posts instead of queueing all 300 detail pages into one uninterrupted burst.
- After profile discovery completes, the first detail batch waits 15 seconds; later batches wait 5 seconds.
- Main-frame HTTP 429 from Instagram is detected immediately. The failed page is requeued without waiting for 16 empty-media polls.
- 429 recovery applies a run-wide cooldown of 30s, then 60s, then up to 120s for repeated limits.
- Added diagnostics: `SNS_IG_DETAIL_BATCH_QUEUE`, `SNS_IG_DETAIL_BATCH_WAIT`, `SNS_IG_RATE_LIMIT`, `SNS_IG_RATE_LIMIT_WAIT`, and `SNS_IG_RATE_LIMIT_RESUME`.
- Existing 300-post discovery cap, carousel/media extraction, retry behavior, package id, and signing key are retained from v0.1.57.
- versionCode 59 / versionName 0.1.58.

## v0.1.56
- Exact behavior base: v0.1.51.
- Added Instagram detail-page diagnostics only: WebView provider/settings, main-frame HTTP status, DOM/meta/auth/resource snapshots at detail start and empty-media polls 8/16 for the first three posts.
- No Instagram extraction, traversal, retry, carousel, media registration, thumbnail policy, or background behavior is intentionally changed.

## v0.1.51
- Instagram Networkで検出済みの動画候補を、DOM詳細収集開始時刻より前という理由だけで破棄しないよう修正。ReelのMP4本体をVIDEOとして一覧へ渡す。
- Instagramの `video_default_cover_frame` は動画サムネイルとして判定し、独立IMAGEとして一覧へ追加しない。
- Instagram VIDEO登録時に `MEDIA_QUEUED kind=VIDEO` を診断ログへ記録。
- v0.1.50で改善したInstagram巡回・再試行・カルーセル読み込みロジックは変更なし。

## v0.1.50
- Instagram detail traversal no longer lets one failed post block the whole profile.
- A failed carousel/detail load is moved to the back of the detail queue and retried from slide 1 after other queued posts get a turn.
- Instagram retry has no completion/skip cap; the crawler continues cycling unfinished posts until they complete or the user presses Stop.
- Empty-media/reel waits are bounded per visit, then deferred instead of ending analysis.
- Missing/un-clickable Next and slide-change failures get short in-page recovery, then defer/retry rather than completion.
- A first-slide terminal state with multiple loaded media items is treated as ambiguous carousel state and is never accepted as completed; it is retried later.
- Normal single-media/final-slide terminal confirmation uses the v0.1.43-style grace period without a full reload.
- Existing Instagram image/video de-duplication remains based on actual CDN image identity and video asset/path identity, not only slide number.
- Header gear and diagnostic icons retain the slightly reduced visual size while keeping the same 44dp touch targets.

## Package
- versionCode 59 / versionName 0.1.58.
- applicationId and fixed signing key are unchanged.
