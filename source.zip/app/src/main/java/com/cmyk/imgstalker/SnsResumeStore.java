package com.cmyk.imgstalker;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Locale;

/**
 * External SNS resume state stored beside downloaded media.
 *
 * Android 11+ does not allow arbitrary JSON creation in Pictures through MediaStore.Files.
 * v0.1.78 therefore uses the persisted SAF tree selected by the N Explorer.  Reads/writes are
 * deliberately kept off the UI thread by MainActivity.
 */
public final class SnsResumeStore {
    private static final int SCHEMA_VERSION = 1;
    private static final String MIME_JSON = "application/json";

    private SnsResumeStore() { }

    public static final class Target {
        public final SnsAccountManager.Service service;
        public final String accountName;
        public final String categoryName;
        public final String fileName;
        public final String tempFileName;

        Target(SnsAccountManager.Service service, String accountName) {
            this.service = service;
            this.accountName = sanitizeSegment(accountName);
            this.categoryName = service == SnsAccountManager.Service.INSTAGRAM ? "Instagram" : "X";
            String prefix = service == SnsAccountManager.Service.INSTAGRAM ? "is_instagram_" : "is_x_";
            this.fileName = prefix + this.accountName + ".json";
            this.tempFileName = this.fileName + ".tmp";
        }

        public String relativeFolder() {
            return categoryName + "/" + accountName;
        }
    }

    public static final class State {
        public String sourceUrl = "";
        public boolean complete = false;
        public final LinkedHashSet<String> completedInstagramPosts = new LinkedHashSet<>();
        public final LinkedHashSet<String> discoveredInstagramPosts = new LinkedHashSet<>();
        public final ArrayList<MediaItem> mediaItems = new ArrayList<>();
    }

    public static Target targetForUrl(String rawUrl) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) return null;
        try {
            URI uri = new URI(rawUrl.trim());
            String host = uri.getHost();
            if (host == null) return null;
            host = host.toLowerCase(Locale.ROOT);
            String path = uri.getPath() == null ? "" : uri.getPath();
            String[] parts = path.split("/");
            String first = "";
            for (String p : parts) {
                if (p != null && !p.trim().isEmpty()) { first = p.trim(); break; }
            }
            if (first.isEmpty()) return null;
            if (host.equals("instagram.com") || host.endsWith(".instagram.com")) {
                String low = first.toLowerCase(Locale.ROOT);
                if (low.equals("p") || low.equals("reel") || low.equals("reels")
                        || low.equals("explore") || low.equals("accounts") || low.equals("stories")) return null;
                return new Target(SnsAccountManager.Service.INSTAGRAM, first);
            }
            if (host.equals("x.com") || host.endsWith(".x.com")
                    || host.equals("twitter.com") || host.endsWith(".twitter.com")) {
                String low = first.toLowerCase(Locale.ROOT);
                if (low.equals("home") || low.equals("search") || low.equals("explore")
                        || low.equals("notifications") || low.equals("messages") || low.equals("i")
                        || low.equals("settings") || low.equals("compose")) return null;
                return new Target(SnsAccountManager.Service.X, first);
            }
        } catch (Throwable ignored) { }
        return null;
    }

    public static State load(Context context, Target target) {
        if (context == null || target == null) return null;
        Uri tree = usableTree(context);
        if (tree == null) {
            State direct = loadDirectIfReadable(context, target);
            if (direct != null) return direct;
            DiagnosticLog.log("SNS_RESUME_LOAD miss service=" + target.categoryName
                    + " account=" + target.accountName + " reason=no_saf_tree path="
                    + new File(SavePrefs.directory(context), target.relativeFolder() + "/" + target.fileName));
            return null;
        }
        try {
            Uri dir = findTargetDirectory(context, tree, target, false);
            if (dir == null) {
                DiagnosticLog.log("SNS_RESUME_LOAD miss service=" + target.categoryName
                        + " account=" + target.accountName + " reason=folder_missing");
                return null;
            }
            ContentResolver resolver = context.getContentResolver();
            Uri file = findChild(resolver, tree, dir, target.fileName, false);
            boolean tempRecovery = false;
            if (file == null) {
                file = findChild(resolver, tree, dir, target.tempFileName, false);
                tempRecovery = file != null;
            }
            if (file == null) {
                DiagnosticLog.log("SNS_RESUME_LOAD miss service=" + target.categoryName
                        + " account=" + target.accountName + " reason=file_missing");
                return null;
            }
            if (tempRecovery) DiagnosticLog.log("SNS_RESUME_LOAD temp_recovery file=" + target.tempFileName);
            try (InputStream in = resolver.openInputStream(file)) {
                if (in == null) return null;
                String json = readUtf8(in);
                State state = parseStateJson(target, new JSONObject(json));
                if (state == null) {
                    DiagnosticLog.log("SNS_RESUME_LOAD identity_or_schema_mismatch file=" + target.fileName);
                    return null;
                }
                DiagnosticLog.log("SNS_RESUME_LOAD ok service=" + target.categoryName
                        + " account=" + target.accountName
                        + " complete=" + state.complete
                        + " media=" + state.mediaItems.size()
                        + " igCompleted=" + state.completedInstagramPosts.size()
                        + " igDiscovered=" + state.discoveredInstagramPosts.size()
                        + " backend=saf uri=" + file);
                return state;
            }
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_LOAD_FAIL file=" + target.fileName + " backend=saf", t);
            return null;
        }
    }

    public static boolean write(Context context, Target target, State state) {
        if (context == null || target == null || state == null) return false;
        Uri tree = usableTree(context);
        if (tree == null) {
            DiagnosticLog.log("SNS_RESUME_WRITE_DEFERRED file=" + target.fileName
                    + " reason=no_saf_tree path=" + SavePrefs.directory(context).getAbsolutePath());
            return false;
        }
        try {
            ContentResolver resolver = context.getContentResolver();
            Uri dir = findTargetDirectory(context, tree, target, true);
            if (dir == null) throw new IllegalStateException("resume directory unavailable");
            byte[] bytes = stateToJson(target, state).toString(2).getBytes(StandardCharsets.UTF_8);

            Uri oldTemp = findChild(resolver, tree, dir, target.tempFileName, false);
            if (oldTemp != null) DocumentsContract.deleteDocument(resolver, oldTemp);
            Uri temp = DocumentsContract.createDocument(resolver, dir, MIME_JSON, target.tempFileName);
            if (temp == null) throw new IllegalStateException("resume temp create failed");
            writeBytes(resolver, temp, bytes);

            Uri oldFinal = findChild(resolver, tree, dir, target.fileName, false);
            if (oldFinal != null) DocumentsContract.deleteDocument(resolver, oldFinal);
            Uri renamed = null;
            try { renamed = DocumentsContract.renameDocument(resolver, temp, target.fileName); }
            catch (Throwable ignored) { }
            if (renamed == null) {
                Uri finalUri = DocumentsContract.createDocument(resolver, dir, MIME_JSON, target.fileName);
                if (finalUri == null) throw new IllegalStateException("resume final create failed");
                writeBytes(resolver, finalUri, bytes);
                try { DocumentsContract.deleteDocument(resolver, temp); } catch (Throwable ignored) { }
            }
            DiagnosticLog.log("SNS_RESUME_WRITE ok service=" + target.categoryName
                    + " account=" + target.accountName
                    + " complete=" + state.complete
                    + " media=" + state.mediaItems.size()
                    + " igCompleted=" + state.completedInstagramPosts.size()
                    + " igDiscovered=" + state.discoveredInstagramPosts.size()
                    + " bytes=" + bytes.length + " backend=saf file=" + target.fileName);
            return true;
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_WRITE_FAIL file=" + target.fileName + " backend=saf", t);
            return false;
        }
    }

    public static boolean delete(Context context, Target target) {
        if (context == null || target == null) return false;
        Uri tree = usableTree(context);
        if (tree == null) return false;
        boolean any = false;
        try {
            ContentResolver resolver = context.getContentResolver();
            Uri dir = findTargetDirectory(context, tree, target, false);
            if (dir == null) return false;
            for (String name : new String[]{target.fileName, target.tempFileName}) {
                Uri file = findChild(resolver, tree, dir, name, false);
                if (file != null) any |= DocumentsContract.deleteDocument(resolver, file);
            }
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_DELETE_FAIL file=" + target.fileName, t);
        }
        return any;
    }

    private static Uri usableTree(Context context) {
        if (!SavePrefs.hasTreeAccess(context)) return null;
        return SavePrefs.treeUri(context);
    }

    private static Uri findTargetDirectory(Context context, Uri tree, Target target, boolean create) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        String rootId = DocumentsContract.getTreeDocumentId(tree);
        Uri current = DocumentsContract.buildDocumentUriUsingTree(tree, rootId);
        for (String segment : target.relativeFolder().split("/")) {
            if (segment == null || segment.trim().isEmpty()) continue;
            Uri next = findChild(resolver, tree, current, segment, true);
            if (next == null && create) {
                next = DocumentsContract.createDocument(resolver, current,
                        DocumentsContract.Document.MIME_TYPE_DIR, segment);
            }
            if (next == null) return null;
            current = next;
        }
        return current;
    }

    private static Uri findChild(ContentResolver resolver, Uri tree, Uri parent,
                                 String displayName, boolean directoryOnly) {
        if (resolver == null || tree == null || parent == null || displayName == null) return null;
        try {
            String parentId = DocumentsContract.getDocumentId(parent);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
            String[] projection = new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
            };
            try (Cursor c = resolver.query(children, projection, null, null, null)) {
                if (c == null) return null;
                int idCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                while (c.moveToNext()) {
                    String name = nameCol >= 0 ? c.getString(nameCol) : null;
                    if (!displayName.equals(name)) continue;
                    String mime = mimeCol >= 0 ? c.getString(mimeCol) : null;
                    if (directoryOnly && !DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) continue;
                    String id = idCol >= 0 ? c.getString(idCol) : null;
                    if (id != null) return DocumentsContract.buildDocumentUriUsingTree(tree, id);
                }
            }
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_SAF_FIND_FAIL name=" + displayName, t);
        }
        return null;
    }

    private static void writeBytes(ContentResolver resolver, Uri uri, byte[] bytes) throws Exception {
        try (OutputStream out = resolver.openOutputStream(uri, "wt")) {
            if (out == null) throw new IllegalStateException("resume output null");
            out.write(bytes);
            out.flush();
        }
    }

    private static String readUtf8(InputStream in) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        char[] buf = new char[8192];
        int n;
        while ((n = reader.read(buf)) >= 0) sb.append(buf, 0, n);
        return sb.toString();
    }

    /** Compatibility read only; avoids throwing on scoped-storage paths. */
    private static State loadDirectIfReadable(Context context, Target target) {
        File file = new File(new File(SavePrefs.directory(context), target.relativeFolder()), target.fileName);
        if (!file.isFile() || !file.canRead()) return null;
        try (InputStream in = new FileInputStream(file)) {
            State state = parseStateJson(target, new JSONObject(readUtf8(in)));
            if (state != null) DiagnosticLog.log("SNS_RESUME_LOAD direct_ok file=" + file.getAbsolutePath());
            return state;
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_LOAD_DIRECT_FAIL file=" + file.getAbsolutePath(), t);
            return null;
        }
    }

    private static JSONObject stateToJson(Target target, State state) throws Exception {
        JSONObject obj = new JSONObject();
        obj.put("schema", SCHEMA_VERSION);
        obj.put("service", target.categoryName);
        obj.put("account", target.accountName);
        obj.put("source_url", state.sourceUrl == null ? "" : state.sourceUrl);
        obj.put("complete", state.complete);
        obj.put("updated_at", System.currentTimeMillis());
        obj.put("instagram_completed", toJsonArray(state.completedInstagramPosts));
        obj.put("instagram_discovered", toJsonArray(state.discoveredInstagramPosts));
        JSONArray media = new JSONArray();
        for (MediaItem item : state.mediaItems) {
            if (item == null || item.url == null || item.url.trim().isEmpty()) continue;
            JSONObject m = new JSONObject();
            m.put("url", item.url);
            m.put("referrer", item.referrer == null ? "" : item.referrer);
            m.put("kind", item.kind.name());
            m.put("width", item.width);
            m.put("height", item.height);
            m.put("duration_ms", item.durationMs);
            m.put("dedup_key", item.dedupKey == null ? "" : item.dedupKey);
            m.put("display_order", item.displayOrder);
            media.put(m);
        }
        obj.put("media", media);
        return obj;
    }

    private static State parseStateJson(Target target, JSONObject obj) {
        if (obj == null || obj.optInt("schema", 0) != SCHEMA_VERSION) return null;
        String service = obj.optString("service", "");
        String account = sanitizeSegment(obj.optString("account", ""));
        if (!target.categoryName.equalsIgnoreCase(service) || !target.accountName.equals(account)) return null;
        State state = new State();
        state.sourceUrl = obj.optString("source_url", "");
        state.complete = obj.optBoolean("complete", false);
        addStrings(obj.optJSONArray("instagram_completed"), state.completedInstagramPosts);
        addStrings(obj.optJSONArray("instagram_discovered"), state.discoveredInstagramPosts);
        JSONArray media = obj.optJSONArray("media");
        if (media != null) {
            for (int i = 0; i < media.length(); i++) {
                JSONObject m = media.optJSONObject(i);
                if (m == null) continue;
                String url = m.optString("url", "");
                String ref = m.optString("referrer", "");
                String kindName = m.optString("kind", "");
                if (url.isEmpty() || kindName.isEmpty()) continue;
                try {
                    MediaItem.Kind kind = MediaItem.Kind.valueOf(kindName);
                    state.mediaItems.add(new MediaItem(url, ref, kind, false,
                            Math.max(0, m.optInt("width", 0)),
                            Math.max(0, m.optInt("height", 0)),
                            Math.max(0L, m.optLong("duration_ms", 0L)),
                            m.optString("dedup_key", ""),
                            m.has("display_order") ? m.optLong("display_order", Long.MAX_VALUE) : Long.MAX_VALUE));
                } catch (Throwable ignored) { }
            }
        }
        return state;
    }

    private static void addStrings(JSONArray array, Collection<String> out) {
        if (array == null || out == null) return;
        for (int i = 0; i < array.length(); i++) {
            String value = array.optString(i, "").trim();
            if (!value.isEmpty()) out.add(value);
        }
    }

    private static JSONArray toJsonArray(Collection<String> values) {
        JSONArray array = new JSONArray();
        if (values != null) {
            for (String value : values) {
                if (value != null && !value.trim().isEmpty()) array.put(value);
            }
        }
        return array;
    }

    private static String sanitizeSegment(String raw) {
        String value = raw == null ? "" : raw.trim();
        value = value.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
        value = value.replaceAll("\\s+", "_");
        while (value.startsWith(".")) value = value.substring(1);
        while (value.endsWith(".")) value = value.substring(0, value.length() - 1);
        if (value.length() > 80) value = value.substring(0, 80);
        return value.isEmpty() ? "account" : value;
    }
}
