package com.cmyk.imgstalker;
import java.util.Collection;
import java.util.List;
import android.webkit.WebView;
import org.json.JSONObject;

/** X v0.1.135 is never edited or subclassed. All calls delegate unchanged. */
final class XCrawlerAdapter implements ModeCrawler {
    private final CrawlerEngine core;
    XCrawlerAdapter(WebView view, CrawlerEngine.Listener listener) { core = new CrawlerEngine(view, listener); }
    @Override public void start(String url, boolean pages, boolean details, boolean intelligent, boolean images, boolean videos, int px) {
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.X) { core.cancel(); throw new IllegalArgumentException("X crawler refused non-X host"); }
        core.start(url, pages, details, intelligent, images, videos, px);
    }
    @Override public void cancel(){core.cancel();}
    @Override public void requestGracefulStop(){core.requestGracefulStop();}
    @Override public boolean recoverFromStall(){return core.recoverFromStall();}
    @Override public boolean hasPendingWork(){return core.hasPendingWork();}
    @Override public String progressSnapshot(){return core.progressSnapshot();}
    @Override public void seedExternalResumeMedia(List<MediaItem> items){core.seedExternalResumeMedia(items);}
    @Override public void seedContinuationResults(List<MediaItem> items){core.seedContinuationResults(items);}
    @Override public void seedInstagramContinuationState(Collection<String> done, Collection<String> discovered){core.seedInstagramContinuationState(done, discovered);}
    @Override public List<String> getCompletedInstagramPostUrls(){return core.getCompletedInstagramPostUrls();}
    @Override public List<String> getDiscoveredInstagramPostUrls(){return core.getDiscoveredInstagramPostUrls();}
    @Override public int getInstagramFailedPostCount(){return core.getInstagramFailedPostCount();}
    @Override public boolean isIncompleteCompletion(){return core.isIncompleteCompletion();}
    @Override public String getIncompleteCompletionReason(){return core.getIncompleteCompletionReason();}
    @Override public JSONObject checkpointCursor(){return core.checkpointCursor();}
    @Override public void seedQueueCursor(JSONObject cursor){core.seedQueueCursor(cursor);}
    @Override public void setIncludeXReposts(boolean enabled){core.setIncludeXReposts(enabled);}
    @Override public void setXSearchExecutionAllowed(boolean enabled, String reason){core.setXSearchExecutionAllowed(enabled, reason);}
}
