# ImgStalker v0.1.72 (73)

## Base
- Functional base: v0.1.71 (72).
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.

## Instagram architecture rebuild
- Instagram profile discovery and post-media acquisition are now separate responsibilities.
- The profile WebView remains on the profile grid during the normal acquisition path; it is no longer navigated into each post and back again.
- Visible `/p/`, `/reel/`, and `/tv/` URLs are discovered in profile order and queued one at a time.
- A dedicated `InstagramMediaResolver` resolves each canonical post URL from inside the already-authenticated Instagram WebView context using same-origin `fetch()` with the active session.
- The resolver parses post-owned image/video/stream candidates from the returned post HTML/serialized metadata and optionally the Instagram embed representation without replacing the profile document.
- Regular post/carousel images and videos are emitted directly from resolver results.
- Reel cover/poster images remain excluded as standalone IMAGE results; Reel video/stream media are retained.

## Ordered inline fallback
- The normal path still resolves a post without leaving the profile grid.
- `videoHint` is no longer treated as a completion blocker for regular `/p/` posts when usable media candidates already exist; Instagram HTML frequently exposes that hint on still-image posts.
- Reel completion still requires playable video/stream media, and a carousel with only one candidate is still treated as incomplete.
- An incomplete resolver result is handled immediately with the existing browser-style `SPA_OPEN -> carousel traversal -> SPA_CLOSE` path before discovery advances to a newer post.
- A first browser failure returns to the profile and retries the same post once inline; a second failure skips that post and continues, preventing a large tail-retry backlog.

## Discovery / continuation
- Resolver-complete posts proceed without detail-page round trips; only genuinely incomplete posts use an inline browser fallback.
- Completed/discovered post URLs still persist across continuation reloads.
- The existing 300-post session cap remains.
- Result ordering follows canonical profile post order and per-post media order because fallback work is completed before the next post is selected.

## Video thumbnail path
- Instagram video thumbnails no longer pass signed CDN URLs directly to `MediaMetadataRetriever`.
- The visible-cell thumbnail loader downloads the MP4 with the active Cookie/Referer/User-Agent policy into a bounded temporary cache file, then extracts a local frame and deletes the temporary file.
- The standalone video-cover-as-IMAGE exclusion remains unchanged.

## Diagnostics
- `SNS_IG_RESOLVER_START`: canonical post URL handed from discovery to the resolver.
- `SNS_IG_RESOLVER_DONE`: resolver source, candidate counts, and emitted media counts.
- `SNS_IG_RESOLVER_INLINE_FALLBACK`: weak resolver result is being resolved immediately through browser traversal.
- `SNS_IG_STREAM_RETRY_INLINE`: the same fallback post is being retried once before discovery continues.
- `VIDEO_THUMB_HTTP`: authenticated MP4 download used for local frame extraction.
- `VIDEO_THUMB_OK source=local_http`: local MP4 frame extraction succeeded.

## Package
- versionCode: 73
- versionName: 0.1.72
