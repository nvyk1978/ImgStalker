# ImgStalker v0.1.38 (39)

## v0.1.38
- Instagram profile grid is discovery-only; post URLs are canonicalized and queued directly from readiness/scroll probes.
- Instagram post detail traversal now drives carousel collection. Hidden/preloaded carousel images can be collected from DOM and visible next controls are clicked with label/geometry/hit-test fallbacks.
- Instagram detail images with DOM-known dimensions are accepted without mandatory HttpURLConnection size probing.
- Instagram MP4 DASH range URLs remove bytestart/byteend, audio-only representations are excluded, and network video capture is limited to active post detail pages.
- Instagram completion waits for a network quiet period before ANALYZE_DONE.
- Incomplete detail budget/timeouts/carousel/DNS/post-queue states remain visible through the trailing 「続き」 reload cell.
- Continuation preserves completed Instagram post IDs while revisiting partial posts and deduplicating already-acquired media.
- versionCode 39 / versionName 0.1.38. applicationId and fixed signing are unchanged.
