#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/com/cmyk/imgstalker/NavigationIconLoader.java').read_text()
u=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
c=Path('app/src/main/java/com/cmyk/imgstalker/NavigationMediaCounts.java').read_text()
assert 'Mode.INSTAGRAM.ordinal()) view.setImageResource(R.drawable.ic_nav_instagram)' in s
assert 'Mode.THREADS.ordinal()) view.setImageResource(R.drawable.ic_nav_threads)' in s
assert 'view.setImageBitmap(cached)' in s and 'publishProfileAvatar(key, found)' in s
assert 'NavigationMediaCounts.forUrlHistory(' in u and 'NavigationMediaCounts.withFiles(' in u
assert u.index('NavigationMediaCounts.forUrlHistory(') < u.index('NavigationMediaCounts.withFiles(')
assert 'NavigationMediaCounts.hasUnknown(shown)' in u and 'postDelayed(loadCounts[0]' in u
assert 'DiscoveredMediaLedger.merge' in c and 'SnsSavedLedgerStore.load' in c
assert 'private final Runnable snsAvatarProbeTick' in u
assert 'navigationIconHandler.postDelayed(snsAvatarProbeTick, 250L)' in u
assert 'DiagnosticLog.clear()' in u and 'LOG_RESET_BEFORE_PAGE_LOAD' in u
print('PASS: service fallback icons, live avatar replacement, JSON-first navigation stats, retry & retained media history')
PY
node tests/sns_avatar_probe_test.cjs
