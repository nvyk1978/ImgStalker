package com.cmyk.imgstalker;
import java.util.List;
interface ModeDownloader {
    void download(List<MediaItem> items, String title, String category, String account);
    void cancel();
}
