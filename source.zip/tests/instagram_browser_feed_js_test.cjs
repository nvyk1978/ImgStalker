const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const source = fs.readFileSync('app/src/main/assets/instagram_browser_feed.js', 'utf8');
const responseText = JSON.stringify({data:{user:{edge_owner_to_timeline_media:{edges:[{node:{shortcode:'AAbbcc999',display_url:'https://scontent.cdninstagram.com/a.jpg'}}]}}}});
function contextFor(status, body) {
 const links=[{getAttribute(){return '/p/AAbbcc999/'}},{getAttribute(){return '/reel/GGHHii111/'}}];
 class FakeXhr {
  constructor(){this.listeners={}; this.status=status;this.responseText=body;}
  open(){} send(){} addEventListener(n,cb){this.listeners[n]=cb;}
 }
 const ctx={URL, Promise, XMLHttpRequest:FakeXhr, location:{hostname:'www.instagram.com',href:'https://www.instagram.com/example/',pathname:'/example/'}, document:{querySelectorAll:()=>links, scrollingElement:{scrollTop:500,scrollHeight:1200,clientHeight:600}},
  fetch:async()=>({status,clone(){return {text:async()=>body}}}), window:{}};
 ctx.window.fetch=ctx.fetch;
 vm.createContext(ctx);
 vm.runInContext(source,ctx);
 return ctx;
}
(async()=>{
 let ctx=contextFor(200,responseText);
 const returned=await ctx.window.fetch('/api/graphql');
 assert.equal(returned.status,200);
 await new Promise(r=>setImmediate(r));
 let snap=JSON.parse(ctx.window.__imgStalkerFeedSnapshot());
 assert.equal(snap.responses.length,1);
 assert.ok(snap.responses[0].includes('AAbbcc999'));
 assert.equal(snap.links.length,2);
 assert.equal(snap.blocked,'');
 assert.equal(JSON.parse(ctx.window.__imgStalkerFeedSnapshot()).responses.length,0);
 ctx=contextFor(400,'{"message":"","spam":true,"status":"fail"}');
 await ctx.window.fetch('/api/graphql');
 await new Promise(r=>setImmediate(r));
 snap=JSON.parse(ctx.window.__imgStalkerFeedSnapshot());
 assert.equal(snap.blocked,'spam');
 assert.equal(snap.responses.length,0);
 ctx=contextFor(401,'{"require_login":true,"status":"fail"}');
 await ctx.window.fetch('/api/graphql'); await new Promise(r=>setImmediate(r));
 assert.equal(JSON.parse(ctx.window.__imgStalkerFeedSnapshot()).blocked,'login');
 ctx=contextFor(429,'{"message":"rate limit"}');
 await ctx.window.fetch('/api/graphql'); await new Promise(r=>setImmediate(r));
 assert.equal(JSON.parse(ctx.window.__imgStalkerFeedSnapshot()).blocked,'rate_limited');
 console.log('PASS: browser first-party fetch responses, DOM links, queue draining, spam and login gates');
})().catch(e=>{console.error(e);process.exit(1)})
