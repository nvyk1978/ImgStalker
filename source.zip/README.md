# ImgStalker 0.1.5 (6)

WebページをWebViewで実際に読み込み、画像・動画・ページ送り・画像付き詳細リンクを追跡して一括保存する個人用Androidアプリ。

## 初回実装
- URL直接入力
- Android共有メニューからURL受け取り
- JavaScript実行後DOMを解析
- img/currentSrc/src/srcset/data-src/data-original/data-lazy-src
- CSS background-image
- og:image / twitter:image
- video/source / og:video
- MP4 / WebM / MOV / M4V / 3GP直接ファイル
- HLS(.m3u8) / DASH(.mpd)は検出表示のみ（0.1.2では結合保存しない）
- rel=next、Next/次へ、pagination内数字リンクを追跡
- 画像を含むリンク先を詳細ページ候補として追跡
- lazy-load対策としてページを複数回自動スクロール
- 同一ホスト内のみ自動巡回
- URL重複除外
- 画像・動画の選択保存
- Downloads/ImgStalker/<ページタイトル_日時>/images と /videos に一括保存
- Cookie / Referer / User-Agentを引き継いで直接ファイルを取得

## N規格
- BG #303030
- D.Gray #252020
- Gray #454040
- L.Gray #656060
- Blue #223355
- L.Blue #445577
- Orange #775500
- N White #A9A999（非テキストUI）
- 通常テキスト #FFFFFF
- NToggleSwitch同系統のカプセル型トグル

## ビルド
リポジトリ直下に `source.zip` を置き、`.github/workflows/ImgStalker.yml` として同梱のworkflowを配置する。
workflow_dispatch または source.zip 更新でビルドされる。

APK出力名: `ImgStalker-v0.1.5.apk`

## 署名
`keystore/imgstalker.jks` を固定署名として使用する。今後の上書きインストールのため、このkeystoreを変更・紛失しないこと。

## 0.1.5の制限
- DRM保護コンテンツの回避は行わない。
- blob: URL、MediaSource、暗号化ストリームは直接保存対象外。
- HLS/DASHは検出のみ。
- onclickだけで遷移しhrefを持たない独自ギャラリーはサイト依存で未検出の場合がある。
- ログイン済みCookieはWebViewから直接ファイル取得時に引き継ぐが、サイト固有の追加認証ヘッダが必要な場合は失敗することがある。


## 0.1.1 修正
- Android ListViewに存在しない setDividerColor(int) 呼び出しを修正。ColorDrawableを setDivider() へ渡す実装に変更。


## 0.1.2 追加
- 解析結果の画像行にサムネイル表示を追加。Cookie / Referer / User-Agentを引き継いで非同期読込し、メモリキャッシュする。
- 動画・ストリーム行では画像サムネイル欄を表示しない。
- 右上の三点メニューから「診断ログ」を表示可能。
- 診断ログにアプリ起動、解析条件、ページ巡回、DOM解析、メディア検出、追跡キュー、WebView読込エラー、ダウンロードHTTP応答、保存成否、サムネイル失敗、未処理例外を記録。
- 診断ログはコピー／共有可能。端末・Android・アプリバージョンをレポート先頭に付加。


## 0.1.3 変更
- 題字と三点メニューを従来位置から200dp下へ移動。三点メニューは44dpの丸型アイコン化。
- URL入力欄右端に×アイコンを追加し、タップでURL全文をクリア。
- 取得画像解像度フィールドを追加。小=640px / 中=1280px / 大=1920px のプリセットと64〜8192pxの直接入力に対応。
- srcset/data-srcsetの候補から、指定解像度以上で最小の候補を優先し、無ければ最大候補を採用。
- 画像サムネイルタップで元画像をWebView表示。選択/解除はチェックボックスのタップだけに限定。
- 診断ログ画面をPriceRec系の「ログ消去 / コピー / 閉じる」構成へ変更。
- ダウンロード処理を強化。WebView相当User-Agent、Cookie、Refererを利用し、リダイレクト追従、Content-Type検査、MediaStore URI、書込バイト数、公開結果まで診断ログへ記録。

## 0.1.4 変更
- 題字と丸型三点メニューの縦位置を再調整。元位置から100dp下（0.1.3より100dp上）へ変更。
- 診断ログ下部の「ログ消去 / コピー / 閉じる」をPriceRec 0.1.81と同じ48dp操作スロット＋26dp極薄カプセル描画へ移植。左端ログ消去、右側コピー/閉じるの配置も同一化。
- 新しいURLで解析を開始する際、前回の診断ログを一度消去してから新URL分のログを記録。再解析でURLが同一なら既存ログを継続。
- 詳細リンク追跡でサイトトップ、ナビ系URL、重複URLを誤って大量キュー投入しにくいよう候補判定を強化。キューログは実際に追加された場合だけ記録。
- 広告/同期/トラッキング系の画像URLを検出結果から除外し、1〜2px級トラッカーもDOM収集時に除外。
- 解析途中でも選択済みメディアがあれば保存可能。保存開始時はクローラを停止して、その時点までの選択項目を保存する。
- サムネイル取得ログを強化。HTTPコード、Content-Type、Content-Length、最終URL、Referer、Cookie有無、例外メッセージ、デコード結果を記録。
- サムネイル取得上限を12MBから32MBへ拡張し、WebView相当User-Agentと画像向けHTTPヘッダを利用。


## 0.1.5 変更

- 画像保存時のHTTP取得条件を、実機で200取得できているサムネイル取得と同じ条件へ統一。画像保存だけは従来の追加ヘッダー／手動リダイレクト処理を使わない。
- 画像保存がHTTP 403になった場合は同条件で1回だけ再試行し、`DOWNLOAD_RETRY` と再試行結果を診断ログへ記録。
- 診断ログ画面に「.txtを共有」を追加。左端は「ログ消去」、右端に「.txtを共有 / コピー / 閉じる」を詰めて配置。
- 診断ログ全文は `ImgStalker_diagnostic_yyyyMMdd_HHmmss.txt` としてキャッシュへ書き出し、read-onlyのcontent URIでAndroid共有シートへ渡す。
