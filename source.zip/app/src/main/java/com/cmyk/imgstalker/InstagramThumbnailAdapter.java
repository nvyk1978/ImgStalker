package com.cmyk.imgstalker;
import android.content.Context;
import android.widget.ImageView;
final class InstagramThumbnailAdapter implements ModeThumbnailLoader {
    private final InstagramThumbnailLoader core;
    InstagramThumbnailAdapter(Context context, Runnable onMetadata) {core=new InstagramThumbnailLoader(context,onMetadata);}
    @Override public void prefetch(MediaItem item){core.prefetch(item);}
    @Override public boolean isCachedOrPending(MediaItem item){return core.isCachedOrPending(item);}
    @Override public int pendingCount(){return core.pendingCount();}
    @Override public void load(ImageView view, MediaItem item){core.load(view,item);}
    @Override public void cancelPending(){core.cancelPending();}
    @Override public void clearCache(){core.clearCache();}
    @Override public void shutdown(){core.shutdown();}
}
