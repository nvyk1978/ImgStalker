#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
import hashlib,re
root=Path('app/src/main/java/com/cmyk/imgstalker')
expected={
 'InstagramCrawlerEngine.java':'d5091a03e4fd4a5fbe1f35f4538ad352bd98729aad331b31db98975826bb0921',
 'InstagramInstagramMediaResolver.java':'5d8894a16035f014cb8faffcaaa625ac7dd2410248ad111983428d7d5b352a06',
}
for name,digest in expected.items():
 f=root/name
 assert hashlib.sha256(f.read_bytes()).hexdigest()==digest, f'Version-0.1.84 media flow modified unexpectedly: {name}'
c=(root/'InstagramCrawlerEngine.java').read_text()
p=(root/'InstagramInstagramSourcePipeline.java').read_text()
r=(root/'InstagramCrawlerAdapter.java').read_text()
assert 'fallback=source_only browser=false' in c
assert 'startInstagramInstagramSourcePipeline(normalized)' in c
assert 'InstagramSessionCookies.getCookie(' in c
assert 'core = new InstagramCrawlerEngine(view, listener)' in r
assert 'AnalysisModeRouter.Mode.INSTAGRAM' in r
assert 'SNS_IG_SOURCE_TIMELINE_RESOLVE' in p
assert 'video_versions' in p and 'carousel_media' in p
assert 'con.setInstanceFollowRedirects(true)' in p
assert "versionCode 143" in Path('app/build.gradle').read_text()
assert "versionName '0.1.142'" in Path('app/build.gradle').read_text()
assert 'profileRequestWithBackoff' in p and 'SNS_IG_SOURCE_PROFILE_PRE_DISCOVERY' in p
print('PASS: 0.1.84 crawler/resolver preserved; Instagram-only discovery/429 policy updated; mode isolation preserved')
PY
sha256sum -c mode-locks.sha256
