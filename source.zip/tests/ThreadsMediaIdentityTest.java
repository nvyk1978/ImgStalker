package com.cmyk.imgstalker;
public final class ThreadsMediaIdentityTest {
    private static void check(boolean b){if(!b)throw new AssertionError("Threads saved key migration failed");}
    public static void main(String[] a){
        String ref="https://www.threads.com/@reika_shimo/post/Example123";
        String m1="https://instagram.fhnd2-1.fna.fbcdn.net/v/t51.1/example_n.jpg?oh=OLD&oe=AAA";
        String m2="https://instagram.fhnd2-2.fna.fbcdn.net/v/t51.1/example_n.jpg?oh=NEW&oe=BBB";
        String k1=ThreadsMediaIdentity.key(MediaItem.Kind.IMAGE,m1,ref);
        String k2=ThreadsMediaIdentity.key(MediaItem.Kind.IMAGE,m2,ref+"?hl=ja");
        check(!k1.isEmpty()&&k1.equals(k2));
        check(!k1.equals(ThreadsMediaIdentity.key(MediaItem.Kind.VIDEO,m2,ref)));
        check(!k1.equals(ThreadsMediaIdentity.key(MediaItem.Kind.IMAGE,m2,ref.replace("Example123","Example124"))));
        check(ThreadsMediaIdentity.key(MediaItem.Kind.IMAGE,"blob:aaa",ref).isEmpty());
        System.out.println("PASS: Threads stable media identity, CDN rotation, signature changes, type and post isolation");
    }
}
