package com.cmyk.imgstalker;

import android.content.Context;
import android.content.UriPermission;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;

import java.io.File;

public final class SavePrefs {
    private static final String PREFS = "imgstalker_save_prefs";
    private static final String KEY_PATH = "save_directory";
    private static final String KEY_TREE_URI = "save_tree_uri";

    private SavePrefs() { }

    public static File defaultDirectory() {
        return new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "ImgStalker");
    }

    public static File directory(Context context) {
        String stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PATH, null);
        if (stored == null || stored.trim().isEmpty()) return defaultDirectory();
        return new File(stored);
    }

    /** Set a path without a SAF grant. Any older grant is cleared to avoid path/URI mismatch. */
    public static void setDirectory(Context context, File directory) {
        if (directory == null) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_PATH, directory.getAbsolutePath())
                .remove(KEY_TREE_URI)
                .apply();
    }

    /** Persist the path and the matching SAF tree URI as one atomic preference update. */
    public static void setDirectoryWithTree(Context context, File directory, Uri treeUri) {
        if (directory == null || treeUri == null) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_PATH, directory.getAbsolutePath())
                .putString(KEY_TREE_URI, treeUri.toString())
                .apply();
    }

    public static Uri treeUri(Context context) {
        String raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TREE_URI, null);
        if (raw == null || raw.trim().isEmpty()) return null;
        try { return Uri.parse(raw); } catch (Throwable ignored) { return null; }
    }

    public static boolean hasTreeAccess(Context context) {
        Uri wanted = treeUri(context);
        if (wanted == null) return false;
        try {
            for (UriPermission p : context.getContentResolver().getPersistedUriPermissions()) {
                if (wanted.equals(p.getUri()) && p.isReadPermission() && p.isWritePermission()) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    /** Convert Android's external-storage tree URI back to a filesystem location for the N explorer. */
    public static File fileFromTreeUri(Uri treeUri) {
        if (treeUri == null || !"com.android.externalstorage.documents".equals(treeUri.getAuthority())) return null;
        try {
            String id = DocumentsContract.getTreeDocumentId(treeUri);
            if (id == null || id.trim().isEmpty()) return null;
            int colon = id.indexOf(':');
            String volume = colon >= 0 ? id.substring(0, colon) : id;
            String relative = colon >= 0 ? id.substring(colon + 1) : "";
            File root;
            if ("primary".equalsIgnoreCase(volume)) root = Environment.getExternalStorageDirectory();
            else root = new File("/storage", volume);
            return relative.isEmpty() ? root : new File(root, relative);
        } catch (Throwable ignored) {
            return null;
        }
    }

    public static void reset(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(KEY_PATH)
                .remove(KEY_TREE_URI)
                .apply();
    }
}
