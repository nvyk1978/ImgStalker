package com.cmyk.imgstalker;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Instagram source-first crawler.
 *
 * This pipeline intentionally does not navigate, scroll or click an Instagram WebView.
 * Discovery and post resolution run as two independent producer/consumer stages:
 *
 *   profile feed -> ordered post queue -> media-info resolver -> MediaSet
 *
 * Browser state is used only as an authentication source (CookieManager is sampled by the
 * caller before start).  A 429 never triggers an immediate retry storm: all workers share one
 * request gate and honor Retry-After when supplied.  Posts that still fail after one deferred
 * retry are reported as skipped so a later ImgStalker resume can retry only those posts.
 */
final class InstagramSourcePipeline {
    interface Listener {
        void onProfileMeta(String username, int expectedPosts);
        void onPostDiscovered(int index, String postUrl);
        void onPostResolved(String postUrl, List<ResolvedMedia> media);
        void onPostRetry(String postUrl, int attempt, String reason, long delayMs);
        void onPostSkipped(String postUrl, String reason);
        void onRateLimited(String scope, int statusCode, long waitMs);
        void onComplete(int discovered, int resolved, int skipped, int expectedPosts, boolean countMatched);
        void onFatal(String message);
    }

    static final class ResolvedMedia {
        final MediaItem.Kind kind;
        final String url;
        final int width;
        final int height;

        ResolvedMedia(MediaItem.Kind kind, String url, int width, int height) {
            this.kind = kind;
            this.url = url == null ? "" : url;
            this.width = Math.max(0, width);
            this.height = Math.max(0, height);
        }
    }

    private static final class PostTask {
        static final PostTask END = new PostTask("", true);
        final String url;
        final boolean end;

        PostTask(String url) { this(url, false); }
        private PostTask(String url, boolean end) {
            this.url = url == null ? "" : url;
            this.end = end;
        }
    }

    private static final class HttpResult {
        final int code;
        final String body;
        final long retryAfterMs;

        HttpResult(int code, String body, long retryAfterMs) {
            this.code = code;
            this.body = body == null ? "" : body;
            this.retryAfterMs = Math.max(0L, retryAfterMs);
        }
    }

    private static final class ResolveResult {
        final boolean ok;
        final boolean rateLimited;
        final int statusCode;
        final long retryAfterMs;
        final String reason;
        final List<ResolvedMedia> media;

        private ResolveResult(boolean ok, boolean rateLimited, int statusCode, long retryAfterMs,
                              String reason, List<ResolvedMedia> media) {
            this.ok = ok;
            this.rateLimited = rateLimited;
            this.statusCode = statusCode;
            this.retryAfterMs = retryAfterMs;
            this.reason = reason == null ? "" : reason;
            this.media = media == null ? Collections.emptyList() : media;
        }

        static ResolveResult ok(List<ResolvedMedia> media) {
            return new ResolveResult(true, false, 200, 0L, "", media);
        }

        static ResolveResult fail(String reason, int statusCode) {
            return new ResolveResult(false, false, statusCode, 0L, reason, Collections.emptyList());
        }

        static ResolveResult limited(int statusCode, long retryAfterMs, String reason) {
            return new ResolveResult(false, true, statusCode, retryAfterMs, reason, Collections.emptyList());
        }
    }

    private static final String IG_APP_ID = "936619743392459";
    private static final String IG_ASBD_ID = "129477";
    private static final int PAGE_SIZE = 12;
    private static final long PAGE_PACE_MS = 650L;
    private static final long POST_PACE_MS = 550L;
    private static final long FALLBACK_PACE_MS = 300L;
    private static final long DEFAULT_429_WAIT_MS = 45000L;
    private static final long MAX_429_WAIT_MS = 120000L;
    private static final int POST_RETRY_LIMIT = 1; // first pass + one deferred retry

    private final Listener listener;
    private final String cookie;
    private final String userAgent;
    private final String csrf;
    private final ExecutorService discoveryExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService resolverExecutor = Executors.newSingleThreadExecutor();
    private final LinkedBlockingQueue<PostTask> postQueue = new LinkedBlockingQueue<>();
    private final LinkedHashSet<String> discoveredUrls = new LinkedHashSet<>();
    private final Set<String> completedSeed = Collections.synchronizedSet(new HashSet<>());
    private final List<String> retryQueue = Collections.synchronizedList(new ArrayList<>());
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private final AtomicBoolean active = new AtomicBoolean(false);
    private final AtomicBoolean discoveryDone = new AtomicBoolean(false);
    private final AtomicBoolean fatal = new AtomicBoolean(false);
    private final AtomicLong requestGateUntil = new AtomicLong(0L);

    private volatile int expectedPosts = 0;
    private volatile int resolvedPosts = 0;
    private volatile int skippedPosts = 0;
    private volatile int targetLimit = 300;
    private volatile boolean followPagination = true;
    private volatile boolean resolveDetails = true;
    private volatile String username = "";

    InstagramSourcePipeline(String cookie, String userAgent, Listener listener) {
        this.cookie = cookie == null ? "" : cookie;
        this.userAgent = (userAgent == null || userAgent.trim().isEmpty())
                ? "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/151.0 Mobile Safari/537.36"
                : userAgent.trim();
        this.csrf = cookieValue(this.cookie, "csrftoken");
        this.listener = listener;
    }

    void start(String inputUrl, int targetLimit, boolean followPagination, boolean resolveDetails,
               Collection<String> completed, Collection<String> discoveredSeed) {
        if (!active.compareAndSet(false, true)) return;
        this.targetLimit = Math.max(1, Math.min(300, targetLimit));
        this.followPagination = followPagination;
        this.resolveDetails = resolveDetails;
        if (completed != null) {
            for (String raw : completed) {
                String canonical = canonicalPostUrl(raw);
                if (!canonical.isEmpty()) completedSeed.add(canonical);
            }
        }

        String onePost = canonicalPostUrl(inputUrl);
        if (!onePost.isEmpty()) {
            username = "";
            expectedPosts = 1;
            listener.onProfileMeta("", 1);
            rememberAndQueue(onePost);
            discoveryDone.set(true);
            postQueue.offer(PostTask.END);
            resolverExecutor.execute(this::resolverLoop);
            return;
        }

        username = usernameFromProfile(inputUrl);
        if (username.isEmpty()) {
            active.set(false);
            listener.onFatal("InstagramプロフィールURLを確認してください");
            return;
        }

        resolverExecutor.execute(this::resolverLoop);
        discoveryExecutor.execute(() -> discoveryLoop(discoveredSeed));
    }

    void cancel() {
        cancelled.set(true);
        active.set(false);
        postQueue.clear();
        postQueue.offer(PostTask.END);
        discoveryExecutor.shutdownNow();
        resolverExecutor.shutdownNow();
    }

    boolean isActive() { return active.get() && !cancelled.get(); }
    boolean isDiscoveryDone() { return discoveryDone.get(); }
    int getDiscoveredCount() { synchronized (discoveredUrls) { return discoveredUrls.size(); } }
    int getResolvedCount() { return resolvedPosts; }
    int getSkippedCount() { return skippedPosts; }
    int getExpectedPosts() { return expectedPosts; }

    String snapshot() {
        return "sourceActive=" + isActive()
                + ",discoveryDone=" + discoveryDone.get()
                + ",discovered=" + getDiscoveredCount()
                + ",resolved=" + resolvedPosts
                + ",skipped=" + skippedPosts
                + ",expected=" + expectedPosts
                + ",queue=" + postQueue.size()
                + ",retry=" + retryQueue.size();
    }

    private void discoveryLoop(Collection<String> discoveredSeed) {
        try {
            if (discoveredSeed != null) {
                for (String raw : discoveredSeed) {
                    if (cancelled.get()) break;
                    String canonical = canonicalPostUrl(raw);
                    if (!canonical.isEmpty() && !completedSeed.contains(canonical)) rememberAndQueue(canonical);
                }
            }
            discoverProfileFeed();
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_IG_SOURCE_DISCOVERY_FATAL", t);
            abortFatal("Instagram投稿URL取得に失敗: " + t.getClass().getSimpleName());
        } finally {
            discoveryDone.set(true);
            postQueue.offer(PostTask.END);
            DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_DONE discovered=" + getDiscoveredCount()
                    + " expected=" + expectedPosts + " cancelled=" + cancelled.get());
        }
    }

    private void discoverProfileFeed() throws Exception {
        String maxId = "";
        boolean first = true;
        int page = 0;
        while (!cancelled.get()) {
            int discovered = getDiscoveredCount();
            if (discovered >= targetLimit) break;
            if (!first && !followPagination) break;

            StringBuilder endpoint = new StringBuilder("https://www.instagram.com/api/v1/feed/user/")
                    .append(URLEncoder.encode(username, "UTF-8"))
                    .append("/username/?count=").append(PAGE_SIZE);
            if (!maxId.isEmpty()) endpoint.append("&max_id=").append(URLEncoder.encode(maxId, "UTF-8"));

            HttpResult http = getJson(endpoint.toString(), "https://www.instagram.com/" + username + "/", "discovery");
            if (http.code == 429) {
                long wait = registerRateLimit("discovery", http);
                if (!sleepInterruptibly(wait)) break;
                HttpResult retry = getJson(endpoint.toString(), "https://www.instagram.com/" + username + "/", "discovery_retry");
                if (retry.code == 429) {
                    registerRateLimit("discovery_retry", retry);
                    DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_STOP reason=repeat_429 page=" + page);
                    break;
                }
                http = retry;
            }
            if (http.code == 401 || http.code == 403 || containsAuthGate(http.body)) {
                throw new IllegalStateException("Instagram認証が必要です (HTTP " + http.code + ")");
            }
            if (http.code < 200 || http.code >= 300) {
                DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_STOP reason=http_" + http.code + " page=" + page);
                break;
            }

            JSONObject root = new JSONObject(http.body);
            int metaCount = findMediaCount(root);
            if (metaCount > 0 && expectedPosts <= 0) {
                expectedPosts = metaCount;
                listener.onProfileMeta(username, expectedPosts);
                DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_META username=" + username + " expected=" + expectedPosts
                        + " source=feed");
            }

            JSONArray items = root.optJSONArray("items");
            int addedThisPage = 0;
            if (items != null) {
                for (int i = 0; i < items.length() && getDiscoveredCount() < targetLimit; i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item == null) continue;
                    String code = firstNonEmpty(item.optString("code", ""), item.optString("shortcode", ""));
                    if (code.isEmpty()) continue;
                    String product = item.optString("product_type", "").toLowerCase(Locale.ROOT);
                    String path = (product.equals("clips") || product.equals("reels")) ? "reel" : "p";
                    if (rememberAndQueue("https://www.instagram.com/" + path + "/" + code + "/")) addedThisPage++;
                }
            }

            if (first && expectedPosts <= 0) {
                int profileMeta = fetchExpectedCountBestEffort();
                if (profileMeta > 0) {
                    expectedPosts = profileMeta;
                    listener.onProfileMeta(username, expectedPosts);
                    DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_META username=" + username + " expected=" + expectedPosts
                            + " source=web_profile_info");
                } else {
                    listener.onProfileMeta(username, 0);
                }
            }

            page++;
            String next = root.optString("next_max_id", "");
            boolean more = root.optBoolean("more_available", !next.isEmpty());
            DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_PAGE page=" + page
                    + " items=" + (items == null ? 0 : items.length())
                    + " added=" + addedThisPage
                    + " discovered=" + getDiscoveredCount()
                    + " expected=" + expectedPosts
                    + " more=" + more
                    + " cursor=" + (!next.isEmpty()));

            if (!more || next.isEmpty()) break;
            if (next.equals(maxId)) {
                DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_STOP reason=cursor_repeat");
                break;
            }
            maxId = next;
            first = false;
            if (!sleepInterruptibly(PAGE_PACE_MS)) break;
        }

        int discovered = getDiscoveredCount();
        int target = expectedPosts > 0 ? Math.min(expectedPosts, targetLimit) : 0;
        if (target > 0 && discovered < target) {
            DiagnosticLog.log("SNS_IG_SOURCE_COUNT_MISMATCH expectedTarget=" + target + " discovered=" + discovered);
        } else if (target > 0) {
            DiagnosticLog.log("SNS_IG_SOURCE_COUNT_MATCH expectedTarget=" + target + " discovered=" + discovered);
        }
    }

    private int fetchExpectedCountBestEffort() {
        try {
            String endpoint = "https://www.instagram.com/api/v1/users/web_profile_info/?username="
                    + URLEncoder.encode(username, "UTF-8");
            HttpResult http = getJson(endpoint, "https://www.instagram.com/" + username + "/", "profile_meta");
            if (http.code == 200 && !http.body.isEmpty()) {
                int count = findMediaCount(new JSONObject(http.body));
                if (count > 0) return count;
            } else {
                DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_META_API_SKIP http=" + http.code);
            }
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_META_API_SKIP reason=" + t.getClass().getSimpleName());
        }

        // web_profile_info is selectively gated for some accounts.  Read the profile source itself
        // as a metadata-only fallback; this still performs no WebView render, scroll or click.
        try {
            String profileUrl = "https://www.instagram.com/" + username + "/";
            HttpResult http = getJson(profileUrl, "https://www.instagram.com/", "profile_html_meta");
            if (http.code != 200 || http.body.isEmpty()) return 0;
            String body = http.body.replace("\\\"", "\"").replace("\\u0026", "&");
            String[] patterns = {
                    "\"media_count\"\\s*:\\s*(\\d+)",
                    "\"edge_owner_to_timeline_media\"\\s*:\\s*\\{[^}]{0,600}\"count\"\\s*:\\s*(\\d+)",
                    "\"profile_post_count\"\\s*:\\s*(\\d+)"
            };
            for (String pattern : patterns) {
                Matcher m = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(body);
                if (!m.find()) continue;
                try {
                    int count = Integer.parseInt(m.group(1));
                    if (count > 0) return count;
                } catch (Throwable ignored) {}
            }
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_META_HTML_SKIP reason=" + t.getClass().getSimpleName());
        }
        return 0;
    }

    private boolean rememberAndQueue(String raw) {
        String canonical = canonicalPostUrl(raw);
        if (canonical.isEmpty()) return false;
        final int index;
        synchronized (discoveredUrls) {
            if (!discoveredUrls.add(canonical)) return false;
            index = discoveredUrls.size() - 1;
        }
        listener.onPostDiscovered(index, canonical);
        DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERED index=" + index + " url=" + canonical);
        if (!completedSeed.contains(canonical) && resolveDetails) postQueue.offer(new PostTask(canonical));
        return true;
    }

    private void resolverLoop() {
        try {
            while (!cancelled.get()) {
                PostTask task = postQueue.poll(1200L, TimeUnit.MILLISECONDS);
                if (task == null) {
                    if (discoveryDone.get()) break;
                    continue;
                }
                if (task.end) break;
                resolveOne(task.url, false);
                if (!sleepInterruptibly(POST_PACE_MS)) break;
            }

            if (!cancelled.get() && resolveDetails) {
                List<String> retrySnapshot;
                synchronized (retryQueue) { retrySnapshot = new ArrayList<>(retryQueue); }
                retryQueue.clear();
                for (String url : retrySnapshot) {
                    if (cancelled.get()) break;
                    listener.onPostRetry(url, 1, "deferred", 1200L);
                    DiagnosticLog.log("SNS_IG_SOURCE_RETRY url=" + url + " attempt=1 delayMs=1200");
                    if (!sleepInterruptibly(1200L)) break;
                    resolveOne(url, true);
                    if (!sleepInterruptibly(POST_PACE_MS)) break;
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_IG_SOURCE_RESOLVER_FATAL", t);
            abortFatal("Instagram投稿解析に失敗: " + t.getClass().getSimpleName());
        } finally {
            active.set(false);
            if (!cancelled.get() && !fatal.get()) {
                int discovered = getDiscoveredCount();
                int target = expectedPosts > 0 ? Math.min(expectedPosts, targetLimit) : 0;
                boolean matched = target <= 0 || discovered >= target;
                listener.onComplete(discovered, resolvedPosts, skippedPosts, expectedPosts, matched);
                DiagnosticLog.log("SNS_IG_SOURCE_PIPELINE_DONE discovered=" + discovered
                        + " resolved=" + resolvedPosts + " skipped=" + skippedPosts
                        + " expected=" + expectedPosts + " countMatched=" + matched);
            }
        }
    }

    private void resolveOne(String postUrl, boolean retryPass) {
        if (cancelled.get() || completedSeed.contains(postUrl)) return;
        String code = shortcodeFromPostUrl(postUrl);
        if (code.isEmpty()) {
            skip(postUrl, "shortcode_missing");
            return;
        }

        DiagnosticLog.log("SNS_IG_SOURCE_RESOLVE_START retry=" + retryPass + " url=" + postUrl);
        ResolveResult result = resolvePost(code, postUrl);
        if (result.rateLimited) {
            long wait = Math.max(DEFAULT_429_WAIT_MS, result.retryAfterMs);
            wait = Math.min(MAX_429_WAIT_MS, wait);
            requestGateUntil.accumulateAndGet(System.currentTimeMillis() + wait, Math::max);
            listener.onRateLimited("post", result.statusCode, wait);
            DiagnosticLog.log("SNS_IG_SOURCE_RATE_LIMIT scope=post http=" + result.statusCode
                    + " waitMs=" + wait + " url=" + postUrl);
            if (!retryPass) {
                if (!retryQueue.contains(postUrl)) retryQueue.add(postUrl);
            } else {
                skip(postUrl, "rate_limited");
            }
            return;
        }
        if (!result.ok || result.media.isEmpty()) {
            String reason = result.reason.isEmpty() ? "media_empty" : result.reason;
            if (reason.startsWith("auth_gate_")) {
                abortFatal("Instagram認証が必要です (" + reason + ")");
                return;
            }
            if (!retryPass) {
                if (!retryQueue.contains(postUrl)) retryQueue.add(postUrl);
                listener.onPostRetry(postUrl, 0, reason, 0L);
                DiagnosticLog.log("SNS_IG_SOURCE_RETRY_DEFER reason=" + reason + " url=" + postUrl);
            } else {
                skip(postUrl, reason);
            }
            return;
        }

        completedSeed.add(postUrl);
        resolvedPosts++;
        listener.onPostResolved(postUrl, result.media);
        DiagnosticLog.log("SNS_IG_SOURCE_RESOLVE_DONE media=" + result.media.size()
                + " resolved=" + resolvedPosts + " url=" + postUrl);
    }

    private void skip(String postUrl, String reason) {
        skippedPosts++;
        listener.onPostSkipped(postUrl, reason);
        DiagnosticLog.log("SNS_IG_SOURCE_SKIP reason=" + reason + " skipped=" + skippedPosts + " url=" + postUrl);
    }

    private ResolveResult resolvePost(String shortcode, String postUrl) {
        try {
            String mediaId = mediaIdFromShortcode(shortcode);
            if (!mediaId.isEmpty()) {
                String endpoint = "https://www.instagram.com/api/v1/media/" + mediaId + "/info/";
                HttpResult http = getJson(endpoint, postUrl, "post_info");
                if (http.code == 429) return ResolveResult.limited(429, http.retryAfterMs, "media_info_429");
                if (http.code == 200 && !http.body.isEmpty()) {
                    JSONObject root = new JSONObject(http.body);
                    JSONObject item = firstMediaItem(root, shortcode);
                    if (item != null) {
                        List<ResolvedMedia> media = parseMediaItem(item);
                        if (!media.isEmpty()) return ResolveResult.ok(media);
                    }
                }
                if (http.code == 401 || http.code == 403 || containsAuthGate(http.body)) {
                    return ResolveResult.fail("auth_gate_" + http.code, http.code);
                }
            }

            // Source-only fallbacks; still no WebView navigation or DOM interaction.
            String[] fallbacks = {
                    postUrl + (postUrl.contains("?") ? "&" : "?") + "__a=1&__d=dis",
                    postUrl + (postUrl.contains("?") ? "&" : "?") + "__a=1&__b=1"
            };
            for (String endpoint : fallbacks) {
                HttpResult http = getJson(endpoint, postUrl, "post_source");
                if (http.code == 429) return ResolveResult.limited(429, http.retryAfterMs, "post_source_429");
                if (http.code != 200 || http.body.isEmpty()) continue;
                try {
                    JSONObject root = new JSONObject(http.body);
                    JSONObject item = firstMediaItem(root, shortcode);
                    if (item != null) {
                        List<ResolvedMedia> media = parseMediaItem(item);
                        if (!media.isEmpty()) return ResolveResult.ok(media);
                    }
                } catch (Throwable ignored) {
                    // Some fallbacks return HTML despite a 200; raw source scan below handles it.
                }
                List<ResolvedMedia> raw = parseRawSourceMedia(http.body);
                if (!raw.isEmpty()) return ResolveResult.ok(raw);
                if (!sleepInterruptibly(FALLBACK_PACE_MS)) return ResolveResult.fail("cancelled", 499);
            }
            return ResolveResult.fail("media_not_resolved", 0);
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_IG_SOURCE_RESOLVE_FAIL error=" + t.getClass().getSimpleName() + " url=" + postUrl);
            return ResolveResult.fail(t.getClass().getSimpleName(), 0);
        }
    }

    private List<ResolvedMedia> parseMediaItem(JSONObject item) {
        if (item == null) return Collections.emptyList();
        JSONArray carousel = item.optJSONArray("carousel_media");
        if (carousel != null && carousel.length() > 0) {
            ArrayList<ResolvedMedia> out = new ArrayList<>();
            for (int i = 0; i < carousel.length(); i++) {
                JSONObject child = carousel.optJSONObject(i);
                ResolvedMedia one = parseSingleMedia(child);
                if (one != null) out.add(one);
            }
            return out;
        }

        // GraphQL source fallback.
        JSONObject sidecar = item.optJSONObject("edge_sidecar_to_children");
        JSONArray edges = sidecar == null ? null : sidecar.optJSONArray("edges");
        if (edges != null && edges.length() > 0) {
            ArrayList<ResolvedMedia> out = new ArrayList<>();
            for (int i = 0; i < edges.length(); i++) {
                JSONObject edge = edges.optJSONObject(i);
                JSONObject node = edge == null ? null : edge.optJSONObject("node");
                ResolvedMedia one = parseGraphMedia(node);
                if (one != null) out.add(one);
            }
            return out;
        }

        ResolvedMedia one = parseSingleMedia(item);
        if (one == null) one = parseGraphMedia(item);
        return one == null ? Collections.emptyList() : Collections.singletonList(one);
    }

    private ResolvedMedia parseSingleMedia(JSONObject item) {
        if (item == null) return null;
        int mediaType = item.optInt("media_type", 0);
        JSONArray videos = item.optJSONArray("video_versions");
        if (mediaType == 2 || (videos != null && videos.length() > 0)) {
            JSONObject best = bestCandidate(videos);
            if (best != null) {
                String url = best.optString("url", "");
                if (!url.isEmpty()) return new ResolvedMedia(MediaItem.Kind.VIDEO, url,
                        best.optInt("width", 0), best.optInt("height", 0));
            }
            String direct = item.optString("video_url", "");
            if (!direct.isEmpty()) return new ResolvedMedia(MediaItem.Kind.VIDEO, direct,
                    item.optInt("original_width", 0), item.optInt("original_height", 0));
            return null;
        }

        JSONObject imageVersions = item.optJSONObject("image_versions2");
        JSONObject best = bestCandidate(imageVersions == null ? null : imageVersions.optJSONArray("candidates"));
        if (best != null) {
            String url = best.optString("url", "");
            if (!url.isEmpty()) return new ResolvedMedia(MediaItem.Kind.IMAGE, url,
                    best.optInt("width", 0), best.optInt("height", 0));
        }
        String direct = firstNonEmpty(item.optString("display_url", ""), item.optString("image_url", ""));
        if (!direct.isEmpty()) return new ResolvedMedia(MediaItem.Kind.IMAGE, direct,
                item.optInt("original_width", 0), item.optInt("original_height", 0));
        return null;
    }

    private ResolvedMedia parseGraphMedia(JSONObject node) {
        if (node == null) return null;
        boolean video = node.optBoolean("is_video", false)
                || node.optString("__typename", "").toLowerCase(Locale.ROOT).contains("video");
        if (video) {
            String url = node.optString("video_url", "");
            if (!url.isEmpty()) {
                JSONObject dimensions = node.optJSONObject("dimensions");
                return new ResolvedMedia(MediaItem.Kind.VIDEO, url,
                        dimensions == null ? 0 : dimensions.optInt("width", 0),
                        dimensions == null ? 0 : dimensions.optInt("height", 0));
            }
            return parseSingleMedia(node);
        }
        String url = firstNonEmpty(node.optString("display_url", ""), node.optString("display_src", ""));
        if (!url.isEmpty()) {
            JSONObject dimensions = node.optJSONObject("dimensions");
            return new ResolvedMedia(MediaItem.Kind.IMAGE, url,
                    dimensions == null ? 0 : dimensions.optInt("width", 0),
                    dimensions == null ? 0 : dimensions.optInt("height", 0));
        }
        return parseSingleMedia(node);
    }

    private static JSONObject bestCandidate(JSONArray candidates) {
        if (candidates == null || candidates.length() == 0) return null;
        JSONObject best = null;
        long bestArea = -1L;
        for (int i = 0; i < candidates.length(); i++) {
            JSONObject c = candidates.optJSONObject(i);
            if (c == null || c.optString("url", "").isEmpty()) continue;
            long w = Math.max(0, c.optLong("width", 0L));
            long h = Math.max(0, c.optLong("height", 0L));
            long area = w * h;
            if (best == null || area > bestArea) {
                best = c;
                bestArea = area;
            }
        }
        return best;
    }

    private JSONObject firstMediaItem(JSONObject root, String shortcode) {
        if (root == null) return null;
        JSONArray items = root.optJSONArray("items");
        if (items != null && items.length() > 0) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                String code = firstNonEmpty(item.optString("code", ""), item.optString("shortcode", ""));
                if (code.isEmpty() || shortcode.equals(code)) return item;
            }
            JSONObject first = items.optJSONObject(0);
            if (first != null) return first;
        }

        JSONObject data = root.optJSONObject("data");
        if (data != null) {
            JSONObject web = data.optJSONObject("xdt_api__v1__media__shortcode__web_info");
            JSONObject found = firstMediaItem(web, shortcode);
            if (found != null) return found;
            JSONObject gql = data.optJSONObject("shortcode_media");
            if (gql != null) return gql;
        }
        JSONObject graphql = root.optJSONObject("graphql");
        if (graphql != null) {
            JSONObject media = graphql.optJSONObject("shortcode_media");
            if (media != null) return media;
        }
        return findMediaObjectRecursive(root, shortcode, 0);
    }

    private JSONObject findMediaObjectRecursive(Object value, String shortcode, int depth) {
        if (value == null || depth > 8) return null;
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            String code = firstNonEmpty(obj.optString("code", ""), obj.optString("shortcode", ""));
            if ((!code.isEmpty() && code.equals(shortcode))
                    && (obj.has("carousel_media") || obj.has("image_versions2") || obj.has("video_versions")
                    || obj.has("display_url") || obj.has("edge_sidecar_to_children"))) return obj;
            JSONArray names = obj.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    Object child = obj.opt(names.optString(i));
                    JSONObject found = findMediaObjectRecursive(child, shortcode, depth + 1);
                    if (found != null) return found;
                }
            }
        } else if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i = 0; i < a.length(); i++) {
                JSONObject found = findMediaObjectRecursive(a.opt(i), shortcode, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private List<ResolvedMedia> parseRawSourceMedia(String body) {
        if (body == null || body.isEmpty()) return Collections.emptyList();
        String decoded = body.replace("\\u0026", "&").replace("\\u003d", "=")
                .replace("\\u002f", "/").replace("\\/", "/").replace("&amp;", "&");
        Pattern p = Pattern.compile("https?://[^\\s\\\"'<>\\\\]+", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(decoded);
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        ArrayList<ResolvedMedia> out = new ArrayList<>();
        while (m.find() && out.size() < 24) {
            String url = m.group();
            if (!(url.contains("cdninstagram.com") || url.contains("fbcdn.net"))) continue;
            int start = Math.max(0, m.start() - 220);
            int end = Math.min(decoded.length(), m.end() + 220);
            String context = decoded.substring(start, end).toLowerCase(Locale.ROOT);
            MediaItem.Kind kind;
            if (url.matches("(?i).*\\.mp4(?:\\?.*)?$")
                    && (context.contains("video_versions") || context.contains("video_url") || context.contains("carousel_media"))) {
                kind = MediaItem.Kind.VIDEO;
            } else if (url.matches("(?i).*\\.(?:jpg|jpeg|png|webp)(?:\\?.*)?$")
                    && (context.contains("image_versions2") || context.contains("display_url") || context.contains("carousel_media"))) {
                kind = MediaItem.Kind.IMAGE;
            } else continue;
            String key = kind.name() + "|" + stripQuery(url);
            if (seen.add(key)) out.add(new ResolvedMedia(kind, url, 0, 0));
        }
        return out;
    }

    private void abortFatal(String message) {
        if (!fatal.compareAndSet(false, true)) return;
        cancelled.set(true);
        postQueue.clear();
        postQueue.offer(PostTask.END);
        DiagnosticLog.log("SNS_IG_SOURCE_ABORT_FATAL message=" + (message == null ? "" : message));
        listener.onFatal(message == null ? "Instagramソース解析に失敗" : message);
    }

    private HttpResult getJson(String endpoint, String referrer, String scope) throws Exception {
        awaitRequestGate();
        if (cancelled.get()) return new HttpResult(499, "", 0L);
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(endpoint).openConnection();
            con.setInstanceFollowRedirects(true);
            con.setConnectTimeout(12000);
            con.setReadTimeout(18000);
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", userAgent);
            con.setRequestProperty("Accept", "*/*");
            con.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en-US;q=0.7,en;q=0.6");
            con.setRequestProperty("X-IG-App-ID", IG_APP_ID);
            con.setRequestProperty("X-ASBD-ID", IG_ASBD_ID);
            if (!csrf.isEmpty()) con.setRequestProperty("X-CSRFToken", csrf);
            if (!cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
            if (referrer != null && !referrer.isEmpty()) con.setRequestProperty("Referer", referrer);
            con.setRequestProperty("X-Requested-With", "XMLHttpRequest");
            int code = con.getResponseCode();
            long retryAfterMs = parseRetryAfterMs(con.getHeaderField("Retry-After"));
            InputStream stream = code >= 200 && code < 400 ? con.getInputStream() : con.getErrorStream();
            String body = readAll(stream, 8 * 1024 * 1024);
            DiagnosticLog.log("SNS_IG_SOURCE_HTTP scope=" + scope + " http=" + code
                    + " bytes=" + body.length() + " retryAfterMs=" + retryAfterMs);
            return new HttpResult(code, body, retryAfterMs);
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private long registerRateLimit(String scope, HttpResult http) {
        long wait = http.retryAfterMs > 0L ? http.retryAfterMs : DEFAULT_429_WAIT_MS;
        wait = Math.min(MAX_429_WAIT_MS, Math.max(5000L, wait));
        long until = System.currentTimeMillis() + wait;
        requestGateUntil.accumulateAndGet(until, Math::max);
        listener.onRateLimited(scope, http.code, wait);
        DiagnosticLog.log("SNS_IG_SOURCE_RATE_LIMIT scope=" + scope + " http=" + http.code + " waitMs=" + wait);
        return wait;
    }

    private void awaitRequestGate() throws InterruptedException {
        while (!cancelled.get()) {
            long remaining = requestGateUntil.get() - System.currentTimeMillis();
            if (remaining <= 0L) return;
            Thread.sleep(Math.min(remaining, 1000L));
        }
    }

    private boolean sleepInterruptibly(long ms) {
        long end = System.currentTimeMillis() + Math.max(0L, ms);
        while (!cancelled.get()) {
            long remaining = end - System.currentTimeMillis();
            if (remaining <= 0L) return true;
            try {
                Thread.sleep(Math.min(remaining, 500L));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return false;
    }

    private static String readAll(InputStream in, int maxBytes) throws Exception {
        if (in == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            int chars = 0;
            while ((n = br.read(buf)) >= 0) {
                if (n == 0) continue;
                if (chars + n > maxBytes) n = Math.max(0, maxBytes - chars);
                if (n <= 0) break;
                out.append(buf, 0, n);
                chars += n;
                if (chars >= maxBytes) break;
            }
        }
        return out.toString();
    }

    private static int findMediaCount(JSONObject root) {
        if (root == null) return 0;
        try {
            JSONObject data = root.optJSONObject("data");
            JSONObject user = data == null ? null : data.optJSONObject("user");
            if (user != null) {
                int direct = user.optInt("media_count", 0);
                if (direct > 0) return direct;
                JSONObject timeline = user.optJSONObject("edge_owner_to_timeline_media");
                if (timeline != null && timeline.optInt("count", 0) > 0) return timeline.optInt("count", 0);
            }
            JSONArray items = root.optJSONArray("items");
            if (items != null && items.length() > 0) {
                JSONObject first = items.optJSONObject(0);
                JSONObject itemUser = first == null ? null : first.optJSONObject("user");
                if (itemUser != null && itemUser.optInt("media_count", 0) > 0) return itemUser.optInt("media_count", 0);
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    private static String usernameFromProfile(String raw) {
        if (raw == null) return "";
        try {
            URI uri = new URI(raw.trim());
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!(host.equals("instagram.com") || host.endsWith(".instagram.com"))) return "";
            String path = uri.getPath() == null ? "" : uri.getPath();
            String[] parts = path.split("/");
            for (String p : parts) {
                if (p == null || p.trim().isEmpty()) continue;
                String value = p.trim();
                String lower = value.toLowerCase(Locale.ROOT);
                if (lower.equals("p") || lower.equals("reel") || lower.equals("tv") || lower.equals("explore")
                        || lower.equals("accounts") || lower.equals("stories")) return "";
                return value;
            }
        } catch (Throwable ignored) {}
        return "";
    }

    static String canonicalPostUrl(String raw) {
        if (raw == null) return "";
        try {
            URI uri = new URI(raw.trim());
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!(host.equals("instagram.com") || host.endsWith(".instagram.com"))) return "";
            String path = uri.getPath() == null ? "" : uri.getPath();
            Matcher m = Pattern.compile("/(p|reel|tv)/([^/?#]+)", Pattern.CASE_INSENSITIVE).matcher(path);
            if (!m.find()) return "";
            return "https://www.instagram.com/" + m.group(1).toLowerCase(Locale.ROOT) + "/" + m.group(2) + "/";
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static String shortcodeFromPostUrl(String raw) {
        String canonical = canonicalPostUrl(raw);
        if (canonical.isEmpty()) return "";
        Matcher m = Pattern.compile("/(?:p|reel|tv)/([^/?#]+)", Pattern.CASE_INSENSITIVE).matcher(canonical);
        return m.find() ? m.group(1) : "";
    }

    private static String mediaIdFromShortcode(String code) {
        try {
            if (code == null || code.isEmpty() || code.length() > 11) return "";
            StringBuilder padded = new StringBuilder(code);
            while (padded.length() < 12) padded.insert(0, 'A');
            byte[] decoded = Base64.decode(padded.toString(), Base64.URL_SAFE | Base64.NO_WRAP);
            return new BigInteger(1, decoded).toString();
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static String cookieValue(String cookie, String key) {
        if (cookie == null || key == null) return "";
        for (String part : cookie.split(";")) {
            int eq = part.indexOf('=');
            if (eq <= 0) continue;
            if (part.substring(0, eq).trim().equals(key)) return part.substring(eq + 1).trim();
        }
        return "";
    }

    private static boolean containsAuthGate(String body) {
        if (body == null || body.isEmpty()) return false;
        String lower = body.toLowerCase(Locale.ROOT);
        return lower.contains("login_required") || lower.contains("challenge_required")
                || lower.contains("checkpoint_required") || lower.contains("feedback_required");
    }

    private static long parseRetryAfterMs(String raw) {
        if (raw == null || raw.trim().isEmpty()) return 0L;
        try {
            long seconds = Long.parseLong(raw.trim());
            return Math.max(0L, seconds * 1000L);
        } catch (Throwable ignored) {
            return 0L;
        }
    }

    private static String firstNonEmpty(String a, String b) {
        if (a != null && !a.trim().isEmpty()) return a.trim();
        return b == null ? "" : b.trim();
    }

    private static String stripQuery(String url) {
        if (url == null) return "";
        int q = url.indexOf('?');
        return q >= 0 ? url.substring(0, q) : url;
    }
}
