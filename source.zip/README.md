# ImgStalker v0.1.63 (64)

## Base
- Functional base: v0.1.62, which derives from the exact v0.1.52 crawler line.
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.

## Instagram SPA click traversal
- Instagram profile discovery/scrolling remains the v0.1.52-style discovery flow.
- Post detail pages are no longer opened with direct `WebView.loadUrl()` or `window.location.assign()` navigation.
- During the detail phase, the crawler finds the matching post/reel anchor inside the live Instagram profile DOM.
- The target anchor is scrolled into view and tapped by Android-side WebView touch DOWN/UP events, matching the successful v0.1.62 manual-tap path as closely as possible.
- The crawler waits for Instagram's SPA/history transition to the requested `/p/`, `/reel/`, or `/tv/` item before starting media extraction.
- Existing Instagram carousel/image/video/network-candidate extraction is reused inside the opened SPA post view.
- After a post is completed, the crawler closes the SPA post view (close-button first, History fallback) and continues to the next discovered post.
- Direct top-level Instagram post navigation is intentionally not used as a fallback, to avoid returning to the observed HTTP 429 path.

## Media collection / save flow
- Existing image/video/stream URL deduplication and media-list registration remain in use.
- Existing download/save UI and MediaDownloader flow remain available after traversal, so collected URLs can be selected/saved in bulk as before.
- Existing Reel network video capture and cover-frame exclusion behavior is retained.

## Safety / recovery
- SPA anchor search is bounded.
- SPA native tap retries are capped at 2 attempts per post.
- Existing per-post recovery limit remains capped.
- HTTP 429 detection still stops analysis rather than repeatedly hammering the same post.

## Diagnostics added
- `SNS_IG_SPA_DETAIL_PHASE_READY`
- `SNS_IG_SPA_TARGET`
- `SNS_IG_SPA_ANCHOR_SEARCH`
- `SNS_IG_SPA_ANCHOR_FOUND`
- `SNS_IG_SPA_NATIVE_TAP`
- `SNS_IG_SPA_OPEN`
- `SNS_IG_SPA_OPEN_RETRY`
- `SNS_IG_SPA_OPEN_TIMEOUT`
- `SNS_IG_SPA_CLOSE_START`
- `SNS_IG_SPA_CLOSE_ACTION`
- `SNS_IG_SPA_CLOSE_FALLBACK`
- `SNS_IG_SPA_CLOSE_DONE`

## Package
- versionCode: 64
- versionName: 0.1.63
