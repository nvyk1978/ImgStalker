#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/com/cmyk/imgstalker" "$TMP/src/android/os"
cat > "$TMP/src/android/os/SystemClock.java" <<'JAVA'
package android.os; public final class SystemClock {
 public static long now = 100000L;
 public static long elapsedRealtime() { return now; }
}
JAVA
python3 - "$TMP/src/com/cmyk/imgstalker/OrderedSweepRunnerTest.java" <<'PY'
import sys
from pathlib import Path
s=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
def method(name):
 start=s.index('    private void '+name+'(')
 brace=s.index('{',start)
 depth=0
 for i in range(brace,len(s)):
  if s[i]=='{': depth+=1
  elif s[i]=='}':
   depth-=1
   if depth==0: return s[start:i+1]
 raise ValueError(name)
methods='\n'.join(method(x) for x in ['reconcileSnsThumbnailInFlight','runSnsThumbnailSweep'])
template='''package com.cmyk.imgstalker;
import java.util.*;
class DiagnosticLog { static void log(String s) {} }
class MediaItem {
 enum Kind { IMAGE, VIDEO, STREAM }
 final String url; final Kind kind;
 MediaItem(int index) {this.url="item:"+index; this.kind=Kind.IMAGE;}
}
class MockLoader {
 final Set<String> pending = new HashSet<>();
 final Set<String> ready = new HashSet<>();
 final ArrayList<String> startOrder = new ArrayList<>();
 boolean isReady(MediaItem item) { return ready.contains(item.url); }
 boolean isCachedOrPending(MediaItem item) { return pending.contains(item.url) || ready.contains(item.url); }
 int pendingCount() { return pending.size(); }
 void prefetch(MediaItem item) {if (!pending.contains(item.url) && !ready.contains(item.url)) {pending.add(item.url); startOrder.add(item.url);}}
 void success(String key) { pending.remove(key); ready.add(key); }
 void fail(String key) {pending.remove(key);}
}
public class OrderedSweepRunnerTest {
 static final int SNS_THUMB_BACKGROUND_BATCH = 2;
 static final int SNS_THUMB_BACKGROUND_MAX_PENDING = 3;
 static final long SNS_THUMB_BACKGROUND_TICK_MS = 650L;
 final SnsThumbnailSweepPolicy snsThumbnailSweepPolicy = new SnsThumbnailSweepPolicy();
 final HashMap<String,MediaItem> snsThumbnailInFlight = new HashMap<>();
 final ArrayList<MediaItem> items = new ArrayList<>();
 MockLoader thumbnailLoader = new MockLoader();
 int snsThumbnailSweepCursor;
 int snsThumbnailSweepPassScanned;
 boolean snsThumbnailSweepScheduled;
 boolean isSnsThumbnailLazyMode() { return true; }
 String safeText(String value) { return value; }
 void scheduleSnsThumbnailSweep(String reason, long delay) { snsThumbnailSweepScheduled=true; }
 __METHODS__
 static void check(boolean b,String message) {if(!b) throw new AssertionError(message);}
 public static void main(String[] args) {
   OrderedSweepRunnerTest test = new OrderedSweepRunnerTest();
   for(int i=0;i<500;i++) test.items.add(new MediaItem(i));
   int completed=0;
   for(int tick=0;tick<1600 && completed<500;tick++) {
     test.runSnsThumbnailSweep();
     ArrayList<String> current = new ArrayList<>(test.thumbnailLoader.pending);
     for (String key:current) { test.thumbnailLoader.success(key); completed++; }
     android.os.SystemClock.now+=650L;
   }
   check(completed==500,"all 500 previews must launch and complete");
   for(int i=0;i<500;i++) check(test.thumbnailLoader.startOrder.get(i).equals("item:"+i),"not strictly sequential: "+i);
   for(int k=0;k<12;k++) { test.runSnsThumbnailSweep(); if (!test.snsThumbnailSweepScheduled) break; }
   check(test.snsThumbnailSweepPolicy.isFinished("IMAGE|item:499"),"last success not reconciled");
   check(!test.snsThumbnailSweepScheduled,"completed list should become idle");
   // One failed request must be observed as a failure only after transport completion.
   OrderedSweepRunnerTest failTest = new OrderedSweepRunnerTest();
   failTest.items.add(new MediaItem(0));
   failTest.items.add(new MediaItem(1));
   failTest.runSnsThumbnailSweep();
   check(failTest.snsThumbnailSweepPolicy.attempts("IMAGE|item:0")==0,"initial dispatch counted as failure");
   failTest.thumbnailLoader.fail("item:0");
   failTest.thumbnailLoader.success("item:1");
   failTest.runSnsThumbnailSweep();
   check(failTest.snsThumbnailSweepPolicy.attempts("IMAGE|item:0")==1,"missing completed-failure count");
   check(failTest.thumbnailLoader.startOrder.size()==2,"retried during backoff");
   android.os.SystemClock.now+=3500L;
   for(int k=0;k<8;k++) failTest.runSnsThumbnailSweep();
   check(failTest.thumbnailLoader.startOrder.size()==3,"no retry after backoff");
   check(failTest.thumbnailLoader.startOrder.get(2).equals("item:0"),"wrong retry key");
   System.out.println("PASS: actual extracted scheduler sends 500 consecutive items in strict order; retry only after completion and backoff");
 }
}
'''
Path(sys.argv[1]).write_text(template.replace('__METHODS__',methods))
PY
javac -d "$TMP/classes" "$TMP/src/android/os/SystemClock.java" app/src/main/java/com/cmyk/imgstalker/SnsThumbnailSweepPolicy.java "$TMP/src/com/cmyk/imgstalker/OrderedSweepRunnerTest.java"
java -cp "$TMP/classes" com.cmyk.imgstalker.OrderedSweepRunnerTest
