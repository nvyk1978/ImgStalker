# ImgStalker v0.1.81 (82)

## Base
- Exact implementation base: v0.1.80 (81).
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.


## v0.1.81 — Instagram source pipeline rebuild

- Instagram normal analysis no longer loads profiles/posts into the crawler WebView and does not scroll, tap posts, click carousel Next, restore SPA state, or expose the debug browser. Login/session WebView remains only for account authentication and cookie acquisition.
- Profile discovery is source/API driven. The primary route reads `api/v1/feed/user/<username>/username/` in profile order and follows `next_max_id`; the visible profile count is used as an integrity target, capped by the existing 300-post limit.
- Discovery and resolution are separate producer/consumer workers. New post URLs are persisted in order while the resolver starts processing the head of the queue immediately instead of waiting for discovery to finish.
- Post resolution is structured-data first: shortcode -> media id -> `api/v1/media/<id>/info/`; `carousel_media`, `image_versions2` and `video_versions` are expanded without operating the carousel UI. Source-only JSON/HTML parsing is fallback; browser fallback is not part of the Instagram path.
- A failed post is deferred once, then skipped as a resume target so later posts continue. Completed/discovered post state continues to use the SNS resume sidecar.
- HTTP 429 is handled with one shared request gate across discovery and resolver. `Retry-After` is honored when present; repeated discovery 429 ends the current discovery pass rather than hammering the endpoint. Authentication/challenge gates abort the run instead of retrying every post.
- New diagnostics center on `SNS_IG_SOURCE_*`, `SNS_IG_DISCOVERY_SOURCE`, `SNS_IG_RESOLVER_DONE`, `SNS_IG_POST_RETRY_*`, and `SNS_IG_RATE_LIMIT`.

Package: versionName 0.1.81 / versionCode 82.


## v0.1.74 Instagram recovery changes
- Carousel `Next` click success followed by slide-change timeout is no longer treated as the last slide. The current post state is reloaded/reopened and retried from slide 1.
- A visible `Next` button that remains unclickable after retries is also treated as a post failure/reload path, never as successful carousel completion.
- One reload/reopen retry is performed for the affected post; if it still fails, only that post is marked failed and profile discovery continues.
- Continuation reload restores `discovered - completed` as an explicit pending set and processes those posts before ordinary new-post discovery.
- When Instagram exposes a profile post count and discovered posts are still below `min(profileCount, 300)`, `bottom_stall`/pass-limit no longer end analysis. The profile is reloaded and discovery resumes.
- New diagnostics: `SNS_IG_CONTINUE_PENDING_START/PICK/DONE`, `SNS_IG_POST_RELOAD`, and `SNS_IG_DISCOVERY_RELOAD`.

## Instagram CDN URL-hash fix
- Resolver candidates from Instagram post HTML are no longer accepted merely because they look like valid fbcdn/cdninstagram media URLs.
- IMAGE/VIDEO candidates on Meta CDN must include the expiring `oh` and `oe` hash parameters before the resolver may complete the post.
- A candidate missing either hash is treated as incomplete and immediately enters the existing browser/WebView fallback for that same post.
- The browser fallback continues to read post media from the live DOM/current WebView session, where Instagram supplies the complete signed CDN URL actually used by the page.
- This targets the v0.1.72 failure where direct thumbnail/video requests returned HTTP 403 with a 12-byte text response while the visible Instagram page itself could display the media.

## Ordered inline fallback
- The profile is still processed in order, one post at a time.
- An invalid/partial resolver URL does not get queued as finished media and discovery does not advance past that post.
- Browser fallback is completed for the current post before the next profile post is selected.
- Existing inline retry behavior remains: one browser retry after profile restoration, then skip and continue if the same post still cannot be resolved.

## Preserved behavior
- Reel completion still requires playable video/stream media.
- Regular `/p/` posts are not rejected solely because `videoHint` is present.
- Carousel-hinted resolver results with fewer than two candidates still use browser fallback.
- Reel/video cover JPEGs remain excluded as standalone IMAGE results.
- Video thumbnails still use bounded local MP4 download followed by local frame extraction.
- Completed/discovered post URLs and profile-order display ordering remain unchanged.

## Diagnostics
- `SNS_IG_RESOLVER_SIGNATURE_FALLBACK`: resolver returned an IMAGE/VIDEO CDN URL missing Meta `oh`/`oe` hash parameters, so the post is handed to browser fallback instead of emitting the broken URL.
- Existing `SNS_IG_RESOLVER_INLINE_FALLBACK`, `SNS_IG_STREAM_RETRY_INLINE`, `THUMB_HTTP`, and `VIDEO_THUMB_HTTP` diagnostics remain.

## Package
- versionCode: 75
- versionName: 0.1.74

## v0.1.75

- Analyze button now transitions `停止 -> クリア -> 解析` after a manual stop; Clear removes media/reload cells before returning to Analyze.
- Selected media metadata uses one continuous N-light-blue rounded square around filename + resolution.
- Header gear artwork reduced one step; X and Instagram glyph visual sizes normalized.
- Status text suppresses raw URLs. Instagram `投稿を取得中（done/total）` is shown on the right side of the image/video/stream/selection summary row.
- Added `保存場所を変更` directly below the resolution floor setting. It opens the N Explorer dialog with storage switching, parent navigation, new-folder creation, direct-grab scrollbar and folder confirmation.
- Downloads now use the persisted save destination; default remains `Downloads/ImgStalker`.


## v0.1.77

- Settings section title changed from X to SNS.
- Added SNS resume toggle, default ON and persisted.
- External resume JSON is stored per SNS account with account-bearing names:
  - Instagram/<account>/is_instagram_<account>.json
  - X/<account>/is_x_<account>.json
  - atomic temp: same name + .tmp
- Analysis start automatically checks the account resume JSON when resume is enabled.
- Incomplete resume state restores media cells and Instagram completed/discovered post state.
- Completed resume state is ignored for a fresh analysis.
- Resume checkpoints are written during SNS analysis and on safe stop/error/completion.
- SNS download folders are account based: Instagram/<account>/ and X/<account>/.
- Save-location button moved to the far left, renamed 保存場所変更, 13sp, N Light Blue.
- Resolution controls are grouped and right-aligned on the same row.
- Reload cell label changed to 続きを再読込.
- Reload glyph replaced by a process-vectorized VectorDrawable from the latest supplied reference and rendered at 80% visual size.
- Diagnostic log glyph reduced one visual step without changing its touch target.


## v0.1.76

- Manual Analyze stop is now a graceful/safe stop: no new crawl work is started after the stop request, while the current resolver/post and already-running image probes are allowed to settle before final completion. The button shows `停止中…`, then becomes `クリア`.
- Safe-stop completion is marked incomplete (`user_stop`) so the continuation cell can recover unfinished posts on the next reload.
- Save root default changed to `Pictures/ImgStalker`.
- Instagram downloads are grouped under `ImgStalker/Instagram/<page_timestamp>/`; X/Twitter downloads are grouped under `ImgStalker/X/<page_timestamp>/`. Other pages continue directly under the selected ImgStalker root.
- `保存場所を変更` moved onto the resolution-floor row, uses N light blue `#445577`, and consumes the remaining right-side width.
- Summary-line font restored to 14sp. `投稿を取得中（000/000）` uses the same 14sp size; existing colors are preserved.
- Reload/continuation cell now uses an Android VectorDrawable traced from the supplied circular-arrow reference instead of the old hand-drawn reload glyph.
- TikTok support is not included in this version.

## Package v0.1.77
- versionCode: 78
- versionName: 0.1.77


## v0.1.78

- Analysis start now enters an immediate disabled `準備中…` state before resume lookup.
- External resume loading runs on the dedicated resume I/O executor instead of the UI thread.
- Empty resume checkpoints at analysis start are no longer written.
- Resume sidecars under Pictures are written through a persisted SAF tree, avoiding Android 16 MediaStore.Files / direct-file EPERM failures.
- N Explorer confirmation now obtains and persists Android folder access for the selected save root.
- Without a persisted SAF grant, resume writes are deferred without throwing; normal analysis continues.

Package: versionName 0.1.78 / versionCode 79.


## v0.1.79

- First SNS analysis with resume enabled now requests persisted SAF access for the configured save root when needed, instead of silently leaving JSON checkpoints unwritable.
- The automatic grant flow keeps `Pictures/ImgStalker` as the configured root even when Android grants its parent `Pictures`; missing `ImgStalker/Instagram|X/<account>` directories are created through SAF.
- Resume sidecars are resolved relative to the configured save root inside the granted tree, so parent-tree grants and custom save roots both work.
- Active analysis/preparation/download now owns a foreground keep-alive service regardless of the optional background-execution toggle.
- The foreground service uses `START_STICKY`, `stopWithTask=false`, a wake lock, and keeps the active worker owner alive when the task is removed from Recents.
- Task removal no longer destroys/cancels the active WebView crawler or downloader; detached work is allowed to reach a safe terminal state.
- Resume checkpoint writes are included in the keep-alive lifetime so the service is not released before the JSON sidecar is committed.
- If Android restarts the service after a full process kill with no retained worker, the service stops itself instead of leaving a stale notification.

Package: versionName 0.1.79 / versionCode 80.


## v0.1.80

- SNS sidecar JSON now includes `saved_media_keys`, a persistent ledger containing only media that actually completed MediaStore publish successfully.
- Re-analysis and continuation load this ledger even when the crawler state is already marked complete.
- Save now skips selected media whose stable crawler `dedupKey` is already recorded in the account JSON; signed Instagram CDN query changes therefore do not cause a second save.
- Duplicate keys in the same save queue are also suppressed.
- Failed/cancelled/partial downloads are never added to the ledger, so they remain retryable.
- Each successful publish queues a serialized resume-sidecar checkpoint, and a final download checkpoint is written after completion.
- Existing schema-1 JSON from v0.1.79 and earlier remains readable; missing `saved_media_keys` is treated as an empty save ledger.

Package: versionName 0.1.80 / versionCode 81.
