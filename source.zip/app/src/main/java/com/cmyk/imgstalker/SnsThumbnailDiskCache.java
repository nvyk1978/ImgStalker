package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;

/** Per-service best-effort cache of resized previews. Never stores original media. */
final class SnsThumbnailDiskCache {
    private static final long MAX_BYTES = 96L * 1024 * 1024;
    private final File directory;
    private int writes;

    SnsThumbnailDiskCache(Context context, String service) {
        // The directory is deliberately different for Instagram and Threads;
        // no service can borrow another service's authenticated previews.
        directory = new File(context.getApplicationContext().getCacheDir(),
                "imgstalker_thumbnails_" + service.toLowerCase(Locale.ROOT));
    }

    boolean contains(String key) {
        File file = target(key);
        return file.isFile() && file.length() > 0L;
    }

    Bitmap read(String key) {
        File file = target(key);
        if (!file.isFile()) return null;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
        if (bitmap == null) {
            // Invalid/incomplete entries must not prevent the network fallback.
            file.delete();
            return null;
        }
        file.setLastModified(System.currentTimeMillis());
        return bitmap;
    }

    void write(String key, Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled()) return;
        if (!directory.exists() && !directory.mkdirs()) return;
        File file = target(key);
        if (file.isFile() && file.length() > 0L) return;
        File temp = new File(directory, file.getName() + ".tmp" + Thread.currentThread().getId());
        try (FileOutputStream out = new FileOutputStream(temp)) {
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)) {
                temp.delete();
                return;
            }
            out.flush();
        } catch (Exception error) {
            temp.delete();
            return;
        }
        try {
            if (!file.isFile() && !temp.renameTo(file)) temp.delete();
            else temp.delete();
            // Bound disk usage without blocking the UI thread (this executes in a worker).
            if (++writes % 24 == 0) prune();
        } catch (Exception ignored) { temp.delete(); }
    }

    void clear() {
        if (!directory.exists()) return;
        File old = new File(directory.getParentFile(), directory.getName() + "_clearing_" + System.nanoTime());
        if (!directory.renameTo(old)) {
            // Best effort fallback: never perform large I/O on the UI thread.
            old = directory;
        }
        final File discarded = old;
        new Thread(() -> {
            File[] files = discarded.listFiles();
            if (files != null) for (File file : files) if (file.isFile()) file.delete();
            discarded.delete();
        }, "imgstalker-thumb-clear").start();
    }

    private void prune() {
        File[] files = directory.listFiles((dir, name) -> name.endsWith(".jpg"));
        if (files == null) return;
        long bytes = 0;
        for (File file : files) bytes += file.length();
        if (bytes <= MAX_BYTES) return;
        Arrays.sort(files, Comparator.comparingLong(File::lastModified));
        for (File file : files) {
            if (bytes <= MAX_BYTES) break;
            long oldSize = file.length();
            if (file.delete()) bytes -= oldSize;
        }
    }

    private File target(String key) {
        return new File(directory, digest(key) + ".jpg");
    }

    private static String digest(String key) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256")
                    .digest(key.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            char[] digits = "0123456789abcdef".toCharArray();
            char[] result = new char[hash.length * 2];
            for (int i = 0; i < hash.length; i++) {
                result[i * 2] = digits[(hash[i] >> 4) & 15];
                result[i * 2 + 1] = digits[hash[i] & 15];
            }
            return new String(result);
        } catch (Exception ignored) {
            // SHA-256 exists on every supported Android version.
            throw new IllegalStateException("SHA-256 unavailable", ignored);
        }
    }
}
