package com.cmyk.imgstalker;

import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Resolves Instagram post media without navigating the profile WebView away from the grid.
 *
 * The resolver intentionally executes fetch() inside the already authenticated Instagram
 * document. That keeps Cookie / same-origin browser state owned by WebView while separating
 * discovery from detail-media acquisition. Browser navigation is left to CrawlerEngine only as
 * a last-resort fallback for posts this resolver cannot decode.
 */
final class InstagramMediaResolver {
    interface Callback {
        void onResult(Result result);
    }

    static final class Image {
        final String url;
        final int width;
        final int height;

        Image(String url, int width, int height) {
            this.url = url == null ? "" : url;
            this.width = Math.max(0, width);
            this.height = Math.max(0, height);
        }
    }

    static final class Result {
        final boolean ok;
        final String source;
        final String error;
        final List<Image> images;
        final List<String> videos;
        final List<String> streams;
        final boolean carouselHint;
        final boolean videoHint;

        Result(boolean ok, String source, String error,
               List<Image> images, List<String> videos, List<String> streams,
               boolean carouselHint, boolean videoHint) {
            this.ok = ok;
            this.source = source == null ? "" : source;
            this.error = error == null ? "" : error;
            this.images = images == null ? Collections.emptyList() : images;
            this.videos = videos == null ? Collections.emptyList() : videos;
            this.streams = streams == null ? Collections.emptyList() : streams;
            this.carouselHint = carouselHint;
            this.videoHint = videoHint;
        }

        int candidateCount() {
            return images.size() + videos.size() + streams.size();
        }
    }

    private static final long POLL_MS = 220L;
    private static final int MAX_POLLS = 55; // ~12 s, then browser fallback may take over.

    private final WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long serial = 0L;

    InstagramMediaResolver(WebView webView) {
        this.webView = webView;
    }

    void cancel() {
        serial++;
        handler.removeCallbacksAndMessages(null);
    }

    void resolve(String postUrl, Callback callback) {
        final long token = ++serial;
        final String key = "r" + token;
        final String script = buildStartScript(key, postUrl);
        webView.evaluateJavascript(script, raw -> {
            if (token != serial) return;
            poll(token, key, 0, callback);
        });
    }

    private void poll(long token, String key, int pass, Callback callback) {
        if (token != serial) return;
        if (pass >= MAX_POLLS) {
            callback.onResult(new Result(false, "page_fetch", "timeout",
                    Collections.emptyList(), Collections.emptyList(), Collections.emptyList(),
                    false, false));
            return;
        }
        String js = "(function(){try{var r=(window.__imgStalkerMediaResolver||{})["
                + JSONObject.quote(key)
                + "];return r?JSON.stringify(r):JSON.stringify({state:'missing'})}catch(e){return JSON.stringify({state:'error',error:String(e)})}})()";
        webView.evaluateJavascript(js, raw -> {
            if (token != serial) return;
            try {
                String decoded = unquote(raw);
                JSONObject obj = new JSONObject(decoded);
                String state = obj.optString("state", "");
                if ("done".equals(state)) {
                    callback.onResult(parseResult(obj));
                    cleanup(key);
                    return;
                }
                if ("error".equals(state)) {
                    callback.onResult(new Result(false, obj.optString("source", "page_fetch"),
                            obj.optString("error", "resolver_error"),
                            Collections.emptyList(), Collections.emptyList(), Collections.emptyList(),
                            false, false));
                    cleanup(key);
                    return;
                }
            } catch (Exception ignored) {
                // Keep polling; Instagram may still be resolving the fetch Promise.
            }
            handler.postDelayed(() -> poll(token, key, pass + 1, callback), POLL_MS);
        });
    }

    private void cleanup(String key) {
        String js = "(function(){try{if(window.__imgStalkerMediaResolver)delete window.__imgStalkerMediaResolver["
                + JSONObject.quote(key) + "];return true}catch(e){return false}})()";
        webView.evaluateJavascript(js, ignored -> {});
    }

    private static Result parseResult(JSONObject obj) {
        ArrayList<Image> images = new ArrayList<>();
        ArrayList<String> videos = new ArrayList<>();
        ArrayList<String> streams = new ArrayList<>();
        JSONArray ia = obj.optJSONArray("images");
        if (ia != null) {
            for (int i = 0; i < ia.length(); i++) {
                JSONObject x = ia.optJSONObject(i);
                if (x == null) continue;
                String u = x.optString("u", "");
                if (!u.isEmpty()) images.add(new Image(u, x.optInt("w", 0), x.optInt("h", 0)));
            }
        }
        JSONArray va = obj.optJSONArray("videos");
        if (va != null) for (int i = 0; i < va.length(); i++) {
            String u = va.optString(i, "");
            if (!u.isEmpty()) videos.add(u);
        }
        JSONArray sa = obj.optJSONArray("streams");
        if (sa != null) for (int i = 0; i < sa.length(); i++) {
            String u = sa.optString(i, "");
            if (!u.isEmpty()) streams.add(u);
        }
        boolean ok = obj.optBoolean("ok", false);
        return new Result(ok, obj.optString("source", "page_fetch"), obj.optString("error", ""),
                images, videos, streams, obj.optBoolean("carouselHint", false),
                obj.optBoolean("videoHint", false));
    }

    private static String buildStartScript(String key, String postUrl) {
        String k = JSONObject.quote(key);
        String u = JSONObject.quote(postUrl);
        return "(function(){try{"
                + "window.__imgStalkerMediaResolver=window.__imgStalkerMediaResolver||{};"
                + "var K=" + k + ",U=" + u + ";"
                + "window.__imgStalkerMediaResolver[K]={state:'pending',source:'page_fetch'};"
                + "const dec=s=>{let x=String(s||'').replace(/\\\\u0026/gi,'&').replace(/\\\\u003d/gi,'=').replace(/\\\\u002f/gi,'/'),o='';for(let i=0;i<x.length;i++){if(x.charCodeAt(i)===92&&x.charAt(i+1)==='/'){o+='/';i++;}else{o+=x.charAt(i)}}return o.replace(/&amp;/gi,'&')};"
                + "const abs=x=>{try{return x?new URL(dec(x),U).href:''}catch(e){return ''}};"
                + "const mediaHost=x=>/(?:cdninstagram\\.com|fbcdn\\.net)/i.test(x||'');"
                + "const badImage=(x,c)=>/(?:profile_pic|profilepic|avatar|owner_profile|t51\\.2885-19|t51\\.82787-19|_nc_sid=bf7eb4)/i.test((c||'')+' '+(x||''));"
                + "const imgUrl=x=>/\\.(?:jpe?g|png|webp)(?:\\?|$)/i.test(x||'');"
                + "const vidUrl=x=>/\\.mp4(?:\\?|$)/i.test(x||'');"
                + "const streamUrl=x=>/\\.(?:m3u8|mpd)(?:\\?|$)/i.test(x||'');"
                + "const I=[],V=[],S=[],is=new Set(),vs=new Set(),ss=new Set();let carouselHint=false,videoHint=false;"
                + "const addI=(x,w,h,c)=>{x=abs(x);if(!x||!mediaHost(x)||!imgUrl(x)||badImage(x,c)||is.has(x)||I.length>=48)return;is.add(x);I.push({u:x,w:w||0,h:h||0})};"
                + "const addV=x=>{x=abs(x);if(!x||!mediaHost(x)||!vidUrl(x)||vs.has(x)||V.length>=16)return;vs.add(x);V.push(x)};"
                + "const addS=x=>{x=abs(x);if(!x||!mediaHost(x)||!streamUrl(x)||ss.has(x)||S.length>=8)return;ss.add(x);S.push(x)};"
                + "const parse=(html,source)=>{"
                + "try{var d=new DOMParser().parseFromString(html,'text/html');"
                + "d.querySelectorAll('meta[property=\\\"og:image\\\"],meta[name=\\\"twitter:image\\\"]').forEach(m=>addI(m.content,0,0,'og:image'));"
                + "d.querySelectorAll('meta[property=\\\"og:video\\\"],meta[property=\\\"og:video:url\\\"],meta[name=\\\"twitter:player:stream\\\"]').forEach(m=>{let x=abs(m.content);if(streamUrl(x))addS(x);else addV(x)});"
                + "}catch(e){}"
                + "let t=dec(html);carouselHint=carouselHint||/(?:\"carousel_media\"|GraphSidecar|XDTGraphSidecar)/i.test(t);videoHint=videoHint||/(?:\"video_versions\"|\"video_url\"|GraphVideo|XDTGraphVideo)/i.test(t);let re=/https?:\\/\\/[^\\s\\\"'<>\\\\]+/g,m;while((m=re.exec(t))){let x=m[0],c=t.slice(Math.max(0,m.index-260),Math.min(t.length,m.index+x.length+260));"
                + "if(streamUrl(x)&&/(?:dash|manifest|video|clips|carousel_media)/i.test(c))addS(x);"
                + "else if(vidUrl(x)&&/(?:video_versions|video_url|contentUrl|dash|clips|carousel_media|og:video)/i.test(c))addV(x);"
                + "else if(imgUrl(x)&&/(?:image_versions2|display_url|image_url|thumbnail_url|carousel_media|og:image|additional_image_versions)/i.test(c))addI(x,0,0,c);"
                + "}return source};"
                + "const get=async x=>{let r=await fetch(x,{credentials:'include',redirect:'follow',cache:'no-store',headers:{'Accept':'text/html,application/xhtml+xml'}});let h=await r.text();return {ok:r.ok,status:r.status,url:r.url,html:h}};"
                + "(async()=>{try{let src='canonical',a=await get(U);parse(a.html,'canonical');"
                + "if((I.length+V.length+S.length)<2){try{let E=U.replace(/\\/$/,'')+'/embed/';let b=await get(E);parse(b.html,'embed');src='canonical+embed'}catch(e){}}"
                + "let ok=(I.length+V.length+S.length)>0;window.__imgStalkerMediaResolver[K]={state:'done',ok:ok,source:src,status:a.status,finalUrl:a.url,images:I,videos:V,streams:S,carouselHint:carouselHint,videoHint:videoHint,error:ok?'':'no_post_media'};"
                + "}catch(e){window.__imgStalkerMediaResolver[K]={state:'error',ok:false,source:'page_fetch',error:String(e),images:[],videos:[],streams:[],carouselHint:false,videoHint:false}}})();"
                + "return 'started';"
                + "}catch(e){return 'start_error:'+String(e)}})()";
    }

    private static String unquote(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) {
            try {
                return new JSONArray("[" + s + "]").getString(0);
            } catch (Exception ignored) {}
        }
        return s;
    }
}
