package com.cmyk.imgstalker;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class SnsSavedMediaIdentityTest {
    private static int checks = 0;
    private static void assertTrue(boolean ok, String why) {
        if (!ok) throw new AssertionError(why);
        checks++;
    }
    private static MediaItem image(String url, String dedup) {
        return new MediaItem(url, "https://www.instagram.com/p/AbC/",
                MediaItem.Kind.IMAGE, false, 0, 0, 0L, dedup);
    }
    public static void main(String[] args) {
        String file = "771822602_18113075227982937_6750355641439683631_n.jpg";
        String cache1 = "Mzk2MjEzODAwNjYzMDkyMjQ4Mg==.3-ccb7-5";
        String cache2 = "Mzk2MjEzODAwNjYzMDkyMjQ4Mg==.4-ccb8-5";
        String a = "https://instagram.fhnd2-1.fna.fbcdn.net/v/t51.82787-15/" + file
                + "?ig_cache_key=Mzk2MjEzODAwNjYzMDkyMjQ4Mg%3D%3D.3-ccb7-5&oh=OLD&oe=AAAA";
        String b = "https://instagram.fhnd2-2.fna.fbcdn.net/v/t51.82787-15/" + file
                + "?ig_cache_key=Mzk2MjEzODAwNjYzMDkyMjQ4Mg%3D%3D.4-ccb8-5&oh=NEW&oe=BBBB";
        MediaItem now = image(b, "IMAGE|IG|cache:" + cache2);
        Set<String> older = SnsSavedMediaIdentity.savedAliases(Collections.singleton("IMAGE|IG|cache:" + cache1));
        assertTrue(SnsSavedMediaIdentity.isSaved(now, older), "changed CDN encode suffix must retain media ID");
        assertTrue(SnsSavedMediaIdentity.isSaved(now,
                SnsSavedMediaIdentity.savedAliases(Collections.singleton("IMAGE|" + a))),
                "legacy expiring full URL must map to current CDN identity");
        assertTrue(SnsSavedMediaIdentity.isSaved(now,
                SnsSavedMediaIdentity.savedAliases(Collections.singleton("IMAGE|IG|file:" + file))),
                "legacy CDN filename must be recognized through current media URL");
        assertTrue(SnsSavedMediaIdentity.isSaved(now,
                SnsSavedMediaIdentity.savedAliases(Collections.singleton(
                        "IMAGE|IG|path:/v/t51.82787-15/" + file))),
                "old IG path key should match new cache key by exact filename");
        assertTrue(SnsSavedMediaIdentity.isSaved(now,
                SnsSavedMediaIdentity.savedAliases(Collections.singleton(
                        "IMAGE|IG|url:" + a))),
                "old IG URL fallback should match current CDN identity");
        assertTrue(!SnsSavedMediaIdentity.isSaved(image(b, "IMAGE|IG|cache:OTHER"),
                SnsSavedMediaIdentity.savedAliases(Collections.singleton("IMAGE|IG|cache:DIFFERENT"))),
                "an unrelated key cannot match another key without file evidence");
        String other = b.replace("Mzk2MjEzODAwNjYzMDkyMjQ4Mg%3D%3D", "OTk5OTk5OTk5OTk5OTk5OTk5OQ%3D%3D").replace(file,
                "123456789_987654321_1234567890123456789_n.jpg");
        assertTrue(!SnsSavedMediaIdentity.isSaved(image(other, "IMAGE|IG|cache:OTHER"), older),
                "a different media asset must remain unmarked");
        assertTrue(!SnsSavedMediaIdentity.isSaved(
                new MediaItem(b, "", MediaItem.Kind.VIDEO, false, 0, 0, 0, "VIDEO|IG|cache:" + cache2), older),
                "a video must not match an image");
        assertTrue(SnsSavedMediaIdentity.hasVerifiedFile(now,
                new HashSet<>(Collections.singletonList(file.toLowerCase())), Collections.emptySet()),
                "exact saved original filename should recover a mark");
        assertTrue(!SnsSavedMediaIdentity.hasVerifiedFile(now,
                new HashSet<>(Collections.singletonList("another_name.jpg")), Collections.emptySet()),
                "folder file count by itself is never enough for an item check");
        assertTrue(!SnsSavedMediaIdentity.hasVerifiedFile(image("https://example.com/image.jpg", ""),
                new HashSet<>(Collections.singletonList("image.jpg")), Collections.emptySet()),
                "generic basename must not count as unique identity");
        String x1 = "https://pbs.twimg.com/media/ABCDEF0123456789?format=jpg&name=large";
        String x2 = "https://pbs.twimg.com/media/ABCDEF0123456789?format=jpg&name=orig";
        assertTrue(SnsSavedMediaIdentity.isSaved(image(x2, "IMAGE|" + x2),
                SnsSavedMediaIdentity.savedAliases(Collections.singleton("IMAGE|" + x1))),
                "X CDN rendition query can change without losing mark");
        assertTrue(!SnsSavedMediaIdentity.isSaved(image(x2, "IMAGE|" + x2),
                SnsSavedMediaIdentity.savedAliases(Arrays.asList("VIDEO|" + x1))),
                "X image/video are separate");
        assertTrue(SnsSavedMediaIdentity.savedAliases(Collections.singleton("NORMAL|key")).size() == 1,
                "NORMAL keys must not be interpreted as SNS aliases");
        System.out.println("PASS: " + checks + " SNS saved-media compatibility tests");
    }
}
