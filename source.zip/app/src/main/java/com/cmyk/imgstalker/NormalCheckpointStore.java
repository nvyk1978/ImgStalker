package com.cmyk.imgstalker;

import android.content.Context;
import java.io.File;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

/** NORMAL-only checkpoint identity and storage; never reads X or Instagram files. */
final class NormalCheckpointStore {
    private NormalCheckpointStore() { }

    static String key(String url) {
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.NORMAL) return "";
        try {
            URI u = new URI(url.trim());
            String host = u.getHost();
            if (host == null || host.isEmpty()) return "";
            String path = u.getRawPath();
            if (path == null || path.isEmpty()) path = "/";
            // A paging link is the same target. Preserve all other query parameters,
            // so separate boards and search filters can never share a checkpoint.
            ArrayList<String> args = new ArrayList<>();
            String raw = u.getRawQuery();
            if (raw != null) for (String part : raw.split("&")) {
                if (part.isEmpty()) continue;
                String name = part.split("=", 2)[0];
                if (name.equalsIgnoreCase("page")) continue;
                args.add(part);
            }
            Collections.sort(args);
            int port = u.getPort();
            return u.getScheme().toLowerCase(Locale.ROOT) + "://" + host.toLowerCase(Locale.ROOT)
                    + (port < 0 ? "" : ":" + port) + path
                    + (args.isEmpty() ? "" : "?" + String.join("&", args));
        } catch (Exception ignored) { return ""; }
    }

    static boolean matches(String a, String b) {
        String key = key(a);
        return !key.isEmpty() && key.equals(key(b));
    }

    static File root(Context context) { return new File(context.getFilesDir(), "Normal"); }

    static File checkpoint(Context context, String url) {
        String canonical = key(url);
        if (canonical.isEmpty()) throw new IllegalArgumentException("Not a NORMAL URL");
        URI uri = URI.create(canonical);
        String host = uri.getHost().replaceAll("[^a-zA-Z0-9._-]", "_");
        String path = uri.getPath();
        String leaf = path == null || path.isEmpty() ? "index" : path.substring(path.lastIndexOf('/') + 1);
        if (leaf.isEmpty()) leaf = "index";
        leaf = leaf.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (leaf.length() > 36) leaf = leaf.substring(0, 36);
        return new File(new File(root(context), host), leaf + "_" + sha256(canonical).substring(0, 20) + ".json");
    }

    private static String sha256(String data) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(data.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            for (byte v : bytes) b.append(String.format(Locale.ROOT, "%02x", v & 255));
            return b.toString();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
}
