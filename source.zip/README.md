# ImgStalker v0.1.54 (55)

## 0.1.54 rollback
- Reverted the 0.1.53 background-session retention implementation that moved/retained the live Crawler/WebView in `AnalysisKeepAliveService`.
- Restored `AnalysisKeepAliveService`, `MainActivity` lifecycle handling, and `android:stopWithTask` behavior to the 0.1.52 implementation.
- Instagram crawler/retry/carousel logic is not changed by this rollback.
- The existing `バックグラウンドでも解析` UI/toggle from 0.1.52 is retained.
- applicationId and fixed signing configuration are unchanged.

## Package
- versionCode 55 / versionName 0.1.54.
- applicationId: com.cmyk.imgstalker
