package com.cmyk.imgstalker;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Display-only publication dates. Never infers a post date from file modification time,
 * thumbnail headers, download time or Instagram CDN expiration. The crawler/downloader is
 * deliberately not involved: only X's public snowflake ID and Instagram's already-observed
 * first-party timeline publication timestamps are used.
 */
final class PostPublicationDates {
    private static final long TWITTER_EPOCH_MS = 1288834974657L;
    private static final long MIN_PUBLISHED_MS = 1262304000000L; // 2010-01-01 UTC
    private static final String PREFS = "imgstalker_post_dates_v1";
    private static final Pattern X_STATUS = Pattern.compile(
            "https?://(?:(?:www|mobile)\\.)?(?:x\\.com|twitter\\.com)/(?:[^/?#]+/status|i/web/status)/(\\d{8,20})(?:[/?#]|$)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern IG_POST = Pattern.compile(
            "https?://(?:www\\.)?instagram\\.com/(?:p|reel|tv)/([A-Za-z0-9_-]{5,30})(?:[/?#]|$)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern IG_CODE = Pattern.compile("[A-Za-z0-9_-]{5,30}");
    private static final DateTimeFormatter DISPLAY = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm", Locale.JAPAN)
            .withZone(ZoneId.of("Asia/Tokyo"));

    private PostPublicationDates() {}

    static String formatForItem(Context context, MediaItem item) {
        if (item == null) return "";
        long published = twitterPublishedAt(item.referrer);
        if (published == 0L) published = twitterPublishedAt(item.url);
        if (published == 0L && context != null) {
            String code = instagramCode(item.referrer);
            if (code.isEmpty()) code = instagramCode(item.url);
            if (!code.isEmpty()) {
                published = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .getLong("ig_" + code, 0L);
            }
        }
        return valid(published) ? DISPLAY.format(Instant.ofEpochMilli(published)) : "";
    }

    /** X's published status timestamp is encoded in the ID, independently of media filename. */
    static long twitterPublishedAt(String url) {
        if (url == null || url.isEmpty()) return 0L;
        Matcher match = X_STATUS.matcher(url);
        if (!match.find()) return 0L;
        try {
            long id = Long.parseLong(match.group(1));
            long time = (id >>> 22) + TWITTER_EPOCH_MS;
            return valid(time) ? time : 0L;
        } catch (NumberFormatException e) { return 0L; }
    }

    /** Read only already intercepted Instagram response data. Never initiates network requests. */
    static void observeInstagramResponse(Context context, String payload) {
        if (context == null || payload == null || payload.length() < 12 || payload.length() > 3000000) return;
        try {
            Object root = payload.charAt(0) == '[' ? new JSONArray(payload) : new JSONObject(payload);
            ArrayDeque<Object> queue = new ArrayDeque<>();
            queue.add(root);
            Map<String, Long> found = new HashMap<>();
            int visited = 0;
            while (!queue.isEmpty() && visited++ < 4500) {
                Object value = queue.removeFirst();
                if (value instanceof JSONObject) {
                    JSONObject obj = (JSONObject) value;
                    String code = obj.optString("code", obj.optString("shortcode", ""));
                    long unix = firstTimestamp(obj);
                    if (IG_CODE.matcher(code).matches() && unix > 0L) {
                        found.put(code, unix);
                    }
                    JSONArray names = obj.names();
                    if (names == null) continue;
                    for (int i = 0; i < names.length(); i++) {
                        Object child = obj.opt(names.optString(i));
                        if (child instanceof JSONObject || child instanceof JSONArray) queue.addLast(child);
                    }
                } else if (value instanceof JSONArray) {
                    JSONArray items = (JSONArray) value;
                    for (int i = 0; i < items.length(); i++) {
                        Object child = items.opt(i);
                        if (child instanceof JSONObject || child instanceof JSONArray) queue.addLast(child);
                    }
                }
            }
            if (found.isEmpty()) return;
            SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            boolean changed = false;
            for (Map.Entry<String, Long> entry : found.entrySet()) {
                String key = "ig_" + entry.getKey();
                if (prefs.getLong(key, 0L) != entry.getValue()) {
                    editor.putLong(key, entry.getValue());
                    changed = true;
                }
            }
            if (changed) editor.apply();
        } catch (Throwable ignored) {
            // A malformed, changed or unsupported source payload must never break IG collection.
        }
    }

    private static String instagramCode(String url) {
        if (url == null || url.isEmpty()) return "";
        Matcher match = IG_POST.matcher(url);
        return match.find() ? match.group(1) : "";
    }

    private static long firstTimestamp(JSONObject item) {
        for (String key : new String[]{"taken_at", "taken_at_timestamp", "media_taken_at", "publish_time"}) {
            if (!item.has(key)) continue;
            Object raw = item.opt(key);
            if (raw == null || raw == JSONObject.NULL) continue;
            try {
                long value = Long.parseLong(String.valueOf(raw).trim());
                long millis = value > 100000000000L ? value : value * 1000L;
                if (valid(millis)) return millis;
            } catch (NumberFormatException ignored) { }
        }
        return 0L;
    }

    private static boolean valid(long timestamp) {
        return timestamp >= MIN_PUBLISHED_MS && timestamp <= System.currentTimeMillis() + 86400000L;
    }
}
