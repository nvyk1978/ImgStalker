#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$TEMP/src/android/content" "$TEMP/src/android/graphics" "$TEMP/src/android/webkit" "$TEMP/src/android/widget" "$TEMP/src/org/json" "$TEMP/src/com/cmyk/imgstalker" "$TEMP/classes"
cat > "$TEMP/src/android/content/Context.java" <<'JAVA'
package android.content; public class Context {}
JAVA
cat > "$TEMP/src/android/graphics/Bitmap.java" <<'JAVA'
package android.graphics; public class Bitmap {}
JAVA
cat > "$TEMP/src/android/webkit/CookieManager.java" <<'JAVA'
package android.webkit; public class CookieManager {public String getCookie(String url){return url;} public static CookieManager getInstance(){return new CookieManager();}}
JAVA
cat > "$TEMP/src/android/webkit/WebView.java" <<'JAVA'
package android.webkit; public class WebView {}
JAVA
cat > "$TEMP/src/android/widget/ImageView.java" <<'JAVA'
package android.widget; public class ImageView {}
JAVA
cat > "$TEMP/src/org/json/JSONObject.java" <<'JAVA'
package org.json; public class JSONObject {}
JAVA
cat > "$TEMP/src/com/cmyk/imgstalker/BackendStubs.java" <<'JAVA'
package com.cmyk.imgstalker;
import java.util.*;
import android.content.Context;
import android.graphics.Bitmap;
import android.webkit.*;
import android.widget.ImageView;
import org.json.JSONObject;
class CrawlerEngine {
    interface Listener {}
    CrawlerEngine(WebView v, Listener l){}
    void start(String u,boolean p,boolean d,boolean i,boolean im,boolean vid,int px){}
    void cancel(){} void requestGracefulStop(){}
    boolean recoverFromStall(){return false;} boolean hasPendingWork(){return false;}
    String progressSnapshot(){return "";}
    void seedExternalResumeMedia(List<MediaItem> m){} void seedContinuationResults(List<MediaItem> m){}
    boolean isIncompleteCompletion(){return false;} String getIncompleteCompletionReason(){return "";}
    JSONObject checkpointCursor(){return null;} void seedQueueCursor(JSONObject o){}
    void setIncludeXReposts(boolean v){} void setXSearchExecutionAllowed(boolean v,String why){}
}
class NormalCrawlerEngine {
    NormalCrawlerEngine(WebView v,CrawlerEngine.Listener l){}
    void start(String u,boolean p,boolean d,boolean im,boolean vid,int px){}
    void cancel(){} void requestGracefulStop(){}
    boolean recoverFromStall(){return false;} boolean hasPendingWork(){return false;}
    String progressSnapshot(){return "";}
    void seedExternalResumeMedia(List<MediaItem> m){} void seedContinuationResults(List<MediaItem> m){}
    boolean isIncompleteCompletion(){return false;} String getIncompleteCompletionReason(){return "";}
    JSONObject checkpointCursor(){return null;} void seedQueueCursor(JSONObject cursor){}
}
class InstagramCrawlerEngine extends NormalCrawlerEngine {
    InstagramCrawlerEngine(WebView v,CrawlerEngine.Listener l){super(v,l);}
    void seedInstagramContinuationState(Collection<String> a,Collection<String> b){}
    List<String> getCompletedInstagramPostUrls(){return new ArrayList<>();}
    List<String> getDiscoveredInstagramPostUrls(){return new ArrayList<>();}
    int getInstagramFailedPostCount(){return 0;}
}
class MediaDownloader {
    interface Listener{}
    MediaDownloader(Context c,boolean x,Listener l){}
    void cancel(){}
    void download(List<MediaItem> items,String title,String category,String account){}
}
class NormalMediaDownloader extends MediaDownloader {
    NormalMediaDownloader(Context c,boolean x,Listener l){super(c,x,l);}
}
class InstagramMediaDownloader extends MediaDownloader {
    InstagramMediaDownloader(Context c,boolean x,Listener l){super(c,x,l);}
}
class ThumbnailLoader {
    ThumbnailLoader(Context c,Runnable r){}
    void prefetch(MediaItem i){} boolean isCachedOrPending(MediaItem i){return false;}
    int pendingCount(){return 0;} void load(ImageView v,MediaItem i){}
    void cancelPending(){} void clearCache(){} void shutdown(){}
}
class NormalThumbnailLoader extends ThumbnailLoader {NormalThumbnailLoader(Context c,Runnable r){super(c,r);}}
class InstagramThumbnailLoader extends ThumbnailLoader {InstagramThumbnailLoader(Context c,Runnable r){super(c,r);}}
class OriginalImageLoader {static Bitmap load(Context c,MediaItem i) throws Exception{return null;}}
class NormalOriginalImageLoader {static Bitmap load(Context c,MediaItem i) throws Exception{return null;}}
class InstagramOriginalImageLoader {static Bitmap load(Context c,MediaItem i) throws Exception{return null;}}
class SessionCookies {static void use(CookieManager c){} static String getCookie(String u){return "X";}}
class NormalSessionCookies {static void use(CookieManager c){} static String getCookie(String u){return "NORMAL";}}
class InstagramSessionCookies {static void use(CookieManager c){} static String getCookie(String u){return "INSTAGRAM";}}
class TwitterVideoUrl {
    static boolean isTwitterVideoMp4(String u){return true;}
    static boolean isKnownFailed(String u,String kind){return false;}
    static String resolvedOrOriginal(String u){return "x:"+u;}
    static String resolveFresh(String u,String ref,String ua){return "fresh:"+u;}
    static void markRecovered(String u,String r){} static void markFailed(String u,String kind){}
    static void resetSession(){}
}
JAVA
cat > "$TEMP/src/com/cmyk/imgstalker/ProviderTest.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.webkit.WebView;
public final class ProviderTest {
    static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    public static void main(String[] args){
        String[] urls={"https://example.org/p","https://x.com/test","https://instagram.com/test"};
        Class<?>[] types={NormalCrawlerAdapter.class,XCrawlerAdapter.class,InstagramCrawlerAdapter.class};
        for(int i=0;i<3;i++){
            ModeProvider provider=ModeProviders.forUrl(urls[i]);
            ModeCrawler crawler=provider.crawler(new WebView(),null);
            check(crawler.getClass()==types[i],"wrong provider crawler "+i);
            check(provider.cookieFor("url").equals(i==0?"NORMAL":i==1?"X":"INSTAGRAM"),"wrong cookie owner");
            check((crawler instanceof InstagramCrawlerSession)==(i==2),"Instagram methods on other mode");
            check((crawler instanceof XCrawlerSession)==(i==1),"X methods on other mode");
            check(provider.preview().resolvedUrl("movie").equals(i==1?"x:movie":"movie"),"preview policy mixed");
            crawler.start(urls[i],true,true,true,true,true,640);
            for(int j=0;j<3;j++)if(i!=j){
                boolean refused=false;
                try{crawler.start(urls[j],true,true,true,true,true,640);}
                catch(IllegalArgumentException e){refused=true;}
                check(refused,"foreign URL reached provider "+i+" from "+j);
            }
        }
        System.out.println("PASS: 3 providers, 3 cookie scopes, 3 preview policies, all 6 cross-provider starts refused");
    }
}
JAVA
SRC='app/src/main/java/com/cmyk/imgstalker'
FILES=(AnalysisModeRouter.java MediaItem.java ModeCrawler.java ModeDownloader.java ModeThumbnailLoader.java
       InstagramCrawlerSession.java XCrawlerSession.java NormalCrawlerSession.java ModeProvider.java ModeProviders.java ModePreviewPolicy.java
       NormalModeProvider.java XModeProvider.java InstagramModeProvider.java
       NormalCrawlerAdapter.java XCrawlerAdapter.java InstagramCrawlerAdapter.java
       NormalDownloaderAdapter.java XDownloaderAdapter.java InstagramDownloaderAdapter.java
       NormalThumbnailAdapter.java XThumbnailAdapter.java InstagramThumbnailAdapter.java
       NormalPreviewPolicy.java XPreviewPolicy.java InstagramPreviewPolicy.java)
SOURCEFILES=(); for name in "${FILES[@]}"; do SOURCEFILES+=("$SRC/$name"); done
javac -encoding UTF-8 -sourcepath "$TEMP/src" -d "$TEMP/classes" $(find "$TEMP/src" -name '*.java') "${SOURCEFILES[@]}"
java -cp "$TEMP/classes" com.cmyk.imgstalker.ProviderTest
