package com.cmyk.imgstalker;

import android.content.Context;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/** Read-only navigation statistics. Never starts a crawl or changes a saved/analysis JSON. */
final class NavigationMediaCounts {
    static final class Result {
        final String images;
        final String videos;
        Result(String images, String videos) { this.images = images; this.videos = videos; }
    }
    private NavigationMediaCounts() { }

    /** Resolve the same cached statistics identity as the existing per-mode JSON stores. */
    static String identity(String url) {
        SnsResumeStore.Target target = SnsResumeStore.targetForUrl(url);
        if (target != null) return target.categoryName + ":" + target.accountName.toLowerCase(java.util.Locale.ROOT);
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.NORMAL) return "";
        return NormalCheckpointStore.key(url);
    }

    static Result forUrl(Context context, String url) {
        if (context == null || SiteVisitStore.normalize(url).isEmpty()) return new Result("画像 —/—", "動画 —/—");
        try {
            SnsResumeStore.Target target = SnsResumeStore.targetForUrl(url);
            if (target != null) {
                SnsResumeStore.State external = SnsResumeStore.load(context, target);
                AnalysisSessionStore.State internal = AnalysisSessionStore.load(context, url);
                List<MediaItem> discovered = external != null ? external.mediaItems : null;
                // An internal SNS checkpoint is global to this mode. Never accept another account's media.
                if ((discovered == null || discovered.isEmpty()) && internal != null
                        && sameAccount(target, SnsResumeStore.targetForUrl(internal.sourceUrl))) {
                    discovered = internal.mediaItems;
                }
                LinkedHashSet<String> saved = SnsSavedLedgerStore.load(context, target);
                if (external != null) saved.addAll(external.savedMediaKeys);
                return useFiles(calculate(discovered, saved),
                        NavigationSavedFileInventory.forUrl(context, url));
            }
            if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.NORMAL)
                return new Result("画像 —/—", "動画 —/—");
            AnalysisSessionStore.State state = AnalysisSessionStore.load(context, url);
            Map<String, String> savedLocations = NormalSavedLedgerStore.load(context, url);
            return useFiles(calculate(state == null ? null : state.mediaItems, savedLocations.keySet()),
                    NavigationSavedFileInventory.forUrl(context, url));
        } catch (Throwable t) {
            DiagnosticLog.logException("NAVIGATION_MEDIA_COUNTS_FAIL", t);
            return new Result("画像 —/—", "動画 —/—");
        }
    }

    /** The inventory is authoritative for the numerator; checkpoint JSON supplies the denominator. */
    static Result useFiles(Result fallback, NavigationSavedFileInventory.Counts files) {
        if (files == null) return fallback;
        return new Result(withFileCount(fallback.images, "画像", files.images),
                withFileCount(fallback.videos, "動画", files.videos));
    }

    private static String withFileCount(String old, String kind, Integer files) {
        if (files == null) return old; // Permission/volume not accessible: preserve JSON result.
        int slash = old.indexOf('/');
        return kind + " " + files + "/" + (slash >= 0 ? old.substring(slash + 1) : "—");
    }

    private static boolean sameAccount(SnsResumeStore.Target a, SnsResumeStore.Target b) {
        return a != null && b != null && a.service == b.service
                && a.accountName.equalsIgnoreCase(b.accountName);
    }

    /** Pure counting logic: media keys are deduped, stream links do not count as image/video. */
    static Result calculate(List<MediaItem> discovered, Collection<String> savedKeys) {
        LinkedHashMap<String, MediaItem.Kind> media = new LinkedHashMap<>();
        if (discovered != null) for (MediaItem item : discovered) {
            if (item == null || item.kind == MediaItem.Kind.STREAM) continue;
            String key = SnsResumeStore.savedMediaKey(item);
            if (!key.isEmpty() && !media.containsKey(key)) media.put(key, item.kind);
        }
        int imageTotal = 0, videoTotal = 0, imageSaved = 0, videoSaved = 0;
        HashSet<String> accountedSaved = new HashSet<>();
        for (Map.Entry<String, MediaItem.Kind> item : media.entrySet()) {
            if (item.getValue() == MediaItem.Kind.IMAGE) imageTotal++;
            else videoTotal++;
            if (savedKeys != null && savedKeys.contains(item.getKey())) {
                if (item.getValue() == MediaItem.Kind.IMAGE) imageSaved++;
                else videoSaved++;
                accountedSaved.add(item.getKey());
            }
        }
        // Old saved keys might outlive the crawl JSON. A typed URL fallback is safe;
        // an opaque Instagram/X dedup key without a matching media entry is NOT classifiable.
        boolean unknownSavedKind = false;
        if (savedKeys != null) for (String key : savedKeys) {
            if (key == null || key.isEmpty() || accountedSaved.contains(key)) continue;
            if (media.containsKey(key)) continue;
            if (key.startsWith("IMAGE|")) imageSaved++;
            else if (key.startsWith("VIDEO|")) videoSaved++;
            else unknownSavedKind = true;
        }
        boolean haveDiscovery = discovered != null && (!discovered.isEmpty() || savedKeys == null || savedKeys.isEmpty());
        String imageDenominator = haveDiscovery ? Integer.toString(imageTotal) : "—";
        String videoDenominator = haveDiscovery ? Integer.toString(videoTotal) : "—";
        String imageNumerator = unknownSavedKind ? "—" : Integer.toString(imageSaved);
        String videoNumerator = unknownSavedKind ? "—" : Integer.toString(videoSaved);
        return new Result("画像 " + imageNumerator + "/" + imageDenominator,
                "動画 " + videoNumerator + "/" + videoDenominator);
    }
}
