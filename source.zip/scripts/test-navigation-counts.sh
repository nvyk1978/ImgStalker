#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/stub/android/content" "$TMP/stub/com/cmyk/imgstalker" "$TMP/out"
cat > "$TMP/stub/android/content/Context.java" <<'JAVA'
package android.content; public class Context { }
JAVA
cat > "$TMP/stub/com/cmyk/imgstalker/NavigationCountStubs.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.content.Context;
import java.util.*;
final class SiteVisitStore { static String normalize(String s){return s;} }
final class AnalysisModeRouter { enum Mode {NORMAL,X,INSTAGRAM} static Mode fromUrl(String u){return Mode.NORMAL;} }
final class DiagnosticLog { static void logException(String k,Throwable t){throw new RuntimeException(t);} }
final class SnsResumeStore {
 static class Target { final String accountName=""; final String categoryName=""; final Object service=""; }
 static class State { final java.util.ArrayList<MediaItem> mediaItems=new java.util.ArrayList<>();final LinkedHashSet<String> savedMediaKeys=new LinkedHashSet<>(); }
 static Target targetForUrl(String s){return null;}
 static State load(Context c, Target t){return null;}
 static String savedMediaKey(MediaItem item) {return item.dedupKey.isEmpty()?item.kind.name()+"|"+item.url:item.dedupKey;}
}
final class SnsSavedLedgerStore { static LinkedHashSet<String> load(Context c,SnsResumeStore.Target t){return new LinkedHashSet<>();} }
final class NormalSavedLedgerStore { static Map<String,String> load(Context c,String url){return new HashMap<>();} }
final class NavigationSavedFileInventory {
 static class Counts {final Integer images,videos;Counts(Integer a,Integer b){images=a;videos=b;}}
 static Counts forUrl(Context context,String url){return new Counts(null,null);}
}
final class NormalCheckpointStore { static String key(String s){return s;} }
final class DiscoveredMediaLedger {
 static class Snapshot { boolean readable=true,existed=false; java.util.ArrayList<MediaItem> mediaItems(){return new java.util.ArrayList<>();} }
 static String identity(String u){return u;}
 static Snapshot merge(Context c,String u,java.util.Collection<MediaItem> m){return new Snapshot();}
}
final class AnalysisSessionStore {
 static class State {String sourceUrl=""; java.util.ArrayList<MediaItem> mediaItems=new java.util.ArrayList<>();}
 static State load(Context c,String u){return null;}
}
JAVA
cat > "$TMP/stub/com/cmyk/imgstalker/NavigationCountTest.java" <<'JAVA'
package com.cmyk.imgstalker;
import java.util.*;
public class NavigationCountTest {
 static void eq(String want,String got) { if (!want.equals(got)) throw new AssertionError(want+" != "+got); }
 public static void main(String[] args) {
  List<MediaItem> media = Arrays.asList(
   new MediaItem("https://cdn/img/1", "", MediaItem.Kind.IMAGE, false,0,0,0L,"i1"),
   new MediaItem("https://cdn/img/1?size=2", "", MediaItem.Kind.IMAGE, false,0,0,0L,"i1"),
   new MediaItem("https://cdn/img/2", "", MediaItem.Kind.IMAGE, false,0,0,0L,"i2"),
   new MediaItem("https://cdn/video/1", "", MediaItem.Kind.VIDEO, false,0,0,0L,"v1"),
   new MediaItem("https://cdn/stream", "", MediaItem.Kind.STREAM, false,0,0,0L,"stream")
  );
  NavigationMediaCounts.Result r = NavigationMediaCounts.calculate(media,Arrays.asList("i1","v1"));
  eq("画像 1/2",r.images);eq("動画 1/1",r.videos);
  r=NavigationMediaCounts.calculate(null,Arrays.asList("IMAGE|https://old/img","VIDEO|https://old/video"));
  eq("画像 1/—",r.images);eq("動画 1/—",r.videos);
  r=NavigationMediaCounts.calculate(null,Arrays.asList("opaque-sns-key"));
  eq("画像 —/—",r.images);eq("動画 —/—",r.videos);
  r=NavigationMediaCounts.calculate(Collections.emptyList(),Collections.emptySet());
  eq("画像 0/0",r.images);eq("動画 0/0",r.videos);
  r=NavigationMediaCounts.useFiles(new NavigationMediaCounts.Result("画像 —/12","動画 —/3"),
          new NavigationSavedFileInventory.Counts(7,2));
  eq("画像 7/12",r.images);eq("動画 2/3",r.videos);
  r=NavigationMediaCounts.useFiles(new NavigationMediaCounts.Result("画像 5/—","動画 1/—"),
          new NavigationSavedFileInventory.Counts(0,null));
  eq("画像 0/—",r.images);eq("動画 1/—",r.videos);
  System.out.println("PASS: count dedup, typed legacy, unknown, live filesystem override, unknown volume");
 }
}
JAVA
javac -encoding UTF-8 -d "$TMP/out" \
 "$TMP/stub/android/content/Context.java" "$TMP/stub/com/cmyk/imgstalker/NavigationCountStubs.java" \
 app/src/main/java/com/cmyk/imgstalker/MediaItem.java \
 app/src/main/java/com/cmyk/imgstalker/NavigationMediaCounts.java \
 "$TMP/stub/com/cmyk/imgstalker/NavigationCountTest.java"
java -cp "$TMP/out" com.cmyk.imgstalker.NavigationCountTest
