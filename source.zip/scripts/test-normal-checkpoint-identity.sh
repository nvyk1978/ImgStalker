#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/content" "$TMP/out"
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content;
public class Context {
 private final java.io.File dir;
 public Context(java.io.File dir) {this.dir = dir;}
 public java.io.File getFilesDir() { return dir; }
}
JAVA
javac -encoding UTF-8 -d "$TMP/out" "$TMP/src/android/content/Context.java" \
 app/src/main/java/com/cmyk/imgstalker/AnalysisModeRouter.java \
 app/src/main/java/com/cmyk/imgstalker/NormalCheckpointStore.java \
 tests/NormalCheckpointIdentityTest.java
java -cp "$TMP/out" com.cmyk.imgstalker.NormalCheckpointIdentityTest
