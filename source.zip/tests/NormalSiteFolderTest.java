package com.cmyk.imgstalker;

public final class NormalSiteFolderTest {
    private static void expected(String url, String want) {
        String actual = NormalSiteFolder.forPage(url);
        if (!want.equals(actual)) {
            throw new AssertionError(url + ": expected [" + want + "] got [" + actual + "]");
        }
    }
    public static void main(String[] args) {
        expected("https://legmemory.com/bbs/officelady/joyfulyy.cgi?page=0", "Normal/legmemory.com");
        expected("https://legmemory.com/bbs/officelady/joyfulyy.cgi?page=15", "Normal/legmemory.com");
        expected("http://legmemory.com/otherboard/index.html", "Normal/legmemory.com");
        expected("https://WWW.LegMemory.Com/something", "Normal/legmemory.com");
        expected("https://example.org/pictures?a=1", "Normal/example.org");
        expected("https://cdn.example.org/pictures?a=1", "Normal/cdn.example.org");
        expected("https://x.com/name", "");
        expected("https://twitter.com/name", "");
        expected("https://instagram.com/p/abc", "");
        expected("https://x.com.evil.example/gallery", "Normal/x.com.evil.example");
        expected("file:///tmp/whatever", "");
        expected("not a url with spaces", "");
        System.out.println("PASS: NORMAL destination fixed per site, foreign modes rejected");
    }
}
