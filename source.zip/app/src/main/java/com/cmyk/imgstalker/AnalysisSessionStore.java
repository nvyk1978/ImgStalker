package com.cmyk.imgstalker;

import android.content.Context;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Process-independent checkpoint for every analysis mode, including ordinary web pages,
 * streams and SNS. Stored in private storage; the existing SNS download-sidecar is unchanged.
 * A checkpoint is only written on an ordered single-thread executor by the owner Activity.
 */
final class AnalysisSessionStore {
    static final int SCHEMA = 1;
    static final class State {
        String sourceUrl = "";
        boolean complete;
        boolean pages, details, intelligent, images, videos, background, xReposts, xGifAsGif;
        int targetPx = 640;
        long updatedAt;
        JSONObject cursor;
        final ArrayList<MediaItem> mediaItems = new ArrayList<>();
    }
    private AnalysisSessionStore() {}
    private static AtomicFile file(Context context) {
        return new AtomicFile(new File(context.getFilesDir(), "imgstalker_analysis_checkpoint.json"));
    }
    static void write(Context context, State state) {
        if (context == null || state == null || state.sourceUrl.isEmpty()) return;
        FileOutputStream output = null;
        AtomicFile atomic = file(context);
        try {
            JSONObject root = new JSONObject();
            root.put("schema", SCHEMA);
            root.put("url", state.sourceUrl);
            root.put("complete", state.complete);
            root.put("updatedAt", state.updatedAt);
            root.put("pages", state.pages);
            root.put("details", state.details);
            root.put("intelligent", state.intelligent);
            root.put("images", state.images);
            root.put("videos", state.videos);
            root.put("background", state.background);
            root.put("xReposts", state.xReposts);
            root.put("xGifAsGif", state.xGifAsGif);
            root.put("targetPx", state.targetPx);
            if (state.cursor != null) root.put("cursor", state.cursor);
            JSONArray media = new JSONArray();
            for (MediaItem item : state.mediaItems) {
                if (item == null || item.url == null || item.url.isEmpty()) continue;
                JSONObject m = new JSONObject();
                m.put("url", item.url);
                m.put("ref", item.referrer);
                m.put("kind", item.kind.name());
                m.put("width", item.width);
                m.put("height", item.height);
                m.put("duration", item.durationMs);
                m.put("dedup", item.dedupKey);
                m.put("order", item.displayOrder);
                media.put(m);
            }
            root.put("media", media);
            output = atomic.startWrite();
            output.write(root.toString().getBytes(StandardCharsets.UTF_8));
            atomic.finishWrite(output);
            DiagnosticLog.log("ANALYSIS_CHECKPOINT_WRITE complete=" + state.complete
                    + " media=" + state.mediaItems.size()
                    + " cursor=" + (state.cursor != null) + " url=" + state.sourceUrl);
        } catch (Throwable t) {
            if (output != null) atomic.failWrite(output);
            DiagnosticLog.logException("ANALYSIS_CHECKPOINT_WRITE_FAIL", t);
        }
    }
    static State load(Context context) {
        if (context == null) return null;
        try (FileInputStream in = file(context).openRead()) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] bytes = new byte[8192];
            int n;
            while ((n = in.read(bytes)) >= 0) buffer.write(bytes, 0, n);
            JSONObject root = new JSONObject(buffer.toString(StandardCharsets.UTF_8.name()));
            if (root.optInt("schema", -1) != SCHEMA) return null;
            State state = new State();
            state.sourceUrl = root.optString("url", "");
            if (!(state.sourceUrl.startsWith("https://") || state.sourceUrl.startsWith("http://"))) return null;
            state.complete = root.optBoolean("complete", false);
            state.updatedAt = root.optLong("updatedAt", 0L);
            state.pages = root.optBoolean("pages", true);
            state.details = root.optBoolean("details", true);
            state.intelligent = root.optBoolean("intelligent", true);
            state.images = root.optBoolean("images", true);
            state.videos = root.optBoolean("videos", true);
            state.background = root.optBoolean("background", false);
            state.xReposts = root.optBoolean("xReposts", false);
            state.xGifAsGif = root.optBoolean("xGifAsGif", true);
            state.targetPx = root.optInt("targetPx", 640);
            state.cursor = root.optJSONObject("cursor");
            JSONArray media = root.optJSONArray("media");
            if (media != null) for (int i = 0; i < media.length(); i++) {
                JSONObject m = media.optJSONObject(i);
                if (m == null) continue;
                String url = m.optString("url", "");
                if (url.isEmpty()) continue;
                try {
                    state.mediaItems.add(new MediaItem(url, m.optString("ref", ""),
                            MediaItem.Kind.valueOf(m.optString("kind", "IMAGE")), false,
                            m.optInt("width", 0), m.optInt("height", 0),
                            m.optLong("duration", 0L), m.optString("dedup", ""),
                            m.optLong("order", Long.MAX_VALUE)));
                } catch (IllegalArgumentException ignored) { }
            }
            DiagnosticLog.log("ANALYSIS_CHECKPOINT_LOAD complete=" + state.complete
                    + " media=" + state.mediaItems.size() + " cursor=" + (state.cursor != null)
                    + " ageMs=" + (System.currentTimeMillis() - state.updatedAt));
            return state;
        } catch (java.io.FileNotFoundException ignored) {
            return null;
        } catch (Throwable t) {
            DiagnosticLog.logException("ANALYSIS_CHECKPOINT_LOAD_FAIL", t);
            return null;
        }
    }
}
