package com.cmyk.imgstalker;

import java.net.URI;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

/**
 * URL fallback cache used only by the INSTAGRAM media/thumbnail transport.
 * It never reads or writes TwitterVideoUrl's (X mode) recovery state.
 */
final class InstagramVideoUrl {
    private static final ConcurrentHashMap<String, String> RECOVERED = new ConcurrentHashMap<>();

    private InstagramVideoUrl() {}

    static String resolvedOrOriginal(String raw) {
        if (raw == null) return null;
        String recovered = RECOVERED.get(raw);
        return recovered == null || recovered.isEmpty() ? raw : recovered;
    }

    static void markRecovered(String original, String recovered) {
        if (original == null || recovered == null || recovered.trim().isEmpty()) return;
        RECOVERED.put(original, recovered);
    }

    /**
     * Legacy CDN 403 fallback: remove the X video CDN's optional tag parameter.
     * Never rewrite Instagram/normal sites' signed CDN query parameters.
     */
    static String stripTag(String raw) {
        if (raw == null || raw.isEmpty()) return raw;
        try {
            URI uri = new URI(raw);
            String host = uri.getHost();
            String path = uri.getPath();
            if (host == null || !host.equalsIgnoreCase("video.twimg.com")
                    || path == null || !path.toLowerCase(Locale.ROOT).endsWith(".mp4")) {
                return raw;
            }
            int question = raw.indexOf('?');
            if (question < 0) return raw;
            int fragment = raw.indexOf('#', question);
            int queryEnd = fragment < 0 ? raw.length() : fragment;
            String query = raw.substring(question + 1, queryEnd);
            StringBuilder filtered = new StringBuilder();
            boolean removed = false;
            for (String param : query.split("&", -1)) {
                String key = param.substring(0, param.indexOf('=') < 0 ? param.length() : param.indexOf('='));
                if ("tag".equalsIgnoreCase(key)) {
                    removed = true;
                    continue;
                }
                if (filtered.length() > 0) filtered.append('&');
                filtered.append(param);
            }
            if (!removed) return raw;
            return raw.substring(0, question)
                    + (filtered.length() == 0 ? "" : "?" + filtered)
                    + raw.substring(queryEnd);
        } catch (Exception ignored) {
            return raw;
        }
    }
}
