#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
SRC="$TMP/stub"
mkdir -p "$SRC/android/content" "$SRC/android/database" "$SRC/android/net" "$SRC/android/os" "$SRC/android/os/storage" "$SRC/android/provider" "$SRC/com/cmyk/imgstalker" "$TMP/out"
cat > "$SRC/android/net/Uri.java" <<'JAVA'
package android.net;
public class Uri {
 private final String v;
 public Uri(String s){v=s;}
 public static Uri parse(String s){return new Uri(s);}
 public String toString(){return v;}
}
JAVA
cat > "$SRC/android/database/Cursor.java" <<'JAVA'
package android.database;
public interface Cursor extends AutoCloseable {
 boolean moveToNext(); int getColumnIndex(String column); String getString(int col);
 long getLong(int col); boolean isNull(int col); void close();
}
JAVA
cat > "$SRC/android/content/ContentResolver.java" <<'JAVA'
package android.content;
import android.database.Cursor;
import android.net.Uri;
public class ContentResolver {
 public Cursor query(Uri uri, String[] projection,String selection,String[] args,String sort){return null;}
}
JAVA
cat > "$SRC/android/content/Context.java" <<'JAVA'
package android.content;
public class Context {
 public static final String STORAGE_SERVICE="storage";
 public ContentResolver getContentResolver(){return null;}
 public Object getSystemService(String name){return null;}
}
JAVA
cat > "$SRC/android/os/Environment.java" <<'JAVA'
package android.os;
import java.io.File;
public class Environment {
 public static final String DIRECTORY_MOVIES="Movies";
 public static File getExternalStorageDirectory(){return new File("/storage/emulated/0");}
 public static File getExternalStoragePublicDirectory(String name){return new File("/storage/emulated/0/"+name);}
}
JAVA
cat > "$SRC/android/os/storage/StorageManager.java" <<'JAVA'
package android.os.storage;
import java.util.*;
public class StorageManager {
 public java.util.List<StorageVolume> getStorageVolumes(){return Collections.emptyList();}
}
JAVA
cat > "$SRC/android/os/storage/StorageVolume.java" <<'JAVA'
package android.os.storage;
import java.io.File;
public class StorageVolume {
 public File getDirectory(){return null;}
 public String getMediaStoreVolumeName(){return null;}
}
JAVA
cat > "$SRC/android/provider/MediaStore.java" <<'JAVA'
package android.provider;
import android.net.Uri;
public class MediaStore {
 public static final String VOLUME_EXTERNAL_PRIMARY="external_primary";
 public static final class MediaColumns {
  public static final String DISPLAY_NAME="_display_name",SIZE="_size",RELATIVE_PATH="relative_path",IS_PENDING="is_pending";
 }
 public static final class Images {public static final class Media {
  public static Uri getContentUri(String volume){return Uri.parse("image:"+volume);}
 }}
 public static final class Video {public static final class Media {
  public static Uri getContentUri(String volume){return Uri.parse("video:"+volume);}
 }}
}
JAVA
cat > "$SRC/android/provider/DocumentsContract.java" <<'JAVA'
package android.provider;
import android.net.Uri;
public class DocumentsContract {
 public static String getTreeDocumentId(Uri uri){return "primary:Pictures";}
 public static String getDocumentId(Uri uri){return uri.toString();}
 public static Uri buildDocumentUriUsingTree(Uri tree,String id){return Uri.parse(id);}
 public static Uri buildChildDocumentsUriUsingTree(Uri tree,String id){return Uri.parse("children:"+id);}
 public static final class Document {
  public static final String MIME_TYPE_DIR="vnd.android.document/directory", COLUMN_DISPLAY_NAME="name",COLUMN_MIME_TYPE="mime",COLUMN_DOCUMENT_ID="id",COLUMN_SIZE="size";
 }
}
JAVA
cat > "$SRC/com/cmyk/imgstalker/InventoryStubs.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.content.Context;
import android.net.Uri;
import java.io.File;
final class SavePrefs {
 static File directory(Context ctx){return new File("/storage/emulated/0/Pictures/ImgStalker");}
 static boolean hasTreeAccess(Context ctx){return ctx instanceof InventoryTest.TestContext && ((InventoryTest.TestContext)ctx).tree;}
 static Uri treeUri(Context ctx){return Uri.parse("primary:Pictures");}
 static File fileFromTreeUri(Uri uri){return new File("/storage/emulated/0/Pictures");}
}
final class NormalSiteFolder {
 static String forPage(String s){return s.contains("example.com")?"Normal/example.com":"";}
}
final class AnalysisModeRouter {
 enum Mode{NORMAL,X,INSTAGRAM}
 static Mode fromUrl(String s){return s.contains("instagram.com")?Mode.INSTAGRAM:s.contains("x.com/")?Mode.X:Mode.NORMAL;}
}
final class SnsResumeStore {
 static class Target {
  final String folder;
  Target(String f){folder=f;}
  String relativeFolder(){return folder;}
 }
 static Target targetForUrl(String url){
  if(url.contains("x.com/test"))return new Target("X/test");
  if(url.contains("instagram.com/test"))return new Target("Instagram/test");
  return null;
 }
}
final class DiagnosticLog {
 static void logException(String s,Throwable t){System.err.println("WARN "+s+": "+t);}
 static void log(String s){}
}
JAVA
cat > "$SRC/com/cmyk/imgstalker/InventoryTest.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.content.*;
import android.net.Uri;
import android.database.Cursor;
import java.util.*;
public class InventoryTest {
 static class Rows implements Cursor {
  final String[] cols;
  final List<Object[]> rows;
  int index=-1;
  Rows(String[] cols,List<Object[]> rows){this.cols=cols;this.rows=rows;}
  public boolean moveToNext(){return ++index<rows.size();}
  public int getColumnIndex(String col){for(int i=0;i<cols.length;i++)if(col.equals(cols[i]))return i;return -1;}
  public String getString(int col){return rows.get(index)[col]==null?null:rows.get(index)[col].toString();}
  public long getLong(int col){return ((Number)rows.get(index)[col]).longValue();}
  public boolean isNull(int col){return rows.get(index)[col]==null;}
  public void close(){}
 }
 static class Resolver extends ContentResolver {
  Map<String,List<Object[]>> media=new HashMap<>();
  final Map<String,List<Object[]>> docs=new HashMap<>();
  void media(String type,String path,Object[]...files){media.put(type+":"+path,Arrays.asList(files));}
  void docs(String id,Object[]...files){docs.put("children:"+id,Arrays.asList(files));}
  public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){
   String url=uri.toString();
   if(url.startsWith("image:")||url.startsWith("video:")){
    if(!"relative_path = ? AND is_pending = 0".equals(selection))throw new AssertionError(selection);
    return new Rows(projection,media.getOrDefault(url+":"+args[0],Collections.emptyList()));
   }
   if(url.startsWith("children:")){
    List<Object[]> selected=new ArrayList<>();
    String[] names={"name","mime","id","size"};
    for(Object[] raw:docs.getOrDefault(url,Collections.emptyList())){
      Object[] matched=new Object[projection.length];
      for(int i=0;i<projection.length;i++){
       for(int j=0;j<names.length;j++)if(names[j].equals(projection[i]))matched[i]=raw[j];
      }
      selected.add(matched);
    }
    return new Rows(projection,selected);
   }
   throw new AssertionError(url);
  }
 }
 static class TestContext extends Context {
  final Resolver resolver=new Resolver();
  boolean tree=false;
  public ContentResolver getContentResolver(){return resolver;}
 }
 static void eq(Object a,Object b){if(!Objects.equals(a,b))throw new AssertionError(a+" != "+b);}
 public static void main(String[] args){
  TestContext ctx=new TestContext();
  eq("Normal/example.com",NavigationSavedFileInventory.folderForUrl("https://www.example.com/one"));
  eq("X/test",NavigationSavedFileInventory.folderForUrl("https://x.com/test"));
  eq("Instagram/test",NavigationSavedFileInventory.folderForUrl("https://instagram.com/test/"));
  eq(true,NavigationSavedFileInventory.matchesMedia("foo.gif","image/gif",true));
  eq(false,NavigationSavedFileInventory.matchesMedia("foo.json","application/json",true));
  eq(false,NavigationSavedFileInventory.matchesMedia("photos.png","vnd.android.document/directory",true));
  eq(true,NavigationSavedFileInventory.matchesMedia("foo.webm","application/octet-stream",false));
  eq(false,NavigationSavedFileInventory.matchesMedia("foo.m3u8","application/octet-stream",false));
  String root="Pictures/ImgStalker/Normal/example.com/";
  String oldVideos="Movies/ImgStalker/Normal/example.com/videos/";
  ctx.resolver.media("image:external_primary",root,new Object[]{"a.jpg",200L},new Object[]{"b.png",100L},new Object[]{"zero.jpg",0L});
  ctx.resolver.media("video:external_primary",oldVideos,new Object[]{"one.mp4",100L},new Object[]{"two.mp4",99L});
  NavigationSavedFileInventory.Counts counts=NavigationSavedFileInventory.forUrl(ctx,"https://example.com/post/1");
  eq(2,counts.images);eq(2,counts.videos);
  ctx.tree=true;
  // The same image appears through SAF and MediaStore; it must not double-count.
  ctx.resolver.docs("primary:Pictures",new Object[]{"ImgStalker","vnd.android.document/directory","primary:Pictures/ImgStalker",null});
  ctx.resolver.docs("primary:Pictures/ImgStalker",new Object[]{"Normal","vnd.android.document/directory","primary:Pictures/ImgStalker/Normal",null});
  ctx.resolver.docs("primary:Pictures/ImgStalker/Normal",new Object[]{"example.com","vnd.android.document/directory","primary:Pictures/ImgStalker/Normal/example.com",null});
  ctx.resolver.docs("primary:Pictures/ImgStalker/Normal/example.com",new Object[]{"a.jpg","image/jpeg","file:1",200L},new Object[]{"videos","vnd.android.document/directory","primary:Pictures/ImgStalker/Normal/example.com/videos",null},new Object[]{"data.json","application/json","file:2",200L});
  ctx.resolver.docs("primary:Pictures/ImgStalker/Normal/example.com/videos",new Object[]{"new.mp4","video/mp4","file:3",999L},new Object[]{"empty.mp4","video/mp4","file:4",0L});
  counts=NavigationSavedFileInventory.forUrl(ctx,"https://example.com/post/2");
  eq(2,counts.images);eq(3,counts.videos); // two Movies + one SAF video
  // Re-reading the same URL after a user deletes a file reflects the live count.
  ctx.tree=false;
  ctx.resolver.media("image:external_primary",root,new Object[]{"b.png",100L});
  counts=NavigationSavedFileInventory.forUrl(ctx,"https://example.com/post/1");
  eq(1,counts.images);eq(2,counts.videos);
  System.out.println("PASS: saved folder routing, MediaStore + Movies + SAF, dedup, filtering");
 }
}
JAVA
javac -encoding UTF-8 -d "$TMP/out" $(find "$SRC" -name '*.java') \
 app/src/main/java/com/cmyk/imgstalker/NavigationSavedFileInventory.java
java -cp "$TMP/out" com.cmyk.imgstalker.InventoryTest
