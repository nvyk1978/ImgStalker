#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" app/src/main/java/com/cmyk/imgstalker/NavigationBookmarkOrder.java tests/NavigationBookmarkOrderTest.java
java -cp "$TMP" com.cmyk.imgstalker.NavigationBookmarkOrderTest
