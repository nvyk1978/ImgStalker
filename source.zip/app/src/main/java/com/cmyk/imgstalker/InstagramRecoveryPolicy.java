package com.cmyk.imgstalker;

import java.net.URI;
import java.util.Locale;

/** IG-only failover decisions; no shared NORMAL/X state and no Android dependencies. */
final class InstagramRecoveryPolicy {
    private InstagramRecoveryPolicy() {}

    /** Only IG profile URLs without a session may go straight to WebView.
     * A direct post or unrelated host must never be rerouted to a profile grid. */
    static boolean browserFirstForAnonymousProfile(String rawUrl, boolean sessionAuthenticated) {
        if (sessionAuthenticated || AnalysisModeRouter.fromUrl(rawUrl) != AnalysisModeRouter.Mode.INSTAGRAM) return false;
        if (rawUrl == null) return false;
        try {
            URI uri = new URI(rawUrl.trim());
            String path = uri.getPath();
            if (path == null) return false;
            String[] seg = path.split("/");
            if (seg.length < 2) return false;
            String first = seg[1].toLowerCase(Locale.ROOT);
            if (first.isEmpty() || first.equals("p") || first.equals("reel") || first.equals("tv")
                    || first.equals("stories") || first.equals("accounts") || first.equals("explore")
                    || first.equals("challenge") || first.equals("direct") || first.equals("about")) return false;
            return seg.length == 2 || (seg.length == 3 && seg[2].isEmpty());
        } catch (Exception ignored) {
            return false;
        }
    }

    static boolean sourceNeedsBrowser(int discovered, int resolved, int skipped, int emittedMedia) {
        return discovered <= 0 || resolved <= 0 || skipped > 0 || emittedMedia <= 0;
    }

    static boolean mayReloadGrid(boolean knownPostsBelowTarget, int reloads, int maxReloads) {
        return knownPostsBelowTarget && reloads < maxReloads;
    }

    static String authGateType(String raw) {
        if (raw == null) return "none";
        try {
            URI uri = new URI(raw);
            if (!"https".equalsIgnoreCase(uri.getScheme())
                    && !"http".equalsIgnoreCase(uri.getScheme())) return "none";
            String host = uri.getHost();
            if (host == null) return "none";
            host = host.toLowerCase(Locale.ROOT);
            if (!host.equals("instagram.com") && !host.endsWith(".instagram.com")) return "none";
            String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
            if (path.startsWith("/accounts/login") || path.startsWith("/accounts/onetap")) return "login";
            if (path.startsWith("/challenge")) return "challenge";
            if (path.startsWith("/accounts/suspended")) return "suspended";
        } catch (Exception ignored) {}
        return "none";
    }
}
