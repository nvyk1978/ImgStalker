package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.webkit.CookieManager;
import android.webkit.WebView;

/** Dedicated X backend; all classes referenced here belong to X. */
final class XModeProvider implements ModeProvider {
    @Override public AnalysisModeRouter.Mode mode() { return AnalysisModeRouter.Mode.X; }
    @Override public void useCookies(CookieManager cookies) { SessionCookies.use(cookies); }
    @Override public String cookieFor(String url) { return SessionCookies.getCookie(url); }
    @Override public ModeCrawler crawler(WebView view, CrawlerEngine.Listener listener) {
        return new XCrawlerAdapter(view, listener);
    }
    @Override public ModeThumbnailLoader thumbnails(Context context, Runnable onMetadata) {
        return new XThumbnailAdapter(context, onMetadata);
    }
    @Override public ModeDownloader downloader(Context context, boolean saveXGifAsGif, MediaDownloader.Listener listener) {
        return new XDownloaderAdapter(context, saveXGifAsGif, listener);
    }
    private final ModePreviewPolicy preview = new XPreviewPolicy();
    @Override public ModePreviewPolicy preview() { return preview; }
    @Override public Bitmap original(Context context, MediaItem item) throws Exception {
        return OriginalImageLoader.load(context, item);
    }
}
