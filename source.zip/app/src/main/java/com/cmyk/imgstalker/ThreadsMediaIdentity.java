package com.cmyk.imgstalker;
import java.net.URI;
import java.util.Locale;
/** Stable Threads media identity: CDN signatures, regions, hostnames, and query are not IDs. */
final class ThreadsMediaIdentity {
    private ThreadsMediaIdentity() {}
    static String key(MediaItem.Kind kind,String mediaUrl,String postUrl) {
        String media = filename(mediaUrl);
        String post = postPath(postUrl);
        if (media.isEmpty() || post.isEmpty() || kind == null) return "";
        return "threads|"+kind.name()+"|"+post+"|"+media;
    }
    private static String filename(String mediaUrl) {
        try {
            URI uri = new URI(mediaUrl);
            if (!"https".equalsIgnoreCase(uri.getScheme()) && !"http".equalsIgnoreCase(uri.getScheme())) return "";
            String path = uri.getPath();
            if (path == null) return "";
            int pos = path.lastIndexOf('/');
            String filename = path.substring(pos+1);
            if (filename.isEmpty()) return "";
            // Keep the entire CDN file identity, not the expiring signed URL.
            return filename.toLowerCase(Locale.ROOT);
        } catch (Exception e) { return ""; }
    }
    private static String postPath(String postUrl) {
        try {
            URI uri = new URI(postUrl);
            String host = uri.getHost();
            if (host == null || !(host.equalsIgnoreCase("threads.com") || host.endsWith(".threads.com")
                    || host.equalsIgnoreCase("threads.net") || host.endsWith(".threads.net"))) return "";
            String path = uri.getPath();
            if (path == null || path.isEmpty()) return "";
            return path.toLowerCase(Locale.ROOT);
        } catch (Exception e) { return ""; }
    }
}
