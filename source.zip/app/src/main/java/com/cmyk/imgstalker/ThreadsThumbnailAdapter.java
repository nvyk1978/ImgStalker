package com.cmyk.imgstalker;
import android.content.Context;
import android.widget.ImageView;
/** Threads-only thumbnail cache, independent from the other three modes. */
final class ThreadsThumbnailAdapter implements ModeThumbnailLoader {
    private final ThreadsThumbnailLoader core;
    ThreadsThumbnailAdapter(Context c, Runnable callback) { core = new ThreadsThumbnailLoader(c, callback); }
    @Override public void prefetch(MediaItem item) { core.prefetch(item); }
    @Override public boolean isCachedOrPending(MediaItem item) { return core.isCachedOrPending(item); }
    @Override public int pendingCount() { return core.pendingCount(); }
    @Override public void load(ImageView view, MediaItem item) { core.load(view, item); }
    @Override public void cancelPending() { core.cancelPending(); }
    @Override public void clearCache() { core.clearCache(); }
    @Override public void shutdown() { core.shutdown(); }
}
