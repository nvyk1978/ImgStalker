#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/com/cmyk/imgstalker" "$TMP/src/android/os"
cat > "$TMP/src/android/os/SystemClock.java" <<'JAVA'
package android.os; public final class SystemClock {
 public static long now = 100000L;
 public static long elapsedRealtime() { return now; }
}
JAVA
python3 - "$TMP/src/com/cmyk/imgstalker/QueueSchedulerRunnerTest.java" <<'PY'
from pathlib import Path
import sys
src=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
def method(name):
    needle='    private void '+name+'('
    start=src.index(needle)
    brace=src.index('{',start)
    depth=0
    for i in range(brace,len(src)):
        if src[i]=='{':depth+=1
        if src[i]=='}':
            depth-=1
            if depth==0: return src[start:i+1]
    raise ValueError(name)
methods='\n'.join(method(m) for m in ('offerSnsThumbnailWork','seedSnsThumbnailWorkQueue','reconcileSnsThumbnailInFlight','runSnsThumbnailSweep'))
fixture='''package com.cmyk.imgstalker;
import java.util.*;
class DiagnosticLog { static void log(String s) {} }
class MediaItem {
 enum Kind { IMAGE, VIDEO, STREAM }
 final String url; final Kind kind=Kind.IMAGE;
 MediaItem(int id) {this.url="item:"+id;}
}
class MockLoader {
 final LinkedHashSet<String> pending=new LinkedHashSet<>();
 final HashSet<String> ready=new HashSet<>();
 final ArrayList<String> startOrder=new ArrayList<>();
 boolean isReady(MediaItem item) {return ready.contains(item.url);}
 boolean isCachedOrPending(MediaItem item) {return isReady(item) || pending.contains(item.url);}
 int pendingCount() {return pending.size();}
 void prefetch(MediaItem item) {
  if (!pending.contains(item.url) && !ready.contains(item.url)) {
   pending.add(item.url);startOrder.add(item.url);
  }
 }
 void success(String key) {pending.remove(key);ready.add(key);}
 void fail(String key) {pending.remove(key);}
 void cancelPending(){pending.clear();}
}
public class QueueSchedulerRunnerTest {
 static final int SNS_THUMB_BACKGROUND_BATCH=2;
 static final int SNS_THUMB_BACKGROUND_MAX_PENDING=2;
 static final long SNS_THUMB_BACKGROUND_TICK_MS=400L;
 final SnsThumbnailSweepPolicy snsThumbnailSweepPolicy=new SnsThumbnailSweepPolicy();
 final SnsThumbnailWorkQueue snsThumbnailWorkQueue=new SnsThumbnailWorkQueue();
 final HashMap<String,MediaItem> snsThumbnailKnownItems=new HashMap<>();
 final HashMap<String,MediaItem> snsThumbnailInFlight=new HashMap<>();
 final ArrayList<MediaItem> items=new ArrayList<>();
 MockLoader thumbnailLoader=new MockLoader();
 boolean snsThumbnailQueueSeeded;
 boolean snsThumbnailSweepScheduled;
 boolean isSnsThumbnailLazyMode(){return true;}
 String safeText(String x){return x;}
 void scheduleSnsThumbnailSweep(String reason,long delay){snsThumbnailSweepScheduled=true;}
 __METHODS__
 void insert(int at,int id) {
   MediaItem item=new MediaItem(id);
   items.add(at,item);
   if (!snsThumbnailQueueSeeded) seedSnsThumbnailWorkQueue();
   else offerSnsThumbnailWork(item);
 }
 void addN(int n){for(int i=0;i<n;i++) insert(items.size(),i);}
 void tick(){runSnsThumbnailSweep();android.os.SystemClock.now+=400L;}
 void succeedPending(){for(String key:new ArrayList<>(thumbnailLoader.pending))thumbnailLoader.success(key);}
 static void check(boolean c,String message){if(!c)throw new AssertionError(message);}
 static void sequential500(){
  QueueSchedulerRunnerTest t=new QueueSchedulerRunnerTest();t.addN(500);
  for(int i=0;i<2500 && t.snsThumbnailSweepPolicy.finishedCount()<500;i++){
   t.tick();t.succeedPending();
  }
  check(t.snsThumbnailSweepPolicy.finishedCount()==500,"500 items did not finish");
  check(t.thumbnailLoader.startOrder.size()==500,"duplicate/missing dispatch");
  for(int i=0;i<500;i++) check(t.thumbnailLoader.startOrder.get(i).equals("item:"+i),"out of order at "+i);
  t.tick();check(t.snsThumbnailWorkQueue.isEmpty() && t.snsThumbnailInFlight.isEmpty(),"completed work still pending");
 }
 static void newItemsAtFront(){
  QueueSchedulerRunnerTest t=new QueueSchedulerRunnerTest();t.addN(70);
  t.tick();check(t.thumbnailLoader.startOrder.size()==2,"initial batch");
  t.succeedPending();t.insert(0,99);t.insert(0,100); // Two late insertions before cursor
  for(int tick=0;tick<200 && t.snsThumbnailSweepPolicy.finishedCount()<72;tick++){
   t.tick();t.succeedPending();
  }
  check(t.snsThumbnailSweepPolicy.finishedCount()==72,"dynamic inserts missing");
  for(int i=0;i<70;i++) check(t.thumbnailLoader.startOrder.get(i).equals("item:"+i),"insertion rewound existing work "+i);
  check(t.thumbnailLoader.startOrder.get(70).equals("item:99") && t.thumbnailLoader.startOrder.get(71).equals("item:100"),"late inserts not scheduled");
 }
 static void slowFailureDoesNotBlockFollowers(){
  QueueSchedulerRunnerTest t=new QueueSchedulerRunnerTest();t.addN(40);
  t.tick(); // 0 & 1 in-flight
  t.tick();check(t.thumbnailLoader.startOrder.size()==2,"capacity oversubscribed");
  t.thumbnailLoader.fail("item:0"); t.tick();
  check(t.snsThumbnailSweepPolicy.attempts("IMAGE|item:0")==1,"first failure not recorded");
  check(t.thumbnailLoader.startOrder.get(2).equals("item:2"),"slow item blocks later work");
  // Keep item 1 slow, let every other request finish.
  for(int i=0;i<160;i++){
   for(String k:new ArrayList<>(t.thumbnailLoader.pending))if(!"item:1".equals(k))t.thumbnailLoader.success(k);
   t.tick();
  }
  check(t.thumbnailLoader.startOrder.contains("item:39"),"later requests starved behind slow item");
  check(!t.thumbnailLoader.startOrder.subList(0,3).contains("item:0") || t.thumbnailLoader.startOrder.get(2).equals("item:2"),"retry blocked head");
  t.thumbnailLoader.fail("item:1");
  // Eventually the slow key gets its own delayed retry.
  for(int i=0;i<100;i++){
   t.tick();t.succeedPending();
  }
  check(t.snsThumbnailSweepPolicy.finishedCount()==40,"delayed retries never drained");
 }
 static void viewportRequestJoins(){
  QueueSchedulerRunnerTest t=new QueueSchedulerRunnerTest();t.addN(6);
  t.thumbnailLoader.prefetch(t.items.get(0)); // UI initiated, not background scheduler
  t.tick();check(t.thumbnailLoader.startOrder.size()==2,"should join UI and dispatch 1");
  check(t.snsThumbnailInFlight.containsKey("IMAGE|item:0"),"UI request untracked");
  t.succeedPending();
  for(int i=0;i<30 && t.snsThumbnailSweepPolicy.finishedCount()<6;i++){t.tick();t.succeedPending();}
  check(t.snsThumbnailSweepPolicy.finishedCount()==6,"UI prefetch not reconciled");
  check(t.thumbnailLoader.startOrder.size()==6,"UI item downloaded twice");
 }
 static void capacityThenRecover(){
  QueueSchedulerRunnerTest t=new QueueSchedulerRunnerTest();t.addN(10);
  t.thumbnailLoader.prefetch(new MediaItem(999));t.thumbnailLoader.prefetch(new MediaItem(998));
  t.tick();check(t.thumbnailLoader.startOrder.size()==2,"saturated capacity still queued");
  t.thumbnailLoader.success("item:999");t.thumbnailLoader.success("item:998");
  for(int i=0;i<30 && t.snsThumbnailSweepPolicy.finishedCount()<10;i++){t.tick();t.succeedPending();}
  check(t.snsThumbnailSweepPolicy.finishedCount()==10,"capacity recovery stalls permanently");
 }
 static void uniqueQueue(){
  SnsThumbnailWorkQueue q=new SnsThumbnailWorkQueue();
  q.offer("A");q.offer("A");q.offer("B");
  check(q.size()==2,"duplicate queue entries");
  check(q.poll().equals("A"),"FIFO broken");
  q.offer("A");q.remove("B");
  check(q.poll().equals("A") && q.isEmpty(),"requeue or remove broken");
 }
 public static void main(String[] args){
  uniqueQueue();sequential500();newItemsAtFront();slowFailureDoesNotBlockFollowers();
  viewportRequestJoins();capacityThenRecover();
  System.out.println("PASS: live extracted scheduler: 500 sequential, insertion-before-cursor, slow/failure, viewport, saturation, retry, queue identity");
 }
}
'''
Path(sys.argv[1]).write_text(fixture.replace('__METHODS__',methods))
PY
javac -encoding UTF-8 -d "$TMP/classes" "$TMP/src/android/os/SystemClock.java" \
 app/src/main/java/com/cmyk/imgstalker/SnsThumbnailSweepPolicy.java \
 app/src/main/java/com/cmyk/imgstalker/SnsThumbnailWorkQueue.java \
 "$TMP/src/com/cmyk/imgstalker/QueueSchedulerRunnerTest.java"
java -cp "$TMP/classes" com.cmyk.imgstalker.QueueSchedulerRunnerTest
