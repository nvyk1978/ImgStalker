package com.cmyk.imgstalker;
import android.content.Context;
import java.util.List;
final class InstagramDownloaderAdapter implements ModeDownloader {
    private final InstagramMediaDownloader core;
    InstagramDownloaderAdapter(Context context, boolean xGif, MediaDownloader.Listener listener) {core=new InstagramMediaDownloader(context, xGif, listener);}
    @Override public void download(List<MediaItem> items, String title, String category, String account) {
        core.download(items, title, category, account);
    }
    @Override public void cancel(){core.cancel();}
}
