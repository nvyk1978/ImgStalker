package com.cmyk.imgstalker;

import java.util.LinkedHashMap;

/** Regression: removing a history row must never remove a bookmark or media. */
public final class SiteNavigationHistoryTest {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        String onlyHistory = "https://example.com/board?page=0";
        String bookmarked = "https://instagram.com/jiee_wen";
        String untouched = "https://x.com/example";
        LinkedHashMap<String, SiteVisitStore.Entry> rows = new LinkedHashMap<>();
        rows.put(onlyHistory, new SiteVisitStore.Entry(onlyHistory, "Example", false, 111L, 112L));
        rows.put(bookmarked, new SiteVisitStore.Entry(bookmarked, "Jie Wen", true, 222L, 223L));
        rows.put(untouched, new SiteVisitStore.Entry(untouched, "Example", true, 333L, 334L));

        check(SiteVisitStore.removeHistoryFromEntries(rows, onlyHistory), "unstarred history should be removed");
        check(!rows.containsKey(onlyHistory), "unstarred history must leave the store");
        check(SiteVisitStore.removeHistoryFromEntries(rows, bookmarked), "starred history should be hidden");
        SiteVisitStore.Entry preserved = rows.get(bookmarked);
        check(preserved != null && preserved.favorite && preserved.visitedAt == 0L,
                "starred entry must survive in bookmarks with no visit history");
        check("Jie Wen".equals(preserved.title) && preserved.updatedAt == 223L,
                "bookmark title and sort timestamp must remain unchanged");
        check(rows.get(untouched).visitedAt == 333L, "other history must stay untouched");
        check(!SiteVisitStore.removeHistoryFromEntries(rows, bookmarked),
                "already removed history must not change bookmark");
        check(!SiteVisitStore.removeHistoryFromEntries(rows, "https://missing.example"),
                "missing history must be a no-op");
        System.out.println("PASS: unstarred delete, bookmarked preservation, no-op, other history unchanged");
    }
}
