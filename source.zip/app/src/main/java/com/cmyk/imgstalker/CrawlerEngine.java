package com.cmyk.imgstalker;

import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class CrawlerEngine {
    public interface Listener {
        void onStatus(String text);
        void onItem(MediaItem item);
        void onDone(String title, int visitedPages, int imageCount, int videoCount, int streamCount);
        void onError(String message);
    }

    private static final class Node {
        final String url;
        final int depth;
        final boolean detail;
        Node(String url, int depth, boolean detail) {
            this.url = url;
            this.depth = depth;
            this.detail = detail;
        }
    }

    private final WebView webView;
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Node> queue = new ArrayDeque<>();
    private final Set<String> queuedOrVisited = new HashSet<>();
    private final Set<String> mediaSeen = new HashSet<>();

    private boolean followPagination = true;
    private boolean followDetails = true;
    private boolean wantImages = true;
    private boolean wantVideos = true;
    private boolean cancelled = false;
    private String rootHost = "";
    private String pageTitle = "ImgStalker";
    private int pageCount = 0;
    private int detailCount = 0;
    private int imageCount = 0;
    private int videoCount = 0;
    private int streamCount = 0;
    private int maxPages = 30;
    private int maxDetails = 120;
    private int maxDepth = 2;
    private Node current;

    public CrawlerEngine(WebView webView, Listener listener) {
        this.webView = webView;
        this.listener = listener;
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString() + " ImgStalker/0.1.0");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (cancelled || current == null) return;
                handler.postDelayed(() -> autoScroll(0), 450);
            }

            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                                                  android.webkit.WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    listener.onStatus("読込失敗: " + request.getUrl());
                }
            }
        });
    }

    public void start(String startUrl, boolean followPagination, boolean followDetails,
                      boolean wantImages, boolean wantVideos) {
        cancel();
        cancelled = false;
        queue.clear();
        queuedOrVisited.clear();
        mediaSeen.clear();
        pageCount = detailCount = imageCount = videoCount = streamCount = 0;
        pageTitle = "ImgStalker";
        this.followPagination = followPagination;
        this.followDetails = followDetails;
        this.wantImages = wantImages;
        this.wantVideos = wantVideos;

        String normalized = normalizeInputUrl(startUrl);
        try {
            rootHost = new URI(normalized).getHost();
            if (rootHost == null) rootHost = "";
        } catch (Exception e) {
            listener.onError("URLを確認してください");
            return;
        }
        enqueue(new Node(normalized, 0, false));
        loadNext();
    }

    public void cancel() {
        cancelled = true;
        current = null;
        try { webView.stopLoading(); } catch (Exception ignored) {}
        handler.removeCallbacksAndMessages(null);
    }

    private void autoScroll(int pass) {
        if (cancelled || current == null) return;
        if (pass >= 3) {
            collectDom();
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{window.scrollTo(0,document.body.scrollHeight);return String(document.body.scrollHeight)}catch(e){return '0'}})()",
                value -> handler.postDelayed(() -> autoScroll(pass + 1), 350));
    }

    private void collectDom() {
        if (cancelled || current == null) return;
        listener.onStatus("解析中 " + (pageCount + detailCount + 1) + "ページ目");
        webView.evaluateJavascript(JS_COLLECTOR, raw -> {
            if (cancelled || current == null) return;
            try {
                String jsonText = unquoteJsResult(raw);
                JSONObject obj = new JSONObject(jsonText);
                String title = obj.optString("title", "").trim();
                if (!title.isEmpty() && pageCount == 0 && detailCount == 0) pageTitle = title;
                processMediaArray(obj.optJSONArray("images"), MediaItem.Kind.IMAGE, current.url);
                processMediaArray(obj.optJSONArray("videos"), MediaItem.Kind.VIDEO, current.url);
                processMediaArray(obj.optJSONArray("streams"), MediaItem.Kind.STREAM, current.url);
                processLinks(obj.optJSONArray("links"), current);
            } catch (Exception e) {
                listener.onStatus("ページ解析を一部スキップ: " + e.getClass().getSimpleName());
            }

            if (current.detail) detailCount++; else pageCount++;
            current = null;
            loadNext();
        });
    }

    private void processMediaArray(JSONArray array, MediaItem.Kind kind, String referrer) throws JSONException {
        if (array == null) return;
        if (kind == MediaItem.Kind.IMAGE && !wantImages) return;
        if ((kind == MediaItem.Kind.VIDEO || kind == MediaItem.Kind.STREAM) && !wantVideos) return;
        for (int i = 0; i < array.length(); i++) {
            String u = cleanUrl(array.optString(i, ""));
            if (!isHttp(u)) continue;
            String key = kind.name() + "|" + stripFragment(u);
            if (!mediaSeen.add(key)) continue;
            MediaItem item = new MediaItem(u, referrer, kind, kind != MediaItem.Kind.STREAM);
            if (kind == MediaItem.Kind.IMAGE) imageCount++;
            else if (kind == MediaItem.Kind.VIDEO) videoCount++;
            else streamCount++;
            listener.onItem(item);
        }
    }

    private void processLinks(JSONArray links, Node from) throws JSONException {
        if (links == null) return;
        for (int i = 0; i < links.length(); i++) {
            JSONObject link = links.optJSONObject(i);
            if (link == null) continue;
            String u = cleanUrl(link.optString("url", ""));
            if (!isHttp(u) || !sameHost(u)) continue;
            if (looksDirectMedia(u)) continue;
            boolean pagination = link.optBoolean("pagination", false);
            boolean hasImage = link.optBoolean("hasImage", false);

            if (pagination && followPagination && pageCount + countQueued(false) < maxPages) {
                enqueue(new Node(u, from.depth, false));
            } else if (hasImage && followDetails && from.depth < maxDepth && detailCount + countQueued(true) < maxDetails) {
                enqueue(new Node(u, from.depth + 1, true));
            }
        }
    }

    private int countQueued(boolean detail) {
        int n = 0;
        for (Node q : queue) if (q.detail == detail) n++;
        return n;
    }

    private void enqueue(Node node) {
        String key = stripFragment(node.url);
        if (queuedOrVisited.add(key)) queue.add(node);
    }

    private void loadNext() {
        if (cancelled) return;
        current = queue.poll();
        if (current == null) {
            listener.onDone(pageTitle, pageCount, imageCount, videoCount, streamCount);
            return;
        }
        listener.onStatus((current.detail ? "詳細追跡: " : "ページ追跡: ") + current.url);
        webView.loadUrl(current.url);
    }

    private boolean sameHost(String url) {
        try {
            String h = new URI(url).getHost();
            if (h == null) return false;
            if (h.equalsIgnoreCase(rootHost)) return true;
            return h.toLowerCase(Locale.ROOT).endsWith("." + rootHost.toLowerCase(Locale.ROOT));
        } catch (Exception e) {
            return false;
        }
    }

    private static String normalizeInputUrl(String s) {
        s = s == null ? "" : s.trim();
        if (!s.matches("(?i)^https?://.*")) s = "https://" + s;
        return s;
    }

    private static boolean looksDirectMedia(String u) {
        String x = u.toLowerCase(Locale.ROOT).split("\\?")[0];
        return x.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif|mp4|webm|mov|m4v|3gp|m3u8|mpd)$");
    }

    private static boolean isHttp(String u) {
        return u != null && (u.startsWith("http://") || u.startsWith("https://"));
    }

    private static String cleanUrl(String s) {
        if (s == null) return "";
        return s.trim().replace("&amp;", "&");
    }

    private static String stripFragment(String s) {
        int i = s.indexOf('#');
        return i >= 0 ? s.substring(0, i) : s;
    }

    private static String unquoteJsResult(String raw) throws JSONException {
        if (raw == null || raw.equals("null")) return "{}";
        if (raw.startsWith("\"") && raw.endsWith("\"")) {
            return new JSONArray("[" + raw + "]").getString(0);
        }
        return raw;
    }

    private static final String JS_COLLECTOR =
            "(function(){" +
            "const abs=(u)=>{try{if(!u||/^(data:|blob:|javascript:|#)/i.test(u))return '';return new URL(u,document.baseURI).href}catch(e){return ''}};" +
            "const uniq=(a)=>Array.from(new Set(a.filter(Boolean)));" +
            "let images=[],videos=[],streams=[],links=[];" +
            "document.querySelectorAll('img').forEach(i=>{" +
            " let c=[i.currentSrc,i.src,i.getAttribute('data-src'),i.getAttribute('data-original'),i.getAttribute('data-lazy-src')];" +
            " let ss=i.getAttribute('srcset'); if(ss){ss.split(',').forEach(x=>c.push(x.trim().split(/\\s+/)[0]))}" +
            " c.map(abs).filter(Boolean).forEach(x=>images.push(x));" +
            "});" +
            "document.querySelectorAll('meta[property=\"og:image\"],meta[name=\"twitter:image\"],link[rel=\"image_src\"]').forEach(m=>images.push(abs(m.content||m.href)));" +
            "document.querySelectorAll('video').forEach(v=>{[v.currentSrc,v.src,v.getAttribute('data-src')].map(abs).filter(Boolean).forEach(x=>{if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)})});" +
            "document.querySelectorAll('video source,source[type^=\"video/\"]').forEach(s=>{let x=abs(s.src||s.getAttribute('src'));if(x){if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)}});" +
            "document.querySelectorAll('meta[property=\"og:video\"],meta[property=\"og:video:url\"],meta[property=\"og:video:secure_url\"]').forEach(m=>{let x=abs(m.content);if(x){if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)}});" +
            "document.querySelectorAll('a[href]').forEach(a=>{" +
            " let u=abs(a.href);if(!u)return;" +
            " if(/\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif)(\\?|$)/i.test(u))images.push(u);" +
            " if(/\\.(mp4|webm|mov|m4v|3gp)(\\?|$)/i.test(u))videos.push(u);" +
            " if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);" +
            " let t=(a.textContent||'').trim(); let rel=(a.rel||'').toLowerCase();" +
            " let ctx=((a.className||'')+' '+(a.id||'')+' '+((a.parentElement&&(a.parentElement.className||''))||'')).toLowerCase();" +
            " let numeric=/^\\s*\\d{1,4}\\s*$/.test(t);" +
            " let next=/^(next|next page|次へ|次のページ|›|»|>|→)$/i.test(t);" +
            " let pageClass=/(pagination|pager|paging|page-numbers|pagenavi)/i.test(ctx);" +
            " let pagination=rel.includes('next')||next||(numeric&&pageClass);" +
            " links.push({url:u,hasImage:!!a.querySelector('img'),pagination:pagination});" +
            "});" +
            "document.querySelectorAll('[style]').forEach(e=>{let b=getComputedStyle(e).backgroundImage||'';let m=b.match(/url\\([\"']?([^\"')]+)[\"']?\\)/i);if(m)images.push(abs(m[1]))});" +
            "return JSON.stringify({title:document.title||'',images:uniq(images),videos:uniq(videos),streams:uniq(streams),links:links});" +
            "})()";
}
