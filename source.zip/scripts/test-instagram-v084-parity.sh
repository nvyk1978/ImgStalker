#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
import hashlib,re
root=Path('app/src/main/java/com/cmyk/imgstalker')
expected={
 'InstagramInstagramMediaResolver.java':'5d8894a16035f014cb8faffcaaa625ac7dd2410248ad111983428d7d5b352a06',
}
for name,digest in expected.items():
 f=root/name
 assert hashlib.sha256(f.read_bytes()).hexdigest()==digest, f'Version-0.1.84 media flow modified unexpectedly: {name}'
c=(root/'InstagramCrawlerEngine.java').read_text()
p=(root/'InstagramInstagramSourcePipeline.java').read_text()
r=(root/'InstagramCrawlerAdapter.java').read_text()
assert 'startInstagramBrowserProfile("anonymous_profile_avoid_429")' in c
assert 'IG_BROWSER_REQUIRED:' in c
assert 'InstagramRecoveryPolicy.browserFirstForAnonymousProfile' in c
assert 'startInstagramProfileStream(' in c
assert 'buildInstagramCarouselInspectScript()' in c
assert 'startInstagramInstagramSourcePipeline(normalized)' in c
assert 'InstagramSessionCookies.getCookie(' in c
assert 'core = new InstagramCrawlerEngine(view, listener)' in r
assert 'AnalysisModeRouter.Mode.INSTAGRAM' in r
assert 'SNS_IG_SOURCE_TIMELINE_RESOLVE' in p
assert 'video_versions' in p and 'carousel_media' in p
assert 'con.setInstanceFollowRedirects(true)' in p
assert "versionCode 144" in Path('app/build.gradle').read_text()
assert "versionName '0.1.143'" in Path('app/build.gradle').read_text()
assert 'profileRequestWithBackoff' in p and 'SNS_IG_SOURCE_PROFILE_PRE_DISCOVERY' in p
assert c.index('startInstagramBrowserProfile("anonymous_profile_avoid_429")') < c.index('startInstagramInstagramSourcePipeline(normalized);')
assert p.index('SNS_IG_086_PROFILE_INFO_AVOID') < p.index('String endpoint = "https://www.instagram.com/api/v1/users/web_profile_info/')
assert 'SNS_IG_SOURCE_RATE_LIMIT_RETRY' not in p, '429 must not retry automatically'
assert 'timeline_web_graphql_retry' not in p, '429 must not use immediate timeline retry'
assert 'SNS_IG_086_POST_DEFER' in p and 'SNS_IG_086_TIMELINE_DEFER' in p
print('PASS: Legacy Instagram extraction anchors and resolver preserved; safe browser dispatch; mode isolation preserved')
PY
sha256sum -c mode-locks.sha256
