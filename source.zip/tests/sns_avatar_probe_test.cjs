const fs=require('fs'), vm=require('vm'), assert=require('assert');
const code=fs.readFileSync('app/src/main/assets/sns_profile_avatar.js','utf8');
function run(path, imgs, target='someone') {
 const main={querySelector:()=>({getBoundingClientRect:()=>({top:600})}),querySelectorAll:()=>imgs};
 const sandbox={location:{pathname:path,href:'https://www.instagram.com'+path},document:{querySelector:(s)=>main},
  window:{getComputedStyle:el=>({backgroundImage:'none',borderRadius:el.rad||''})},URL,Image:class {set src(v){}},console};
 return JSON.parse(vm.runInNewContext(code.replace('__ACCOUNT_HANDLE__',JSON.stringify(target)),sandbox));
}
function mock(url, opts={}) {return {tagName:'IMG', currentSrc:url, parentElement:{rad:opts.parentRadius||''}, rad:opts.radius||'',
  closest:s=>s==='header'?!!opts.header:s.includes('article')?!!opts.post:false,
  getAttribute:attr=>attr==='alt'?(opts.alt||''):null,
  getBoundingClientRect:()=>({width:opts.width||90,height:opts.height||90,top:opts.top||120})};}
const avatar='https://scontent.cdninstagram.com/v/t51.2885-19/avatar.jpg?sig=123';
const bad='https://scontent.cdninstagram.com/v/t51.2885-15/feed.jpg?sig=123';
assert.strictEqual(run('/someone',[mock(bad,{post:true,alt:'someone avatar'}),mock(avatar,{header:true,alt:'someone profile picture'})]).url,avatar);
assert.strictEqual(run('/@someone',[mock(avatar,{radius:'50%',top:40})]).url,avatar);
assert.strictEqual(run('/other',[mock(avatar,{header:true,alt:'someone profile picture'})]).reason,'not_target_profile');
assert.strictEqual(run('/someone',[mock(bad,{top:240,width:100,height:100})]).reason,'no_verified_header_avatar');
console.log('PASS: profile owner images chosen over posts, Threads handle, URL isolation, no thumbnail fallback');
