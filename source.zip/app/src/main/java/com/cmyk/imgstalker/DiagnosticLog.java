package com.cmyk.imgstalker;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;
import android.os.PowerManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class DiagnosticLog {
    private static final Object LOCK = new Object();
    private static final long MAX_FILE = 768L * 1024L;
    private static Context appContext;
    private static File logFile;
    private static boolean installed;
    private static boolean startupDiagnosticsLogged;

    private DiagnosticLog() {}

    public static void install(Context context) {
        boolean runStartupDiagnostics = false;
        synchronized (LOCK) {
            if (appContext == null) {
                appContext = context.getApplicationContext();
                logFile = new File(appContext.getFilesDir(), "imgstalker_diagnostic.log");
            }
            if (!installed) {
                installed = true;
                Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
                Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
                    logException("UNCAUGHT thread=" + thread.getName(), error);
                    if (previous != null) previous.uncaughtException(thread, error);
                });
                log("APP_PROCESS_START");
            }
            if (!startupDiagnosticsLogged) {
                startupDiagnosticsLogged = true;
                runStartupDiagnostics = true;
            }
        }
        if (runStartupDiagnostics) {
            log("APP_RUNTIME_STATE " + runtimeState(context));
            logHistoricalExitReasons(context);
        }
    }


    public static String runtimeState(Context context) {
        if (context == null) return "unavailable";
        try {
            Context app = context.getApplicationContext();
            ActivityManager am = (ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            UsageStatsManager usage = (UsageStatsManager) app.getSystemService(Context.USAGE_STATS_SERVICE);
            boolean backgroundRestricted = am != null && am.isBackgroundRestricted();
            boolean batteryOptimizationIgnored = pm != null
                    && pm.isIgnoringBatteryOptimizations(app.getPackageName());
            int standbyBucket = usage == null ? -1 : usage.getAppStandbyBucket();
            return "backgroundRestricted=" + backgroundRestricted
                    + " batteryOptimizationIgnored=" + batteryOptimizationIgnored
                    + " standbyBucket=" + standbyBucketName(standbyBucket)
                    + "(" + standbyBucket + ")";
        } catch (Throwable t) {
            return "unavailable:" + t.getClass().getSimpleName();
        }
    }

    private static String standbyBucketName(int bucket) {
        switch (bucket) {
            case 10: return "ACTIVE";
            case 20: return "WORKING_SET";
            case 30: return "FREQUENT";
            case 40: return "RARE";
            case 45: return "RESTRICTED";
            case 50: return "NEVER";
            default: return "UNKNOWN";
        }
    }

    private static void logHistoricalExitReasons(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || context == null) {
            log("PREVIOUS_EXIT unavailable sdk=" + Build.VERSION.SDK_INT);
            return;
        }
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) {
                log("PREVIOUS_EXIT unavailable reason=no_activity_manager");
                return;
            }
            List<ApplicationExitInfo> exits = am.getHistoricalProcessExitReasons(
                    context.getPackageName(), 0, 5);
            if (exits == null || exits.isEmpty()) {
                log("PREVIOUS_EXIT none");
                return;
            }
            int index = 0;
            for (ApplicationExitInfo info : exits) {
                if (info == null) continue;
                log("PREVIOUS_EXIT index=" + index + " " + formatExitInfo(info));
                index++;
            }
        } catch (Throwable t) {
            logException("PREVIOUS_EXIT query_fail", t);
        }
    }

    private static String historicalExitReport(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || context == null) {
            return "unavailable (requires Android 11 / API 30+)\n";
        }
        try {
            ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return "unavailable (ActivityManager)\n";
            List<ApplicationExitInfo> exits = am.getHistoricalProcessExitReasons(
                    context.getPackageName(), 0, 5);
            if (exits == null || exits.isEmpty()) return "(none)\n";
            StringBuilder out = new StringBuilder();
            int index = 0;
            for (ApplicationExitInfo info : exits) {
                if (info == null) continue;
                out.append(index++).append(": ").append(formatExitInfo(info)).append('\n');
            }
            return out.length() == 0 ? "(none)\n" : out.toString();
        } catch (Throwable t) {
            return "query failed: " + t.getClass().getSimpleName() + "\n";
        }
    }

    private static String formatExitInfo(ApplicationExitInfo info) {
        String description = info.getDescription();
        if (description == null || description.trim().isEmpty()) description = "-";
        description = description.replace('\n', ' ').replace('\r', ' ');
        return "reason=" + exitReasonName(info.getReason())
                + "(" + info.getReason() + ")"
                + " status=" + info.getStatus()
                + " timestamp=" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
                        .format(new Date(info.getTimestamp()))
                + " importance=" + info.getImportance()
                + " pssKb=" + info.getPss()
                + " rssKb=" + info.getRss()
                + " description=" + description;
    }

    private static String exitReasonName(int reason) {
        switch (reason) {
            case 0: return "UNKNOWN";
            case 1: return "EXIT_SELF";
            case 2: return "SIGNALED";
            case 3: return "LOW_MEMORY";
            case 4: return "CRASH";
            case 5: return "CRASH_NATIVE";
            case 6: return "ANR";
            case 7: return "INITIALIZATION_FAILURE";
            case 8: return "PERMISSION_CHANGE";
            case 9: return "EXCESSIVE_RESOURCE_USAGE";
            case 10: return "USER_REQUESTED";
            case 11: return "USER_STOPPED";
            case 12: return "DEPENDENCY_DIED";
            case 13: return "OTHER";
            case 14: return "FREEZER";
            case 15: return "PACKAGE_STATE_CHANGE";
            case 16: return "PACKAGE_UPDATED";
            case 17: return "MEMORY_LIMITER";
            case 18: return "ANOMALY";
            default: return "CODE_" + reason;
        }
    }

    public static void log(String message) {
        if (message == null) message = "null";
        synchronized (LOCK) {
            if (logFile == null) return;
            try {
                if (logFile.exists() && logFile.length() > MAX_FILE) {
                    clearLocked();
                }
                String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
                String line = time + " " + message + "\n";
                try (FileOutputStream out = new FileOutputStream(logFile, true)) {
                    out.write(line.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) {}
        }
    }

    public static void logException(String prefix, Throwable error) {
        StringBuilder b = new StringBuilder(prefix == null ? "ERROR" : prefix);
        if (error != null) {
            b.append(" | ").append(error.getClass().getSimpleName());
            if (error.getMessage() != null) b.append(": ").append(error.getMessage());
            StackTraceElement[] stack = error.getStackTrace();
            int n = Math.min(stack == null ? 0 : stack.length, 8);
            for (int i = 0; i < n; i++) b.append("\n    at ").append(stack[i]);
        }
        log(b.toString());
    }

    public static void clear() {
        synchronized (LOCK) {
            clearLocked();
        }
    }

    private static void clearLocked() {
        if (logFile == null) return;
        try (FileOutputStream out = new FileOutputStream(logFile, false)) {
            out.write(new byte[0]);
        } catch (Exception ignored) {}
    }

    public static File exportReportFile(Context context) throws Exception {
        install(context);
        File dir = new File(context.getCacheDir(), "diagnostic_share");
        if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("cannot create diagnostic_share");
        File[] old = dir.listFiles();
        if (old != null) {
            long cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L;
            for (File f : old) {
                if (f != null && f.isFile() && f.lastModified() < cutoff) {
                    try { f.delete(); } catch (Exception ignored) {}
                }
            }
        }
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File out = new File(dir, "ImgStalker_diagnostic_" + stamp + ".txt");
        try (FileOutputStream stream = new FileOutputStream(out, false)) {
            stream.write(report(context).getBytes(StandardCharsets.UTF_8));
        }
        return out;
    }

    public static String report(Context context) {
        install(context);
        String versionName = "?";
        long versionCode = -1;
        try {
            PackageInfo p = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            versionName = p.versionName == null ? "?" : p.versionName;
            versionCode = p.getLongVersionCode();
        } catch (Exception e) {
            logException("PACKAGE_INFO_FAIL", e);
        }

        StringBuilder out = new StringBuilder();
        out.append("ImgStalker diagnostic report\n");
        out.append("Generated: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date())).append('\n');
        out.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("App: ").append(versionName).append(" (").append(versionCode).append(")\n");
        out.append("Runtime: ").append(runtimeState(context)).append("\n\n");
        out.append("--- PREVIOUS PROCESS EXITS ---\n");
        out.append(historicalExitReport(context)).append('\n');
        out.append("--- LOG ---\n");
        out.append(readLog());
        return out.toString();
    }

    private static String readLog() {
        synchronized (LOCK) {
            if (logFile == null || !logFile.exists()) return "(empty)\n";
            try (FileInputStream in = new FileInputStream(logFile)) {
                long length = logFile.length();
                int wanted = (int) Math.min(length, MAX_FILE);
                byte[] bytes = new byte[wanted];
                if (length > wanted) {
                    long skip = length - wanted;
                    while (skip > 0) {
                        long s = in.skip(skip);
                        if (s <= 0) break;
                        skip -= s;
                    }
                }
                int off = 0;
                while (off < bytes.length) {
                    int n = in.read(bytes, off, bytes.length - off);
                    if (n < 0) break;
                    off += n;
                }
                return new String(bytes, 0, off, StandardCharsets.UTF_8);
            } catch (Exception e) {
                return "(log read failed: " + e.getClass().getSimpleName() + ")\n";
            }
        }
    }
}
