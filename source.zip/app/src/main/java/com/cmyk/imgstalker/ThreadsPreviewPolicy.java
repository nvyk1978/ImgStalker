package com.cmyk.imgstalker;
/** Independent Threads preview policy. No X/Instagram URL rewriting. */
final class ThreadsPreviewPolicy implements ModePreviewPolicy {
    @Override public boolean isSpecialVideo(String u) { return false; }
    @Override public boolean isKnownFailed(String u) { return false; }
    @Override public String resolvedUrl(String u) { return u; }
    @Override public String resolveFresh(String u, String r, String agent) { return null; }
    @Override public void markRecovered(String u, String v) { }
    @Override public void markFailed(String u) { }
    @Override public void reset() { }
}
