package com.cmyk.imgstalker;

import java.util.Collection;
import java.util.List;

/** Instagram-only continuation API. X and NORMAL adapters cannot implement this by accident. */
interface InstagramCrawlerSession {
    void seedInstagramContinuationState(Collection<String> done, Collection<String> discovered);
    List<String> getCompletedInstagramPostUrls();
    List<String> getDiscoveredInstagramPostUrls();
    int getInstagramFailedPostCount();
}
