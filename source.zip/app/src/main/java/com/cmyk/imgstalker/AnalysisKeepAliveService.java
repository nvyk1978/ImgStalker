package com.cmyk.imgstalker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/**
 * Foreground keep-alive for active ImgStalker work.
 *
 * v0.1.79 intentionally survives removal of the app task.  The service keeps a strong
 * reference to the currently active work owner so the WebView/crawler/download pipeline is
 * not garbage-collected when Android destroys the visible Activity after a Recents swipe.
 * The owner releases itself only when the active work reaches a safe terminal state.
 */
public class AnalysisKeepAliveService extends Service {
    public interface RetainedWorkOwner {
        void onKeepAliveTaskRemoved();
        void onKeepAliveTimeout();
        boolean hasActiveKeepAliveWork();
    }

    private static final String CHANNEL_ID = "imgstalker_analysis";
    private static final int NOTIFICATION_ID = 1052;
    private static final long WAKE_LOCK_TIMEOUT_MS = 6L * 60L * 60L * 1000L;

    private static volatile RetainedWorkOwner retainedOwner;

    public static void retainOwner(RetainedWorkOwner owner) {
        if (owner == null) return;
        retainedOwner = owner;
        DiagnosticLog.log("BACKGROUND_ANALYSIS_OWNER retain active=" + owner.hasActiveKeepAliveWork());
    }

    public static void releaseOwner(RetainedWorkOwner owner) {
        if (owner != null && retainedOwner == owner) {
            retainedOwner = null;
            DiagnosticLog.log("BACKGROUND_ANALYSIS_OWNER release");
        }
    }

    public static boolean isRetaining(RetainedWorkOwner owner) {
        return owner != null && retainedOwner == owner;
    }

    public static boolean hasOtherRetainedOwner(RetainedWorkOwner candidate) {
        RetainedWorkOwner owner = retainedOwner;
        return owner != null && owner != candidate && owner.hasActiveKeepAliveWork();
    }

    private PowerManager.WakeLock wakeLock;
    private final Handler heartbeatHandler = new Handler(Looper.getMainLooper());
    private final Runnable heartbeat = new Runnable() {
        @Override public void run() {
            RetainedWorkOwner owner = retainedOwner;
            DiagnosticLog.log("BACKGROUND_ANALYSIS_HEARTBEAT service_alive=true wakeLock="
                    + (wakeLock != null && wakeLock.isHeld())
                    + " owner=" + (owner != null)
                    + " active=" + (owner != null && owner.hasActiveKeepAliveWork()));
            heartbeatHandler.postDelayed(this, 15000L);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        DiagnosticLog.install(this);
        createNotificationChannel();
        acquireWakeLock();
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE onCreate");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        RetainedWorkOwner owner = retainedOwner;
        if (owner == null || !owner.hasActiveKeepAliveWork()) {
            DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE restart_without_owner startId=" + startId
                    + " flags=" + flags + " -> stop");
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        Notification notification = buildNotification();
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE foreground startId=" + startId
                + " flags=" + flags + " sticky=true");
        heartbeatHandler.removeCallbacks(heartbeat);
        heartbeatHandler.post(heartbeat);
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        RetainedWorkOwner owner = retainedOwner;
        DiagnosticLog.log("BACKGROUND_ANALYSIS_TASK_REMOVED owner=" + (owner != null)
                + " active=" + (owner != null && owner.hasActiveKeepAliveWork()));
        if (owner != null && owner.hasActiveKeepAliveWork()) {
            try { owner.onKeepAliveTaskRemoved(); }
            catch (Throwable t) { DiagnosticLog.logException("BACKGROUND_ANALYSIS_TASK_REMOVED_CALLBACK_FAIL", t); }
        }
        // Deliberately do not stopSelf(). The foreground service remains the lifetime anchor.
        super.onTaskRemoved(rootIntent);
    }

    private void createNotificationChannel() {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "バックグラウンド解析",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("ImgStalkerの解析・保存をバックグラウンドで継続します");
        channel.setSound(null, null);
        channel.enableVibration(false);
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Intent launchIntent = new Intent(this, MainActivity.class);
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("ImgStalker")
                .setContentText("解析・保存処理を継続中")
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ImgStalker:BackgroundAnalysis");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(WAKE_LOCK_TIMEOUT_MS);
            DiagnosticLog.log("BACKGROUND_ANALYSIS_WAKELOCK acquire");
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_ANALYSIS_WAKELOCK acquire_fail", t);
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            DiagnosticLog.log("BACKGROUND_ANALYSIS_WAKELOCK release");
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_ANALYSIS_WAKELOCK release_fail", t);
        }
        wakeLock = null;
    }

    @Override public void onTimeout(int startId, int fgsType) {
        RetainedWorkOwner owner = retainedOwner;
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE timeout startId=" + startId + " type=" + fgsType
                + " owner=" + (owner != null));
        if (owner != null && owner.hasActiveKeepAliveWork()) {
            try { owner.onKeepAliveTimeout(); }
            catch (Throwable t) { DiagnosticLog.logException("BACKGROUND_ANALYSIS_TIMEOUT_CALLBACK_FAIL", t); }
        }
        stopSelf(startId);
    }

    @Override public void onDestroy() {
        heartbeatHandler.removeCallbacks(heartbeat);
        releaseWakeLock();
        stopForeground(STOP_FOREGROUND_REMOVE);
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE onDestroy owner=" + (retainedOwner != null));
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }
}
