# ImgStalker v0.1.68 (69)

## Base
- Functional base: v0.1.67 (68).
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.

## Instagram discover-then-acquire traversal
- Before opening any post, the crawler reads the profile post count and uses it as the discovery target (up to the existing 300-post safety limit).
- The profile grid is scrolled from the top toward the bottom while canonical `/p/`, `/reel/`, and `/tv/` post URLs are collected and deduplicated.
- The visible analysis status reports discovery progress as `投稿をスクロール中（12/94）`.
- Reaching a transient bottom state no longer ends acquisition. If the known URL count is still below the profile post count, the crawler performs verification sweeps from the top before declaring the discovery phase incomplete.
- Once the expected post IDs have been collected, the profile is returned to the top and post acquisition starts from the stored ordered URL queue.
- Acquisition progress is shown as `投稿を取得中（1/94）`.

## Recovery and continuation
- Because the post URL queue is fixed before detail traversal, a temporary profile-return/virtualization gap cannot silently turn into a normal bottom-of-profile completion.
- Failed posts still use the deferred retry queue.
- If final failed posts remain, the media grid keeps the reload/continuation cell visible so those posts can be retried.
- If discovery itself ends short of the profile post count after verification sweeps, completion is marked incomplete and the continuation cell remains available.

## Stable result order
- Each Instagram post receives a stable profile-order index when first discovered.
- Emitted media carry a display-order value derived from post order plus per-post media order.
- Result cells are inserted by that display order, so delayed/retried media return to their profile position rather than simply appending.

## Retained behavior
- Existing carousel traversal, image URL normalization, duplicate suppression, target-size filtering, Reel/network video capture, cover-frame exclusion, background foreground-service/WakeLock support, diagnostics and signing remain in place. The floating browser is retained only for the dormant manual diagnostic path, not normal analysis.

## Package
- versionCode: 69
- versionName: 0.1.68
## Instagram lightweight WebView (v0.1.68)
- Normal Instagram analysis keeps the crawler WebView hidden; the floating debug browser is no longer shown during automatic discovery/acquisition.
- Offscreen pre-rasterization is disabled.
- Instagram network images are blocked and automatic image loading is disabled during profile discovery and normal detail inspection.
- If a detail DOM exposes no usable media after a short bounded wait, image loading is temporarily enabled for that post only, then blocked again as soon as the crawler returns to the profile.
- JavaScript/DOM and video request observation stay enabled so shortcode discovery, carousel controls and video URL capture continue to work.

