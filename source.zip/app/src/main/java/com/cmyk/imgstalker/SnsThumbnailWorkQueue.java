package com.cmyk.imgstalker;

import java.util.ArrayDeque;
import java.util.HashSet;

/** UI-thread-owned stable-key thumbnail work queue.
 *
 * Crawl additions append without rewinding existing work. A dispatched key
 * leaves the queue until its transport finishes. Failed jobs rejoin at the tail
 * after the retry policy records a confirmed failure; deferred jobs do not
 * monopolize the queue head. No network calls or media downloads live here.
 */
final class SnsThumbnailWorkQueue {
    private final ArrayDeque<String> keys = new ArrayDeque<>();
    private final HashSet<String> present = new HashSet<>();

    void offer(String key) {
        if (key != null && !key.isEmpty() && present.add(key)) keys.addLast(key);
    }

    String poll() {
        String key = keys.pollFirst();
        if (key != null) present.remove(key);
        return key;
    }

    void remove(String key) {
        if (key != null && present.remove(key)) keys.remove(key);
    }

    boolean isEmpty() { return keys.isEmpty(); }
    int size() { return keys.size(); }
    void clear() { keys.clear(); present.clear(); }
}
