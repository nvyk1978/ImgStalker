# ImgStalker 0.1.137 independent mode wiring

## Sources
- NORMAL crawler/media HTTP/thumbnail/original implementation: exact v0.1.92 `(93)` source (`source(20260930-001448).zip`, SHA-256 `2cc71115d35215d672b958d97d0db734a1271a90fb28fb57520a45e246f3b11d`). Legacy files are duplicated by provider, with only class/listener/cookie-scope adaptations.
- INSTAGRAM crawler/media HTTP/thumbnail/original implementation: separate duplicate of the same v0.1.92 revision. `InstagramSourcePipeline` itself has identical bytes in v0.1.92 and v0.1.135.
- X crawler, downloader, thumbnail, original image loader and support code: **unchanged** v0.1.135 `(136)` source (`ImgStalker_0.1.135_source.zip`).

## Host authority
`AnalysisModeRouter` checks the URL's parsed host only: x.com / twitter.com => X; instagram.com => Instagram; anything else => normal. Full subdomains accepted; lookalike domains and mentions in query strings do not switch.

## Isolation mechanisms
- One `ModeCrawler` contract, implemented by three adapters. An adapter refuses to begin crawling an alien domain.
- Separate concrete CrawlerEngine source files for NORMAL / INSTAGRAM (0.1.92) / X (0.1.135 original), with separately cloned legacy Instagram source and browser resolvers. Per-crawler traversal state is independent; UI, diagnostics and some process services are shared.
- Provider switching cancels the previous crawler, destroys its WebView, creates a new WebView and new mode-specific crawler, switches the cookie holder, and increments a callback epoch. Old callbacks cannot modify the new run.
- Separate thumbnail and downloader implementations per mode. `X` delegates to the byte-identical current transports; legacy modes delegate to byte-identical original logic with independent cookie holders.
- Separate original-image transport class per mode.
- Separate normal/Instagram cookie scopes; X's original `SessionCookies` remains unchanged.
- Separate internal queue checkpoint files: original X filename preserved; normal/Instagram new filenames. SNS sidecar/ledger remains separated by original SNS per-account target names.
- `mode-locks.sha256` seals the v0.1.135 X source and stable keystore; Gradle preBuild rejects accidental changes.

## Scope limitations to validate
- The UI Activity, `MediaItem` model, account-list UI, and Android app process remain shared; this is **processing isolation**, not three independent application processes.
- The legacy NORMAL and INSTAGRAM engines predate the v0.1.135 generic queue cursor; the legacy SNS session-resume model is retained, but generic JSON queue restoration remains X-only.
- No claim of actual Instagram HTTP access or Android device behavior: the legacy Instagram source HTTP crawler is the same byte-for-byte as the current version and may still encounter Instagram server redirects, authentication changes, or network blocks.
- Full Android/Gradle compile and real-world device/network tests must be run in GitBuild/Actions.

## Instagram v0.1.138 recovery
HTTP profile-discovery fatal, zero-media completion or skipped posts now switches **only Instagram** to the dedicated WebView browser recovery. NORMAL/X are unchanged. The recovered WebView must have active Instagram login and accessible profile; this cannot be verified without device/network tests.
