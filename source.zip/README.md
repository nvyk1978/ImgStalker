# ImgStalker v0.1.88 (89)

Android 16 / SDK 36 source package for ImgStalker.

## v0.1.88 — X late GIF/video materialization wait

Based on v0.1.87 (88).

### X / Twitter animated GIF follow-up
- X status-detail pages no longer leave immediately when the first DOM collection returns no media.
- X detail pages skip the old whole-page bottom-scroll sequence so the primary tweet stays near the viewport and its video player can materialize.
- When an X detail exposes no media, ImgStalker keeps that status active for up to five collection passes, 600 ms apart.
- During the wait the primary tweet article is scrolled into view and existing video elements are nudged with muted / playsinline / preload=auto / load() / play().
- While the status remains active, existing video.twimg.com request capture stays attached to the correct post, including /tweet_video/*.mp4 animated-GIF delivery.
- If an animated-GIF hint appears before an actual video URL, polling continues until a video/performance/network candidate appears or the bounded wait expires.
- Ordinary image posts finish on the first successful media pass and do not pay the GIF wait delay.
- Added diagnostics: SNS_X_DETAIL_MEDIA_WAIT, SNS_X_DETAIL_MEDIA_WARMUP, SNS_X_DETAIL_MEDIA_DONE, SNS_X_DETAIL_PARSE_FAIL.

### Retained from v0.1.87
- X animated_gif / video_info.variants parsing and video.twimg.com Performance/Network capture.
- Automatic gradual SNS thumbnail sweep with visible-cell priority.
- Instagram timeline-direct media path and existing rate-limit/resume behavior.
- Saved media circular green check / selection blocked; failed media circular dark-red check / retry selectable.
- N White #A9A999 title.
- SAF-first video saving with MediaStore Movies fallback.
- Fixed applicationId and stable signing keystore for overwrite install.

Package: versionName 0.1.88 / versionCode 89.
