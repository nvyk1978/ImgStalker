package com.cmyk.imgstalker;

import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Legacy HTTP 403 fallback state for Normal mode only.
 * Never accesses the X-specific TwitterVideoUrl caches/retry pipeline.
 * Strip only the legacy tag argument on a Twitter video CDN URL; do not
 * remove tags from unrelated media providers (including Instagram URLs).
 */
final class NormalVideoUrl {
    private static final ConcurrentHashMap<String, String> RECOVERED = new ConcurrentHashMap<>();

    private NormalVideoUrl() {}

    static void resetSession() {
        RECOVERED.clear();
    }

    static String resolvedOrOriginal(String raw) {
        if (raw == null) return null;
        String result = RECOVERED.get(raw);
        return result == null || result.isEmpty() ? raw : result;
    }

    static void markRecovered(String original, String recovered) {
        if (original == null || recovered == null || recovered.isEmpty()) return;
        RECOVERED.put(original, recovered);
    }

    static String stripTag(String raw) {
        if (raw == null || raw.isEmpty()) return raw;
        try {
            URL url = new URL(raw);
            String host = url.getHost() == null ? "" : url.getHost().toLowerCase(Locale.ROOT);
            if (!(host.equals("video.twimg.com") || host.endsWith(".video.twimg.com"))) return raw;
            String path = url.getPath() == null ? "" : url.getPath().toLowerCase(Locale.ROOT);
            if (!path.endsWith(".mp4")) return raw;
        } catch (Exception ignored) {
            return raw;
        }
        int question = raw.indexOf('?');
        if (question < 0) return raw;
        int fragment = raw.indexOf('#', question + 1);
        int end = fragment >= 0 ? fragment : raw.length();
        String query = raw.substring(question + 1, end);
        StringBuilder remaining = new StringBuilder();
        boolean found = false;
        for (String item : query.split("&", -1)) {
            String key = item.split("=", 2)[0];
            if (key.equalsIgnoreCase("tag")) { found = true; continue; }
            if (remaining.length() > 0) remaining.append('&');
            remaining.append(item);
        }
        if (!found) return raw;
        return raw.substring(0, question) + (remaining.length() > 0 ? "?" + remaining : "")
                + (fragment >= 0 ? raw.substring(fragment) : "");
    }
}
