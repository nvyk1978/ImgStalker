package com.cmyk.imgstalker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

final class SnsUiController {
    private static final int BG = 0xFF303030;
    private static final int DARK_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int BLUE = 0xFF223355;
    private static final int LIGHT_BLUE = 0xFF445577;
    private static final int ORANGE = 0xFF775500;
    private static final int DARK_RED = 0xFF441100;
    private static final int N_WHITE = 0xFFA9A999;
    private static final int TEXT_WHITE = 0xFFFFFFFF;
    private static final int GREEN = 0xFF227733;

    private final Activity activity;
    private final SnsAccountManager accounts;
    private final Handler handler = new Handler(Looper.getMainLooper());

    SnsUiController(Activity activity, SnsAccountManager accounts) {
        this.activity = activity;
        this.accounts = accounts;
    }

    void showAccountDialog(SnsAccountManager.Service service) {
        DiagnosticLog.log("SNS_DIALOG_OPEN service=" + service.label);
        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(14), dp(16), dp(14));
        panel.setBackgroundColor(BG);

        TextView title = text(service.label + " アカウント", 21, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        panel.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

        TextView hint = text(accounts.supportsMultiProfile()
                ? "登録順に自動試行。閲覧できない場合は次のアカウントへ切り替えます。"
                : "このWebViewは複数プロファイル非対応のため、このSNSは1アカウント運用です。",
                12, N_WHITE);
        hint.setPadding(0, 0, 0, dp(8));
        panel.addView(hint);

        ScrollView scroll = new ScrollView(activity);
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        List<SnsAccountManager.Account> current = accounts.getAccounts(service);
        if (current.isEmpty()) {
            TextView empty = text("未登録", 14, N_WHITE);
            empty.setGravity(Gravity.CENTER);
            list.addView(empty, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        } else {
            for (SnsAccountManager.Account account : current) addAccountRow(list, account, service);
        }

        LinearLayout actions = new LinearLayout(activity);
        actions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.setPadding(0, dp(10), 0, 0);
        Button add = button("＋ ログイン追加", BLUE);
        actions.addView(add, new LinearLayout.LayoutParams(0, dp(42), 1f));
        if (service == SnsAccountManager.Service.X) {
            Button sensitive = button("センシティブ表示 一括ON", ORANGE);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(178), dp(42));
            slp.leftMargin = dp(8);
            actions.addView(sensitive, slp);
            sensitive.setOnClickListener(v -> applySensitiveForAllX());
        }
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(activity).setView(panel).create();
        add.setOnClickListener(v -> {
            List<SnsAccountManager.Account> existing = accounts.getAccounts(service);
            if (!accounts.supportsMultiProfile() && !existing.isEmpty()) {
                Toast.makeText(activity, "この端末では複数アカウントを分離できません", Toast.LENGTH_SHORT).show();
                return;
            }
            SnsAccountManager.Account account = accounts.allocateAccount(service);
            dialog.dismiss();
            openLogin(account);
        });
        dialog.setOnShowListener(x -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, dp(520));
            }
        });
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, dp(520));
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
    }

    private void addAccountRow(LinearLayout list, SnsAccountManager.Account account, SnsAccountManager.Service service) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(6), dp(8), dp(6));
        row.setBackground(rounded(DARK_GRAY, 10));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        rlp.bottomMargin = dp(6);
        list.addView(row, rlp);

        boolean loggedIn = accounts.isLoggedIn(account);
        TextView label = text(account.displayName() + (loggedIn ? "   ●ログイン済み" : "   未ログイン"), 13,
                loggedIn ? TEXT_WHITE : N_WHITE);
        row.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        Button login = button(loggedIn ? "開く" : "ログイン", BLUE);
        row.addView(login, new LinearLayout.LayoutParams(dp(76), dp(38)));
        Button remove = button("削除", DARK_RED);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(62), dp(38));
        dlp.leftMargin = dp(6);
        row.addView(remove, dlp);

        login.setOnClickListener(v -> openLogin(account));
        remove.setOnClickListener(v -> new AlertDialog.Builder(activity)
                .setMessage(account.displayName() + " を削除しますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    accounts.removeAccount(account);
                    DiagnosticLog.log("SNS_ACCOUNT_REMOVE service=" + service.label + " profile=" + account.profileName);
                    row.setVisibility(View.GONE);
                    Toast.makeText(activity, account.displayName() + " を削除しました", Toast.LENGTH_SHORT).show();
                }).show());
    }

    private void openLogin(SnsAccountManager.Account account) {
        DiagnosticLog.log("SNS_LOGIN_OPEN service=" + account.service.label + " profile=" + account.profileName);
        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(BG);

        TextView header = text(account.service.label + " ログイン", 18, TEXT_WHITE);
        header.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), 0, dp(14), 0);
        panel.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        WebView loginWebView = new WebView(activity);
        accounts.applyProfile(loginWebView, account.profileName);
        WebSettings settings = loginWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUserAgentString(settings.getUserAgentString() + " ImgStalkerSNS/0.1.28");
        panel.addView(loginWebView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout actions = new LinearLayout(activity);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.setPadding(dp(10), dp(6), dp(10), dp(8));
        Button done = button("完了", BLUE);
        Button cancel = button("閉じる", GRAY);
        actions.addView(done, new LinearLayout.LayoutParams(dp(92), dp(42)));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(92), dp(42));
        clp.leftMargin = dp(8);
        actions.addView(cancel, clp);
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(activity).setView(panel).create();
        loginWebView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                DiagnosticLog.log("SNS_LOGIN_PAGE service=" + account.service.label + " profile=" + account.profileName + " url=" + url);
                if (accounts.isLoggedIn(account)) header.setText(account.service.label + " ログイン済み");
            }
        });
        loginWebView.loadUrl(account.service.loginUrl);

        View.OnClickListener finish = v -> {
            boolean loggedIn = accounts.isLoggedIn(account);
            if (loggedIn) {
                accounts.commitAccount(account);
                DiagnosticLog.log("SNS_LOGIN_OK service=" + account.service.label + " profile=" + account.profileName);
            } else {
                DiagnosticLog.log("SNS_LOGIN_CLOSE_NOT_AUTHENTICATED service=" + account.service.label + " profile=" + account.profileName);
            }
            loginWebView.stopLoading();
            loginWebView.destroy();
            dialog.dismiss();
            showAccountDialog(account.service);
        };
        done.setOnClickListener(finish);
        cancel.setOnClickListener(finish);
        dialog.setOnCancelListener(d -> {
            try { loginWebView.destroy(); } catch (Throwable ignored) {}
        });
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
    }

    private void applySensitiveForAllX() {
        ArrayList<SnsAccountManager.Account> list = new ArrayList<>();
        for (SnsAccountManager.Account a : accounts.getAccounts(SnsAccountManager.Service.X)) {
            if (accounts.isLoggedIn(a)) list.add(a);
        }
        if (list.isEmpty()) {
            Toast.makeText(activity, "ログイン済みXアカウントがありません", Toast.LENGTH_SHORT).show();
            return;
        }
        DiagnosticLog.log("X_SENSITIVE_ALL_START count=" + list.size());

        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(16), dp(16), dp(16));
        panel.setBackgroundColor(BG);
        TextView title = text("X センシティブ表示", 20, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView status = text("開始します…", 13, N_WHITE);
        panel.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        panel.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        FrameLayout webHost = new FrameLayout(activity);
        panel.addView(webHost, new LinearLayout.LayoutParams(1, 1));
        AlertDialog progress = new AlertDialog.Builder(activity).setView(panel).create();
        progress.setCanceledOnTouchOutside(false);
        progress.show();
        if (progress.getWindow() != null) progress.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        runSensitiveAccount(list, 0, status, webHost, progress, 0);
    }

    private void runSensitiveAccount(List<SnsAccountManager.Account> list, int index, TextView status,
                                     FrameLayout host, AlertDialog dialog, int okCount) {
        if (index >= list.size()) {
            DiagnosticLog.log("X_SENSITIVE_ALL_DONE success=" + okCount + " total=" + list.size());
            status.setText("完了  " + okCount + "/" + list.size());
            handler.postDelayed(() -> {
                if (dialog.isShowing()) dialog.dismiss();
                Toast.makeText(activity, "X設定 " + okCount + "/" + list.size() + " 完了", Toast.LENGTH_SHORT).show();
            }, 900L);
            return;
        }
        SnsAccountManager.Account account = list.get(index);
        status.setText(account.displayName() + "  設定中…");
        DiagnosticLog.log("X_SENSITIVE_ACCOUNT_START profile=" + account.profileName);

        WebView w = new WebView(activity);
        accounts.applyProfile(w, account.profileName);
        w.getSettings().setJavaScriptEnabled(true);
        w.getSettings().setDomStorageEnabled(true);
        w.getSettings().setUserAgentString(w.getSettings().getUserAgentString() + " ImgStalkerSNS/0.1.28");
        host.removeAllViews();
        host.addView(w, new FrameLayout.LayoutParams(1, 1));
        final boolean[] contentDone = {false};
        final boolean[] searchDone = {false};
        final int[] retry = {0};

        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (url == null) return;
                if (url.contains("/settings/content_you_see") && !contentDone[0]) {
                    handler.postDelayed(() -> applyContentToggle(view, result -> {
                        if ("missing".equals(result) && retry[0]++ < 3) {
                            view.reload();
                            return;
                        }
                        contentDone[0] = true;
                        DiagnosticLog.log("X_SENSITIVE_CONTENT profile=" + account.profileName + " result=" + result);
                        retry[0] = 0;
                        view.loadUrl("https://x.com/settings/search");
                    }), 1200L);
                } else if (url.contains("/settings/search") && contentDone[0] && !searchDone[0]) {
                    handler.postDelayed(() -> applySearchToggle(view, result -> {
                        if ("missing".equals(result) && retry[0]++ < 3) {
                            view.reload();
                            return;
                        }
                        searchDone[0] = true;
                        DiagnosticLog.log("X_SENSITIVE_SEARCH profile=" + account.profileName + " result=" + result);
                        boolean success = !"missing".equals(result);
                        try { view.stopLoading(); view.destroy(); } catch (Throwable ignored) {}
                        runSensitiveAccount(list, index + 1, status, host, dialog, okCount + (success ? 1 : 0));
                    }), 1200L);
                }
            }
        });
        w.loadUrl("https://x.com/settings/content_you_see");

        handler.postDelayed(() -> {
            if (!searchDone[0] && dialog.isShowing()) {
                searchDone[0] = true;
                DiagnosticLog.log("X_SENSITIVE_TIMEOUT profile=" + account.profileName);
                try { w.stopLoading(); w.destroy(); } catch (Throwable ignored) {}
                runSensitiveAccount(list, index + 1, status, host, dialog, okCount);
            }
        }, 25000L);
    }

    private interface JsResult { void done(String result); }

    private void applyContentToggle(WebView w, JsResult callback) {
        String js = "(function(){"
                + "function txt(e){return ((e&&e.innerText)||'').toLowerCase();}"
                + "var all=[].slice.call(document.querySelectorAll('input[type=checkbox],[role=checkbox]'));"
                + "for(var i=0;i<all.length;i++){var c=all[i],p=c.closest('label,div');var t=txt(p);"
                + "if(t.indexOf('sensitive')>=0||t.indexOf('センシティブ')>=0){"
                + "var checked=(c.checked===true)||(c.getAttribute('aria-checked')==='true');"
                + "if(!checked){c.click();return 'changed';}return 'already';}}return 'missing';})()";
        w.evaluateJavascript(js, value -> callback.done(cleanJsResult(value)));
    }

    private void applySearchToggle(WebView w, JsResult callback) {
        String js = "(function(){"
                + "function txt(e){return ((e&&e.innerText)||'').toLowerCase();}"
                + "var all=[].slice.call(document.querySelectorAll('input[type=checkbox],[role=checkbox]'));"
                + "for(var i=0;i<all.length;i++){var c=all[i],p=c.closest('label,div');var t=txt(p);"
                + "if((t.indexOf('hide')>=0&&t.indexOf('sensitive')>=0)||(t.indexOf('センシティブ')>=0&&t.indexOf('表示しない')>=0)){"
                + "var checked=(c.checked===true)||(c.getAttribute('aria-checked')==='true');"
                + "if(checked){c.click();return 'changed';}return 'already';}}return 'missing';})()";
        w.evaluateJavascript(js, value -> callback.done(cleanJsResult(value)));
    }

    private String cleanJsResult(String value) {
        if (value == null) return "missing";
        String s = value.replace("\\\"", "\"").replace("\"", "").trim();
        if (s.contains("changed")) return "changed";
        if (s.contains("already")) return "already";
        return "missing";
    }

    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(activity);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        return t;
    }

    private Button button(String value, int bg) {
        Button b = new Button(activity);
        b.setText(value);
        b.setTextColor(TEXT_WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(rounded(bg, 20));
        b.setElevation(0f);
        b.setStateListAnimator(null);
        return b;
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(float value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }
}
