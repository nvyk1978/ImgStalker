package com.cmyk.imgstalker;

import android.content.Context;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;

/**
 * Durable, append-only (by identity) history of unique discovered image/video links.
 * This is NOT a crawl checkpoint: a shorter reload, completion, Resume OFF, or analysis
 * cache deletion never makes previously discovered media disappear from the count.
 * File inventory remains the independent authority for the saved numerator.
 * All disk methods must be called from an IO executor, never the main/UI thread.
 */
final class DiscoveredMediaLedger {
    private static final int SCHEMA = 1;
    private static final String DIR = "discovered_media_v1";

    static final class Entry {
        final String key;
        final MediaItem.Kind kind;
        final String url;
        Entry(String key, MediaItem.Kind kind, String url) {
            this.key = key; this.kind = kind; this.url = url;
        }
    }

    static final class Snapshot {
        final String identity;
        final LinkedHashMap<String, Entry> entries = new LinkedHashMap<>();
        boolean readable = true;
        boolean existed = false;
        Snapshot(String identity) { this.identity = identity; }
        ArrayList<MediaItem> mediaItems() {
            ArrayList<MediaItem> result = new ArrayList<>(entries.size());
            for (Entry e : entries.values()) {
                result.add(new MediaItem(e.url.isEmpty() ? e.key : e.url, "", e.kind,
                        false, 0, 0, 0L, e.key));
            }
            return result;
        }
        int imageCount() {
            int count = 0;
            for (Entry e : entries.values()) if (e.kind == MediaItem.Kind.IMAGE) count++;
            return count;
        }
        int videoCount() {
            int count = 0;
            for (Entry e : entries.values()) if (e.kind == MediaItem.Kind.VIDEO) count++;
            return count;
        }
    }

    private DiscoveredMediaLedger() { }

    /** Identity is NORMAL's canonical page or SNS's service + account, never a CDN URL. */
    static String identity(String url) {
        SnsResumeStore.Target target = SnsResumeStore.targetForUrl(url);
        if (target != null) return target.categoryName + ":" + target.accountName.toLowerCase(Locale.ROOT);
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.NORMAL) return "";
        return NormalCheckpointStore.key(url);
    }

    /** Same deterministic key in every session; type prevents an image/video key collision. */
    static String keyFor(MediaItem item) {
        if (item == null || item.kind == MediaItem.Kind.STREAM) return "";
        String savedKey = SnsResumeStore.savedMediaKey(item);
        return savedKey.isEmpty() ? "" : item.kind.name() + ":" + savedKey;
    }

    static synchronized Snapshot merge(Context context, String url, Collection<MediaItem> found) {
        String id = identity(url);
        if (context == null || id.isEmpty()) return new Snapshot(id);
        Snapshot snapshot = read(context, id);
        if (!snapshot.readable) return snapshot; // Do not replace an unreadable historical file.
        boolean changed = false;
        if (found != null) for (MediaItem item : found) {
            String key = keyFor(item);
            if (key.isEmpty() || snapshot.entries.containsKey(key)) continue;
            snapshot.entries.put(key, new Entry(SnsResumeStore.savedMediaKey(item), item.kind,
                    item.url == null ? "" : item.url));
            changed = true;
        }
        if (changed) {
            snapshot.existed = true;
            write(context, snapshot);
            DiagnosticLog.log("DISCOVERED_MEDIA_MERGE target=" + id
                    + " images=" + snapshot.imageCount() + " videos=" + snapshot.videoCount());
        }
        return snapshot;
    }

    private static File path(Context context, String id) {
        String group = id.startsWith("Instagram:") ? "Instagram"
                : id.startsWith("X:") ? "X" : "Normal";
        return new File(new File(new File(context.getFilesDir(), DIR), group), sha256(id) + ".json");
    }

    private static Snapshot read(Context context, String id) {
        Snapshot snapshot = new Snapshot(id);
        AtomicFile atomic = new AtomicFile(path(context, id));
        try (FileInputStream input = atomic.openRead()) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int size;
            while ((size = input.read(buffer)) != -1) bytes.write(buffer, 0, size);
            JSONObject root = new JSONObject(bytes.toString(StandardCharsets.UTF_8.name()));
            if (root.optInt("schema", -1) != SCHEMA || !id.equals(root.optString("identity", "")))
                throw new IllegalStateException("discovered history identity/schema mismatch");
            snapshot.existed = true;
            JSONArray media = root.optJSONArray("media");
            if (media != null) for (int i = 0; i < media.length(); i++) {
                JSONObject raw = media.optJSONObject(i);
                if (raw == null) continue;
                String key = raw.optString("key", "");
                String kind = raw.optString("kind", "");
                if (key.isEmpty() || !("IMAGE".equals(kind) || "VIDEO".equals(kind))) continue;
                MediaItem.Kind type = MediaItem.Kind.valueOf(kind);
                snapshot.entries.putIfAbsent(kind + ":" + key,
                        new Entry(key, type, raw.optString("url", "")));
            }
        } catch (java.io.FileNotFoundException ignored) {
            // The first scan starts with a new ledger; absence is not corruption.
        } catch (Throwable error) {
            snapshot.readable = false;
            DiagnosticLog.logException("DISCOVERED_MEDIA_LOAD_FAIL target=" + id, error);
        }
        return snapshot;
    }

    private static void write(Context context, Snapshot snapshot) {
        File file = path(context, snapshot.identity);
        File parent = file.getParentFile();
        if (parent != null && !parent.isDirectory() && !parent.mkdirs() && !parent.isDirectory()) {
            DiagnosticLog.log("DISCOVERED_MEDIA_WRITE_FAIL mkdir=" + parent.getAbsolutePath());
            return;
        }
        AtomicFile atomic = new AtomicFile(file);
        FileOutputStream out = null;
        try {
            JSONObject root = new JSONObject();
            root.put("schema", SCHEMA);
            root.put("identity", snapshot.identity);
            root.put("updated_at", System.currentTimeMillis());
            JSONArray array = new JSONArray();
            for (Entry entry : snapshot.entries.values()) {
                JSONObject item = new JSONObject();
                item.put("key", entry.key);
                item.put("kind", entry.kind.name());
                item.put("url", entry.url);
                array.put(item);
            }
            root.put("media", array);
            out = atomic.startWrite();
            out.write(root.toString().getBytes(StandardCharsets.UTF_8));
            atomic.finishWrite(out);
        } catch (Throwable error) {
            if (out != null) atomic.failWrite(out);
            DiagnosticLog.logException("DISCOVERED_MEDIA_WRITE_FAIL target=" + snapshot.identity, error);
        }
    }

    private static String sha256(String id) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(id.getBytes(StandardCharsets.UTF_8));
            StringBuilder s = new StringBuilder();
            for (byte b : hash) s.append(String.format(Locale.ROOT, "%02x", b & 255));
            return s.toString();
        } catch (Exception error) { throw new IllegalStateException(error); }
    }
}
