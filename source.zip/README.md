# ImgStalker v0.1.41 (42)

## v0.1.41
- Media grid cells now show a single-line filename and a second-line resolution under the thumbnail.
- Video cells render a real video frame thumbnail when available, keep the centered play button, and show duration at the lower-left of the thumbnail.
- Image dimensions are carried from crawler probes; video dimensions/duration are filled from video metadata or Media3 playback metadata.
- Settings and Diagnostic Log header icons were redrawn as vector graphics based on the supplied gear/document references.
- Manual Analyze/Stop now leaves the Continue cell so the same analysis can be resumed with existing results preserved.
- Instagram video duplicate suppression now keys same-post video requests by Instagram asset id when available.
- Instagram audio-only tracks are excluded and explicit ad-tagged video encodes are skipped.
- Existing Instagram carousel traversal, X repost setting, X status detail collection, SNS login/profile support, and fixed signing are retained.
- versionCode 42 / versionName 0.1.41. applicationId and fixed signing are unchanged.
