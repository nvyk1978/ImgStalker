package com.cmyk.imgstalker;

/** Standalone host-only routing regression (compile together with AnalysisModeRouter.java). */
public final class ModeRoutingTest {
    private static int tested = 0;
    private static void check(String url, AnalysisModeRouter.Mode expected) {
        AnalysisModeRouter.Mode actual = AnalysisModeRouter.fromUrl(url);
        if (actual != expected) throw new AssertionError(url + ": expected " + expected + " got " + actual);
        ++tested;
    }
    public static void main(String[] args) {
        check("https://instagram.com/a", AnalysisModeRouter.Mode.INSTAGRAM);
        check("https://www.instagram.com/reel/Q", AnalysisModeRouter.Mode.INSTAGRAM);
        check("http://m.instagram.com/p/abc", AnalysisModeRouter.Mode.INSTAGRAM);
        check("instagram.com/foo", AnalysisModeRouter.Mode.INSTAGRAM);
        check("https://x.com/name", AnalysisModeRouter.Mode.X);
        check("https://mobile.twitter.com/name/media", AnalysisModeRouter.Mode.X);
        check("twitter.com/name/status/123", AnalysisModeRouter.Mode.X);
        check("https://twitter.com./abc", AnalysisModeRouter.Mode.X);
        check("https://example.com/instagram.com", AnalysisModeRouter.Mode.NORMAL);
        check("https://instagram.com.evil.example/post", AnalysisModeRouter.Mode.NORMAL);
        check("https://x.com.evil.example/post", AnalysisModeRouter.Mode.NORMAL);
        check("https://example.org/?link=https://x.com/test", AnalysisModeRouter.Mode.NORMAL);
        check("https://example.org/?link=https://instagram.com/test", AnalysisModeRouter.Mode.NORMAL);
        check("https://example.org/a", AnalysisModeRouter.Mode.NORMAL);
        check("https://notx.com/", AnalysisModeRouter.Mode.NORMAL);
        check("ftp://instagram.com/me", AnalysisModeRouter.Mode.NORMAL);
        check("https://user@x.com/home", AnalysisModeRouter.Mode.X);
        check("https://x.com:443/home", AnalysisModeRouter.Mode.X);
        check("", AnalysisModeRouter.Mode.NORMAL);
        System.out.println("PASS: " + tested + " domain-routing cases");
    }
}
