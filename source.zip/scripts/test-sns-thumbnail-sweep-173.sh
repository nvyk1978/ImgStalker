#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
r=Path('app/src/main/java/com/cmyk/imgstalker')
ui=(r/'MainActivity.java').read_text()
policy=(r/'SnsThumbnailSweepPolicy.java').read_text()
assert 'SNS_THUMB_BACKGROUND_BATCH = 2' in ui
assert 'SNS_THUMB_BACKGROUND_MAX_PENDING = 3' in ui
assert 'final int scanLimit = Math.min(size, 128)' in ui
assert 'snsThumbnailSweepCursor = (index + 1) % size;' in ui
assert 'if (started >= SNS_THUMB_BACKGROUND_BATCH' in ui
assert 'SNS_THUMB_AUTO_PREFETCH index=' in ui
assert 'snsThumbnailSweepPolicy.recordStart(key);' in ui
assert 'snsThumbnailSweepPolicy.recordResult(key, false, now);' in ui
assert 'snsThumbnailSweepPolicy.recordResult(key, true, now);' in ui
assert 'reconcileSnsThumbnailInFlight(now);' in ui
assert 'snsThumbnailSweepPassScanned += examined;' in ui
assert 'snsThumbnailSweepPolicy.abandonInFlight();' in ui
assert 'scheduleSnsThumbnailSweep("media_item")' in ui
assert 'scheduleSnsThumbnailSweep("resume_restore")' in ui
assert 'scheduleSnsThumbnailSweep("continue_reload")' in ui
assert 'scheduleSnsThumbnailSweep("activity_resume")' in ui
assert 'prefetchSnsThumbnailWindow(firstVisibleItem, visibleItemCount)' in ui
assert 'resetSnsThumbnailSweep("cache_clear")' in ui
assert 'scanCount = Math.min(size, 160)' not in ui
assert 'recordAttempt' not in ui
assert 'latestAttempt' not in policy
assert 'lastFailure.put(key, now)' in policy
assert 'void abandonInFlight()' in policy
for service in ('Instagram','Threads'):
 loader=(r/(service+'ThumbnailLoader.java')).read_text()
 adapter=(r/(service+'ThumbnailAdapter.java')).read_text()
 assert 'new SnsThumbnailDiskCache(context, "'+service.lower()+'")' in loader
 assert 'bitmap = diskCache.read(key);' in loader
 assert 'diskCache.write(key, bitmap)' in loader
 assert 'core.isReady(item)' in adapter
 assert 'metadataChanged.run()' in loader
cache=(r/'SnsThumbnailDiskCache.java').read_text()
assert '96L * 1024 * 1024' in cache
assert 'versionCode 174' in Path('app/build.gradle').read_text()
assert "versionName '0.1.173'" in Path('app/build.gradle').read_text()
print('PASS: ordered cursor, bounded start batch, completed-request retry, continuation and disk caches')
PY
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/com/cmyk/imgstalker"
cat > "$TMP/com/cmyk/imgstalker/SweepPolicyTest.java" <<'JAVA'
package com.cmyk.imgstalker;
final class SweepPolicyTest {
    static void yes(boolean value, String message) { if (!value) throw new AssertionError(message); }
    public static void main(String[] args) {
        SnsThumbnailSweepPolicy policy = new SnsThumbnailSweepPolicy();
        long t=100000L;
        String a="IMAGE|https://example.org/a";
        String b="IMAGE|https://example.org/b";
        yes(policy.canAttempt(a,t), "initial request");
        policy.recordStart(a);
        yes(policy.attempts(a)==0, "dispatch MUST NOT count as failure");
        yes(!policy.canAttempt(a,t+999999), "in-flight cannot retry");
        policy.recordResult(a,false,t);
        yes(policy.attempts(a)==1, "confirmed failure counted");
        yes(!policy.canAttempt(a,t+3499), "first retry delayed");
        yes(policy.canAttempt(a,t+3500), "first retry available");
        policy.recordStart(a);
        policy.recordResult(a,false,t+3500);
        yes(policy.attempts(a)==2, "second failure counted");
        yes(!policy.canAttempt(a,t+17500-1), "second retry delayed");
        yes(policy.canAttempt(a,t+17500), "second retry available");
        policy.recordStart(a);
        policy.recordResult(a,false,t+17500);
        yes(policy.canAttempt(a,t+77500), "third retry available");
        policy.recordStart(a);
        policy.recordResult(a,false,t+77500);
        yes(policy.exhausted(a) && !policy.canAttempt(a,t+9999999), "four failures exhaust");
        yes(!policy.hasRetryableFailures(), "exhausted isn't perpetual work");
        yes(policy.canAttempt(b,t), "independent key");
        policy.recordStart(b);
        policy.recordResult(b,true,t);
        yes(policy.isFinished(b) && !policy.canAttempt(b,t), "successful keys complete");
        policy.reset();
        policy.recordStart(a);
        policy.abandonInFlight();
        yes(policy.canAttempt(a,t), "continuation cancellation clears in-flight");
        System.out.println("PASS: failure-after-completion backoff, success, cancellation and exhausted state");
    }
}
JAVA
javac -d "$TMP" app/src/main/java/com/cmyk/imgstalker/SnsThumbnailSweepPolicy.java "$TMP/com/cmyk/imgstalker/SweepPolicyTest.java"
java -cp "$TMP" com.cmyk.imgstalker.SweepPolicyTest
