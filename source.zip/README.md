# ImgStalker v0.1.55 (56)

## v0.1.55 rollback
- Full rollback to the v0.1.51 application behavior/codebase.
- Removed the background-analysis Foreground Service/WakeLock implementation introduced after v0.1.51.
- Instagram traversal/retry/carousel logic is the v0.1.51 implementation without new behavioral changes.
- applicationId and fixed signing key are unchanged.

# ImgStalker v0.1.51 (52)

## v0.1.51
- Instagram Networkで検出済みの動画候補を、DOM詳細収集開始時刻より前という理由だけで破棄しないよう修正。ReelのMP4本体をVIDEOとして一覧へ渡す。
- Instagramの `video_default_cover_frame` は動画サムネイルとして判定し、独立IMAGEとして一覧へ追加しない。
- Instagram VIDEO登録時に `MEDIA_QUEUED kind=VIDEO` を診断ログへ記録。
- v0.1.50で改善したInstagram巡回・再試行・カルーセル読み込みロジックは変更なし。

## v0.1.50
- Instagram detail traversal no longer lets one failed post block the whole profile.
- A failed carousel/detail load is moved to the back of the detail queue and retried from slide 1 after other queued posts get a turn.
- Instagram retry has no completion/skip cap; the crawler continues cycling unfinished posts until they complete or the user presses Stop.
- Empty-media/reel waits are bounded per visit, then deferred instead of ending analysis.
- Missing/un-clickable Next and slide-change failures get short in-page recovery, then defer/retry rather than completion.
- A first-slide terminal state with multiple loaded media items is treated as ambiguous carousel state and is never accepted as completed; it is retried later.
- Normal single-media/final-slide terminal confirmation uses the v0.1.43-style grace period without a full reload.
- Existing Instagram image/video de-duplication remains based on actual CDN image identity and video asset/path identity, not only slide number.
- Header gear and diagnostic icons retain the slightly reduced visual size while keeping the same 44dp touch targets.

## Package
- versionCode 52 / versionName 0.1.51.
- applicationId and fixed signing key are unchanged.
