package com.cmyk.imgstalker;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.UserAgentMetadata;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.net.UnknownHostException;
import java.util.ArrayDeque;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import android.util.Base64;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class CrawlerEngine {
    public interface Listener {
        void onStatus(String text);
        void onProgressPulse(String stage);
        void onItem(MediaItem item);
        void onDone(String title, int visitedPages, int imageCount, int videoCount, int streamCount);
        void onError(String message);
        void onInstagramManualTapReady();
        void onInstagramManualTapResult(boolean opened, String message);
    }

    private static final class Node {
        final String url;
        final int depth;
        final boolean detail;
        Node(String url, int depth, boolean detail) {
            this.url = url;
            this.depth = depth;
            this.detail = detail;
        }
    }

    private static final class ImageCandidate {
        final String url;
        final String referrer;
        final String sourceLogPrefix;
        ImageCandidate(String url, String referrer, String sourceLogPrefix) {
            this.url = url;
            this.referrer = referrer;
            this.sourceLogPrefix = sourceLogPrefix;
        }
    }

    private static final class DeferredDetail {
        final String url;
        final LinkedHashSet<String> thumbKeys = new LinkedHashSet<>();
        DeferredDetail(String url) {
            this.url = url;
        }
    }

    private static final class InstagramVideoCandidate {
        final String key;
        final String url;
        final MediaItem.Kind kind;
        final long seenAt;
        InstagramVideoCandidate(String key, String url, MediaItem.Kind kind, long seenAt) {
            this.key = key;
            this.url = url;
            this.kind = kind;
            this.seenAt = seenAt;
        }
    }

    private final WebView webView;
    private final InstagramMediaResolver instagramMediaResolver;
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private static final boolean INSTAGRAM_MANUAL_TAP_DIAG = false;
    private static final boolean INSTAGRAM_SPA_AUTO_CLICK = true;
    // v0.1.74: Instagram discovery stays on the profile grid. Visible post URLs are
    // resolved by InstagramMediaResolver inside the authenticated page context; browser
    // navigation is reserved for immediate fallback only.
    private static final boolean INSTAGRAM_STREAMING_PROFILE = true;
    private static final long INSTAGRAM_STREAM_SCAN_DELAY_MS = 320L;
    private static final long INSTAGRAM_STREAM_SCROLL_DELAY_MS = 760L;
    private static final int INSTAGRAM_SPA_FIND_MAX_PASSES = 48;
    private static final int INSTAGRAM_SPA_TAP_MAX_ATTEMPTS = 1;
    private static final long INSTAGRAM_SPA_OPEN_TIMEOUT_MS = 15000L;
    private volatile boolean instagramManualTapWaiting = false;
    private volatile String instagramManualTapTargetUrl = "";
    private volatile boolean instagramSpaAwaitingOpen = false;
    private volatile boolean instagramSpaReturningToProfile = false;
    private volatile String instagramSpaTargetUrl = "";
    private volatile int instagramSpaTapAttempts = 0;
    private boolean instagramStreamingMode = false;
    private String instagramStreamingProfileUrl = "";
    private int instagramStreamingPass = 0;
    private int instagramStreamingStall = 0;
    private int instagramStreamingPreviousHeight = 0;
    private int instagramStreamingResumeScrollY = 0;
    private int instagramProfilePostCount = 0;
    private int instagramStreamingTargetPosts = 0;
    // v0.1.74: continuation reload explicitly retries previously discovered-but-not-completed posts first.
    private final LinkedHashSet<String> instagramContinuationPendingUrls = new LinkedHashSet<>();
    private final ArrayDeque<Node> queue = new ArrayDeque<>();
    private final Set<String> queuedOrVisited = new HashSet<>();
    private final Set<String> mediaSeen = new HashSet<>();
    private final Set<String> imageCandidateSeen = new HashSet<>();
    private final Map<String, ImageCandidate> provisionalImages = new LinkedHashMap<>();
    private final Map<String, int[]> acceptedProvisionalSizes = new LinkedHashMap<>();
    private final Set<String> unresolvedProvisionalThumbs = new HashSet<>();
    private final Map<String, DeferredDetail> deferredDetails = new LinkedHashMap<>();
    private final Map<String, Set<String>> detailToProvisionalThumbs = new HashMap<>();
    private final Map<String, Set<String>> replacementToProvisionalThumbs = new HashMap<>();
    private final Set<String> suppressedProvisionalThumbs = new HashSet<>();
    private final Set<String> simpleGateAttemptedUrls = new HashSet<>();
    private final Map<String, Integer> instagramDetailRetryCounts = new HashMap<>();
    private final Set<String> instagramPostsWithNetworkVideo = new HashSet<>();
    private final Map<String, Integer> instagramCarouselSlideByPost = new HashMap<>();
    private final Map<String, Integer> instagramResumeSlideByPost = new HashMap<>();
    private final Map<String, LinkedHashMap<String, InstagramVideoCandidate>> instagramNetworkVideoCandidates = new HashMap<>();
    private final Set<String> instagramConsumedNetworkVideoCandidates = new HashSet<>();
    private final Map<String, Long> instagramSlideStartedAtByPost = new HashMap<>();
    private final Map<String, String> instagramTerminalCandidateByPost = new HashMap<>();
    private final Map<String, Integer> instagramTerminalConfirmCountByPost = new HashMap<>();
    private final Set<String> instagramPostsWithCapturedVideo = new HashSet<>();
    private final ExecutorService imageProbeExecutor = Executors.newFixedThreadPool(3);

    private boolean followPagination = true;
    private boolean followDetails = true;
    private boolean wantImages = true;
    private boolean wantVideos = true;
    private boolean includeXReposts = false;
    private boolean cancelled = true;
    private boolean gracefulStopRequested = false;
    private boolean instagramStreamingResolverInFlight = false;
    private long generation = 0L;
    private String rootHost = "";
    private String crawlerRootUrl = "";
    private String pageTitle = "ImgStalker";
    private int pageCount = 0;
    private int detailCount = 0;
    private int imageCount = 0;
    private int videoCount = 0;
    private int streamCount = 0;
    private int maxPages = 30;
    private int maxDetails = 120;
    private static final long DETAIL_LOAD_TIMEOUT_MS = 12000L;
    private static final long DETAIL_DOM_TIMEOUT_MS = 10000L;
    private static final long DETAIL_PHASE_BUDGET_MS = 180000L; // non-Instagram only
    // Browser-style Instagram detail navigation is fallback-only. Keep it paced like normal
    // browsing so a resolver miss does not turn into a rapid sequence of detail loads.
    private static final long INSTAGRAM_BROWSER_NAV_DELAY_MS = 2500L;
    private static final int INSTAGRAM_POST_RETRY_LIMIT = 2;
    private static final int SNS_SCROLL_MAX_PASSES = 28;
    private static final int INSTAGRAM_SCROLL_MAX_PASSES = 180;
    private static final int SNS_SCROLL_STALL_LIMIT = 3;
    private static final long SNS_SCROLL_DELAY_MS = 800L;
    private static final int INSTAGRAM_DETAIL_LIMIT = 300;
    private static final int X_STATUS_DETAIL_LIMIT = 80;
    private static final int INSTAGRAM_CAROUSEL_MAX_SLIDES = 20;
    private static final long INSTAGRAM_CAROUSEL_DELAY_MS = 220L;
    private static final long INSTAGRAM_STALL_RECOVERY_MS = 30000L;
    private static final long INSTAGRAM_STALL_WATCHDOG_TICK_MS = 3000L;
    private static final int INSTAGRAM_SLIDE_CHANGE_MAX_POLLS = 24;
    private static final long INSTAGRAM_SLIDE_CHANGE_POLL_MS = 250L;
    private static final long INSTAGRAM_NETWORK_QUIET_MS = 7000L;
    private static final int INSTAGRAM_READY_MAX_PASSES = 8;
    private static final int INSTAGRAM_EMPTY_MEDIA_LOG_INTERVAL = 8;
    private static final int INSTAGRAM_EMPTY_MEDIA_DEFER_POLLS = 30;
    // v0.1.69: reliability first. Keep Instagram images enabled so the profile grid
    // and per-post DOM fully materialize. The fallback hook remains for diagnostics but image
    // loading is no longer toggled off between profile/detail navigation.
    private static final int INSTAGRAM_IMAGE_FALLBACK_POLLS = 6;
    private static final int INSTAGRAM_CLICK_RETRY_LIMIT = 3;
    private static final long INSTAGRAM_TERMINAL_RECHECK_MS = 900L;
    private static final long INSTAGRAM_RETRY_DEFER_DELAY_MS = 350L;
    private int targetImagePx = 640;
    private int pendingImageProbes = 0;
    private boolean traversalDone = false;
    private boolean baseTraversalDone = false;
    private boolean detailPhaseStarted = false;
    private boolean detailTraversalDone = false;
    private boolean provisionalPhaseStarted = false;
    private boolean doneEmitted = false;
    private long detailPhaseStartedAt = 0L;
    private String imageProbeUserAgent = "";
    private Node current;
    private long loadSequence = 0L;
    private long activeLoadSequence = 0L;
    private long activeNavigationSequence = 0L;
    private boolean activeLoadStarted = false;
    private boolean activePageFinished = false;
    private long activeStartedGeneration = -1L;
    private String activeRequestedUrl = "";
    private String activeStartedUrl = "";
    private String pendingSimpleGateSourceUrl = "";
    private boolean xMediaFallbackTried = false;
    private String rootXUser = "";
    private boolean activeInstagramDetailCollectionStarted = false;
    private boolean activeInstagramRequestDiagLogged = false;
    private int snsReadyProbeSerial = 0;
    private final Set<String> continuationSeedMediaKeys = new HashSet<>();
    private final Set<String> continuationSeedImageKeys = new HashSet<>();
    private final Set<String> continuationSeedDetailUrls = new HashSet<>();
    private final LinkedHashSet<String> instagramPostUrlsSeen = new LinkedHashSet<>();
    private final LinkedHashMap<String, Integer> instagramPostOrder = new LinkedHashMap<>();
    private final Map<String, Integer> instagramMediaOrderByPost = new HashMap<>();
    private int instagramNextPostOrder = 0;
    private final ArrayDeque<String> instagramStreamingDeferredRetryQueue = new ArrayDeque<>();
    private final LinkedHashSet<String> instagramStreamingDeferredRetrySet = new LinkedHashSet<>();
    private boolean instagramStreamingDeferredRetryPhase = false;
    private final LinkedHashSet<String> instagramCompletedPostUrls = new LinkedHashSet<>();
    private final LinkedHashSet<String> instagramSkippedPostUrls = new LinkedHashSet<>();
    // v0.1.70: Instagram continuation is session based, not run based. Keep the URLs
    // discovered by previous runs so reload can rebuild stable ordering, while completed
    // URLs are seeded separately and skipped without being mistaken for pending work.
    private final LinkedHashSet<String> continuationSeedInstagramCompletedUrls = new LinkedHashSet<>();
    private final LinkedHashSet<String> continuationSeedInstagramDiscoveredUrls = new LinkedHashSet<>();
    private final LinkedHashSet<String> instagramContinuationDiscoveredUrls = new LinkedHashSet<>();
    private final LinkedHashSet<String> incompleteReasons = new LinkedHashSet<>();
    private int instagramPostDetailsQueued = 0;
    private int instagramUnknownHostProbeFailures = 0;
    private long instagramLastNetworkMediaAt = 0L;
    private long instagramCompletionCandidateAt = 0L;
    private boolean instagramCompletionWaitScheduled = false;
    private long activeInstagramLastMeaningfulProgressAt = 0L;
    private boolean instagramNetworkImagesBlocked = false;
    private String instagramImageFallbackPost = "";

    public CrawlerEngine(WebView webView, Listener listener) {
        this.webView = webView;
        this.instagramMediaResolver = new InstagramMediaResolver(webView);
        this.listener = listener;
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString() + " ImgStalker/0.1.80");
        imageProbeUserAgent = s.getUserAgentString();
        try {
            android.content.pm.PackageInfo provider = WebView.getCurrentWebViewPackage();
            DiagnosticLog.log("WEBVIEW_PROVIDER package=" + (provider == null ? "<none>" : provider.packageName)
                    + " version=" + (provider == null ? "<none>" : provider.versionName));
        } catch (Throwable t) {
            DiagnosticLog.log("WEBVIEW_PROVIDER_FAIL reason=" + t.getClass().getSimpleName());
        }
        DiagnosticLog.log("WEBVIEW_SETTINGS js=" + s.getJavaScriptEnabled()
                + " domStorage=" + s.getDomStorageEnabled()
                + " loadsImages=" + s.getLoadsImagesAutomatically()
                + " mediaGesture=" + s.getMediaPlaybackRequiresUserGesture()
                + " cacheMode=" + s.getCacheMode());
        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    String requestUrl = request.getUrl().toString();
                    captureInstagramVideoNetworkRequest(requestUrl);
                    if (request.isForMainFrame() && isInstagramPostUrl(requestUrl)) {
                        logInstagramMainFrameRequest(request, requestUrl);
                        if (INSTAGRAM_MANUAL_TAP_DIAG && instagramManualTapWaiting) {
                            instagramManualTapTargetUrl = stripFragment(requestUrl);
                            DiagnosticLog.log("SNS_IG_MANUAL_TAP_REQUEST url=" + instagramManualTapTargetUrl
                                    + " gesture=" + request.hasGesture()
                                    + " method=" + request.getMethod());
                        }
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                captureInstagramVideoNetworkRequest(url);
                return super.shouldInterceptRequest(view, url);
            }

            @Override public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                if (INSTAGRAM_SPA_AUTO_CLICK && instagramSpaAwaitingOpen && current != null && current.detail
                        && isInstagramPostUrl(url)) {
                    String opened = canonicalInstagramPostUrl(url);
                    String target = canonicalInstagramPostUrl(instagramSpaTargetUrl);
                    if (!opened.isEmpty() && opened.equals(target)) {
                        instagramSpaAwaitingOpen = false;
                        activeLoadStarted = true;
                        activePageFinished = true;
                        activeStartedGeneration = generation;
                        activeStartedUrl = stripFragment(url);
                        activeNavigationSequence++;
                        final long run = generation;
                        final long load = activeLoadSequence;
                        final long nav = activeNavigationSequence;
                        final Node node = current;
                        DiagnosticLog.log("SNS_IG_SPA_OPEN target=" + target
                                + " history=" + stripFragment(url)
                                + " reload=" + isReload
                                + " tapAttempts=" + instagramSpaTapAttempts);
                        listener.onProgressPulse("SNS_IG_SPA_OPEN");
                        markInstagramMeaningfulProgress("spa_open");
                        handler.postDelayed(() -> startInstagramDetailCollection(run, load, nav, node, "spa_history"), 650L);
                    } else if (!opened.isEmpty() && !target.isEmpty()) {
                        final long wrongLoad = activeLoadSequence;
                        final Node wrongNode = current;
                        instagramSpaAwaitingOpen = false;
                        DiagnosticLog.log("SNS_IG_SPA_WRONG_POST expected=" + target
                                + " opened=" + opened + " action=defer");
                        listener.onProgressPulse("SNS_IG_SPA_WRONG_POST");
                        handler.post(() -> restartInstagramPostFromBeginning(wrongNode, wrongLoad, "spa_wrong_post"));
                    }
                }
                if (INSTAGRAM_SPA_AUTO_CLICK && instagramSpaReturningToProfile && !isInstagramPostUrl(url)) {
                    DiagnosticLog.log("SNS_IG_SPA_PROFILE_HISTORY url=" + stripFragment(url) + " reload=" + isReload);
                }
                if (INSTAGRAM_MANUAL_TAP_DIAG && instagramManualTapWaiting && isInstagramPostUrl(url)) {
                    DiagnosticLog.log("SNS_IG_MANUAL_TAP_HISTORY url=" + stripFragment(url)
                            + " reload=" + isReload);
                }
                super.doUpdateVisitedHistory(view, url, isReload);
            }

            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (cancelled || current == null) {
                    DiagnosticLog.log("WEB_PAGE_STARTED_STALE reason=no_active_node url=" + url
                            + " generation=" + generation);
                    return;
                }

                String started = stripFragment(url);
                if (!activeLoadStarted) {
                    // Bind this callback lane only after WebView confirms that the URL requested by
                    // the current Node actually started. A late onPageFinished/onPageStarted from
                    // the previous analysis must never be allowed to arm DOM collection.
                    if (!sameNavigationUrl(started, activeRequestedUrl)) {
                        DiagnosticLog.log("WEB_PAGE_STARTED_STALE reason=request_mismatch url=" + url
                                + " expected=" + activeRequestedUrl
                                + " generation=" + generation
                                + " load=" + activeLoadSequence);
                        return;
                    }
                    activeLoadStarted = true;
                    activePageFinished = false;
                    activeStartedGeneration = generation;
                    activeStartedUrl = started;
                    activeNavigationSequence++;
                    DiagnosticLog.log("WEB_PAGE_STARTED generation=" + generation
                            + " load=" + activeLoadSequence
                            + " nav=" + activeNavigationSequence
                            + " url=" + url);
                    listener.onProgressPulse("WEB_PAGE_STARTED");
                    if (current.detail && isInstagramLikeHost(rootHost)) markInstagramMeaningfulProgress("page_started");
                    return;
                }

                if (activeStartedGeneration != generation) {
                    DiagnosticLog.log("WEB_PAGE_STARTED_STALE reason=generation_mismatch url=" + url
                            + " started_generation=" + activeStartedGeneration
                            + " current_generation=" + generation
                            + " load=" + activeLoadSequence);
                    return;
                }

                // A main-frame redirect belongs to the already bound current load. Keep the final
                // started URL so onPageFinished must correspond to the same navigation.
                activeStartedUrl = started;
                activePageFinished = false;
                activeNavigationSequence++;
                DiagnosticLog.log("WEB_PAGE_STARTED_REDIRECT generation=" + generation
                        + " load=" + activeLoadSequence
                        + " nav=" + activeNavigationSequence
                        + " url=" + url);
                listener.onProgressPulse("WEB_PAGE_STARTED_REDIRECT");
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (cancelled || current == null) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_STALE reason=no_active_node url=" + url
                            + " generation=" + generation);
                    return;
                }
                if (!activeLoadStarted) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_STALE reason=no_matching_start url=" + url
                            + " expected=" + activeRequestedUrl
                            + " generation=" + generation
                            + " load=" + activeLoadSequence);
                    return;
                }
                if (activeStartedGeneration != generation) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_STALE reason=generation_mismatch url=" + url
                            + " started_generation=" + activeStartedGeneration
                            + " current_generation=" + generation
                            + " load=" + activeLoadSequence);
                    return;
                }
                if (!sameNavigationUrl(url, activeStartedUrl)) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_STALE reason=url_mismatch url=" + url
                            + " started=" + activeStartedUrl
                            + " expected=" + activeRequestedUrl
                            + " generation=" + generation
                            + " load=" + activeLoadSequence);
                    return;
                }
                if (activePageFinished) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_DUPLICATE generation=" + generation
                            + " load=" + activeLoadSequence
                            + " nav=" + activeNavigationSequence
                            + " url=" + url);
                    return;
                }

                activePageFinished = true;
                final long run = generation;
                final long load = activeLoadSequence;
                final long nav = activeNavigationSequence;
                final Node node = current;
                DiagnosticLog.log("WEB_PAGE_FINISHED generation=" + run
                        + " load=" + load
                        + " nav=" + nav
                        + " url=" + url
                        + " node=" + node.url);
                listener.onProgressPulse("WEB_PAGE_FINISHED");
                if (instagramSpaReturningToProfile && !isInstagramPostUrl(url)) {
                    DiagnosticLog.log("SNS_IG_PROFILE_RETURN_PAGE_FINISHED url=" + stripFragment(url));
                    return;
                }
                if (INSTAGRAM_MANUAL_TAP_DIAG && instagramManualTapWaiting && isInstagramPostUrl(url)) {
                    String openedUrl = stripFragment(url);
                    DiagnosticLog.log("SNS_IG_MANUAL_TAP_RESULT result=loaded url=" + openedUrl
                            + " target=" + instagramManualTapTargetUrl);
                    logInstagramCookieState("after_manual_tap_loaded");
                    instagramManualTapWaiting = false;
                    instagramManualTapTargetUrl = openedUrl;
                    cancel();
                    listener.onInstagramManualTapResult(true, "手動タップでは投稿詳細を開けました");
                    return;
                }
                if (node.detail && isInstagramLikeHost(rootHost)) markInstagramMeaningfulProgress("page_finished");
                handler.postDelayed(() -> inspectSimpleGateThenContinue(run, load, nav, node), 450L);
            }

            @Override public void onReceivedHttpError(WebView view, android.webkit.WebResourceRequest request,
                                                      android.webkit.WebResourceResponse errorResponse) {
                if (cancelled || request == null || errorResponse == null || !request.isForMainFrame()) return;
                String errorUrl = request.getUrl() == null ? "" : request.getUrl().toString();
                int status = errorResponse.getStatusCode();
                DiagnosticLog.log("WEB_MAIN_HTTP_STATUS status=" + status + " url=" + errorUrl);
                if (status == 429 && isInstagramLikeHost(rootHost)) {
                    Map<String, String> responseHeaders = errorResponse.getResponseHeaders();
                    DiagnosticLog.log("SNS_IG_429_RESPONSE retryAfter=" + headerValue(responseHeaders, "Retry-After")
                            + " server=" + headerValue(responseHeaders, "Server")
                            + " contentType=" + headerValue(responseHeaders, "Content-Type")
                            + " headerNames=" + headerNames(responseHeaders));
                    logInstagramCookieState("after_429");
                    DiagnosticLog.log("SNS_IG_RATE_LIMIT_STOP status=429 url=" + errorUrl
                            + " detail=" + (current != null && current.detail));
                    listener.onProgressPulse("SNS_IG_RATE_LIMIT_STOP");
                    boolean manualTap429 = INSTAGRAM_MANUAL_TAP_DIAG && instagramManualTapWaiting
                            && isInstagramPostUrl(errorUrl);
                    instagramManualTapWaiting = false;
                    instagramManualTapTargetUrl = stripFragment(errorUrl);
                    cancel();
                    if (manualTap429) {
                        DiagnosticLog.log("SNS_IG_MANUAL_TAP_RESULT result=http_429 url=" + errorUrl);
                        listener.onInstagramManualTapResult(false, "手動タップでも投稿詳細がHTTP 429でした");
                    } else {
                        listener.onError("Instagram側でアクセス制限（HTTP 429）。安全のため解析を停止しました");
                    }
                }
            }

            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                                                  android.webkit.WebResourceError error) {
                if (cancelled || request == null || !request.isForMainFrame()) return;
                String errorUrl = request.getUrl() == null ? "" : request.getUrl().toString();
                if (current == null || !activeLoadStarted
                        || activeStartedGeneration != generation
                        || !sameNavigationUrl(errorUrl, activeStartedUrl)) {
                    DiagnosticLog.log("WEB_MAIN_ERROR_STALE url=" + errorUrl
                            + " generation=" + generation
                            + " load=" + activeLoadSequence
                            + " error=" + error);
                    return;
                }
                DiagnosticLog.log("WEB_MAIN_ERROR url=" + errorUrl + " error=" + error);
                listener.onProgressPulse("WEB_MAIN_ERROR");
                listener.onStatus("読込失敗: " + errorUrl);
                if (current != null && current.detail) {
                    Node failedNode = current;
                    long failedLoad = activeLoadSequence;
                    handler.post(() -> skipCurrentDetail(failedNode, failedLoad, "web_error", 0L));
                }
            }
        });
    }

    public void setIncludeXReposts(boolean include) {
        includeXReposts = include;
        DiagnosticLog.log("SNS_X_REPOST_SETTING enabled=" + include);
    }

    /** External resume seeds media dedup only. Detail URLs are intentionally not marked
     * completed here: after process/app restart an interrupted X/Instagram post must be
     * allowed to run again and fill any missing media. */
    public void seedExternalResumeMedia(java.util.List<MediaItem> existing) {
        if (existing == null) return;
        int beforeMedia = continuationSeedMediaKeys.size();
        int beforeImages = continuationSeedImageKeys.size();
        for (MediaItem item : existing) {
            if (item == null || item.url == null || item.url.trim().isEmpty()) continue;
            String clean = stripFragment(cleanUrl(item.url));
            continuationSeedMediaKeys.add(item.dedupKey == null || item.dedupKey.isEmpty()
                    ? mediaDedupKey(item.kind, clean, item.referrer) : item.dedupKey);
            if (item.kind == MediaItem.Kind.IMAGE) {
                String ik = imageKey(clean);
                if (!ik.isEmpty()) continuationSeedImageKeys.add(ik);
            }
        }
        DiagnosticLog.log("CRAWLER_EXTERNAL_RESUME_MEDIA_SEED media=" + beforeMedia + "->"
                + continuationSeedMediaKeys.size() + " imageKeys=" + beforeImages + "->"
                + continuationSeedImageKeys.size());
    }

    public void seedContinuationResults(java.util.List<MediaItem> existing) {
        continuationSeedMediaKeys.clear();
        continuationSeedImageKeys.clear();
        continuationSeedDetailUrls.clear();
        continuationSeedInstagramCompletedUrls.clear();
        continuationSeedInstagramDiscoveredUrls.clear();
        if (existing == null) return;
        for (MediaItem item : existing) {
            if (item == null || item.url == null || item.url.trim().isEmpty()) continue;
            String clean = stripFragment(cleanUrl(item.url));
            continuationSeedMediaKeys.add(item.dedupKey == null || item.dedupKey.isEmpty()
                    ? mediaDedupKey(item.kind, clean, item.referrer) : item.dedupKey);
            if (item.kind == MediaItem.Kind.IMAGE) {
                String ik = imageKey(clean);
                if (!ik.isEmpty()) continuationSeedImageKeys.add(ik);
            }
            String ref = stripFragment(cleanUrl(item.referrer));
            if (isInstagramPostUrl(ref)) {
                // Keep only media URL seeds for Instagram. Revisit the post on continuation so
                // a partially collected carousel can advance beyond the slides already obtained.
            } else if (isXStatusUrl(ref)) {
                String canonical = canonicalXStatusUrl(ref);
                if (!canonical.isEmpty()) continuationSeedDetailUrls.add(canonical);
            }
        }
        DiagnosticLog.log("CRAWLER_CONTINUE_SEED_PREP media=" + continuationSeedMediaKeys.size()
                + " imageKeys=" + continuationSeedImageKeys.size()
                + " details=" + continuationSeedDetailUrls.size());
    }

    public void clearContinuationSeed() {
        continuationSeedMediaKeys.clear();
        continuationSeedImageKeys.clear();
        continuationSeedDetailUrls.clear();
        continuationSeedInstagramCompletedUrls.clear();
        continuationSeedInstagramDiscoveredUrls.clear();
    }

    public java.util.List<String> getCompletedInstagramPostUrls() {
        return new ArrayList<>(instagramCompletedPostUrls);
    }

    public java.util.List<String> getDiscoveredInstagramPostUrls() {
        return new ArrayList<>(instagramPostUrlsSeen);
    }

    public int getInstagramFailedPostCount() {
        return instagramSkippedPostUrls.size();
    }

    public void seedContinuationDetailUrls(java.util.Collection<String> urls) {
        if (urls == null) return;
        for (String raw : urls) {
            String ig = canonicalInstagramPostUrl(raw);
            if (!ig.isEmpty()) {
                continuationSeedDetailUrls.add(ig);
                continuationSeedInstagramCompletedUrls.add(ig);
                continuationSeedInstagramDiscoveredUrls.add(ig);
            } else {
                String x = canonicalXStatusUrl(raw);
                if (!x.isEmpty()) continuationSeedDetailUrls.add(x);
            }
        }
        DiagnosticLog.log("CRAWLER_CONTINUE_DETAIL_SEED_PREP details=" + continuationSeedDetailUrls.size()
                + " igCompleted=" + continuationSeedInstagramCompletedUrls.size());
    }

    public void seedInstagramContinuationState(java.util.Collection<String> completedUrls,
                                                java.util.Collection<String> discoveredUrls) {
        continuationSeedInstagramCompletedUrls.clear();
        continuationSeedInstagramDiscoveredUrls.clear();
        if (discoveredUrls != null) {
            for (String raw : discoveredUrls) {
                String ig = canonicalInstagramPostUrl(raw);
                if (!ig.isEmpty()) continuationSeedInstagramDiscoveredUrls.add(ig);
            }
        }
        if (completedUrls != null) {
            for (String raw : completedUrls) {
                String ig = canonicalInstagramPostUrl(raw);
                if (ig.isEmpty()) continue;
                continuationSeedInstagramCompletedUrls.add(ig);
                continuationSeedInstagramDiscoveredUrls.add(ig);
                continuationSeedDetailUrls.add(ig);
            }
        }
        DiagnosticLog.log("CRAWLER_CONTINUE_IG_SESSION_SEED_PREP completed="
                + continuationSeedInstagramCompletedUrls.size()
                + " discovered=" + continuationSeedInstagramDiscoveredUrls.size());
    }

    private void setInstagramNetworkImagesBlocked(boolean blocked, String reason) {
        if (!isInstagramLikeHost(rootHost)) return;
        try {
            WebSettings settings = webView.getSettings();
            // Apply block first when disabling, and automatic loading first when enabling.
            if (blocked) {
                settings.setBlockNetworkImage(true);
                settings.setLoadsImagesAutomatically(false);
            } else {
                settings.setLoadsImagesAutomatically(true);
                settings.setBlockNetworkImage(false);
            }
            instagramNetworkImagesBlocked = blocked;
            DiagnosticLog.log("SNS_IG_IMAGE_POLICY blocked=" + blocked
                    + " reason=" + reason
                    + " loadsImages=" + settings.getLoadsImagesAutomatically()
                    + " blockNetworkImage=" + settings.getBlockNetworkImage());
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_IG_IMAGE_POLICY_FAIL blocked=" + blocked + " reason=" + reason, t);
        }
    }

    private boolean enableInstagramImagesForFallback(Node node, String reason) {
        if (node == null || !node.detail || !isInstagramLikeHost(rootHost)) return false;
        String post = canonicalInstagramPostUrl(node.url);
        if (post.isEmpty()) post = stripFragment(cleanUrl(node.url));
        if (!instagramNetworkImagesBlocked && post.equals(instagramImageFallbackPost)) return false;
        instagramImageFallbackPost = post;
        setInstagramNetworkImagesBlocked(false, "detail_fallback_" + reason);
        DiagnosticLog.log("SNS_IG_IMAGE_FALLBACK_ENABLE post=" + post + " reason=" + reason);
        listener.onProgressPulse("SNS_IG_IMAGE_FALLBACK_ENABLE");
        return true;
    }

    private void restoreInstagramLightImagePolicy(String reason) {
        instagramImageFallbackPost = "";
        setInstagramNetworkImagesBlocked(false, reason);
    }

    public boolean isIncompleteCompletion() {
        return !incompleteReasons.isEmpty();
    }

    public String getIncompleteCompletionReason() {
        if (incompleteReasons.isEmpty()) return "";
        return String.join(",", incompleteReasons);
    }

    private void markIncomplete(String reason) {
        if (reason == null || reason.trim().isEmpty()) return;
        if (incompleteReasons.add(reason.trim())) {
            DiagnosticLog.log("CRAWLER_INCOMPLETE reason=" + reason.trim());
        }
    }

    public void start(String startUrl, boolean followPagination, boolean followDetails,
                      boolean wantImages, boolean wantVideos, int targetImagePx) {
        cancel();
        cancelled = false;
        gracefulStopRequested = false;
        instagramStreamingResolverInFlight = false;
        queue.clear();
        queuedOrVisited.clear();
        mediaSeen.clear();
        imageCandidateSeen.clear();
        provisionalImages.clear();
        acceptedProvisionalSizes.clear();
        unresolvedProvisionalThumbs.clear();
        deferredDetails.clear();
        detailToProvisionalThumbs.clear();
        replacementToProvisionalThumbs.clear();
        suppressedProvisionalThumbs.clear();
        simpleGateAttemptedUrls.clear();
        instagramDetailRetryCounts.clear();
        instagramPostsWithNetworkVideo.clear();
        instagramCarouselSlideByPost.clear();
        instagramResumeSlideByPost.clear();
        instagramNetworkVideoCandidates.clear();
        instagramTerminalCandidateByPost.clear();
        instagramTerminalConfirmCountByPost.clear();
        instagramPostsWithCapturedVideo.clear();
        instagramConsumedNetworkVideoCandidates.clear();
        instagramSlideStartedAtByPost.clear();
        pendingSimpleGateSourceUrl = "";
        xMediaFallbackTried = false;
        rootXUser = "";
        snsReadyProbeSerial++;
        instagramPostUrlsSeen.clear();
        instagramPostOrder.clear();
        instagramMediaOrderByPost.clear();
        instagramNextPostOrder = 0;
        instagramStreamingDeferredRetryQueue.clear();
        instagramStreamingDeferredRetrySet.clear();
        instagramStreamingDeferredRetryPhase = false;
        instagramCompletedPostUrls.clear();
        instagramSkippedPostUrls.clear();
        instagramContinuationDiscoveredUrls.clear();
        instagramContinuationPendingUrls.clear();
        incompleteReasons.clear();
        instagramPostDetailsQueued = 0;
        instagramUnknownHostProbeFailures = 0;
        instagramLastNetworkMediaAt = 0L;
        instagramCompletionCandidateAt = 0L;
        instagramCompletionWaitScheduled = false;
        activeInstagramLastMeaningfulProgressAt = 0L;
        instagramNetworkImagesBlocked = false;
        instagramImageFallbackPost = "";
        pendingImageProbes = 0;
        traversalDone = false;
        baseTraversalDone = false;
        detailPhaseStarted = false;
        detailTraversalDone = false;
        provisionalPhaseStarted = false;
        doneEmitted = false;
        detailPhaseStartedAt = 0L;
        pageCount = detailCount = imageCount = videoCount = streamCount = 0;
        pageTitle = "ImgStalker";
        if (!continuationSeedMediaKeys.isEmpty() || !continuationSeedImageKeys.isEmpty()
                || !continuationSeedDetailUrls.isEmpty()
                || !continuationSeedInstagramDiscoveredUrls.isEmpty()) {
            mediaSeen.addAll(continuationSeedMediaKeys);
            imageCandidateSeen.addAll(continuationSeedImageKeys);
            queuedOrVisited.addAll(continuationSeedDetailUrls);
            instagramCompletedPostUrls.addAll(continuationSeedInstagramCompletedUrls);
            instagramContinuationDiscoveredUrls.addAll(continuationSeedInstagramDiscoveredUrls);
            for (String restored : instagramContinuationDiscoveredUrls) {
                if (!instagramCompletedPostUrls.contains(restored)) instagramContinuationPendingUrls.add(restored);
            }
            // Count restored completed posts toward the per-profile cap. A reload continues the
            // same analysis session; it must not silently get a new 300-post allowance.
            instagramPostDetailsQueued = Math.min(INSTAGRAM_DETAIL_LIMIT, instagramCompletedPostUrls.size());
            DiagnosticLog.log("CRAWLER_CONTINUE_SEED_APPLY media=" + continuationSeedMediaKeys.size()
                    + " imageKeys=" + continuationSeedImageKeys.size()
                    + " details=" + continuationSeedDetailUrls.size()
                    + " igCompleted=" + instagramCompletedPostUrls.size()
                    + " igDiscovered=" + instagramContinuationDiscoveredUrls.size()
                    + " igPending=" + instagramContinuationPendingUrls.size());
            continuationSeedMediaKeys.clear();
            continuationSeedImageKeys.clear();
            continuationSeedDetailUrls.clear();
            continuationSeedInstagramCompletedUrls.clear();
            continuationSeedInstagramDiscoveredUrls.clear();
        }
        this.followPagination = followPagination;
        this.followDetails = followDetails;
        this.wantImages = wantImages;
        instagramManualTapWaiting = false;
        instagramManualTapTargetUrl = "";
        instagramSpaAwaitingOpen = false;
        instagramSpaReturningToProfile = false;
        instagramSpaTargetUrl = "";
        instagramSpaTapAttempts = 0;
        instagramStreamingMode = false;
        instagramStreamingProfileUrl = "";
        instagramStreamingPass = 0;
        instagramStreamingStall = 0;
        instagramStreamingPreviousHeight = 0;
        instagramStreamingResumeScrollY = 0;
        instagramProfilePostCount = 0;
        instagramStreamingTargetPosts = 0;
        this.wantVideos = wantVideos;
        this.targetImagePx = Math.max(64, Math.min(8192, targetImagePx));
        DiagnosticLog.log("CRAWLER_START generation=" + generation + " url=" + startUrl
                + " pagination=" + followPagination
                + " details=" + followDetails
                + " images=" + wantImages
                + " videos=" + wantVideos
                + " xReposts=" + includeXReposts
                + " targetImagePx=" + this.targetImagePx);

        String normalized = normalizeInputUrl(startUrl);
        String canonicalEntry = canonicalizeSnsEntryUrl(normalized);
        if (!canonicalEntry.equals(normalized)) {
            DiagnosticLog.log("SNS_URL_CANONICALIZE from=" + normalized + " to=" + canonicalEntry);
            normalized = canonicalEntry;
        }
        crawlerRootUrl = normalized;
        try {
            rootHost = new URI(normalized).getHost();
            if (rootHost == null) rootHost = "";
        } catch (Exception e) {
            DiagnosticLog.logException("CRAWLER_BAD_URL " + normalized, e);
            listener.onError("URLを確認してください");
            return;
        }
        maxDetails = isInstagramLikeHost(rootHost) ? INSTAGRAM_DETAIL_LIMIT : 120;
        if (isInstagramLikeHost(rootHost)) {
            setInstagramNetworkImagesBlocked(false, "analysis_start_profile");
        } else {
            try {
                WebSettings settings = webView.getSettings();
                settings.setLoadsImagesAutomatically(true);
                settings.setBlockNetworkImage(false);
            } catch (Throwable ignored) {}
        }
        if (INSTAGRAM_STREAMING_PROFILE && isInstagramLikeHost(rootHost)) {
            instagramStreamingMode = true;
            instagramStreamingProfileUrl = normalized;
            DiagnosticLog.log("SNS_IG_PIPELINE_MODE discovery=profile resolver=page_fetch fallback=browser profile=" + normalized);
        }
        if (isXLikeHost(rootHost)) {
            rootXUser = xUserFromProfileUrl(normalized);
            DiagnosticLog.log("SNS_X_ROOT_USER user=" + (rootXUser.isEmpty() ? "unknown" : rootXUser)
                    + " reposts=" + includeXReposts);
        }
        if (isSnsLikeHost(rootHost)) configureSnsBrowserUserAgent();
        enqueue(new Node(normalized, 0, false));
        loadNext();
    }

    public void cancel() {
        generation++;
        if (!cancelled) DiagnosticLog.log("CRAWLER_CANCEL generation=" + generation);
        cancelled = true;
        current = null;
        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = "";
        activeStartedUrl = "";
        try { webView.stopLoading(); } catch (Exception ignored) {}
        instagramMediaResolver.cancel();
        instagramStreamingResolverInFlight = false;
        gracefulStopRequested = false;
        handler.removeCallbacksAndMessages(null);
    }

    public void requestGracefulStop() {
        if (cancelled || doneEmitted || gracefulStopRequested) return;
        gracefulStopRequested = true;
        markIncomplete("user_stop");
        DiagnosticLog.log("CRAWLER_SAFE_STOP_REQUEST current="
                + (current == null ? "none" : current.url)
                + " detail=" + (current != null && current.detail)
                + " resolverInFlight=" + instagramStreamingResolverInFlight
                + " pendingImageProbes=" + pendingImageProbes
                + " queue=" + queue.size());
        listener.onProgressPulse("SAFE_STOP_REQUEST");
        listener.onStatus("停止処理中…受信済みデータを確定しています");
        handler.post(this::tryFinishGracefulStopIfIdle);
    }

    private void tryFinishGracefulStopIfIdle() {
        if (!gracefulStopRequested || cancelled || doneEmitted) return;
        if (instagramStreamingResolverInFlight) return;
        if (current != null && current.detail) return;
        finishGracefulStopNow("idle_boundary");
    }

    private void finishGracefulStopNow(String reason) {
        if (!gracefulStopRequested || cancelled || doneEmitted) return;
        DiagnosticLog.log("CRAWLER_SAFE_STOP_DRAIN reason=" + reason
                + " pendingImageProbes=" + pendingImageProbes
                + " media=" + (imageCount + videoCount + streamCount));
        listener.onProgressPulse("SAFE_STOP_DRAIN");
        listener.onStatus("停止処理中…受信済みデータを確定しています");
        queue.clear();
        current = null;
        baseTraversalDone = true;
        detailPhaseStarted = true;
        detailTraversalDone = true;
        traversalDone = true;
        maybeFinishAfterImageProbes();
    }

    private boolean isActive(long run, long load, long nav, Node node) {
        return !cancelled
                && generation == run
                && activeStartedGeneration == run
                && activeLoadSequence == load
                && activeNavigationSequence == nav
                && activeLoadStarted
                && current == node;
    }

    private void inspectSimpleGateThenContinue(long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        String liveUrl = webView.getUrl();
        if (!sameNavigationUrl(liveUrl, activeStartedUrl)) {
            DiagnosticLog.log("PASS_GATE_SKIP reason=live_url_mismatch generation=" + run
                    + " load=" + load + " nav=" + nav
                    + " started=" + activeStartedUrl + " live=" + liveUrl);
            return;
        }

        final String gateUrl = stripFragment(liveUrl == null ? node.url : liveUrl);
        final boolean allowClick = !simpleGateAttemptedUrls.contains(gateUrl);
        webView.evaluateJavascript(buildSimpleGateScript(allowClick), raw -> {
            if (!isActive(run, load, nav, node)) return;

            boolean continueNormally = true;
            try {
                JSONObject gate = new JSONObject(unquoteJsResult(raw));
                boolean found = gate.optBoolean("found", false);
                boolean clicked = gate.optBoolean("clicked", false);
                String accept = gate.optString("accept", "").trim();
                String reject = gate.optString("reject", "").trim();

                if (found) {
                    DiagnosticLog.log("PASS_GATE_FOUND type=simple_confirmation url=" + gateUrl
                            + " accept=" + accept + " reject=" + reject);
                    if (clicked) {
                        simpleGateAttemptedUrls.add(gateUrl);
                        pendingSimpleGateSourceUrl = gateUrl;
                        DiagnosticLog.log("PASS_GATE_ACCEPT text=" + accept + " url=" + gateUrl);
                        continueNormally = false;

                        // If the gate changes only the DOM and does not navigate, inspect it once
                        // more after the click. If it navigates, the old nav sequence goes stale
                        // and the new onPageFinished path takes over automatically.
                        handler.postDelayed(() -> {
                            if (isActive(run, load, nav, node)) {
                                inspectSimpleGateThenContinue(run, load, nav, node);
                            }
                        }, 900);
                    } else if (!allowClick) {
                        DiagnosticLog.log("PASS_GATE_FAILED reason=already_attempted_still_present url=" + gateUrl);
                    } else {
                        DiagnosticLog.log("PASS_GATE_FAILED reason=no_clickable_accept url=" + gateUrl);
                    }
                } else if (!pendingSimpleGateSourceUrl.isEmpty()) {
                    DiagnosticLog.log("PASS_GATE_RESOLVED source=" + pendingSimpleGateSourceUrl
                            + " url=" + gateUrl);
                    pendingSimpleGateSourceUrl = "";
                }
            } catch (Exception e) {
                DiagnosticLog.logException("PASS_GATE_PARSE_FAIL url=" + gateUrl, e);
            }

            if (continueNormally && isActive(run, load, nav, node)) {
                if (!node.detail && isSnsLikeHost(rootHost)) {
                    beginSnsReadinessProbe(run, load, nav, node);
                } else {
                    autoScroll(0, run, load, nav, node);
                }
            }
        });
    }

    private void beginSnsReadinessProbe(long run, long load, long nav, Node node) {
        final int serial = ++snsReadyProbeSerial;
        probeSnsReadiness(1, serial, run, load, nav, node);
    }

    private void probeSnsReadiness(int pass, int serial, long run, long load, long nav, Node node) {
        if (serial != snsReadyProbeSerial || !isActive(run, load, nav, node)) return;
        final boolean xMode = isXLikeHost(rootHost);
        final boolean igMode = isInstagramLikeHost(rootHost);
        String js = "(function(){try{" +
                "var articles=document.querySelectorAll('article').length;" +
                "var tweets=document.querySelectorAll('[data-testid=\\\"tweet\\\"]').length;" +
                "var status=0,posts=0,media=0,postUrls=[];" +
                "document.querySelectorAll('a[href]').forEach(function(a){var h=a.href||'';if(/\\/status\\/\\d+/.test(h))status++;if(/\\/(p|reel|tv)\\/[^/?#]+/i.test(h)){try{var u=new URL(h,document.baseURI);var m=u.pathname.match(/\\/(p|reel|tv)\\/([^/?#]+)/i);if(m){posts++;postUrls.push('https://www.instagram.com/'+m[1].toLowerCase()+'/'+m[2]+'/')}}catch(e){}}});" +
                "document.querySelectorAll('img').forEach(function(i){var u=i.currentSrc||i.src||'';if(/pbs\\.twimg\\.com\\/media\\//i.test(u)||/(cdninstagram\\.com|fbcdn\\.net)/i.test(u))media++;});" +
                "var de=document.documentElement,b=document.body;var h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0);" +
                "return JSON.stringify({ready:document.readyState||'',articles:articles,tweets:tweets,status:status,posts:posts,postUrls:Array.from(new Set(postUrls)),media:media,h:h,vh:window.innerHeight||0,body:(document.body&&document.body.innerText?document.body.innerText.length:0)});" +
                "}catch(e){return JSON.stringify({error:String(e)})}})()";
        webView.evaluateJavascript(js, raw -> {
            if (serial != snsReadyProbeSerial || !isActive(run, load, nav, node)) return;
            int articles=0,tweets=0,status=0,posts=0,media=0,h=0,vh=0,body=0;
            String ready="";
            try {
                JSONObject o = new JSONObject(unquoteJsResult(raw));
                articles=o.optInt("articles",0); tweets=o.optInt("tweets",0); status=o.optInt("status",0);
                posts=o.optInt("posts",0); media=o.optInt("media",0); h=o.optInt("h",0); vh=o.optInt("vh",0);
                body=o.optInt("body",0); ready=o.optString("ready","");
                if (igMode && o.optJSONArray("postUrls") != null) {
                    JSONArray readyPosts = o.optJSONArray("postUrls");
                    for (int i = 0; i < readyPosts.length(); i++) {
                        rememberInstagramPost(readyPosts.optString(i, ""));
                    }
                }
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_DOM_PROBE_PARSE_FAIL service=" + snsServiceName(), e);
            }
            DiagnosticLog.log("SNS_DOM_PROBE service=" + snsServiceName()
                    + " pass=" + pass + " ready=" + ready
                    + " articles=" + articles + " tweets=" + tweets + " statusLinks=" + status
                    + " postLinks=" + posts + " media=" + media + " h=" + h + " vh=" + vh + " bodyChars=" + body);
            // X can start as soon as its timeline shell/media materializes. Instagram is
            // different: profile chrome, story rings and preview images appear before the
            // actual post grid. Treating generic media as readiness caused v0.1.38 to finish
            // with zero posts. For Instagram, require at least one canonical post/reel/tv link.
            boolean materialized = xMode ? (articles > 0 || tweets > 0 || status > 0 || media > 0)
                    : igMode ? (posts > 0) : true;
            if (materialized) {
                DiagnosticLog.log("SNS_DOM_READY service=" + snsServiceName() + " pass=" + pass);
                if (INSTAGRAM_MANUAL_TAP_DIAG && igMode && !node.detail) {
                    instagramManualTapWaiting = true;
                    instagramManualTapTargetUrl = "";
                    DiagnosticLog.log("SNS_IG_MANUAL_TAP_READY pass=" + pass
                            + " postLinks=" + posts
                            + " current=" + stripFragment(webView.getUrl()));
                    listener.onProgressPulse("SNS_IG_MANUAL_TAP_READY");
                    listener.onStatus("Instagram診断：表示された投稿を1件タップしてください");
                    listener.onInstagramManualTapReady();
                    return;
                }
                if (igMode && instagramStreamingMode && !node.detail) {
                    DiagnosticLog.log("SNS_IG_STREAM_READY pass=" + pass + " postLinks=" + posts);
                    listener.onProgressPulse("SNS_IG_STREAM_READY");
                    listener.onStatus("Instagram投稿数を確認中…");
                    // v0.1.69: normal Instagram analysis stays headless. The floating browser
                    // was useful while diagnosing navigation, but continuously compositing a full
                    // WebView adds GPU/memory pressure during long profile sweeps. Progress is
                    // surfaced through the normal status text instead.
                    startInstagramProfileStream(run, load, nav, node);
                    return;
                }
                autoScrollSns(0, 0, 0, run, load, nav, node);
                return;
            }
            int maxPasses = igMode ? INSTAGRAM_READY_MAX_PASSES : 5;
            if (pass < maxPasses) {
                long delay;
                if (igMode) {
                    delay = pass <= 2 ? 900L : pass <= 4 ? 1400L : 1900L;
                    DiagnosticLog.log("SNS_IG_READY_WAIT pass=" + pass + " postLinks=0 media=" + media
                            + " h=" + h + " bodyChars=" + body + " nextDelayMs=" + delay);
                } else {
                    delay = pass == 1 ? 900L : pass == 2 ? 1400L : pass == 3 ? 2100L : 3000L;
                }
                handler.postDelayed(() -> probeSnsReadiness(pass + 1, serial, run, load, nav, node), delay);
                return;
            }
            if (igMode) {
                DiagnosticLog.log("SNS_IG_READY_EXHAUSTED passes=" + pass
                        + " postLinks=0 action=scroll_and_keep_waiting");
            }
            if (xMode && !xMediaFallbackTried) {
                String fallback = xMediaFallbackUrl(node.url);
                if (!fallback.isEmpty() && !sameNavigationUrl(fallback, node.url)) {
                    xMediaFallbackTried = true;
                    DiagnosticLog.log("SNS_X_MEDIA_FALLBACK from=" + node.url + " to=" + fallback);
                    replaceCurrentLoad(fallback, "x_media_fallback");
                    return;
                }
            }
            DiagnosticLog.log("SNS_DOM_EMPTY service=" + snsServiceName() + " action=collect_shell");
            autoScrollSns(0, 0, 0, run, load, nav, node);
        });
    }

    private String xMediaFallbackUrl(String url) {
        try {
            URI u = new URI(stripFragment(url));
            String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            if (!isXLikeHost(host)) return "";
            String p = u.getPath() == null ? "/" : u.getPath();
            String[] parts = p.split("/");
            String user = "";
            for (String part : parts) { if (!part.isEmpty()) { user = part; break; } }
            if (user.isEmpty() || user.equalsIgnoreCase("home") || user.equalsIgnoreCase("i")
                    || user.equalsIgnoreCase("settings") || user.equalsIgnoreCase("search")) return "";
            if (p.matches("^/[^/]+/media/?$")) return "";
            if (p.contains("/status/")) return "";
            return "https://x.com/" + user + "/media";
        } catch (Exception e) {
            return "";
        }
    }

    private void replaceCurrentLoad(String url, String reason) {
        if (cancelled || current == null) return;
        Node old = current;
        current = new Node(url, old.depth, old.detail);
        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = stripFragment(url);
        activeStartedUrl = "";
        DiagnosticLog.log("SNS_RELOAD reason=" + reason + " load=" + activeLoadSequence + " url=" + url);
        listener.onProgressPulse("SNS_RELOAD");
        webView.loadUrl(url);
    }

    private void autoScroll(int pass, long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        if (!node.detail && isSnsLikeHost(rootHost)) {
            autoScrollSns(0, 0, 0, run, load, nav, node);
            return;
        }
        if (pass >= 3) {
            collectDom(run, load, nav, node);
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{window.scrollTo(0,document.body.scrollHeight);return String(document.body.scrollHeight)}catch(e){return '0'}})()",
                value -> {
                    if (!isActive(run, load, nav, node)) return;
                    handler.postDelayed(() -> autoScroll(pass + 1, run, load, nav, node), 350);
                });
    }

    private void autoScrollSns(int pass, int stalledAtBottom, int previousHeight, long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        int snsStallLimit = isXLikeHost(rootHost) ? 5 : SNS_SCROLL_STALL_LIMIT;
        int snsMaxPasses = isInstagramLikeHost(rootHost) ? INSTAGRAM_SCROLL_MAX_PASSES : SNS_SCROLL_MAX_PASSES;
        if (pass >= snsMaxPasses || stalledAtBottom >= snsStallLimit) {
            DiagnosticLog.log("SNS_SCROLL_DONE service=" + snsServiceName()
                    + " pass=" + pass + " stalled=" + stalledAtBottom
                    + " images=" + imageCandidateSeen.size() + " media=" + mediaSeen.size());
            collectDom(run, load, nav, node);
            return;
        }

        final int before = imageCandidateSeen.size() + mediaSeen.size();
        webView.evaluateJavascript(buildSnsHarvestScript(isXLikeHost(rootHost), isInstagramLikeHost(rootHost)), raw -> {
            if (!isActive(run, load, nav, node)) return;
            int postLinks = 0;
            try {
                JSONObject obj = new JSONObject(unquoteJsResult(raw));
                String title = obj.optString("title", "").trim();
                if (!title.isEmpty() && pageCount == 0 && detailCount == 0) pageTitle = title;
                // Instagram profile grids are only discovery surfaces. Do not treat their
                // thumbnails / preview videos as final media; queue the post URLs and collect
                // the actual media from each post detail instead.
                if (!isInstagramLikeHost(rootHost)) {
                    processMediaArray(obj.optJSONArray("images"), MediaItem.Kind.IMAGE, webView.getUrl(), false);
                    processMediaArray(obj.optJSONArray("videos"), MediaItem.Kind.VIDEO, webView.getUrl(), false);
                    processMediaArray(obj.optJSONArray("streams"), MediaItem.Kind.STREAM, webView.getUrl(), false);
                }
                if (isXLikeHost(rootHost)) {
                    postLinks = processXStatusLinks(obj.optJSONArray("statusLinks"), node);
                } else if (isInstagramLikeHost(rootHost)) {
                    postLinks = processInstagramPostLinks(obj.optJSONArray("postLinks"), node);
                }
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_HARVEST_PARSE_FAIL service=" + snsServiceName(), e);
            }

            if (!isActive(run, load, nav, node)) return;
            final int added = Math.max(0, imageCandidateSeen.size() + mediaSeen.size() - before);
            final int queuedPosts = postLinks;
            String scrollScript = "(function(){try{" +
                    "var de=document.documentElement,b=document.body;" +
                    "var h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0);" +
                    "var vh=Math.max(window.innerHeight||0,de?de.clientHeight:0);" +
                    "var step=Math.max(560,Math.floor(vh*0.82));" +
                    "window.scrollBy(0,step);" +
                    "var y=window.scrollY||window.pageYOffset||0;" +
                    "return JSON.stringify({y:y,h:h,vh:vh,bottom:(y+vh>=h-96)});" +
                    "}catch(e){return JSON.stringify({y:0,h:0,vh:0,bottom:false})}})()";
            webView.evaluateJavascript(scrollScript, scrollRaw -> {
                if (!isActive(run, load, nav, node)) return;
                boolean bottom = false;
                int y = 0, h = 0, vh = 0;
                try {
                    JSONObject m = new JSONObject(unquoteJsResult(scrollRaw));
                    bottom = m.optBoolean("bottom", false);
                    y = m.optInt("y", 0);
                    h = m.optInt("h", 0);
                    vh = m.optInt("vh", 0);
                } catch (Exception ignored) {}
                boolean heightGrew = h > previousHeight + 24;
                // Dynamic SNS pages often report bottom=true while React is still appending
                // rows. Height growth is real progress and must reset the stall counter.
                int nextStall = (bottom && added == 0 && queuedPosts == 0 && !heightGrew)
                        ? stalledAtBottom + 1 : 0;
                DiagnosticLog.log("SNS_SCROLL service=" + snsServiceName()
                        + " pass=" + (pass + 1)
                        + " added=" + added
                        + " postLinks=" + queuedPosts
                        + " y=" + y + " h=" + h + " vh=" + vh
                        + " heightGrew=" + heightGrew
                        + " bottom=" + bottom + " stall=" + nextStall);
                listener.onProgressPulse("SNS_SCROLL");
                final int nextHeight = Math.max(previousHeight, h);
                handler.postDelayed(() -> autoScrollSns(pass + 1, nextStall, nextHeight, run, load, nav, node), SNS_SCROLL_DELAY_MS);
            });
        });
    }

    private void startInstagramProfileStream(long run, long load, long nav, Node node) {
        if (!instagramStreamingMode || !isActive(run, load, nav, node) || node.detail) return;
        detailPhaseStarted = true;
        detailPhaseStartedAt = System.currentTimeMillis();
        instagramStreamingPass = 0;
        instagramStreamingStall = 0;
        instagramStreamingPreviousHeight = 0;
        instagramStreamingResumeScrollY = 0;
        instagramProfilePostCount = 0;
        instagramStreamingTargetPosts = 0;

        // The readiness probe only proves that the profile grid exists. Reset its provisional
        // ordering so the actual visible-grid scan below becomes the authoritative top-to-bottom
        // order used by both acquisition and UI cell ordering.
        instagramPostUrlsSeen.clear();
        instagramPostOrder.clear();
        instagramMediaOrderByPost.clear();
        instagramNextPostOrder = 0;
        for (String seeded : instagramContinuationDiscoveredUrls) {
            String canonical = canonicalInstagramPostUrl(seeded);
            if (canonical.isEmpty()) continue;
            instagramPostUrlsSeen.add(canonical);
            instagramPostOrder.put(canonical, instagramNextPostOrder++);
        }
        if (!instagramContinuationDiscoveredUrls.isEmpty() || !instagramCompletedPostUrls.isEmpty()) {
            DiagnosticLog.log("SNS_IG_SESSION_QUEUE_RESTORE discovered="
                    + instagramContinuationDiscoveredUrls.size()
                    + " completed=" + instagramCompletedPostUrls.size()
                    + " pending=" + instagramContinuationPendingUrls.size()
                    + " queuedCount=" + instagramPostDetailsQueued);
        }

        // v0.1.69: keep the profile grid fully rendered. Hiding network images here prevents
        // Instagram's virtualized/lazy grid from materializing additional rows on some WebView
        // builds and was the main cause of the v0.1.68 "12 posts only" regression.
        setInstagramNetworkImagesBlocked(false, "profile_stream_start");
        DiagnosticLog.log("SNS_IG_STREAM_START profile=" + stripFragment(node.url)
                + " limit=" + INSTAGRAM_DETAIL_LIMIT + " mode=discover_resolve images=enabled");

        webView.evaluateJavascript(buildInstagramProfilePostCountScript(), raw -> {
            if (!instagramStreamingMode || !isActive(run, load, nav, node) || node.detail) return;
            int count = 0;
            String source = "none";
            try {
                JSONObject obj = new JSONObject(unquoteJsResult(raw));
                count = Math.max(0, obj.optInt("count", 0));
                source = obj.optString("source", "none");
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_IG_PROFILE_POST_COUNT_PARSE_FAIL", e);
            }
            instagramProfilePostCount = count;
            instagramStreamingTargetPosts = count > 0 ? Math.min(count, INSTAGRAM_DETAIL_LIMIT) : 0;
            if (count > INSTAGRAM_DETAIL_LIMIT) markIncomplete("instagram_post_limit");
            DiagnosticLog.log("SNS_IG_PROFILE_POST_COUNT count=" + count
                    + " target=" + instagramStreamingTargetPosts
                    + " source=" + source
                    + " mode=discover_resolve");
            listener.onProgressPulse("SNS_IG_PROFILE_POST_COUNT");
            reportInstagramDiscoveryProgress();
            if (!instagramContinuationPendingUrls.isEmpty()) {
                DiagnosticLog.log("SNS_IG_CONTINUE_PENDING_START count=" + instagramContinuationPendingUrls.size());
                listener.onProgressPulse("SNS_IG_CONTINUE_PENDING_START");
                listener.onStatus("前回未取得の投稿を優先回収中… " + instagramContinuationPendingUrls.size() + "件");
                processNextInstagramContinuationPending(node, load);
            } else {
                scanInstagramProfileStream(run, load, nav, node);
            }
        });
    }

    private void reportInstagramDiscoveryProgress() {
        int done = Math.max(detailCount, instagramCompletedPostUrls.size());
        int total = instagramStreamingTargetPosts > 0 ? instagramStreamingTargetPosts : instagramProfilePostCount;
        if (total > 0) {
            listener.onStatus("投稿を取得中（" + Math.min(done, total) + "/" + total + "）");
        } else {
            listener.onStatus("Instagram投稿を上から順に解析中… " + done + "件");
        }
    }

    private void processNextInstagramContinuationPending(Node profileNode, long profileLoad) {
        if (gracefulStopRequested) {
            finishGracefulStopNow("instagram_continuation_boundary");
            return;
        }
        if (cancelled || !instagramStreamingMode || profileNode == null
                || current != profileNode || activeLoadSequence != profileLoad) return;
        while (!instagramContinuationPendingUrls.isEmpty()) {
            String target = instagramContinuationPendingUrls.iterator().next();
            if (target == null || target.isEmpty()
                    || instagramCompletedPostUrls.contains(target)
                    || instagramSkippedPostUrls.contains(target)) {
                instagramContinuationPendingUrls.remove(target);
                continue;
            }
            DiagnosticLog.log("SNS_IG_CONTINUE_PENDING_PICK remaining="
                    + instagramContinuationPendingUrls.size() + " url=" + target);
            listener.onProgressPulse("SNS_IG_CONTINUE_PENDING_PICK");
            listener.onStatus("前回未取得の投稿を再解析  " + target);
            resolveInstagramStreamingPost(target, profileNode, profileLoad);
            return;
        }
        DiagnosticLog.log("SNS_IG_CONTINUE_PENDING_DONE action=resume_discovery");
        listener.onProgressPulse("SNS_IG_CONTINUE_PENDING_DONE");
        scanInstagramProfileStream(generation, profileLoad, activeNavigationSequence, profileNode);
    }

    private boolean instagramDiscoveryStillBelowTarget() {
        int target = instagramStreamingTargetPosts > 0
                ? instagramStreamingTargetPosts
                : (instagramProfilePostCount > 0 ? Math.min(instagramProfilePostCount, INSTAGRAM_DETAIL_LIMIT) : 0);
        return target > 0
                && instagramPostUrlsSeen.size() < target
                && instagramPostDetailsQueued < INSTAGRAM_DETAIL_LIMIT;
    }

    private void reloadInstagramProfileDiscovery(Node node, String reason) {
        if (gracefulStopRequested) {
            finishGracefulStopNow("instagram_discovery_reload_boundary");
            return;
        }
        if (cancelled || !instagramStreamingMode || node == null || node.detail) return;
        instagramContinuationDiscoveredUrls.addAll(instagramPostUrlsSeen);
        instagramStreamingPass = 0;
        instagramStreamingStall = 0;
        instagramStreamingPreviousHeight = 0;
        instagramStreamingResumeScrollY = 0;
        DiagnosticLog.log("SNS_IG_DISCOVERY_RELOAD reason=" + reason
                + " seen=" + instagramPostUrlsSeen.size()
                + " completed=" + instagramCompletedPostUrls.size()
                + " queued=" + instagramPostDetailsQueued
                + " target=" + instagramStreamingTargetPosts);
        listener.onProgressPulse("SNS_IG_DISCOVERY_RELOAD");
        listener.onStatus("Instagram追加投稿を再読込中… "
                + instagramPostUrlsSeen.size() + "/" + instagramStreamingTargetPosts);
        replaceCurrentLoad(instagramStreamingProfileUrl, "instagram_discovery_" + reason);
    }

    private void scanInstagramProfileStream(long run, long load, long nav, Node node) {
        if (gracefulStopRequested) {
            finishGracefulStopNow("instagram_scan_boundary");
            return;
        }
        if (!instagramStreamingMode || !isActive(run, load, nav, node) || node.detail) return;
        if (instagramStreamingPass >= INSTAGRAM_SCROLL_MAX_PASSES
                || instagramStreamingStall >= SNS_SCROLL_STALL_LIMIT) {
            String stallReason = instagramStreamingPass >= INSTAGRAM_SCROLL_MAX_PASSES ? "pass_limit" : "bottom_stall";
            if (instagramDiscoveryStillBelowTarget()) {
                reloadInstagramProfileDiscovery(node, stallReason);
            } else {
                finishInstagramProfileStream(node, stallReason);
            }
            return;
        }
        if (instagramPostDetailsQueued >= INSTAGRAM_DETAIL_LIMIT) {
            markIncomplete("instagram_post_limit");
            finishInstagramProfileStream(node, "post_limit");
            return;
        }

        webView.evaluateJavascript(buildInstagramVisiblePostCellsScript(), raw -> {
            if (!instagramStreamingMode || !isActive(run, load, nav, node) || node.detail) return;
            String candidate = "";
            boolean candidateFromPreviousSession = false;
            int visibleCells = 0;
            int y = 0, h = 0, vh = 0;
            boolean bottom = false;
            try {
                JSONObject obj = new JSONObject(unquoteJsResult(raw));
                JSONArray cells = obj.optJSONArray("cells");
                visibleCells = cells == null ? 0 : cells.length();
                y = obj.optInt("y", 0);
                h = obj.optInt("h", 0);
                vh = obj.optInt("vh", 0);
                bottom = obj.optBoolean("bottom", false);
                if (cells != null) {
                    for (int i = 0; i < cells.length(); i++) {
                        JSONObject cell = cells.optJSONObject(i);
                        if (cell == null) continue;
                        String u = rememberInstagramPost(cell.optString("url", ""));
                        if (u.isEmpty()) continue;
                        String key = stripFragment(u);
                        if (queuedOrVisited.contains(key)
                                || instagramCompletedPostUrls.contains(u)
                                || instagramSkippedPostUrls.contains(u)) continue;
                        if (candidate.isEmpty()) {
                            candidate = u;
                            candidateFromPreviousSession = instagramContinuationDiscoveredUrls.contains(u);
                        } else if (!candidateFromPreviousSession
                                && instagramContinuationDiscoveredUrls.contains(u)) {
                            // Prefer a previously discovered-but-unfinished URL when it becomes visible.
                            candidate = u;
                            candidateFromPreviousSession = true;
                        }
                    }
                }
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_IG_STREAM_SCAN_PARSE_FAIL", e);
            }

            if (!candidate.isEmpty()) {
                instagramStreamingResumeScrollY = Math.max(0, y);
                DiagnosticLog.log("SNS_IG_STREAM_PICK pass=" + instagramStreamingPass
                        + " visible=" + visibleCells
                        + " seen=" + instagramPostUrlsSeen.size()
                        + " processed=" + detailCount
                        + " restored=" + candidateFromPreviousSession
                        + " y=" + y + " h=" + h + " vh=" + vh
                        + " url=" + candidate);
                listener.onProgressPulse("SNS_IG_STREAM_PICK");
                reportInstagramDiscoveryProgress();
                instagramStreamingStall = 0;
                resolveInstagramStreamingPost(candidate, node, load);
                return;
            }

            final int scannedVisibleCells = visibleCells;
            final int beforeHeight = Math.max(instagramStreamingPreviousHeight, h);
            final int currentY = y;
            final int currentH = h;
            final int currentVh = vh;
            final boolean currentBottom = bottom;
            String scrollScript = "(function(){try{"
                    + "var de=document.documentElement,b=document.body;"
                    + "var sh=(window.screen&&window.screen.height)||0;"
                    + "var vv=(window.visualViewport&&window.visualViewport.height)||0;"
                    + "var h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0);"
                    + "var vh=Math.max(window.innerHeight||0,de?de.clientHeight:0,vv,sh);"
                    + "var step=Math.max(420,Math.floor(vh*0.68));"
                    + "window.scrollBy(0,step);"
                    + "var y=window.scrollY||window.pageYOffset||0;"
                    + "var nh=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0);"
                    + "return JSON.stringify({y:y,h:nh,vh:vh,bottom:(y+vh>=nh-96)});"
                    + "}catch(e){return JSON.stringify({y:0,h:0,vh:0,bottom:false,error:String(e)})}})()";
            webView.evaluateJavascript(scrollScript, scrollRaw -> {
                if (!instagramStreamingMode || !isActive(run, load, nav, node) || node.detail) return;
                int ny = currentY, nh = currentH, nvh = currentVh;
                boolean nbottom = currentBottom;
                try {
                    JSONObject m = new JSONObject(unquoteJsResult(scrollRaw));
                    ny = m.optInt("y", currentY);
                    nh = m.optInt("h", currentH);
                    nvh = m.optInt("vh", currentVh);
                    nbottom = m.optBoolean("bottom", currentBottom);
                } catch (Exception ignored) {}
                boolean heightGrew = nh > beforeHeight + 24;
                instagramStreamingStall = (nbottom && !heightGrew)
                        ? instagramStreamingStall + 1 : 0;
                instagramStreamingPreviousHeight = Math.max(beforeHeight, nh);
                instagramStreamingPass++;
                DiagnosticLog.log("SNS_IG_STREAM_SCROLL pass=" + instagramStreamingPass
                        + " visible=" + scannedVisibleCells
                        + " seen=" + instagramPostUrlsSeen.size()
                        + " processed=" + detailCount
                        + " y=" + ny + " h=" + nh + " vh=" + nvh
                        + " heightGrew=" + heightGrew
                        + " bottom=" + nbottom
                        + " stall=" + instagramStreamingStall);
                listener.onProgressPulse("SNS_IG_STREAM_SCROLL");
                reportInstagramDiscoveryProgress();
                handler.postDelayed(() -> scanInstagramProfileStream(run, load, nav, node),
                        INSTAGRAM_STREAM_SCROLL_DELAY_MS);
            });
        });
    }




    private void resolveInstagramStreamingPost(String rawTarget, Node profileNode, long profileLoad) {
        if (cancelled || !instagramStreamingMode || current != profileNode
                || activeLoadSequence != profileLoad) return;
        final String target = rememberInstagramPost(rawTarget);
        if (target.isEmpty()) {
            handler.postDelayed(() -> scanInstagramProfileStream(generation, profileLoad,
                    activeNavigationSequence, profileNode), INSTAGRAM_STREAM_SCAN_DELAY_MS);
            return;
        }
        final String key = stripFragment(target);
        if (!queuedOrVisited.add(key)) {
            handler.postDelayed(() -> scanInstagramProfileStream(generation, profileLoad,
                    activeNavigationSequence, profileNode), INSTAGRAM_STREAM_SCAN_DELAY_MS);
            return;
        }
        instagramPostDetailsQueued++;
        instagramPostUrlsSeen.add(target);
        final long run = generation;
        final long nav = activeNavigationSequence;
        DiagnosticLog.log("SNS_IG_RESOLVER_START index=" + instagramPostDetailsQueued
                + " url=" + target + " live=" + stripFragment(webView.getUrl()));
        listener.onProgressPulse("SNS_IG_RESOLVER_START");
        listener.onStatus("Instagram投稿を解析中（画面遷移なし）… " + target);

        instagramStreamingResolverInFlight = true;
        instagramMediaResolver.resolve(target, result -> {
            instagramStreamingResolverInFlight = false;
            if (cancelled || generation != run || !instagramStreamingMode
                    || current != profileNode || activeLoadSequence != profileLoad
                    || activeNavigationSequence != nav) return;

            int beforeImages = imageCount;
            int beforeVideos = videoCount;
            int beforeStreams = streamCount;
            boolean reel = isInstagramReelUrl(target);

            int playableCount = result.videos.size() + result.streams.size();
            boolean resolverComplete = result.ok && result.candidateCount() > 0;
            // Instagram's same-origin post HTML sometimes exposes CDN candidates with only the
            // stable asset/cache parameters and omits Meta's expiring hash pair (oh/oe). Those
            // URLs look real but the CDN rejects them with HTTP 403 / "Bad URL hash". Never
            // mark such a resolver result complete: open the post in the existing WebView fallback
            // so currentSrc/srcset/network requests can provide the exact browser-usable URL.
            String signatureProblem = instagramResolverSignatureProblem(result, !reel);
            if (!signatureProblem.isEmpty()) {
                resolverComplete = false;
                DiagnosticLog.log("SNS_IG_RESOLVER_SIGNATURE_FALLBACK reason=" + signatureProblem
                        + " url=" + target);
            }
            // Reel completion still requires playable media. For regular /p/ posts, however,
            // videoHint is too noisy in Instagram HTML to be a completion blocker: it is often
            // present even when the post itself is a still image. A weak one-candidate carousel
            // result is still considered incomplete and is resolved by the browser fallback.
            if (reel && playableCount == 0) resolverComplete = false;
            if (!reel && result.carouselHint && result.candidateCount() < 2) resolverComplete = false;

            if (resolverComplete) {
                // Keep the established Reel policy: the Reel itself is media; its cover/poster is
                // not emitted as a separate IMAGE. Regular /p/ carousel images remain eligible.
                if (!reel && wantImages) {
                    for (InstagramMediaResolver.Image image : result.images) {
                        if (image == null || image.url.isEmpty()) continue;
                        if (image.width > 0 || image.height > 0) {
                            emitQueuedInstagramImage(image.url, target,
                                    "SNS_IG_RESOLVER_IMAGE", image.width, image.height);
                        } else {
                            addMediaUrl(image.url, MediaItem.Kind.IMAGE, target,
                                    "SNS_IG_RESOLVER_IMAGE");
                        }
                    }
                }
                if (wantVideos) {
                    for (String video : result.videos) {
                        addMediaUrl(video, MediaItem.Kind.VIDEO, target,
                                "SNS_IG_RESOLVER_VIDEO");
                    }
                    for (String stream : result.streams) {
                        addMediaUrl(stream, MediaItem.Kind.STREAM, target,
                                "SNS_IG_RESOLVER_STREAM");
                    }
                }

                instagramCompletedPostUrls.add(target);
                instagramSkippedPostUrls.remove(target);
                instagramStreamingDeferredRetrySet.remove(target);
                instagramContinuationPendingUrls.remove(target);
                instagramDetailRetryCounts.remove(target);
                detailCount++;
                DiagnosticLog.log("SNS_IG_RESOLVER_DONE source=" + result.source
                        + " candidates=" + result.candidateCount()
                        + " images=" + result.images.size()
                        + " videos=" + result.videos.size()
                        + " streams=" + result.streams.size()
                        + " carouselHint=" + result.carouselHint
                        + " videoHint=" + result.videoHint
                        + " emittedImages=" + (imageCount - beforeImages)
                        + " emittedVideos=" + (videoCount - beforeVideos)
                        + " emittedStreams=" + (streamCount - beforeStreams)
                        + " url=" + target);
                listener.onProgressPulse("SNS_IG_RESOLVER_DONE");
                reportInstagramDiscoveryProgress();
                if (gracefulStopRequested) {
                    finishGracefulStopNow("instagram_resolver_complete");
                    return;
                }
                if (!instagramContinuationPendingUrls.isEmpty()) {
                    handler.postDelayed(() -> processNextInstagramContinuationPending(profileNode, profileLoad),
                            INSTAGRAM_STREAM_SCAN_DELAY_MS);
                } else {
                    handler.postDelayed(() -> scanInstagramProfileStream(run, profileLoad, nav, profileNode),
                            INSTAGRAM_STREAM_SCAN_DELAY_MS);
                }
                return;
            }

            DiagnosticLog.log("SNS_IG_RESOLVER_INLINE_FALLBACK source=" + result.source
                    + " error=" + result.error
                    + " candidates=" + result.candidateCount()
                    + " carouselHint=" + result.carouselHint
                    + " videoHint=" + result.videoHint
                    + " url=" + target);
            listener.onProgressPulse("SNS_IG_RESOLVER_INLINE_FALLBACK");
            listener.onStatus("Instagram投稿をその場でブラウザ解析  " + target);
            if (gracefulStopRequested) {
                DiagnosticLog.log("SNS_IG_SAFE_STOP_DEFER_CURRENT url=" + target);
                finishGracefulStopNow("instagram_resolver_incomplete");
                return;
            }
            // Do not keep scanning hundreds of newer posts while this one waits in a tail queue.
            // Resolve the current post before advancing so UI cells are emitted in profile order.
            retryInstagramStreamingPost(new Node(target, 1, true), "resolver_inline");
        });
    }




    private void resumeInstagramProfileStream(String reason) {
        if (gracefulStopRequested) {
            finishGracefulStopNow("instagram_post_complete_" + reason);
            return;
        }
        if (cancelled || !instagramStreamingMode) return;
        String live = stripFragment(webView.getUrl());
        if (isInstagramPostUrl(live)) {
            DiagnosticLog.log("SNS_IG_STREAM_RESUME_WAIT reason=still_post live=" + live);
            handler.postDelayed(() -> resumeInstagramProfileStream(reason), 450L);
            return;
        }
        Node profileNode = new Node(instagramStreamingProfileUrl, 0, false);
        current = profileNode;
        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 1L;
        activeLoadStarted = true;
        activePageFinished = true;
        activeStartedGeneration = generation;
        activeRequestedUrl = live;
        activeStartedUrl = live;
        activeInstagramDetailCollectionStarted = false;
        activeInstagramRequestDiagLogged = false;
        final long run = generation;
        final long load = activeLoadSequence;
        final long nav = activeNavigationSequence;
        DiagnosticLog.log("SNS_IG_STREAM_RESUME reason=" + reason
                + " live=" + live
                + " pass=" + instagramStreamingPass
                + " processed=" + detailCount);
        listener.onProgressPulse("SNS_IG_STREAM_RESUME");
        if (instagramStreamingDeferredRetryPhase) {
            listener.onStatus("Instagram未取得投稿を再試行中… " + instagramStreamingDeferredRetryQueue.size() + "件");
            handler.postDelayed(() -> processNextInstagramStreamingDeferredRetry(profileNode, load),
                    INSTAGRAM_STREAM_SCAN_DELAY_MS);
        } else if (!instagramContinuationPendingUrls.isEmpty()) {
            listener.onStatus("前回未取得の投稿を優先回収中… " + instagramContinuationPendingUrls.size() + "件");
            handler.postDelayed(() -> processNextInstagramContinuationPending(profileNode, load),
                    INSTAGRAM_STREAM_SCAN_DELAY_MS);
        } else {
            reportInstagramDiscoveryProgress();
            handler.postDelayed(() -> scanInstagramProfileStream(run, load, nav, profileNode),
                    INSTAGRAM_STREAM_SCAN_DELAY_MS);
        }
    }

    private void retryInstagramStreamingPost(Node previousNode, String reason) {
        if (gracefulStopRequested) {
            finishGracefulStopNow("instagram_retry_boundary_" + reason);
            return;
        }
        if (cancelled || !instagramStreamingMode || previousNode == null) return;
        String target = rememberInstagramPost(previousNode.url);
        setInstagramNetworkImagesBlocked(false, "detail_retry");
        if (target.isEmpty()) {
            resumeInstagramProfileStream("retry_bad_target");
            return;
        }
        Node detailNode = new Node(target, 1, true);
        current = detailNode;
        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = stripFragment(target);
        activeStartedUrl = "";
        activeInstagramDetailCollectionStarted = false;
        activeInstagramRequestDiagLogged = false;
        instagramSpaTargetUrl = target;
        instagramSpaAwaitingOpen = true;
        instagramSpaReturningToProfile = false;
        instagramSpaTapAttempts = 0;
        instagramCarouselSlideByPost.put(target, 1);
        instagramSlideStartedAtByPost.put(target, System.currentTimeMillis());
        final long loadId = activeLoadSequence;
        DiagnosticLog.log("SNS_IG_STREAM_RETRY reason=" + reason + " url=" + target);
        listener.onProgressPulse("SNS_IG_STREAM_RETRY");
        listener.onStatus("Instagram未取得投稿を再試行  " + target);
        markInstagramMeaningfulProgress("stream_retry");
        scheduleInstagramStallWatchdog(generation, loadId, detailNode);
        clickInstagramAnchorViaJs(detailNode, loadId);
    }

    private void processNextInstagramStreamingDeferredRetry(Node profileNode, long profileLoad) {
        if (gracefulStopRequested) {
            finishGracefulStopNow("instagram_deferred_retry_boundary");
            return;
        }
        if (cancelled || !instagramStreamingMode || !instagramStreamingDeferredRetryPhase) return;
        if (current != profileNode || activeLoadSequence != profileLoad) return;
        while (!instagramStreamingDeferredRetryQueue.isEmpty()) {
            String target = instagramStreamingDeferredRetryQueue.removeFirst();
            instagramStreamingDeferredRetrySet.remove(target);
            if (target == null || target.isEmpty() || instagramCompletedPostUrls.contains(target)) continue;
            DiagnosticLog.log("SNS_IG_STREAM_RETRY_PICK remaining=" + instagramStreamingDeferredRetryQueue.size()
                    + " url=" + target);
            retryInstagramStreamingPost(new Node(target, 1, true), "deferred_tail");
            return;
        }
        instagramStreamingDeferredRetryPhase = false;
        DiagnosticLog.log("SNS_IG_STREAM_RETRY_DONE skipped=" + instagramSkippedPostUrls.size());
        finishInstagramProfileStream(profileNode, "retry_complete");
    }

    private void finishInstagramProfileStream(Node node, String reason) {
        if (gracefulStopRequested) {
            finishGracefulStopNow("instagram_stream_finish_" + reason);
            return;
        }
        if (cancelled || !instagramStreamingMode) return;
        if (!instagramStreamingDeferredRetryPhase && !instagramStreamingDeferredRetryQueue.isEmpty()) {
            instagramStreamingDeferredRetryPhase = true;
            DiagnosticLog.log("SNS_IG_STREAM_RETRY_START count=" + instagramStreamingDeferredRetryQueue.size()
                    + " reason=" + reason);
            listener.onProgressPulse("SNS_IG_STREAM_RETRY_START");
            listener.onStatus("Instagram未取得投稿を再試行中… " + instagramStreamingDeferredRetryQueue.size() + "件");
            String live = stripFragment(webView.getUrl());
            Node profileNode = new Node(instagramStreamingProfileUrl, 0, false);
            current = profileNode;
            activeLoadSequence = ++loadSequence;
            activeNavigationSequence = 1L;
            activeLoadStarted = true;
            activePageFinished = true;
            activeStartedGeneration = generation;
            activeRequestedUrl = live;
            activeStartedUrl = live;
            final long profileLoad = activeLoadSequence;
            DiagnosticLog.log("SNS_IG_FALLBACK_RESET_PROFILE_TOP pending="
                    + instagramStreamingDeferredRetryQueue.size());
            webView.evaluateJavascript("(function(){try{window.scrollTo(0,0);return Math.round(window.scrollY||0)}catch(e){return -1}})()", ignored ->
                    handler.postDelayed(() -> processNextInstagramStreamingDeferredRetry(profileNode, profileLoad),
                            900L));
            return;
        }
        DiagnosticLog.log("SNS_IG_STREAM_DONE reason=" + reason
                + " postsSeen=" + instagramPostUrlsSeen.size()
                + " queued=" + instagramPostDetailsQueued
                + " details=" + detailCount
                + " failed=" + instagramSkippedPostUrls.size()
                + " media=" + (imageCount + videoCount + streamCount));
        listener.onProgressPulse("SNS_IG_STREAM_DONE");
        pageCount++;
        baseTraversalDone = true;
        detailPhaseStarted = true;
        detailTraversalDone = true;
        traversalDone = true;
        current = null;
        maybeFinishAfterImageProbes();
    }


    private static String buildInstagramVisiblePostCellsScript() {
        return "(function(){try{"
                + "const abs=u=>{try{return u?new URL(u,document.baseURI).href:''}catch(e){return ''}};"
                + "const de=document.documentElement;"
                + "const sh=(window.screen&&window.screen.height)||0,sw=(window.screen&&window.screen.width)||0;"
                + "const vvh=(window.visualViewport&&window.visualViewport.height)||0,vvw=(window.visualViewport&&window.visualViewport.width)||0;"
                + "const vh=Math.max(window.innerHeight||0,de?de.clientHeight:0,vvh,sh);"
                + "const vw=Math.max(window.innerWidth||0,de?de.clientWidth:0,vvw,sw);"
                + "let seen=new Set(),cells=[];"
                + "document.querySelectorAll('a[href]').forEach(a=>{let u=abs(a.href||'');if(!/\\/(p|reel|tv)\\/[^/?#]+/i.test(u))return;"
                + "let m=u.match(/\\/(p|reel|tv)\\/([^/?#]+)/i);if(!m)return;let c='https://www.instagram.com/'+m[1].toLowerCase()+'/'+m[2]+'/';if(seen.has(c))return;"
                + "let r=a.getBoundingClientRect(),s=getComputedStyle(a);if(r.width<24||r.height<24||s.display==='none'||s.visibility==='hidden')return;"
                + "if(r.bottom<=0||r.top>=vh||r.right<=0||r.left>=vw)return;seen.add(c);cells.push({url:c,top:r.top,left:r.left});});"
                + "cells.sort((a,b)=>Math.abs(a.top-b.top)>6?a.top-b.top:a.left-b.left);"
                + "let b=document.body,h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0),y=window.scrollY||window.pageYOffset||0;"
                + "return JSON.stringify({cells:cells,y:Math.round(y),h:Math.round(h),vh:Math.round(vh),bottom:(y+vh>=h-96)});"
                + "}catch(e){return JSON.stringify({cells:[],y:0,h:0,vh:0,bottom:false,error:String(e)})}})()";
    }

    private static String buildInstagramProfilePostCountScript() {
        return "(function(){try{"
                + "const parse=n=>{if(!n)return 0;let t=String(n).replace(/\\s+/g,'').replace(/,/g,'');"
                + "let m=t.match(/([0-9]+(?:\\.[0-9]+)?)([KMB万億]?)/i);if(!m)return 0;let v=parseFloat(m[1]),u=(m[2]||'').toUpperCase();"
                + "if(u==='K')v*=1e3;else if(u==='M')v*=1e6;else if(u==='B')v*=1e9;else if(m[2]==='万')v*=1e4;else if(m[2]==='億')v*=1e8;return Math.round(v)};"
                + "let cand=[];let push=(txt,src)=>{txt=(txt||'').replace(/\\s+/g,' ').trim();if(!txt||txt.length>160)return;"
                + "let patterns=[/(?:投稿(?:数)?|posts?)\\s*[:：]?\\s*([0-9][0-9,.]*\\s*[KMB万億]?)/i,/([0-9][0-9,.]*\\s*[KMB万億]?)\\s*(?:件\\s*)?(?:の\\s*)?(?:投稿|posts?)/i];"
                + "for(let r of patterns){let m=txt.match(r);if(m){let n=parse(m[1]);if(n>0)cand.push({n:n,src:src,txt:txt});}}};"
                + "document.querySelectorAll('meta[name=description],meta[property=\\\"og:description\\\"]').forEach(e=>push(e.content||'', 'meta'));"
                + "document.querySelectorAll('header span,header a,header div,main header span,main header a').forEach(e=>push(e.innerText||e.textContent||'', 'header'));"
                + "if(!cand.length)push((document.body&&document.body.innerText)||'', 'body');"
                + "cand.sort((a,b)=>a.n-b.n);let best=cand.length?cand[0]:{n:0,src:'none',txt:''};"
                + "return JSON.stringify({count:best.n||0,source:best.src||'none',sample:(best.txt||'').slice(0,120)});"
                + "}catch(e){return JSON.stringify({count:0,source:'error',error:String(e)})}})()";
    }

    private static String buildInstagramProfileDiscoveryScript() {
        return "(function(){try{"
                + "const abs=u=>{try{return u?new URL(u,document.baseURI).href:''}catch(e){return ''}};"
                + "const sy=window.scrollY||window.pageYOffset||0;"
                + "let seen=new Set(),cells=[];"
                + "document.querySelectorAll('a[href]').forEach(a=>{let u=abs(a.href||'');if(!/\\/(p|reel|tv)\\/[^/?#]+/i.test(u))return;"
                + "let m=u.match(/\\/(p|reel|tv)\\/([^/?#]+)/i);if(!m)return;let c='https://www.instagram.com/'+m[1].toLowerCase()+'/'+m[2]+'/';if(seen.has(c))return;"
                + "let r=a.getBoundingClientRect(),s=getComputedStyle(a);if(r.width<24||r.height<24||s.display==='none'||s.visibility==='hidden')return;"
                + "seen.add(c);cells.push({url:c,top:Math.round(r.top+sy),left:Math.round(r.left)});});"
                + "cells.sort((a,b)=>Math.abs(a.top-b.top)>6?a.top-b.top:a.left-b.left);"
                + "let de=document.documentElement,b=document.body,h=Math.max(de?de.scrollHeight:0,b?b.scrollHeight:0),y=sy,vh=Math.max(window.innerHeight||0,de?de.clientHeight:0,(window.visualViewport&&window.visualViewport.height)||0,(window.screen&&window.screen.height)||0);"
                + "return JSON.stringify({cells:cells,y:Math.round(y),h:Math.round(h),vh:Math.round(vh),bottom:(y+vh>=h-96)});"
                + "}catch(e){return JSON.stringify({cells:[],y:0,h:0,vh:0,bottom:false,error:String(e)})}})()";
    }

    private int processXStatusLinks(JSONArray links, Node from) {
        if (!followDetails || links == null || from.detail || from.depth != 0) return 0;
        int added = 0;
        int existing = deferredDetails.size();
        for (int i = 0; i < links.length() && existing + added < X_STATUS_DETAIL_LIMIT; i++) {
            String u = canonicalXStatusUrl(links.optString(i, ""));
            if (u.isEmpty()) continue;
            String owner = xUserFromStatusUrl(u);
            if (!includeXReposts && !rootXUser.isEmpty() && !owner.isEmpty()
                    && !owner.equalsIgnoreCase(rootXUser)) {
                DiagnosticLog.log("SNS_X_REPOST_SKIP owner=" + owner + " root=" + rootXUser + " url=" + u);
                continue;
            }
            String key = stripFragment(u);
            if (deferredDetails.containsKey(key)) continue;
            deferredDetails.put(key, new DeferredDetail(u));
            added++;
            DiagnosticLog.log("SNS_X_STATUS_DEFER owner=" + (owner.isEmpty() ? "unknown" : owner)
                    + " url=" + u);
        }
        return added;
    }

    private static String xUserFromProfileUrl(String raw) {
        try {
            URI uri = new URI(stripFragment(cleanUrl(raw)));
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!isXLikeHost(host)) return "";
            String path = uri.getPath() == null ? "" : uri.getPath();
            Matcher m = Pattern.compile("^/([^/]+)(?:/.*)?$").matcher(path);
            if (!m.find()) return "";
            String user = m.group(1);
            if (user.equalsIgnoreCase("home") || user.equalsIgnoreCase("i")
                    || user.equalsIgnoreCase("settings") || user.equalsIgnoreCase("search")
                    || user.equalsIgnoreCase("explore")) return "";
            return user;
        } catch (Exception e) {
            return "";
        }
    }

    private static String xUserFromStatusUrl(String raw) {
        try {
            URI uri = new URI(stripFragment(cleanUrl(raw)));
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!isXLikeHost(host)) return "";
            String path = uri.getPath() == null ? "" : uri.getPath();
            Matcher m = Pattern.compile("^/([^/]+)/status/\\d+").matcher(path);
            return m.find() ? m.group(1) : "";
        } catch (Exception e) {
            return "";
        }
    }

    private static String canonicalXStatusUrl(String raw) {
        String u = cleanUrl(raw);
        if (!isHttp(u)) return "";
        try {
            URI uri = new URI(stripFragment(u));
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!isXLikeHost(host)) return "";
            String path = uri.getPath() == null ? "" : uri.getPath();
            Matcher m = Pattern.compile("^/([^/]+)/status/(\\d+)").matcher(path);
            if (!m.find()) return "";
            return "https://x.com/" + m.group(1) + "/status/" + m.group(2);
        } catch (Exception e) {
            return "";
        }
    }

    private int processInstagramPostLinks(JSONArray links, Node from) {
        if (!followDetails || links == null || from.detail || from.depth != 0) return 0;
        int added = 0;
        for (int i = 0; i < links.length(); i++) {
            String u = rememberInstagramPost(links.optString(i, ""));
            if (u.isEmpty()) continue;
            String key = stripFragment(u);
            if (deferredDetails.containsKey(key) || queuedOrVisited.contains(key)) continue;
            if (deferredDetails.size() >= INSTAGRAM_DETAIL_LIMIT) {
                markIncomplete("instagram_post_limit");
                continue;
            }
            deferredDetails.put(key, new DeferredDetail(u));
            instagramPostDetailsQueued++;
            added++;
            DiagnosticLog.log("SNS_IG_POST_DEFER url=" + u);
        }
        return added;
    }

    private String rememberInstagramPost(String raw) {
        String u = canonicalInstagramPostUrl(raw);
        if (u.isEmpty()) return "";
        instagramPostUrlsSeen.add(u);
        if (!instagramPostOrder.containsKey(u)) {
            instagramPostOrder.put(u, instagramNextPostOrder++);
            DiagnosticLog.log("SNS_IG_POST_ORDER index=" + instagramPostOrder.get(u) + " url=" + u);
        }
        return u;
    }

    private long instagramDisplayOrder(String referrer) {
        String post = rememberInstagramPost(referrer);
        if (post.isEmpty()) return Long.MAX_VALUE;
        int postOrder = instagramPostOrder.getOrDefault(post, Integer.MAX_VALUE / 4);
        int mediaOrder = instagramMediaOrderByPost.getOrDefault(post, 0);
        instagramMediaOrderByPost.put(post, mediaOrder + 1);
        return ((long) postOrder * 1000L) + Math.min(999, mediaOrder);
    }

    private static String canonicalInstagramPostUrl(String raw) {
        String u = cleanUrl(raw);
        if (!isHttp(u)) return "";
        try {
            URI uri = new URI(stripFragment(u));
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!isInstagramLikeHost(host)) return "";
            String path = uri.getPath() == null ? "" : uri.getPath();
            Matcher m = Pattern.compile("/(p|reel|tv)/([^/?#]+)", Pattern.CASE_INSENSITIVE).matcher(path);
            if (!m.find()) return "";
            return "https://www.instagram.com/" + m.group(1) + "/" + m.group(2) + "/";
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean isInstagramReelUrl(String raw) {
        String canonical = canonicalInstagramPostUrl(raw);
        if (canonical.isEmpty()) return false;
        try {
            String path = new URI(canonical).getPath();
            return path != null && (path.startsWith("/reel/") || path.startsWith("/tv/"));
        } catch (Exception e) {
            return false;
        }
    }

    private void startInstagramDetailCollection(long run, long load, long nav, Node node, String trigger) {
        if (!isActive(run, load, nav, node) || activeInstagramDetailCollectionStarted) return;
        activeInstagramDetailCollectionStarted = true;
        markInstagramMeaningfulProgress("detail_collect_start");
        String ref = canonicalInstagramPostUrl(node.url);
        if (!ref.isEmpty()) instagramSlideStartedAtByPost.put(ref, System.currentTimeMillis());
        DiagnosticLog.log("SNS_IG_DETAIL_COLLECT_START trigger=" + trigger + " load=" + load
                + " restartFrom=1 url=" + node.url);
        collectInstagramCarousel(1, 0, "", run, load, nav, node);
    }

    private void collectDom(long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        String liveUrl = webView.getUrl();
        if (!sameNavigationUrl(liveUrl, activeStartedUrl)) {
            DiagnosticLog.log("DOM_COLLECT_SKIP reason=live_url_mismatch generation=" + run
                    + " load=" + load
                    + " node=" + node.url
                    + " started=" + activeStartedUrl
                    + " live=" + liveUrl);
            return;
        }
        DiagnosticLog.log("DOM_COLLECT generation=" + run + " load=" + load + " nav=" + nav + " url=" + node.url + " detail=" + node.detail + " depth=" + node.depth
                + " live=" + liveUrl
                + " targetImagePx=" + targetImagePx);
        listener.onProgressPulse("DOM_COLLECT");
        if (node.detail && instagramStreamingMode) {
            reportInstagramDiscoveryProgress();
        } else {
            listener.onStatus("解析中 " + (pageCount + detailCount + 1) + "ページ目");
        }
        if (!node.detail && isInstagramLikeHost(rootHost)) {
            // The Instagram profile/grid page is discovery-only. Its thumbnails, avatars and
            // clip cover frames are not the final media. Post URLs were already captured by the
            // readiness/scroll harvest; move directly to the detail phase.
            DiagnosticLog.log("SNS_IG_BASE_DISCOVERY_DONE postsSeen=" + instagramPostUrlsSeen.size()
                    + " deferred=" + deferredDetails.size());
            pageCount++;
            current = null;
            loadNext();
            return;
        }
        if (node.detail && isInstagramLikeHost(rootHost)) {
            if (activeInstagramDetailCollectionStarted) {
                DiagnosticLog.log("SNS_IG_DETAIL_COLLECT_ALREADY_STARTED load=" + load + " url=" + node.url);
                return;
            }
            startInstagramDetailCollection(run, load, nav, node, "page_finished");
            return;
        }
        if (node.detail) {
            handler.postDelayed(() -> {
                if (isActive(run, load, nav, node)) {
                    skipCurrentDetail(node, load, "dom_timeout", DETAIL_DOM_TIMEOUT_MS);
                }
            }, DETAIL_DOM_TIMEOUT_MS);
        }
        String collectorScript = (node.detail && isXLikeHost(rootHost))
                ? buildXDetailCollectorScript()
                : buildCollectorScript(targetImagePx);
        webView.evaluateJavascript(collectorScript, raw -> {
            if (!isActive(run, load, nav, node)) {
                DiagnosticLog.log("DOM_CALLBACK_SKIP stale_generation=" + run
                        + " current_generation=" + generation
                        + " stale_load=" + load
                        + " current_load=" + activeLoadSequence
                        + " stale_nav=" + nav
                        + " current_nav=" + activeNavigationSequence
                        + " url=" + node.url);
                return;
            }
            try {
                String jsonText = unquoteJsResult(raw);
                JSONObject obj = new JSONObject(jsonText);
                String title = obj.optString("title", "").trim();
                if (!title.isEmpty() && pageCount == 0 && detailCount == 0) pageTitle = title;
                if (!isSnsLikeHost(rootHost)) processThumbnailLinks(obj.optJSONArray("thumbLinks"), node, liveUrl);
                processMediaArray(obj.optJSONArray("images"), MediaItem.Kind.IMAGE, liveUrl, node.detail);
                processMediaArray(obj.optJSONArray("videos"), MediaItem.Kind.VIDEO, liveUrl, node.detail);
                processMediaArray(obj.optJSONArray("streams"), MediaItem.Kind.STREAM, liveUrl, node.detail);
                if (!isSnsLikeHost(rootHost)) processLinks(obj.optJSONArray("links"), node);
            } catch (Exception e) {
                DiagnosticLog.logException("DOM_PARSE_FAIL url=" + node.url, e);
                listener.onStatus("ページ解析を一部スキップ: " + e.getClass().getSimpleName());
            }

            if (!isActive(run, load, nav, node)) return;
            listener.onProgressPulse("DOM_CALLBACK");
            if (node.detail) detailCount++; else pageCount++;
            current = null;
            loadNext();
        });
    }

    private void collectInstagramCarousel(int slide, int stalled, String previousKey,
                                          long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        String postRef = canonicalInstagramPostUrl(node.url);
        if (!postRef.isEmpty()) instagramCarouselSlideByPost.put(postRef, Math.max(1, slide));
        if (slide > INSTAGRAM_CAROUSEL_MAX_SLIDES) {
            restartInstagramPostFromBeginning(node, load, "slide_limit");
            return;
        }
        webView.evaluateJavascript(buildInstagramCarouselInspectScript(), raw -> {
            if (!isActive(run, load, nav, node)) return;
            try {
                JSONObject obj = new JSONObject(unquoteJsResult(raw));
                processInstagramCarouselMedia(obj, webView.getUrl(), slide);
                String key = obj.optString("key", "");
                boolean nextFound = obj.optBoolean("next", false);
                boolean carouselHint = obj.optBoolean("carouselHint", false);
                String nextMethod = obj.optString("nextMethod", "none");
                int images = arrayLength(obj.optJSONArray("images"));
                int videos = arrayLength(obj.optJSONArray("videos"));
                int streams = arrayLength(obj.optJSONArray("streams"));
                int liveSlideIndex = instagramCarouselIndex(webView.getUrl());
                boolean mediaChanged = !key.isEmpty() && (previousKey.isEmpty() || !previousKey.equals(key));
                boolean indexChanged = slide > 1 && liveSlideIndex >= slide;
                boolean changed = mediaChanged || indexChanged;
                int nextStall = changed ? 0 : stalled + 1;
                if (changed) markInstagramMeaningfulProgress(indexChanged && !mediaChanged
                        ? "carousel_index_changed" : "carousel_media_changed");
                DiagnosticLog.log("SNS_IG_CAROUSEL slide=" + slide
                        + " images=" + images + " videos=" + videos + " streams=" + streams
                        + " next=" + nextFound + " nextMethod=" + nextMethod
                        + " carouselHint=" + carouselHint
                        + " changed=" + changed + " stall=" + nextStall
                        + " liveIndex=" + liveSlideIndex);
                listener.onProgressPulse("SNS_IG_CAROUSEL");

                if (key.isEmpty() && images == 0 && videos == 0 && streams == 0) {
                    int polls = stalled + 1;
                    if (polls % INSTAGRAM_EMPTY_MEDIA_LOG_INTERVAL == 0) {
                        DiagnosticLog.log("SNS_IG_CAROUSEL_WAIT_MEDIA slide=" + slide + " polls=" + polls);
                    }
                    if (polls >= INSTAGRAM_IMAGE_FALLBACK_POLLS && instagramNetworkImagesBlocked) {
                        if (enableInstagramImagesForFallback(node, "empty_media")) {
                            handler.postDelayed(() -> collectInstagramCarousel(slide, 0, previousKey,
                                    run, load, nav, node), 850L);
                            return;
                        }
                    }
                    if (polls >= INSTAGRAM_EMPTY_MEDIA_DEFER_POLLS) {
                        restartInstagramPostFromBeginning(node, load, "empty_media_defer");
                        return;
                    }
                    handler.postDelayed(() -> collectInstagramCarousel(slide, polls, previousKey,
                            run, load, nav, node), 500L);
                    return;
                }

                if (isInstagramReelUrl(node.url)) {
                    if (instagramPostsWithCapturedVideo.contains(postRef)) {
                        finishInstagramCarousel(run, load, nav, node, "reel_captured");
                    } else {
                        int polls = stalled + 1;
                        DiagnosticLog.log("SNS_IG_REEL_WAIT_VIDEO polls=" + polls + " url=" + node.url);
                        if (polls >= INSTAGRAM_IMAGE_FALLBACK_POLLS && instagramNetworkImagesBlocked) {
                            if (enableInstagramImagesForFallback(node, "reel_wait_video")) {
                                handler.postDelayed(() -> collectInstagramCarousel(slide, 0, previousKey,
                                        run, load, nav, node), 850L);
                                return;
                            }
                        }
                        if (polls >= INSTAGRAM_EMPTY_MEDIA_DEFER_POLLS) {
                            restartInstagramPostFromBeginning(node, load, "reel_video_defer");
                            return;
                        }
                        handler.postDelayed(() -> collectInstagramCarousel(slide, polls, previousKey,
                                run, load, nav, node), 500L);
                    }
                    return;
                }

                if (!nextFound) {
                    int mediaCount = images + videos + streams;
                    confirmTerminalOrRestart(slide, key, liveSlideIndex, mediaCount, carouselHint,
                            run, load, nav, node);
                    return;
                }

                // Seeing Next disproves any earlier terminal guess for this post.
                if (!postRef.isEmpty()) {
                    instagramTerminalCandidateByPost.remove(postRef);
                    instagramTerminalConfirmCountByPost.remove(postRef);
                }
                clickInstagramCarouselNext(slide, key, nextStall, run, load, nav, node);
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_IG_CAROUSEL_PARSE_FAIL url=" + node.url, e);
                restartInstagramPostFromBeginning(node, load, "parse_fail");
            }
        });
    }

    private void clickInstagramCarouselNext(int slide, String currentKey, int stalled,
                                            long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        webView.evaluateJavascript(buildInstagramCarouselClickScript(), raw -> {
            if (!isActive(run, load, nav, node)) return;
            try {
                JSONObject result = new JSONObject(unquoteJsResult(raw));
                boolean clicked = result.optBoolean("clicked", false);
                String method = result.optString("method", "none");
                String label = result.optString("label", "");
                DiagnosticLog.log("SNS_IG_CAROUSEL_NEXT_FOUND slide=" + slide
                        + " clicked=" + clicked + " method=" + method
                        + " label=" + sanitizeDiagnosticText(label));
                if (!clicked) {
                    if (stalled < INSTAGRAM_CLICK_RETRY_LIMIT) {
                        DiagnosticLog.log("SNS_IG_CAROUSEL_CLICK_RETRY slide=" + slide
                                + " attempt=" + (stalled + 1) + "/" + INSTAGRAM_CLICK_RETRY_LIMIT);
                        handler.postDelayed(() -> collectInstagramCarousel(slide, stalled + 1, currentKey,
                                run, load, nav, node), 500L);
                    } else {
                        DiagnosticLog.log("SNS_IG_CAROUSEL_END reason=next_not_clickable slide=" + slide
                                + " action=reload url=" + node.url);
                        restartInstagramPostFromBeginning(node, load, "next_not_clickable");
                    }
                    return;
                }
                String ref = canonicalInstagramPostUrl(node.url);
                if (!ref.isEmpty()) instagramSlideStartedAtByPost.put(ref, System.currentTimeMillis());
                markInstagramMeaningfulProgress("carousel_next_click");
                listener.onProgressPulse("SNS_IG_CAROUSEL_NEXT");
                handler.postDelayed(() -> waitForInstagramSlideChange(slide + 1, currentKey, stalled, 0,
                        run, load, nav, node), INSTAGRAM_CAROUSEL_DELAY_MS);
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_IG_CAROUSEL_CLICK_PARSE_FAIL url=" + node.url, e);
                restartInstagramPostFromBeginning(node, load, "click_parse_fail");
            }
        });
    }

    private void waitForInstagramSlideChange(int nextSlide, String previousKey, int stalled, int poll,
                                             long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        webView.evaluateJavascript(buildInstagramCarouselInspectScript(), raw -> {
            if (!isActive(run, load, nav, node)) return;
            try {
                JSONObject obj = new JSONObject(unquoteJsResult(raw));
                String key = obj.optString("key", "");
                int liveSlideIndex = instagramCarouselIndex(webView.getUrl());
                boolean mediaChanged = !key.isEmpty() && !key.equals(previousKey);
                boolean indexChanged = liveSlideIndex >= nextSlide;
                if (mediaChanged || indexChanged) {
                    String slideRef = canonicalInstagramPostUrl(node.url);
                    if (!slideRef.isEmpty()) instagramCarouselSlideByPost.put(slideRef, Math.max(1, nextSlide));
                    processInstagramCarouselMedia(obj, webView.getUrl(), nextSlide);
                    markInstagramMeaningfulProgress("carousel_slide_changed");
                    DiagnosticLog.log("SNS_IG_CAROUSEL_SLIDE_CHANGED slide=" + nextSlide
                            + " poll=" + poll + " liveIndex=" + liveSlideIndex
                            + " mediaChanged=" + mediaChanged
                            + " images=" + arrayLength(obj.optJSONArray("images"))
                            + " videos=" + arrayLength(obj.optJSONArray("videos"))
                            + " streams=" + arrayLength(obj.optJSONArray("streams")));
                    listener.onProgressPulse("SNS_IG_CAROUSEL_SLIDE_CHANGED");
                    handler.postDelayed(() -> collectInstagramCarousel(nextSlide, 0, key,
                            run, load, nav, node), INSTAGRAM_CAROUSEL_DELAY_MS);
                    return;
                }
                if (poll + 1 >= INSTAGRAM_SLIDE_CHANGE_MAX_POLLS) {
                    DiagnosticLog.log("SNS_IG_CAROUSEL_SLIDE_CHANGE_TIMEOUT slide=" + nextSlide
                            + " polls=" + (poll + 1) + " action=reload");
                    restartInstagramPostFromBeginning(node, load, "slide_change_timeout");
                    return;
                }
                handler.postDelayed(() -> waitForInstagramSlideChange(nextSlide, previousKey, stalled,
                        poll + 1, run, load, nav, node), INSTAGRAM_SLIDE_CHANGE_POLL_MS);
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_IG_CAROUSEL_CHANGE_PARSE_FAIL url=" + node.url, e);
                restartInstagramPostFromBeginning(node, load, "change_parse_fail");
            }
        });
    }

    private void processInstagramCarouselMedia(JSONObject obj, String referrer, int slide) throws JSONException {
        JSONArray meta = obj.optJSONArray("imageMeta");
        HashSet<String> handled = new HashSet<>();
        if (wantImages && meta != null) {
            for (int i = 0; i < meta.length(); i++) {
                JSONObject m = meta.optJSONObject(i);
                if (m == null) continue;
                String u = normalizeSnsImageUrl(cleanUrl(m.optString("u", "")));
                if (!isHttp(u)) continue;
                int w = Math.max(0, m.optInt("w", 0));
                int h = Math.max(0, m.optInt("h", 0));
                String key = imageKey(u);
                if (key.isEmpty()) continue;
                handled.add(key);
                if (Math.max(w, h) >= targetImagePx) {
                    DiagnosticLog.log("SNS_IG_DOM_IMAGE_ACCEPT size=" + w + "x" + h
                            + " target=" + targetImagePx + " url=" + u);
                    emitQueuedInstagramImage(u, referrer, "SNS_IG_CAROUSEL_IMAGE", w, h);
                } else if (w <= 0 && h <= 0) {
                    addMediaUrl(u, MediaItem.Kind.IMAGE, referrer, "SNS_IG_CAROUSEL_PROBE");
                } else {
                    DiagnosticLog.log("SNS_IG_DOM_IMAGE_LOW_RES size=" + w + "x" + h
                            + " target=" + targetImagePx + " url=" + u);
                }
            }
        }
        JSONArray images = obj.optJSONArray("images");
        if (images != null && wantImages) {
            for (int i = 0; i < images.length(); i++) {
                String u = normalizeSnsImageUrl(cleanUrl(images.optString(i, "")));
                String key = imageKey(u);
                if (!key.isEmpty() && handled.contains(key)) continue;
                addMediaUrl(u, MediaItem.Kind.IMAGE, referrer, "SNS_IG_CAROUSEL_PROBE");
            }
        }

        String postRef = canonicalInstagramPostUrl(referrer);
        JSONArray domVideos = obj.optJSONArray("videos");
        JSONArray domStreams = obj.optJSONArray("streams");
        boolean domVideoIdentityPresent = arrayLength(domVideos) > 0 || arrayLength(domStreams) > 0;
        processMediaArray(domVideos, MediaItem.Kind.VIDEO, referrer, true);
        processMediaArray(domStreams, MediaItem.Kind.STREAM, referrer, true);
        if (domVideoIdentityPresent && !postRef.isEmpty()) instagramPostsWithCapturedVideo.add(postRef);

        boolean visibleVideo = obj.optBoolean("videoVisible", false);
        if (visibleVideo || isInstagramReelUrl(referrer)) {
            InstagramVideoCandidate candidate = takeInstagramNetworkVideoCandidate(referrer, slide);
            if (candidate != null) {
                boolean added = addMediaUrl(candidate.url, candidate.kind, referrer,
                        "SNS_IG_VIDEO_NETWORK_ATTACH");
                if (added && !postRef.isEmpty()) instagramPostsWithCapturedVideo.add(postRef);
                DiagnosticLog.log("SNS_IG_VIDEO_NETWORK_ATTACH candidate=" + candidate.key
                        + " slide=" + slide + " added=" + added + " ref=" + referrer);
            }
        }
    }

    private InstagramVideoCandidate takeInstagramNetworkVideoCandidate(String referrer, int slide) {
        String ref = canonicalInstagramPostUrl(referrer);
        LinkedHashMap<String, InstagramVideoCandidate> candidates = instagramNetworkVideoCandidates.get(ref);
        if (candidates == null || candidates.isEmpty()) return null;
        for (InstagramVideoCandidate c : candidates.values()) {
            String consumedKey = ref + "|" + c.key;
            if (instagramConsumedNetworkVideoCandidates.contains(consumedKey)) continue;
            // Network media commonly starts loading before DOM/detail collection begins.
            // Candidates are already scoped to the active canonical post URL, so rejecting
            // a candidate merely because it predates the collection timestamp discards the
            // Reel's own MP4 before it can be attached. Keep the first unconsumed candidate.
            instagramConsumedNetworkVideoCandidates.add(consumedKey);
            return c;
        }
        return null;
    }

    private static int arrayLength(JSONArray a) {
        return a == null ? 0 : a.length();
    }

    private void confirmTerminalOrRestart(int slide, String key, int liveSlideIndex, int mediaCount,
                                          boolean carouselHint,
                                          long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        String ref = canonicalInstagramPostUrl(node.url);
        if (ref.isEmpty()) {
            restartInstagramPostFromBeginning(node, load, "terminal_no_ref_defer");
            return;
        }
        int observed = liveSlideIndex > 0 ? liveSlideIndex : Math.max(1, slide);
        String signature = observed + "|" + mediaCount + "|" + stableInstagramCarouselKey(key);
        String previous = instagramTerminalCandidateByPost.get(ref);
        int confirmations = signature.equals(previous)
                ? instagramTerminalConfirmCountByPost.getOrDefault(ref, 0) + 1 : 1;
        instagramTerminalCandidateByPost.put(ref, signature);
        instagramTerminalConfirmCountByPost.put(ref, confirmations);

        // On slide 1 a single visible media item with no Next is the common single-post case.
        // Re-check once after the old 0.1.43-style grace period, then accept it as complete.
        // Multiple loaded media items on slide 1 strongly suggest a preloaded carousel; never
        // call that complete just because Next disappeared. Move it to the back and retry later.
        boolean ambiguousFirstSlide = observed <= 1 && (mediaCount > 1 || carouselHint);
        int required = ambiguousFirstSlide ? 3 : 2;
        DiagnosticLog.log("SNS_IG_TERMINAL_CHECK slide=" + slide + " observed=" + observed
                + " mediaCount=" + mediaCount
                + " carouselHint=" + carouselHint
                + " ambiguousFirst=" + ambiguousFirstSlide
                + " confirmations=" + confirmations + "/" + required + " url=" + node.url);

        if (confirmations >= required) {
            if (ambiguousFirstSlide) {
                restartInstagramPostFromBeginning(node, load, "terminal_ambiguous_defer");
            } else {
                finishInstagramCarousel(run, load, nav, node, "last_slide_confirmed");
            }
            return;
        }

        handler.postDelayed(() -> collectInstagramCarousel(slide, 0, key,
                run, load, nav, node), INSTAGRAM_TERMINAL_RECHECK_MS);
    }

    private static String stableInstagramCarouselKey(String rawKey) {
        if (rawKey == null || rawKey.isEmpty()) return "";
        ArrayList<String> ids = new ArrayList<>();
        for (String part : rawKey.split("\\|")) {
            if (part == null || part.isEmpty()) continue;
            String clean = stripFragment(cleanUrl(part));
            if (isHttp(clean)) {
                String imageIdentity = instagramImageIdentity(clean);
                if (!imageIdentity.isEmpty()) {
                    ids.add("I:" + imageIdentity);
                    continue;
                }
                String lower = clean.toLowerCase(Locale.ROOT);
                if (lower.contains(".mp4") || lower.contains(".m3u8") || lower.contains(".mpd")) {
                    ids.add("M:" + instagramVideoCandidateKey(clean));
                    continue;
                }
                try {
                    URI uri = new URI(clean);
                    String path = uri.getPath() == null ? "" : uri.getPath();
                    ids.add("U:" + path);
                } catch (Exception ignored) {
                    ids.add("U:" + clean);
                }
            } else {
                ids.add("R:" + part);
            }
        }
        Collections.sort(ids);
        return String.join("|", ids);
    }

    private boolean restartInstagramPostFromBeginning(Node node, long expectedLoad, String reason) {
        if (cancelled || node == null || !node.detail || current != node
                || activeLoadSequence != expectedLoad || !isInstagramLikeHost(rootHost)) return false;
        String key = rememberInstagramPost(node.url);
        if (key.isEmpty()) key = stripFragment(cleanUrl(node.url));
        int attempt = instagramDetailRetryCounts.getOrDefault(key, 0) + 1;
        instagramDetailRetryCounts.put(key, attempt);

        if (instagramStreamingMode) {
            boolean firstFailure = attempt == 1 && !instagramStreamingDeferredRetryPhase;
            try { webView.stopLoading(); } catch (Exception ignored) {}
            if (!key.isEmpty()) {
                instagramCarouselSlideByPost.put(key, 1);
                instagramResumeSlideByPost.remove(key);
                instagramSlideStartedAtByPost.put(key, System.currentTimeMillis());
                instagramPostsWithNetworkVideo.remove(key);
                instagramPostsWithCapturedVideo.remove(key);
                instagramNetworkVideoCandidates.remove(key);
                instagramTerminalCandidateByPost.remove(key);
                instagramTerminalConfirmCountByPost.remove(key);
                final String consumedPrefix = key + "|";
                instagramConsumedNetworkVideoCandidates.removeIf(v -> v != null && v.startsWith(consumedPrefix));
            }
            activeLoadSequence = ++loadSequence;
            activeNavigationSequence = 0L;
            activeLoadStarted = false;
            activePageFinished = false;
            activeStartedGeneration = -1L;
            activeRequestedUrl = "";
            activeStartedUrl = "";
            activeInstagramDetailCollectionStarted = false;
            activeInstagramLastMeaningfulProgressAt = System.currentTimeMillis();
            instagramCompletionCandidateAt = 0L;
            instagramCompletionWaitScheduled = false;

            if (firstFailure) {
                DiagnosticLog.log("SNS_IG_POST_RELOAD attempt=" + attempt
                        + " reason=" + reason + " url=" + node.url);
                listener.onProgressPulse("SNS_IG_POST_RELOAD");
                listener.onStatus("Instagram投稿を再読込して再解析  " + node.url);
                // Return to the profile only long enough to restore the grid, then reopen the same
                // post. The next failure is terminal for this post, so ordering cannot be blocked
                // forever and we still avoid the old tail-retry backlog.
                final Node samePost = new Node(node.url, 1, true);
                returnInstagramSpaToProfile(node, () -> handler.postDelayed(
                        () -> retryInstagramStreamingPost(samePost, "inline_retry_" + reason), 250L));
                return true;
            }

            DiagnosticLog.log("SNS_IG_POST_RETRY_SKIP attempt=" + attempt
                    + " reason=" + reason + " url=" + node.url);
            listener.onProgressPulse("SNS_IG_POST_RETRY_SKIP");
            listener.onStatus("Instagram投稿の取得に失敗  " + node.url);
            if (!key.isEmpty()) {
                instagramSkippedPostUrls.add(key);
                instagramStreamingDeferredRetrySet.remove(key);
                instagramContinuationPendingUrls.remove(key);
                instagramDetailRetryCounts.remove(key);
            }
            detailCount++;
            returnInstagramSpaToProfile(node, () ->
                    handler.postDelayed(() -> resumeInstagramProfileStream("post_failed_" + reason), 250L));
            return true;
        }

        if (attempt > INSTAGRAM_POST_RETRY_LIMIT) {
            DiagnosticLog.log("SNS_IG_POST_RETRY_SKIP attempt=" + attempt
                    + " limit=" + INSTAGRAM_POST_RETRY_LIMIT
                    + " reason=" + reason + " url=" + node.url);
            listener.onProgressPulse("SNS_IG_POST_RETRY_SKIP");
            listener.onStatus("Instagram投稿をスキップ  " + node.url);
            try { webView.stopLoading(); } catch (Exception ignored) {}
            if (!key.isEmpty()) {
                instagramSkippedPostUrls.add(key);
                instagramDetailRetryCounts.remove(key);
            }
            activeLoadSequence = ++loadSequence;
            activeNavigationSequence = 0L;
            activeLoadStarted = false;
            activePageFinished = false;
            activeStartedGeneration = -1L;
            activeRequestedUrl = "";
            activeStartedUrl = "";
            activeInstagramDetailCollectionStarted = false;
            detailCount++;
            if (INSTAGRAM_SPA_AUTO_CLICK) {
                returnInstagramSpaToProfile(node, () -> {
                    current = null;
                    handler.postDelayed(this::loadNext, 250L);
                });
            } else {
                current = null;
                handler.postDelayed(this::loadNext, INSTAGRAM_BROWSER_NAV_DELAY_MS);
            }
            return true;
        }

        int queueBefore = queue.size();
        DiagnosticLog.log("SNS_IG_POST_RETRY_DEFER attempt=" + attempt
                + " reason=" + reason + " queueBefore=" + queueBefore
                + " restartFrom=1 url=" + node.url);
        listener.onProgressPulse("SNS_IG_POST_RETRY_DEFER");
        listener.onStatus("Instagram投稿を後で再試行  " + node.url);
        try { webView.stopLoading(); } catch (Exception ignored) {}
        if (!key.isEmpty()) {
            instagramCarouselSlideByPost.put(key, 1);
            instagramResumeSlideByPost.remove(key);
            instagramSlideStartedAtByPost.put(key, System.currentTimeMillis());
            instagramPostsWithNetworkVideo.remove(key);
            instagramPostsWithCapturedVideo.remove(key);
            instagramNetworkVideoCandidates.remove(key);
            instagramTerminalCandidateByPost.remove(key);
            instagramTerminalConfirmCountByPost.remove(key);
            final String consumedPrefix = key + "|";
            instagramConsumedNetworkVideoCandidates.removeIf(v -> v != null && v.startsWith(consumedPrefix));
        }
        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = "";
        activeStartedUrl = "";
        activeInstagramDetailCollectionStarted = false;
        activeInstagramLastMeaningfulProgressAt = System.currentTimeMillis();
        instagramCompletionCandidateAt = 0L;
        instagramCompletionWaitScheduled = false;
        queue.addLast(new Node(node.url, node.depth, true));
        long delay = queueBefore > 0 ? 120L : INSTAGRAM_RETRY_DEFER_DELAY_MS;
        if (INSTAGRAM_SPA_AUTO_CLICK) {
            returnInstagramSpaToProfile(node, () -> {
                current = null;
                handler.postDelayed(this::loadNext, delay);
            });
        } else {
            current = null;
            handler.postDelayed(this::loadNext, delay);
        }
        return true;
    }

    private void finishInstagramCarousel(long run, long load, long nav, Node node, String reason) {
        if (!isActive(run, load, nav, node)) return;
        DiagnosticLog.log("SNS_IG_CAROUSEL_DONE reason=" + reason + " url=" + node.url);
        boolean completed = "last_slide_confirmed".equals(reason) || "reel_captured".equals(reason);
        if (!completed) {
            restartInstagramPostFromBeginning(node, load, "carousel_" + reason);
            return;
        }
        String completedUrl = canonicalInstagramPostUrl(node.url);
        if (!completedUrl.isEmpty()) {
            instagramCompletedPostUrls.add(completedUrl);
            instagramSkippedPostUrls.remove(completedUrl);
            instagramContinuationPendingUrls.remove(completedUrl);
            instagramDetailRetryCounts.remove(completedUrl);
            instagramResumeSlideByPost.remove(completedUrl);
            instagramTerminalCandidateByPost.remove(completedUrl);
            instagramTerminalConfirmCountByPost.remove(completedUrl);
        }
        listener.onProgressPulse("SNS_IG_CAROUSEL_DONE");
        detailCount++;
        if (instagramStreamingMode) {
            returnInstagramSpaToProfile(node, () -> resumeInstagramProfileStream("post_done"));
        } else if (INSTAGRAM_SPA_AUTO_CLICK) {
            returnInstagramSpaToProfile(node, () -> {
                current = null;
                loadNext();
            });
        } else {
            current = null;
            loadNext();
        }
    }

    private static String buildInstagramCarouselInspectScript() {
        return "(function(){try{" +
                "const abs=(u)=>{try{if(!u||/^(data:|blob:|javascript:|#)/i.test(u))return '';return new URL(u,document.baseURI).href}catch(e){return ''}};" +
                "const uniq=(a)=>Array.from(new Set(a.filter(Boolean)));" +
                "const visible=(e)=>{try{let r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&parseFloat(s.opacity||'1')>0}catch(x){return false}};" +
                "const signed=(u)=>{try{let x=new URL(u,document.baseURI),h=x.hostname||'';if(!/(cdninstagram\\.com|fbcdn\\.net)/i.test(h))return true;return x.searchParams.has('oh')&&x.searchParams.has('oe')}catch(e){return false}};" +
                "const srcInfo=(i)=>{let best='',bw=0,fallback='',fw=0,ss=i.getAttribute('srcset')||i.getAttribute('data-srcset')||'';if(ss){ss.split(',').forEach(p=>{let z=p.trim().split(/\\s+/),u=abs(z[0]);if(!u)return;let d=z[1]||'',w=0;if(/^[0-9.]+w$/i.test(d))w=parseFloat(d);else if(/^[0-9.]+x$/i.test(d))w=(i.clientWidth||i.width||640)*parseFloat(d);if(!fallback||w>=fw){fallback=u;fw=w}if(signed(u)&&(!best||w>=bw)){best=u;bw=w}});}let live=[i.currentSrc,i.src,i.getAttribute('data-original'),i.getAttribute('data-src')].map(abs).filter(Boolean);if(!best)best=live.find(signed)||fallback||live[0]||'';return {u:best,w:bw||fw||i.naturalWidth||i.width||0,h:i.naturalHeight||i.height||0}};" +
                "let scope=document.querySelector('[role=dialog] article')||document.querySelector('main article')||document.querySelector('article')||document.querySelector('main')||document.body;" +
                "let images=[],imageMeta=[],videos=[],streams=[],videoKeys=[],mediaRects=[],videoVisible=false;" +
                "scope.querySelectorAll('img').forEach(i=>{let z=srcInfo(i),u=z.u;if(!u||!/(cdninstagram\\.com|fbcdn\\.net)/i.test(u))return;let r=i.getBoundingClientRect(),nw=i.naturalWidth||z.w||0,nh=i.naturalHeight||z.h||0,dim=Math.max(nw,nh,r.width||0,r.height||0);if(dim<240)return;let likelyAvatar=(Math.max(r.width||0,r.height||0)<=180&&Math.max(nw,nh)<=320&&!i.closest('ul'));if(likelyAvatar)return;images.push(u);imageMeta.push({u:u,w:Math.round(nw||r.width||0),h:Math.round(nh||r.height||0)});if(visible(i)&&Math.max(r.width,r.height)>=180)mediaRects.push({l:r.left,t:r.top,r:r.right,b:r.bottom,a:r.width*r.height})});" +
                "scope.querySelectorAll('video').forEach(v=>{let r=v.getBoundingClientRect(),vv=visible(v)&&Math.max(r.width,r.height)>=180;if(!vv)return;videoVisible=true;mediaRects.push({l:r.left,t:r.top,r:r.right,b:r.bottom,a:r.width*r.height});let pk=abs(v.poster);if(pk)videoKeys.push(pk);[v.currentSrc,v.src,v.getAttribute('src')].map(abs).filter(Boolean).forEach(u=>{if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);else if(/\\.mp4(\\?|$)/i.test(u))videos.push(u)})});" +
                "scope.querySelectorAll('video source,source[type^=\\\"video/\\\"]').forEach(s=>{let v=s.closest&&s.closest('video');if(v){let r=v.getBoundingClientRect();if(!visible(v)||Math.max(r.width,r.height)<180)return;}let u=abs(s.src||s.getAttribute('src'));if(u){if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);else if(/\\.mp4(\\?|$)/i.test(u))videos.push(u)}});" +
                "const label=(b)=>[((b.getAttribute&&b.getAttribute('aria-label'))||''),((b.getAttribute&&b.getAttribute('title'))||''),(b.innerText||''),Array.from(b.querySelectorAll?b.querySelectorAll('svg'):[]).map(s=>(s.getAttribute('aria-label')||s.getAttribute('title')||'')).join(' ')].join(' ').replace(/\\s+/g,' ').trim();" +
                "const bad=(b)=>/(previous|back|戻る|前へ|音源|ミュート|mute|audio|再生|pause|play|閉じる|close|いいね|like|コメント|comment|シェア|share)/i.test(label(b));" +
                "const climb=(e)=>{for(let n=e,d=0;n&&d<7;n=n.parentElement,d++){if(n.matches&&n.matches('button,[role=button]'))return n}return null};" +
                "let raw=Array.from(document.querySelectorAll('button,[role=button],[aria-label],[title],svg[aria-label]')),btns=[];raw.forEach(e=>{let b=(e.matches&&e.matches('button,[role=button]'))?e:climb(e);if(b&&visible(b)&&!bad(b)&&!btns.includes(b))btns.push(b)});let hintRaw=Array.from(scope.querySelectorAll('button,[role=button],[aria-label],[title],svg[aria-label]'));let carouselHint=hintRaw.some(e=>{let b=(e.matches&&e.matches('button,[role=button]'))?e:(climb(e)||e),t=label(b);return /(next|previous|次へ|次の写真|次の画像|前へ)/i.test(t)});let next=null,nextMethod='none';" +
                "next=btns.find(b=>/(^|\\s)(next|次へ|次の写真|次の画像|次)(\\s|$)/i.test(label(b))&&!/(previous|back|戻る|前へ|音源|ミュート|mute|audio|再生|pause|play)/i.test(label(b)));if(next)nextMethod='label';" +
                "let outI=uniq(images),outV=uniq(videos),outS=uniq(streams);let key=outI.concat(outV).concat(outS).concat(uniq(videoKeys)).join('|');if(!key&&mediaRects.length)key=mediaRects.map(r=>[Math.round(r.l),Math.round(r.t),Math.round(r.r),Math.round(r.b)].join(',')).join('|');" +
                "return JSON.stringify({images:outI,imageMeta:imageMeta,videos:outV,streams:outS,videoVisible:videoVisible,next:!!next,nextMethod:nextMethod,carouselHint:carouselHint,key:key});" +
                "}catch(e){return JSON.stringify({images:[],imageMeta:[],videos:[],streams:[],videoVisible:false,next:false,nextMethod:'error',carouselHint:false,key:'',error:String(e)})}})()";
    }

    private static String buildInstagramCarouselClickScript() {
        return "(function(){try{" +
                "const visible=(e)=>{try{let r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'}catch(x){return false}};" +
                "const label=(b)=>[((b.getAttribute&&b.getAttribute('aria-label'))||''),((b.getAttribute&&b.getAttribute('title'))||''),(b.innerText||''),Array.from(b.querySelectorAll?b.querySelectorAll('svg'):[]).map(s=>(s.getAttribute('aria-label')||s.getAttribute('title')||'')).join(' ')].join(' ').replace(/\\s+/g,' ').trim();" +
                "const bad=(b)=>/(previous|back|戻る|前へ|音源|ミュート|mute|audio|再生|pause|play|閉じる|close|いいね|like|コメント|comment|シェア|share)/i.test(label(b));" +
                "const climb=(e)=>{for(let n=e,d=0;n&&d<7;n=n.parentElement,d++){if(n.matches&&n.matches('button,[role=button]'))return n}return null};" +
                "let scope=document.querySelector('[role=dialog] article')||document.querySelector('main article')||document.querySelector('article')||document.querySelector('main')||document.body;" +
                "let media=Array.from(scope.querySelectorAll('img,video')).filter(e=>{if(!visible(e))return false;let r=e.getBoundingClientRect();return Math.max(r.width,r.height)>=180}).map(e=>{let r=e.getBoundingClientRect();return {l:r.left,t:r.top,r:r.right,b:r.bottom,a:r.width*r.height}}).sort((a,b)=>b.a-a.a);" +
                "let raw=Array.from(document.querySelectorAll('button,[role=button],[aria-label],[title],svg[aria-label]')),btns=[];raw.forEach(e=>{let b=(e.matches&&e.matches('button,[role=button]'))?e:climb(e);if(b&&visible(b)&&!bad(b)&&!btns.includes(b))btns.push(b)});let next=null,method='none';" +
                "next=btns.find(b=>/(^|\\s)(next|次へ|次の写真|次の画像|次)(\\s|$)/i.test(label(b))&&!/(previous|back|戻る|前へ|音源|ミュート|mute|audio|再生|pause|play)/i.test(label(b)));if(next)method='label';" +
                "if(!next)return JSON.stringify({clicked:false,method:'none',label:''});let txt=label(next);try{next.scrollIntoView({block:'center',inline:'center'});}catch(e){};" +
                "try{let r=next.getBoundingClientRect(),x=(r.left+r.right)/2,y=(r.top+r.bottom)/2;['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>{try{let C=t.indexOf('pointer')===0&&window.PointerEvent?PointerEvent:MouseEvent;next.dispatchEvent(new C(t,{view:window,bubbles:true,cancelable:true,clientX:x,clientY:y,pointerType:'touch'}))}catch(e){}});return JSON.stringify({clicked:true,method:method+'-events',label:txt})}catch(e){try{next.click();return JSON.stringify({clicked:true,method:method+'-click',label:txt})}catch(x){return JSON.stringify({clicked:false,method:method,label:txt,error:String(x)})}}" +
                "}catch(e){return JSON.stringify({clicked:false,method:'error',label:'',error:String(e)})}})()";
    }

    private void captureInstagramVideoNetworkRequest(String rawUrl) {
        if (rawUrl == null || rawUrl.isEmpty()) return;
        Node active = current;
        if (active == null || !active.detail || !isInstagramPostUrl(active.url)) return;
        final String ref = canonicalInstagramPostUrl(active.url);
        if (ref.isEmpty()) return;

        String u = cleanUrl(rawUrl);
        if (!isHttp(u)) return;
        String lower = u.toLowerCase(Locale.ROOT);
        if (!(lower.contains("cdninstagram.com") || lower.contains("fbcdn.net"))) return;
        final MediaItem.Kind kind;
        if (lower.matches(".*\\.(m3u8|mpd)(\\?.*)?$")) kind = MediaItem.Kind.STREAM;
        else if (lower.matches(".*\\.mp4(\\?.*)?$")) kind = MediaItem.Kind.VIDEO;
        else return;

        if (kind == MediaItem.Kind.VIDEO && isInstagramAudioOnlyUrl(u)) {
            DiagnosticLog.log("SNS_IG_AUDIO_NETWORK_SKIP url=" + u);
            return;
        }
        if (kind == MediaItem.Kind.VIDEO && isInstagramAdvertisingVideoUrl(u)) {
            DiagnosticLog.log("SNS_IG_AD_VIDEO_NETWORK_SKIP asset=" + instagramVideoAssetId(u)
                    + " tag=" + instagramVideoTag(u) + " ref=" + ref);
            return;
        }
        String normalized = kind == MediaItem.Kind.VIDEO ? normalizeInstagramVideoUrl(u) : u;
        if (normalized.isEmpty()) return;
        final String mediaUrl = normalized;
        final boolean normalizedRange = !stripFragment(u).equals(stripFragment(mediaUrl));

        handler.post(() -> {
            if (cancelled || doneEmitted || !isInstagramLikeHost(rootHost)) return;
            instagramLastNetworkMediaAt = System.currentTimeMillis();
            instagramPostsWithNetworkVideo.add(ref);
            if (instagramCompletionCandidateAt > 0L) {
                DiagnosticLog.log("SNS_IG_COMPLETION_ACTIVITY_AFTER_CANDIDATE ref=" + ref);
            }
            if (normalizedRange) {
                DiagnosticLog.log("SNS_IG_VIDEO_RANGE_NORMALIZE from=" + u + " to=" + mediaUrl);
            }
            String candidateKey = instagramVideoCandidateKey(mediaUrl);
            LinkedHashMap<String, InstagramVideoCandidate> candidates =
                    instagramNetworkVideoCandidates.computeIfAbsent(ref, k -> new LinkedHashMap<>());
            if (!candidates.containsKey(candidateKey)) {
                candidates.put(candidateKey, new InstagramVideoCandidate(candidateKey, mediaUrl, kind, System.currentTimeMillis()));
                markInstagramMeaningfulProgress("network_video_candidate");
                DiagnosticLog.log("SNS_IG_VIDEO_NETWORK_QUEUE key=" + candidateKey
                        + " kind=" + kind.name() + " ref=" + ref + " url=" + mediaUrl);
                listener.onProgressPulse("SNS_IG_VIDEO_NETWORK_QUEUE");
            }
        });
    }

    private static String instagramVideoCandidateKey(String raw) {
        String asset = instagramVideoAssetId(raw);
        if (!asset.isEmpty()) return "asset:" + asset;
        String clean = stripFragment(cleanUrl(raw));
        try {
            URI uri = new URI(clean);
            String path = uri.getPath() == null ? "" : uri.getPath();
            if (!path.isEmpty()) return "path:" + path;
        } catch (Exception ignored) {}
        int q = clean.indexOf('?');
        return "url:" + (q >= 0 ? clean.substring(0, q) : clean);
    }

    private static String mediaDedupKey(MediaItem.Kind kind, String url, String referrer) {
        String clean = stripFragment(cleanUrl(url));
        if (kind == MediaItem.Kind.IMAGE) {
            String imageIdentity = instagramImageIdentity(clean);
            if (!imageIdentity.isEmpty()) return kind.name() + "|IG|" + imageIdentity;
        }
        if ((kind == MediaItem.Kind.VIDEO || kind == MediaItem.Kind.STREAM) && isInstagramPostUrl(referrer)) {
            if (kind == MediaItem.Kind.VIDEO) {
                String asset = instagramVideoAssetId(clean);
                if (!asset.isEmpty()) return kind.name() + "|IG|asset:" + asset;
            }
            try {
                URI u = new URI(clean);
                String path = u.getPath() == null ? "" : u.getPath();
                if (!path.isEmpty()) return kind.name() + "|IG|path:" + path;
            } catch (Exception ignored) {}
            int q = clean.indexOf('?');
            return kind.name() + "|IG|url:" + (q >= 0 ? clean.substring(0, q) : clean);
        }
        return kind.name() + "|" + clean;
    }

    private static String instagramImageIdentity(String rawUrl) {
        String clean = stripFragment(cleanUrl(rawUrl));
        if (!isHttp(clean)) return "";
        try {
            URI uri = new URI(clean);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!(host.contains("cdninstagram.com") || host.contains("fbcdn.net"))) return "";

            String cache = decodeQueryComponent(rawQueryValue(clean, "ig_cache_key")).trim();
            if (!cache.isEmpty()) return "cache:" + cache;

            String path = uri.getPath() == null ? "" : uri.getPath();
            int slash = path.lastIndexOf('/');
            String file = slash >= 0 ? path.substring(slash + 1) : path;
            if (!file.isEmpty()) return "file:" + file;
        } catch (Exception ignored) {
        }
        return "";
    }

    private static JSONObject instagramVideoEfg(String raw) {
        String efg = rawQueryValue(raw, "efg");
        if (efg.isEmpty()) return null;
        try {
            String decoded = URLDecoder.decode(efg, "UTF-8");
            byte[] bytes;
            try {
                bytes = Base64.decode(decoded, Base64.DEFAULT);
            } catch (Throwable ignored) {
                bytes = Base64.decode(decoded, Base64.URL_SAFE | Base64.NO_WRAP);
            }
            return new JSONObject(new String(bytes, StandardCharsets.UTF_8));
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static String instagramVideoAssetId(String raw) {
        JSONObject obj = instagramVideoEfg(raw);
        if (obj == null) return "";
        Object v = obj.opt("xpv_asset_id");
        if (v == null || v == JSONObject.NULL) v = obj.opt("asset_id");
        return v == null || v == JSONObject.NULL ? "" : String.valueOf(v);
    }

    private static String instagramVideoTag(String raw) {
        JSONObject obj = instagramVideoEfg(raw);
        return obj == null ? "" : obj.optString("vencode_tag", "").toLowerCase(Locale.ROOT);
    }

    private static boolean isInstagramAdvertisingVideoUrl(String raw) {
        String tag = instagramVideoTag(raw);
        // Instagram currently marks sponsored/ad video encodes with an explicit ".ad." segment.
        // Keep this deliberately narrow so ordinary adaptive/DASH video is not discarded.
        return tag.contains(".ad.");
    }

    private static boolean isInstagramVideoCoverFrameUrl(String raw) {
        JSONObject obj = instagramVideoEfg(raw);
        if (obj == null) return false;
        String tag = obj.optString("vencode_tag", "").toLowerCase(Locale.ROOT);
        return tag.contains("video_default_cover_frame");
    }

    private static String normalizeInstagramVideoUrl(String raw) {
        String u = cleanUrl(raw);
        int q = u.indexOf('?');
        if (q < 0) return u;
        String base = u.substring(0, q);
        String query = u.substring(q + 1);
        StringBuilder kept = new StringBuilder();
        for (String part : query.split("&")) {
            if (part == null || part.isEmpty()) continue;
            int eq = part.indexOf('=');
            String key = eq >= 0 ? part.substring(0, eq) : part;
            String decoded = decodeQueryComponent(key);
            if (decoded.equalsIgnoreCase("bytestart") || decoded.equalsIgnoreCase("byteend")) continue;
            if (kept.length() > 0) kept.append('&');
            kept.append(part);
        }
        return kept.length() == 0 ? base : base + "?" + kept;
    }

    private static boolean isInstagramAudioOnlyUrl(String raw) {
        String tag = instagramVideoTag(raw);
        return tag.contains("audio") || tag.contains("heaac") || tag.contains("aac");
    }

    private static String instagramResolverSignatureProblem(InstagramMediaResolver.Result result, boolean checkImages) {
        if (result == null) return "result_null";
        if (checkImages) {
            for (InstagramMediaResolver.Image image : result.images) {
                if (image != null && !image.url.isEmpty() && isUnsignedInstagramCdnAsset(image.url)) {
                    return "image_missing_oh_oe identity=" + instagramImageIdentity(image.url);
                }
            }
        }
        for (String video : result.videos) {
            if (video != null && !video.isEmpty() && isUnsignedInstagramCdnAsset(video)) {
                return "video_missing_oh_oe asset=" + instagramVideoAssetId(video);
            }
        }
        return "";
    }

    private static boolean isUnsignedInstagramCdnAsset(String raw) {
        String clean = stripFragment(cleanUrl(raw));
        if (!isHttp(clean)) return false;
        try {
            URI uri = new URI(clean);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!(host.contains("cdninstagram.com") || host.contains("fbcdn.net"))) return false;
            String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
            if (!(path.endsWith(".jpg") || path.endsWith(".jpeg") || path.endsWith(".png")
                    || path.endsWith(".webp") || path.endsWith(".mp4"))) return false;
            String oh = rawQueryValue(clean, "oh");
            String oe = rawQueryValue(clean, "oe");
            return oh.isEmpty() || oe.isEmpty();
        } catch (Exception ignored) {
            return false;
        }
    }

    private static String rawQueryValue(String raw, String wantedKey) {
        if (raw == null || wantedKey == null) return "";
        int q = raw.indexOf('?');
        if (q < 0 || q + 1 >= raw.length()) return "";
        String query = raw.substring(q + 1);
        int hash = query.indexOf('#');
        if (hash >= 0) query = query.substring(0, hash);
        for (String part : query.split("&")) {
            int eq = part.indexOf('=');
            String key = eq >= 0 ? part.substring(0, eq) : part;
            if (decodeQueryComponent(key).equalsIgnoreCase(wantedKey)) {
                return eq >= 0 ? part.substring(eq + 1) : "";
            }
        }
        return "";
    }

    private static String sanitizeDiagnosticText(String s) {
        if (s == null) return "";
        return s.replace('\n', ' ').replace('\r', ' ').replaceAll("\\s+", " ").trim();
    }

    private static boolean isXStatusUrl(String url) {
        if (url == null || url.isEmpty()) return false;
        try {
            URI u = new URI(url);
            String host = u.getHost() == null ? "" : u.getHost();
            if (!isXLikeHost(host)) return false;
            String path = u.getPath() == null ? "" : u.getPath();
            return path.matches("^/[^/]+/status/\\d+/?$");
        } catch (Exception e) {
            return false;
        }
    }

    private void processMediaArray(JSONArray array, MediaItem.Kind kind, String referrer, boolean fromDetail) throws JSONException {
        if (array == null) return;
        if (kind == MediaItem.Kind.IMAGE && !wantImages) return;
        if ((kind == MediaItem.Kind.VIDEO || kind == MediaItem.Kind.STREAM) && !wantVideos) return;
        for (int i = 0; i < array.length(); i++) {
            String raw = array.optString(i, "");
            if (kind == MediaItem.Kind.IMAGE && !fromDetail) {
                String k = imageKey(raw);
                if (!k.isEmpty() && provisionalImages.containsKey(k)) {
                    DiagnosticLog.log("IMAGE_PROVISIONAL_PROBE url=" + cleanUrl(raw) + " ref=" + referrer);
                }
            }
            addMediaUrl(raw, kind, referrer, null);
        }
    }

    private boolean addMediaUrl(String rawUrl, MediaItem.Kind kind, String referrer, String sourceLogPrefix) {
        return addMediaUrl(rawUrl, kind, referrer, sourceLogPrefix, "");
    }

    private boolean addMediaUrl(String rawUrl, MediaItem.Kind kind, String referrer, String sourceLogPrefix, String forcedDedupKey) {
        String u = cleanUrl(rawUrl);
        if (kind == MediaItem.Kind.IMAGE) u = normalizeSnsImageUrl(u);
        if (kind == MediaItem.Kind.VIDEO && isInstagramLikeHost(rootHost)) {
            if (isInstagramAudioOnlyUrl(u)) {
                DiagnosticLog.log("SNS_IG_AUDIO_MEDIA_SKIP url=" + u);
                return false;
            }
            if (isInstagramAdvertisingVideoUrl(u)) {
                DiagnosticLog.log("SNS_IG_AD_VIDEO_SKIP asset=" + instagramVideoAssetId(u)
                        + " tag=" + instagramVideoTag(u) + " ref=" + referrer);
                return false;
            }
            u = normalizeInstagramVideoUrl(u);
        }
        if (!isHttp(u)) return false;
        if (kind == MediaItem.Kind.IMAGE && !wantImages) return false;
        if ((kind == MediaItem.Kind.VIDEO || kind == MediaItem.Kind.STREAM) && !wantVideos) return false;
        if (kind == MediaItem.Kind.IMAGE) {
            if (isXLikeHost(rootHost) && !u.toLowerCase(Locale.ROOT).contains("pbs.twimg.com/media/")) {
                DiagnosticLog.log("SNS_X_NON_POST_IMAGE_SKIP url=" + u);
                return false;
            }
            if (isLikelyTrackingImage(u)) {
                DiagnosticLog.log("MEDIA_SKIP_TRACKER url=" + u);
                return false;
            }
            return queueImageCandidate(u, referrer, sourceLogPrefix);
        }

        String key = forcedDedupKey == null || forcedDedupKey.isEmpty()
                ? mediaDedupKey(kind, u, referrer) : forcedDedupKey;
        if (!mediaSeen.add(key)) {
            if (kind == MediaItem.Kind.VIDEO && isInstagramPostUrl(referrer)) {
                DiagnosticLog.log("SNS_IG_VIDEO_DUPLICATE_SKIP key=" + key + " url=" + u);
            }
            return false;
        }
        MediaItem item = new MediaItem(u, referrer, kind, false, 0, 0, 0L, key, instagramDisplayOrder(referrer));
        DiagnosticLog.log("MEDIA_FOUND kind=" + kind.name() + " key=" + key + " url=" + u + " ref=" + referrer);
        if (kind == MediaItem.Kind.VIDEO && isInstagramPostUrl(referrer)) {
            DiagnosticLog.log("MEDIA_QUEUED kind=VIDEO key=" + key + " url=" + u + " ref=" + referrer);
        }
        if (kind == MediaItem.Kind.VIDEO) videoCount++; else streamCount++;
        listener.onItem(item);
        return true;
    }

    private void holdProvisionalImage(String rawUrl, String referrer) {
        String u = cleanUrl(rawUrl);
        String key = imageKey(u);
        if (key.isEmpty() || isLikelyTrackingImage(u)) return;
        if (!provisionalImages.containsKey(key)) {
            provisionalImages.put(key, new ImageCandidate(u, referrer, "IMAGE_PROVISIONAL_FALLBACK"));
            DiagnosticLog.log("IMAGE_PROVISIONAL_ADD url=" + u + " ref=" + referrer);
        }
    }

    private void mapReplacement(Map<String, Set<String>> map, String replacementKey, String thumbKey) {
        if (replacementKey == null || replacementKey.isEmpty() || thumbKey == null || thumbKey.isEmpty()) return;
        Set<String> values = map.get(replacementKey);
        if (values == null) {
            values = new HashSet<>();
            map.put(replacementKey, values);
        }
        values.add(thumbKey);
    }

    private boolean queueImageCandidate(String rawUrl, String referrer, String sourceLogPrefix) {
        String u = cleanUrl(rawUrl);
        String key = imageKey(u);
        if (key.isEmpty()) return false;
        if (isLikelyTrackingImage(u)) {
            DiagnosticLog.log("MEDIA_SKIP_TRACKER url=" + u);
            return false;
        }
        if (isInstagramLikeHost(rootHost) && isInstagramPostUrl(referrer)) {
            return emitQueuedInstagramImage(u, referrer, sourceLogPrefix, 0, 0);
        }
        if (!imageCandidateSeen.add(key)) return false;

        final long run = generation;
        final String cookie;
        try {
            cookie = SessionCookies.getCookie(u);
        } catch (Exception e) {
            DiagnosticLog.log("IMAGE_PROBE_COOKIE_FAIL url=" + u + " error=" + e.getClass().getSimpleName());
            pendingImageProbes++;
            imageProbeExecutor.submit(() -> runImageProbe(run, u, referrer, sourceLogPrefix, null));
            return true;
        }
        pendingImageProbes++;
        DiagnosticLog.log("IMAGE_PROBE_QUEUE target=" + targetImagePx + " url=" + u + " ref=" + referrer);
        listener.onProgressPulse("IMAGE_PROBE_QUEUE");
        imageProbeExecutor.submit(() -> runImageProbe(run, u, referrer, sourceLogPrefix, cookie));
        return true;
    }

    private void runImageProbe(long run, String u, String referrer, String sourceLogPrefix, String cookie) {
        int[] size = null;
        Exception failure = null;
        try {
            size = probeImageSize(u, referrer, cookie);
        } catch (Exception e) {
            failure = e;
        }
        final int[] result = size;
        final Exception error = failure;
        handler.post(() -> {
            if (cancelled || generation != run) return;
            pendingImageProbes = Math.max(0, pendingImageProbes - 1);
            listener.onProgressPulse("IMAGE_PROBE_DONE");
            String candidateKey = imageKey(u);
            boolean provisional = !candidateKey.isEmpty() && provisionalImages.containsKey(candidateKey);
            if (error != null || result == null || result[0] <= 0 || result[1] <= 0) {
                DiagnosticLog.log("IMAGE_REJECT_PROBE_FAIL target=" + targetImagePx + " url=" + u
                        + " error=" + (error == null ? "unknown_size" : error.getClass().getSimpleName()));
                if (isInstagramLikeHost(rootHost) && error instanceof UnknownHostException) {
                    instagramUnknownHostProbeFailures++;
                    markIncomplete("instagram_cdn_dns");
                }
                if (provisional) unresolvedProvisionalThumbs.add(candidateKey);
            } else {
                int w = result[0], h = result[1];
                if (Math.max(w, h) < targetImagePx) {
                    DiagnosticLog.log("IMAGE_REJECT_LOW_RES size=" + w + "x" + h
                            + " target=" + targetImagePx + " url=" + u);
                    if (provisional) unresolvedProvisionalThumbs.add(candidateKey);
                } else if (provisional) {
                    acceptedProvisionalSizes.put(candidateKey, new int[]{w, h});
                    DiagnosticLog.log("IMAGE_PROVISIONAL_READY size=" + w + "x" + h
                            + " target=" + targetImagePx + " url=" + u);
                } else {
                    emitAcceptedImage(u, referrer, sourceLogPrefix, w, h);
                }
            }
            maybeFinishAfterImageProbes();
        });
    }

    private boolean emitQueuedInstagramImage(String url, String referrer, String sourceLogPrefix, int width, int height) {
        String u = normalizeSnsImageUrl(cleanUrl(url));
        if (!isHttp(u)) return false;
        String candidateKey = imageKey(u);
        if (isInstagramVideoCoverFrameUrl(u)) {
            if (!candidateKey.isEmpty()) imageCandidateSeen.add(candidateKey);
            DiagnosticLog.log("SNS_IG_VIDEO_COVER_SKIP url=" + u + " ref=" + referrer);
            return false;
        }
        if (candidateKey.isEmpty() || !imageCandidateSeen.add(candidateKey)) return false;
        String mediaKey = mediaDedupKey(MediaItem.Kind.IMAGE, u, referrer);
        if (!mediaSeen.add(mediaKey)) {
            DiagnosticLog.log("SNS_IG_IMAGE_DUPLICATE_SKIP key=" + mediaKey + " url=" + u);
            return false;
        }
        suppressReplacedThumbnails(u, referrer);
        MediaItem item = new MediaItem(u, referrer, MediaItem.Kind.IMAGE, false, width, height, 0L, mediaKey, instagramDisplayOrder(referrer));
        DiagnosticLog.log("MEDIA_QUEUED kind=IMAGE size=" + width + "x" + height + " url=" + u + " ref=" + referrer);
        if (sourceLogPrefix != null && !sourceLogPrefix.isEmpty()) {
            DiagnosticLog.log(sourceLogPrefix + " queued=" + u + " size=" + width + "x" + height);
        }
        imageCount++;
        listener.onItem(item);
        return true;
    }

    private void emitAcceptedImage(String url, String referrer, String sourceLogPrefix, int width, int height) {
        String mediaKey = mediaDedupKey(MediaItem.Kind.IMAGE, url, referrer);
        if (!mediaSeen.add(mediaKey)) {
            if (!instagramImageIdentity(url).isEmpty()) {
                DiagnosticLog.log("SNS_IG_IMAGE_DUPLICATE_SKIP key=" + mediaKey + " url=" + url);
            }
            return;
        }
        suppressReplacedThumbnails(url, referrer);
        MediaItem item = new MediaItem(url, referrer, MediaItem.Kind.IMAGE, false, width, height, 0L, mediaKey, instagramDisplayOrder(referrer));
        DiagnosticLog.log("MEDIA_FOUND kind=IMAGE size=" + width + "x" + height + " url=" + url + " ref=" + referrer);
        if (sourceLogPrefix != null && !sourceLogPrefix.isEmpty()) {
            DiagnosticLog.log(sourceLogPrefix + " image=" + url + " size=" + width + "x" + height);
        }
        imageCount++;
        listener.onItem(item);
    }

    private void suppressReplacedThumbnails(String acceptedUrl, String referrer) {
        Set<String> direct = replacementToProvisionalThumbs.get(imageKey(acceptedUrl));
        if (direct != null) suppressedProvisionalThumbs.addAll(direct);
        Set<String> detail = detailToProvisionalThumbs.get(stripFragment(cleanUrl(referrer)));
        if (detail != null) suppressedProvisionalThumbs.addAll(detail);
    }

    private void maybeFinishAfterImageProbes() {
        if (cancelled || doneEmitted || pendingImageProbes > 0 || current != null || !queue.isEmpty()) return;

        if (baseTraversalDone && !detailPhaseStarted) {
            startDeferredDetailPhase();
            return;
        }

        if (detailPhaseStarted && detailTraversalDone) {
            finalizeProvisionalImages();
            if (pendingImageProbes == 0) requestEmitDoneWhenQuiet();
        }
    }

    private void requestEmitDoneWhenQuiet() {
        if (cancelled || doneEmitted) return;
        if (!isInstagramLikeHost(rootHost)) {
            emitDone();
            return;
        }
        long now = System.currentTimeMillis();
        if (instagramCompletionCandidateAt <= 0L) {
            instagramCompletionCandidateAt = now;
            DiagnosticLog.log("SNS_IG_COMPLETION_CANDIDATE postsSeen=" + instagramPostUrlsSeen.size()
                    + " queued=" + instagramPostDetailsQueued
                    + " details=" + detailCount
                    + " media=" + (imageCount + videoCount + streamCount));
        }
        long anchor = Math.max(instagramCompletionCandidateAt, instagramLastNetworkMediaAt);
        long wait = INSTAGRAM_NETWORK_QUIET_MS - Math.max(0L, now - anchor);
        if (wait > 0L) {
            if (!instagramCompletionWaitScheduled) {
                instagramCompletionWaitScheduled = true;
                DiagnosticLog.log("SNS_IG_COMPLETION_WAIT quietMs=" + INSTAGRAM_NETWORK_QUIET_MS
                        + " remainingMs=" + wait);
                handler.postDelayed(() -> {
                    instagramCompletionWaitScheduled = false;
                    maybeFinishAfterImageProbes();
                }, wait);
            }
            return;
        }
        emitDone();
    }

    private void startDeferredDetailPhase() {
        if (detailPhaseStarted || cancelled) return;
        detailPhaseStarted = true;
        detailPhaseStartedAt = System.currentTimeMillis();

        int queued = 0;
        int skippedResolved = 0;
        int skippedLimit = 0;
        if (followDetails) {
            for (DeferredDetail d : deferredDetails.values()) {
                boolean needsDetail = d.thumbKeys.isEmpty();
                if (!needsDetail) {
                    for (String thumbKey : d.thumbKeys) {
                        if (suppressedProvisionalThumbs.contains(thumbKey)) continue;
                        if (unresolvedProvisionalThumbs.contains(thumbKey)
                                || !acceptedProvisionalSizes.containsKey(thumbKey)) {
                            needsDetail = true;
                            break;
                        }
                    }
                }
                if (!needsDetail) {
                    skippedResolved++;
                    DiagnosticLog.log("THUMB_DETAIL_SKIP reason=thumb_meets_target href=" + d.url);
                    continue;
                }
                if (queued >= maxDetails) {
                    skippedLimit++;
                    DiagnosticLog.log("THUMB_DETAIL_SKIP reason=detail_limit href=" + d.url);
                    continue;
                }
                if (enqueue(new Node(d.url, 1, true))) {
                    queued++;
                    DiagnosticLog.log("THUMB_DETAIL_QUEUE href=" + d.url);
                }
            }
        }

        DiagnosticLog.log("DETAIL_PHASE_START queued=" + queued
                + " deferred=" + deferredDetails.size()
                + " skippedResolved=" + skippedResolved
                + " skippedLimit=" + skippedLimit
                + " budgetMs=" + (isInstagramLikeHost(rootHost) ? "none" : String.valueOf(DETAIL_PHASE_BUDGET_MS))
                + " timeoutMs=" + (isInstagramLikeHost(rootHost) ? "stall-recovery" : String.valueOf(DETAIL_LOAD_TIMEOUT_MS)));

        if (queue.isEmpty()) {
            detailTraversalDone = true;
            traversalDone = true;
            DiagnosticLog.log("DETAIL_PHASE_DONE details=" + detailCount + " reason=no_pending_detail");
            maybeFinishAfterImageProbes();
        } else {
            if (INSTAGRAM_SPA_AUTO_CLICK && isInstagramLikeHost(rootHost)) {
                DiagnosticLog.log("SNS_IG_SPA_DETAIL_PHASE_READY queued=" + queue.size() + " headless=true");
                listener.onStatus("Instagram投稿を取得中…");
            } else {
                listener.onStatus("必要なサムネイル先だけ追跡中…");
            }
            loadNext();
        }
    }

    private void finalizeProvisionalImages() {
        if (provisionalPhaseStarted) return;
        provisionalPhaseStarted = true;
        for (Map.Entry<String, ImageCandidate> entry : provisionalImages.entrySet()) {
            String key = entry.getKey();
            ImageCandidate c = entry.getValue();
            if (suppressedProvisionalThumbs.contains(key)) {
                DiagnosticLog.log("IMAGE_PROVISIONAL_REPLACED url=" + c.url);
                continue;
            }
            int[] size = acceptedProvisionalSizes.get(key);
            if (size == null || size.length < 2) continue;
            emitAcceptedImage(c.url, c.referrer, c.sourceLogPrefix, size[0], size[1]);
        }
    }

    private void emitDone() {
        if (doneEmitted || cancelled) return;
        if (isInstagramLikeHost(rootHost)) {
            if (instagramPostUrlsSeen.isEmpty()) {
                markIncomplete("instagram_posts_not_found");
            }
            ArrayList<String> unfinished = new ArrayList<>();
            for (String post : instagramPostUrlsSeen) {
                if (!instagramCompletedPostUrls.contains(post)) unfinished.add(post);
            }
            if (!unfinished.isEmpty()) {
                if (instagramStreamingMode) {
                    ArrayList<String> trulyUnfinished = new ArrayList<>();
                    for (String post : unfinished) {
                        if (instagramSkippedPostUrls.contains(post)) continue;
                        if (queuedOrVisited.contains(stripFragment(post))) continue;
                        trulyUnfinished.add(post);
                    }
                    if (!instagramSkippedPostUrls.isEmpty()) {
                        DiagnosticLog.log("SNS_IG_STREAM_FAILED_FINAL count=" + instagramSkippedPostUrls.size());
                    }
                    if (!trulyUnfinished.isEmpty()) {
                        markIncomplete("instagram_stream_unfinished");
                    }
                    DiagnosticLog.log("SNS_IG_STREAM_UNFINISHED seen=" + unfinished.size()
                            + " trulyUnfinished=" + trulyUnfinished.size()
                            + " skipped=" + instagramSkippedPostUrls.size()
                            + " action=no_legacy_requeue");
                } else {
                    DiagnosticLog.log("SNS_IG_UNFINISHED_REQUEUE count=" + unfinished.size());
                    doneEmitted = false;
                    detailTraversalDone = false;
                    traversalDone = false;
                    for (int i = unfinished.size() - 1; i >= 0; i--) {
                        queue.addFirst(new Node(unfinished.get(i), 1, true));
                    }
                    current = null;
                    handler.post(this::loadNext);
                    return;
                }
            }
            if (instagramUnknownHostProbeFailures >= 3 && imageCount == 0) {
                markIncomplete("instagram_cdn_dns");
            }
        }
        doneEmitted = true;
        int visited = pageCount + detailCount;
        DiagnosticLog.log("CRAWLER_DONE pages=" + pageCount + " details=" + detailCount + " visited=" + visited
                + " images=" + imageCount + " videos=" + videoCount + " streams=" + streamCount
                + " incomplete=" + isIncompleteCompletion()
                + " reason=" + getIncompleteCompletionReason());
        listener.onDone(pageTitle, visited, imageCount, videoCount, streamCount);
    }

    private int[] probeImageSize(String imageUrl, String referrer, String cookie) throws Exception {
        Exception last = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(imageUrl).openConnection();
                con.setInstanceFollowRedirects(true);
                con.setConnectTimeout(10000);
                con.setReadTimeout(16000);
                con.setRequestProperty("User-Agent", imageProbeUserAgent == null || imageProbeUserAgent.isEmpty()
                        ? "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36 ImgStalker/0.1.80"
                        : imageProbeUserAgent);
                con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
                con.setRequestProperty("Accept-Encoding", "identity");
                con.setRequestProperty("Sec-Fetch-Dest", "image");
                con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
                if (referrer != null && !referrer.isEmpty()) con.setRequestProperty("Referer", referrer);
                if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
                con.connect();
                int code = con.getResponseCode();
                if (code < 200 || code >= 300) throw new FileNotFoundException("HTTP " + code);
                String type = con.getContentType();
                if (type != null && !type.toLowerCase(Locale.ROOT).startsWith("image/")) {
                    throw new IOException("not image: " + type);
                }
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                try (BufferedInputStream in = new BufferedInputStream(con.getInputStream())) {
                    BitmapFactory.decodeStream(in, null, opts);
                }
                if (opts.outWidth <= 0 || opts.outHeight <= 0) throw new IOException("image bounds unavailable");
                return new int[]{opts.outWidth, opts.outHeight};
            } catch (Exception e) {
                last = e;
                if (attempt == 0) {
                    try { Thread.sleep(150L); } catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        throw interrupted;
                    }
                }
            } finally {
                if (con != null) con.disconnect();
            }
        }
        throw last == null ? new IOException("image size probe failed") : last;
    }

    private static String imageKey(String rawUrl) {
        String u = cleanUrl(rawUrl);
        if (!isHttp(u)) return "";
        String instagramIdentity = instagramImageIdentity(u);
        return instagramIdentity.isEmpty() ? stripFragment(u) : "IG|" + instagramIdentity;
    }

    private void processThumbnailLinks(JSONArray thumbLinks, Node from, String pageUrl) throws JSONException {
        if (!followDetails || thumbLinks == null) return;
        // Base/pagination pages only. Parent pages are deferred until base traversal and
        // image-size probes finish, so we only open detail pages for unresolved thumbnails.
        if (from.detail || from.depth != 0) return;

        for (int i = 0; i < thumbLinks.length(); i++) {
            JSONObject entry = thumbLinks.optJSONObject(i);
            if (entry == null) continue;
            String img = cleanUrl(entry.optString("img", ""));
            String href = cleanUrl(entry.optString("href", ""));
            if (!isHttp(href)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=non_http href=" + href);
                continue;
            }

            DiagnosticLog.log("THUMB_LINK_FOUND img=" + img + " href=" + href);
            String normalizedHref = stripFragment(href);
            String normalizedImg = stripFragment(img);
            if (!normalizedImg.isEmpty() && normalizedHref.equals(normalizedImg)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=same_image href=" + href);
                continue;
            }

            String thumbKey = imageKey(img);
            if (!thumbKey.isEmpty()) holdProvisionalImage(img, pageUrl);

            if (looksDirectImage(href)) {
                mapReplacement(replacementToProvisionalThumbs, imageKey(href), thumbKey);
                boolean queued = addMediaUrl(href, MediaItem.Kind.IMAGE, pageUrl, "THUMB_LINK_RESOLVED");
                if (!queued) DiagnosticLog.log("THUMB_LINK_SKIP reason=duplicate_or_filtered href=" + href);
                continue;
            }

            if (looksDirectMedia(href)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=non_image_media href=" + href);
                continue;
            }

            DeferredDetail d = deferredDetails.get(normalizedHref);
            if (d == null) {
                d = new DeferredDetail(href);
                deferredDetails.put(normalizedHref, d);
                DiagnosticLog.log("THUMB_LINK_DEFER href=" + href);
            }
            if (!thumbKey.isEmpty()) d.thumbKeys.add(thumbKey);
            mapReplacement(detailToProvisionalThumbs, normalizedHref, thumbKey);
        }
    }

    private void processLinks(JSONArray links, Node from) throws JSONException {
        if (links == null) return;
        for (int i = 0; i < links.length(); i++) {
            JSONObject link = links.optJSONObject(i);
            if (link == null) continue;
            String u = cleanUrl(link.optString("url", ""));
            if (!isHttp(u) || !sameHost(u)) continue;
            if (looksDirectMedia(u)) continue;
            boolean pagination = link.optBoolean("pagination", false);
            String paginationKind = link.optString("paginationKind", "");

            // X profile pages are infinite-scroll SPAs. Their reply/repost/like counters are numeric
            // anchors and can look like pagination to the generic detector, causing m.x.com / Play Store
            // detours. Never fan those links out as page navigation; the current page auto-scroll is
            // the only traversal lane for X itself.
            if (pagination && isXLikeHost(rootHost)) {
                DiagnosticLog.log("SNS_X_PAGINATION_SKIP kind="
                        + (paginationKind.isEmpty() ? "unknown" : paginationKind) + " url=" + u);
                continue;
            }

            // Pagination is always a depth=0 lane. Detail pages never fan out to pagination/detail pages.
            if (!from.detail && from.depth == 0 && pagination && followPagination
                    && pageCount + countQueued(false) < maxPages) {
                if (enqueue(new Node(u, 0, false))) {
                    DiagnosticLog.log("QUEUE_PAGE kind=" + (paginationKind.isEmpty() ? "unknown" : paginationKind) + " url=" + u);
                } else {
                    DiagnosticLog.log("PAGE_LINK_SKIP reason=duplicate kind=" + (paginationKind.isEmpty() ? "unknown" : paginationKind) + " url=" + u);
                }
            }
        }
    }

    private int countQueued(boolean detail) {
        int n = 0;
        for (Node q : queue) if (q.detail == detail) n++;
        return n;
    }

    private boolean enqueue(Node node) {
        String key = stripFragment(node.url);
        if (!queuedOrVisited.add(key)) return false;
        queue.add(node);
        return true;
    }

    private void loadNext() {
        if (cancelled) return;
        if (gracefulStopRequested) {
            finishGracefulStopNow("load_next_boundary");
            return;
        }

        if (!isInstagramLikeHost(rootHost) && detailPhaseStarted && !detailTraversalDone && detailPhaseStartedAt > 0L
                && System.currentTimeMillis() - detailPhaseStartedAt >= DETAIL_PHASE_BUDGET_MS) {
            int remaining = queue.size();
            queue.clear();
            current = null;
            detailTraversalDone = true;
            traversalDone = true;
            DiagnosticLog.log("DETAIL_PHASE_BUDGET_END remaining=" + remaining
                    + " elapsedMs=" + (System.currentTimeMillis() - detailPhaseStartedAt));
            if (remaining > 0) markIncomplete(isInstagramLikeHost(rootHost)
                    ? "instagram_detail_budget" : "detail_budget");
            listener.onProgressPulse("DETAIL_PHASE_BUDGET_END");
            listener.onStatus("詳細追跡を時間上限で終了");
            maybeFinishAfterImageProbes();
            return;
        }

        current = queue.poll();
        if (current == null) {
            if (!baseTraversalDone) {
                baseTraversalDone = true;
                DiagnosticLog.log("BASE_TRAVERSAL_DONE pages=" + pageCount
                        + " pendingImageProbes=" + pendingImageProbes
                        + " deferredDetails=" + deferredDetails.size());
                if (pendingImageProbes > 0) listener.onStatus("本画像候補を確認中…");
                maybeFinishAfterImageProbes();
                return;
            }

            if (detailPhaseStarted && !detailTraversalDone) {
                detailTraversalDone = true;
                traversalDone = true;
                DiagnosticLog.log("DETAIL_PHASE_DONE details=" + detailCount
                        + " pendingImageProbes=" + pendingImageProbes);
                if (pendingImageProbes > 0) listener.onStatus("本画像の解像度を確認中…");
                maybeFinishAfterImageProbes();
                return;
            }

            traversalDone = true;
            maybeFinishAfterImageProbes();
            return;
        }

        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = stripFragment(current.url);
        activeStartedUrl = "";
        activeInstagramDetailCollectionStarted = false;
        activeInstagramRequestDiagLogged = false;
        final Node loadNode = current;
        final long loadId = activeLoadSequence;

        DiagnosticLog.log("WEB_LOAD generation=" + generation
                + " load=" + activeLoadSequence
                + " detail=" + current.detail
                + " depth=" + current.depth
                + " url=" + current.url);
        listener.onProgressPulse(current.detail ? "DETAIL_LOAD" : "PAGE_LOAD");
        listener.onStatus((current.detail ? "詳細追跡  " : "ページ追跡  ") + current.url);

        Runnable navigate = () -> {
            if (cancelled || current != loadNode || activeLoadSequence != loadId) return;
            if (loadNode.detail && isInstagramLikeHost(rootHost) && INSTAGRAM_SPA_AUTO_CLICK) {
                navigateInstagramDetailByProfileTap(loadNode, loadId);
                markInstagramMeaningfulProgress("spa_detail_start");
                scheduleInstagramStallWatchdog(generation, loadId, loadNode);
                return;
            }
            navigateNodeBrowserStyle(loadNode);
            if (loadNode.detail) {
                if (isInstagramLikeHost(rootHost)) {
                    markInstagramMeaningfulProgress("detail_load");
                    scheduleInstagramStallWatchdog(generation, loadId, loadNode);
                } else {
                    handler.postDelayed(() -> {
                        if (cancelled || current != loadNode || activeLoadSequence != loadId) return;
                        if (activePageFinished) return;
                        skipCurrentDetail(loadNode, loadId, "load_timeout", DETAIL_LOAD_TIMEOUT_MS);
                    }, DETAIL_LOAD_TIMEOUT_MS);
                }
            }
        };

        if (loadNode.detail && isInstagramLikeHost(rootHost)) {
            DiagnosticLog.log((INSTAGRAM_SPA_AUTO_CLICK ? "SNS_IG_SPA_NAV_WAIT" : "SNS_IG_BROWSER_NAV_WAIT")
                    + " delayMs=" + INSTAGRAM_BROWSER_NAV_DELAY_MS
                    + " url=" + loadNode.url);
            handler.postDelayed(navigate, INSTAGRAM_BROWSER_NAV_DELAY_MS);
        } else {
            navigate.run();
        }
    }

    private void navigateInstagramDetailByProfileTap(Node node, long loadId) {
        if (cancelled || node == null || current != node || activeLoadSequence != loadId) return;
        String target = canonicalInstagramPostUrl(node.url);
        if (target.isEmpty()) {
            restartInstagramPostFromBeginning(node, loadId, "spa_bad_target");
            return;
        }
        instagramSpaTargetUrl = target;
        instagramSpaAwaitingOpen = true;
        instagramSpaReturningToProfile = false;
        instagramSpaTapAttempts = 0;
        DiagnosticLog.log("SNS_IG_SPA_TARGET url=" + target + " live=" + stripFragment(webView.getUrl()));
        findAndTapInstagramAnchor(node, loadId, 0);
    }

    private void clickInstagramAnchorViaJs(Node node, long loadId) {
        if (cancelled || node == null || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
        String target = canonicalInstagramPostUrl(node.url);
        String quoted = JSONObject.quote(target);
        String js = "(function(){try{const t=" + quoted + ";const m=t.match(/\\/(p|reel|tv)\\/([^\\/?#]+)/i);"
                + "const token=m?('/'+m[1]+'/'+m[2]+'/'):'';const a=Array.from(document.querySelectorAll('a[href]')).find(e=>{try{return token&&new URL(e.href,location.href).pathname.indexOf(token)>=0}catch(x){return false}});"
                + "if(!a)return JSON.stringify({clicked:false,reason:'not_found'});try{a.scrollIntoView({block:'center',inline:'center'})}catch(x){};a.click();return JSON.stringify({clicked:true,href:a.href||'',scrollY:Math.round(window.scrollY||0)})"
                + "}catch(e){return JSON.stringify({clicked:false,error:String(e)})}})()";
        webView.evaluateJavascript(js, raw -> {
            if (cancelled || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
            boolean clicked = false;
            try {
                JSONObject click = new JSONObject(unquoteJsResult(raw));
                clicked = click.optBoolean("clicked", false);
                if (clicked) instagramStreamingResumeScrollY = Math.max(0, click.optInt("scrollY", instagramStreamingResumeScrollY));
            } catch (Exception ignored) {}
            DiagnosticLog.log("SNS_IG_SPA_DOM_CLICK clicked=" + clicked + " target=" + target
                    + " raw=" + sanitizeDiagValue(raw));
            listener.onProgressPulse("SNS_IG_SPA_DOM_CLICK");
            if (!clicked) {
                findAndTapInstagramAnchor(node, loadId, 0);
                return;
            }
            handler.postDelayed(() -> {
                if (cancelled || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
                DiagnosticLog.log("SNS_IG_SPA_DOM_CLICK_FALLBACK_NATIVE target=" + target);
                dispatchInstagramNativeTap(node, loadId);
            }, 1200L);
        });
    }

    private void findAndTapInstagramAnchor(Node node, long loadId, int pass) {
        if (cancelled || node == null || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
        if (pass >= INSTAGRAM_SPA_FIND_MAX_PASSES) {
            DiagnosticLog.log("SNS_IG_SPA_ANCHOR_FAIL reason=find_exhausted passes=" + pass + " target=" + instagramSpaTargetUrl);
            restartInstagramPostFromBeginning(node, loadId, "spa_anchor_not_found");
            return;
        }
        final String target = instagramSpaTargetUrl;
        String js = buildInstagramAnchorRectScript(target, true);
        webView.evaluateJavascript(js, raw -> {
            if (cancelled || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
            try {
                JSONObject o = new JSONObject(unquoteJsResult(raw));
                boolean found = o.optBoolean("found", false);
                if (!found) {
                    if (pass == 0 || (pass + 1) % 8 == 0) {
                        DiagnosticLog.log("SNS_IG_SPA_ANCHOR_SEARCH pass=" + (pass + 1)
                                + " y=" + o.optInt("scrollY", 0)
                                + " h=" + o.optInt("scrollH", 0)
                                + " target=" + target);
                    }
                    handler.postDelayed(() -> findAndTapInstagramAnchor(node, loadId, pass + 1), 320L);
                    return;
                }
                instagramStreamingResumeScrollY = Math.max(0, o.optInt("scrollY", instagramStreamingResumeScrollY));
                DiagnosticLog.log("SNS_IG_SPA_ANCHOR_FOUND pass=" + (pass + 1)
                        + " href=" + o.optString("href", "")
                        + " x=" + o.optDouble("x", -1)
                        + " y=" + o.optDouble("y", -1)
                        + " resumeY=" + instagramStreamingResumeScrollY);
                handler.postDelayed(() -> dispatchInstagramNativeTap(node, loadId), 260L);
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_IG_SPA_ANCHOR_PARSE_FAIL target=" + target, e);
                handler.postDelayed(() -> findAndTapInstagramAnchor(node, loadId, pass + 1), 350L);
            }
        });
    }

    private void dispatchInstagramNativeTap(Node node, long loadId) {
        if (cancelled || node == null || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
        final String target = instagramSpaTargetUrl;
        webView.evaluateJavascript(buildInstagramAnchorRectScript(target, false), raw -> {
            if (cancelled || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
            try {
                JSONObject o = new JSONObject(unquoteJsResult(raw));
                if (!o.optBoolean("found", false)) {
                    findAndTapInstagramAnchor(node, loadId, 0);
                    return;
                }
                double cssX = o.optDouble("x", -1);
                double cssY = o.optDouble("y", -1);
                double innerW = Math.max(1.0, o.optDouble("innerW", 1));
                double innerH = Math.max(1.0, o.optDouble("innerH", 1));
                float x = (float) (cssX * Math.max(1, webView.getWidth()) / innerW);
                float y = (float) (cssY * Math.max(1, webView.getHeight()) / innerH);
                x = Math.max(1f, Math.min(Math.max(1, webView.getWidth() - 2), x));
                y = Math.max(1f, Math.min(Math.max(1, webView.getHeight() - 2), y));
                instagramSpaTapAttempts++;
                long downTime = android.os.SystemClock.uptimeMillis();
                android.view.MotionEvent down = android.view.MotionEvent.obtain(downTime, downTime,
                        android.view.MotionEvent.ACTION_DOWN, x, y, 0);
                down.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);
                boolean downHandled = webView.dispatchTouchEvent(down);
                down.recycle();
                final float tapX = x;
                final float tapY = y;
                final int attempt = instagramSpaTapAttempts;
                handler.postDelayed(() -> {
                    if (cancelled || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
                    long upTime = android.os.SystemClock.uptimeMillis();
                    android.view.MotionEvent up = android.view.MotionEvent.obtain(downTime, upTime,
                            android.view.MotionEvent.ACTION_UP, tapX, tapY, 0);
                    up.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);
                    boolean upHandled = webView.dispatchTouchEvent(up);
                    up.recycle();
                    DiagnosticLog.log("SNS_IG_SPA_NATIVE_TAP attempt=" + attempt
                            + " x=" + Math.round(tapX) + " y=" + Math.round(tapY)
                            + " downHandled=" + downHandled + " upHandled=" + upHandled
                            + " target=" + target);
                    listener.onProgressPulse("SNS_IG_SPA_NATIVE_TAP");
                    handler.postDelayed(() -> {
                        if (cancelled || current != node || activeLoadSequence != loadId || !instagramSpaAwaitingOpen) return;
                        if (instagramSpaTapAttempts < INSTAGRAM_SPA_TAP_MAX_ATTEMPTS) {
                            DiagnosticLog.log("SNS_IG_SPA_OPEN_RETRY attempt=" + instagramSpaTapAttempts
                                    + " target=" + target);
                            findAndTapInstagramAnchor(node, loadId, 0);
                        } else {
                            DiagnosticLog.log("SNS_IG_SPA_OPEN_TIMEOUT attempts=" + instagramSpaTapAttempts
                                    + " timeoutMs=" + INSTAGRAM_SPA_OPEN_TIMEOUT_MS + " target=" + target);
                            restartInstagramPostFromBeginning(node, loadId, "spa_open_timeout");
                        }
                    }, INSTAGRAM_SPA_OPEN_TIMEOUT_MS);
                }, 70L);
            } catch (Exception e) {
                DiagnosticLog.logException("SNS_IG_SPA_NATIVE_TAP_PARSE_FAIL target=" + target, e);
                restartInstagramPostFromBeginning(node, loadId, "spa_tap_parse_fail");
            }
        });
    }

    private static String buildInstagramAnchorRectScript(String target, boolean scrollIfMissing) {
        String quoted = JSONObject.quote(target == null ? "" : target);
        return "(function(){try{"
                + "const target=" + quoted + ";"
                + "const m=target.match(/\\/(p|reel|tv)\\/([^\\/?#]+)/i);const token=m?('/'+m[1]+'/'+m[2]+'/'):'';"
                + "const all=Array.from(document.querySelectorAll('a[href]'));let a=all.find(e=>{try{return token&&new URL(e.href,location.href).pathname.indexOf(token)>=0}catch(x){return false}});"
                + "if(!a){" + (scrollIfMissing ? "window.scrollBy(0,Math.max(260,(window.innerHeight||800)*0.72));" : "")
                + "return JSON.stringify({found:false,scrollY:Math.round(window.scrollY||0),scrollH:Math.round(document.documentElement.scrollHeight||document.body.scrollHeight||0)});}"
                + "try{a.scrollIntoView({block:'center',inline:'center'});}catch(x){};let r=a.getBoundingClientRect();"
                + "return JSON.stringify({found:r.width>1&&r.height>1,x:(r.left+r.right)/2,y:(r.top+r.bottom)/2,w:r.width,h:r.height,innerW:window.innerWidth||1,innerH:window.innerHeight||1,href:a.href||'',scrollY:Math.round(window.scrollY||0),scrollH:Math.round(document.documentElement.scrollHeight||0)});"
                + "}catch(e){return JSON.stringify({found:false,error:String(e)})}})()";
    }

    private void returnInstagramSpaToProfile(Node node, Runnable after) {
        if (!INSTAGRAM_SPA_AUTO_CLICK || node == null) {
            if (after != null) after.run();
            return;
        }
        instagramSpaAwaitingOpen = false;
        instagramSpaReturningToProfile = true;
        restoreInstagramLightImagePolicy("return_profile");
        final String profileUrl = instagramStreamingMode && !instagramStreamingProfileUrl.isEmpty()
                ? instagramStreamingProfileUrl : crawlerRootUrl;
        DiagnosticLog.log("SNS_IG_SPA_CLOSE_START url=" + node.url
                + " live=" + stripFragment(webView.getUrl())
                + " resumeY=" + instagramStreamingResumeScrollY);
        webView.evaluateJavascript(buildInstagramClosePostScript(), raw -> {
            DiagnosticLog.log("SNS_IG_SPA_CLOSE_ACTION raw=" + sanitizeDiagValue(raw));
            handler.postDelayed(() -> {
                if (cancelled) return;
                if (isInstagramPostUrl(webView.getUrl())) {
                    DiagnosticLog.log("SNS_IG_SPA_CLOSE_FALLBACK_DIRECT profile=" + stripFragment(profileUrl)
                            + " live=" + stripFragment(webView.getUrl()));
                    Node profileNode = new Node(profileUrl, 0, false);
                    current = profileNode;
                    activeLoadSequence = ++loadSequence;
                    activeNavigationSequence = 0L;
                    activeLoadStarted = false;
                    activePageFinished = false;
                    activeStartedGeneration = -1L;
                    activeRequestedUrl = stripFragment(profileUrl);
                    activeStartedUrl = "";
                    activeInstagramDetailCollectionStarted = false;
                    try { webView.loadUrl(profileUrl); } catch (Throwable t) {
                        DiagnosticLog.logException("SNS_IG_SPA_CLOSE_FALLBACK_DIRECT_FAIL", t);
                    }
                }
                waitForInstagramProfileReturn(node, after, profileUrl, 0);
            }, 550L);
        });
    }

    private void waitForInstagramProfileReturn(Node previousNode, Runnable after, String profileUrl, int poll) {
        if (cancelled) return;
        String live = stripFragment(webView.getUrl());
        if (!isInstagramPostUrl(live) && isInstagramUrl(live) && webView.getProgress() >= 80) {
            // URL/progress can report the profile before Instagram has rebuilt the virtualized grid.
            // Wait for at least one post anchor before restoring the scroll position; otherwise a
            // temporary empty shell looks like the bottom of the profile and can poison the next step.
            webView.evaluateJavascript(buildInstagramProfileDiscoveryScript(), gridRaw -> {
                if (cancelled) return;
                int cells = 0;
                int h = 0;
                try {
                    JSONObject grid = new JSONObject(unquoteJsResult(gridRaw));
                    JSONArray a = grid.optJSONArray("cells");
                    cells = a == null ? 0 : a.length();
                    h = grid.optInt("h", 0);
                } catch (Exception ignored) {}
                if (cells <= 0 && poll < 40) {
                    if (poll == 0 || (poll + 1) % 8 == 0) {
                        DiagnosticLog.log("SNS_IG_SPA_PROFILE_GRID_WAIT poll=" + (poll + 1)
                                + " cells=" + cells + " h=" + h + " live=" + live);
                    }
                    handler.postDelayed(() -> waitForInstagramProfileReturn(previousNode, after, profileUrl, poll + 1), 250L);
                    return;
                }
                final int resumeY = Math.max(0, instagramStreamingResumeScrollY);
                String restore = "(function(){try{window.scrollTo(0," + resumeY + ");return Math.round(window.scrollY||0)}catch(e){return -1}})()";
                final int readyCells = cells;
                final int readyHeight = h;
                webView.evaluateJavascript(restore, raw -> {
                    handler.postDelayed(() -> {
                        if (cancelled) return;
                        instagramSpaReturningToProfile = false;
                        activeLoadSequence = ++loadSequence;
                        activeNavigationSequence = 0L;
                        activeLoadStarted = false;
                        activePageFinished = false;
                        activeStartedGeneration = -1L;
                        activeRequestedUrl = "";
                        activeStartedUrl = "";
                        activeInstagramDetailCollectionStarted = false;
                        DiagnosticLog.log("SNS_IG_SPA_CLOSE_DONE live=" + stripFragment(webView.getUrl())
                                + " resumeY=" + resumeY + " restored=" + sanitizeDiagValue(raw)
                                + " cells=" + readyCells + " h=" + readyHeight);
                        if (after != null) after.run();
                    }, 260L);
                });
            });
            return;
        }
        if (poll >= 40) {
            instagramSpaReturningToProfile = false;
            DiagnosticLog.log("SNS_IG_SPA_CLOSE_TIMEOUT live=" + live + " profile=" + stripFragment(profileUrl));
            markIncomplete("instagram_profile_return_timeout");
            if (instagramStreamingMode) {
                Node profileNode = new Node(profileUrl, 0, false);
                current = profileNode;
                finishInstagramProfileStream(profileNode, "profile_return_timeout");
            } else {
                current = null;
                loadNext();
            }
            return;
        }
        handler.postDelayed(() -> waitForInstagramProfileReturn(previousNode, after, profileUrl, poll + 1), 250L);
    }

    private static String buildInstagramClosePostScript() {
        return "(function(){try{const vis=e=>{try{let r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'}catch(x){return false}};"
                + "const label=e=>[((e.getAttribute&&e.getAttribute('aria-label'))||''),((e.getAttribute&&e.getAttribute('title'))||''),(e.innerText||''),Array.from(e.querySelectorAll?e.querySelectorAll('svg'):[]).map(s=>(s.getAttribute('aria-label')||s.getAttribute('title')||'')).join(' ')].join(' ').replace(/\\s+/g,' ').trim();"
                + "let c=Array.from(document.querySelectorAll('button,[role=button],[aria-label],[title],svg[aria-label]')).map(e=>{for(let n=e,d=0;n&&d<6;n=n.parentElement,d++){if(n.matches&&n.matches('button,[role=button]'))return n}return e}).find(e=>vis(e)&&/(^|\\s)(close|閉じる)(\\s|$)/i.test(label(e)));"
                + "if(!c)return JSON.stringify({clicked:false});try{c.click();return JSON.stringify({clicked:true,label:label(c)})}catch(x){return JSON.stringify({clicked:false,error:String(x)})}}catch(e){return JSON.stringify({clicked:false,error:String(e)})}})()";
    }

    private void navigateNodeBrowserStyle(Node node) {
        if (node == null) return;
        if (node.detail && isInstagramLikeHost(rootHost)) {
            String live = webView.getUrl();
            String cookie = "";
            try {
                String c = SessionCookies.getCookie("https://www.instagram.com/");
                cookie = c == null ? "" : c;
            } catch (Throwable ignored) {}
            boolean session = hasCookieNamed(cookie, "sessionid");
            boolean dsUser = hasCookieNamed(cookie, "ds_user_id");
            boolean csrf = hasCookieNamed(cookie, "csrftoken");
            if (isInstagramUrl(live)) {
                DiagnosticLog.log("SNS_IG_BROWSER_NAV mode=location_assign from=" + stripFragment(live)
                        + " to=" + node.url
                        + " cookieChars=" + cookie.length()
                        + " sessionid=" + session + " dsUserId=" + dsUser + " csrf=" + csrf);
                String envJs = "(function(){try{var d=navigator.userAgentData;var b=(d&&d.brands)?d.brands.map(function(x){return x.brand+'/'+x.version;}).join(','):'';return JSON.stringify({ua:navigator.userAgent||'',ref:document.referrer||'',lang:navigator.language||'',brands:b,mobile:d?d.mobile:null,platform:d?(d.platform||''):''});}catch(e){return JSON.stringify({error:String(e)});}})();";
                webView.evaluateJavascript(envJs, value -> DiagnosticLog.log("SNS_IG_JS_ENV raw=" + sanitizeDiagValue(value)));
                String navJs = "window.location.assign(" + JSONObject.quote(node.url) + ");";
                webView.evaluateJavascript(navJs, null);
                return;
            }
            DiagnosticLog.log("SNS_IG_BROWSER_NAV mode=load_url_fallback from=" + stripFragment(live)
                    + " to=" + node.url
                    + " cookieChars=" + cookie.length()
                    + " sessionid=" + session + " dsUserId=" + dsUser + " csrf=" + csrf);
        }
        webView.loadUrl(node.url);
    }

    private void logInstagramMainFrameRequest(android.webkit.WebResourceRequest request, String requestUrl) {
        if (request == null || activeInstagramRequestDiagLogged) return;
        activeInstagramRequestDiagLogged = true;
        Map<String, String> headers = request.getRequestHeaders();
        DiagnosticLog.log("SNS_IG_REQUEST_MAIN url=" + stripFragment(requestUrl)
                + " method=" + request.getMethod()
                + " gesture=" + request.hasGesture()
                + " redirect=" + safeRequestRedirect(request)
                + " ua=" + headerValue(headers, "User-Agent")
                + " referer=" + headerValue(headers, "Referer")
                + " secFetchSite=" + headerValue(headers, "Sec-Fetch-Site")
                + " secFetchMode=" + headerValue(headers, "Sec-Fetch-Mode")
                + " secFetchDest=" + headerValue(headers, "Sec-Fetch-Dest")
                + " secFetchUser=" + headerValue(headers, "Sec-Fetch-User")
                + " chUa=" + headerValue(headers, "sec-ch-ua")
                + " chMobile=" + headerValue(headers, "sec-ch-ua-mobile")
                + " chPlatform=" + headerValue(headers, "sec-ch-ua-platform")
                + " acceptLanguage=" + headerValue(headers, "Accept-Language")
                + " accept=" + headerValue(headers, "Accept")
                + " upgradeInsecure=" + headerValue(headers, "Upgrade-Insecure-Requests")
                + " priority=" + headerValue(headers, "Priority")
                + " headerNames=" + headerNames(headers));
    }

    private void logInstagramCookieState(String phase) {
        String cookie = "";
        try {
            String c = SessionCookies.getCookie("https://www.instagram.com/");
            cookie = c == null ? "" : c;
        } catch (Throwable ignored) {}
        DiagnosticLog.log("SNS_IG_COOKIE_STATE phase=" + phase
                + " cookieChars=" + cookie.length()
                + " sessionid=" + hasCookieNamed(cookie, "sessionid")
                + " dsUserId=" + hasCookieNamed(cookie, "ds_user_id")
                + " csrf=" + hasCookieNamed(cookie, "csrftoken"));
    }

    private static boolean safeRequestRedirect(android.webkit.WebResourceRequest request) {
        try { return request.isRedirect(); } catch (Throwable ignored) { return false; }
    }

    private static String headerValue(Map<String, String> headers, String name) {
        if (headers == null || headers.isEmpty() || name == null) return "<none>";
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) {
                return sanitizeDiagValue(e.getValue());
            }
        }
        return "<none>";
    }

    private static String headerNames(Map<String, String> headers) {
        if (headers == null || headers.isEmpty()) return "<none>";
        ArrayList<String> names = new ArrayList<>();
        for (String k : headers.keySet()) if (k != null && !k.isEmpty()) names.add(k);
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        return sanitizeDiagValue(String.join(",", names));
    }

    private static String sanitizeDiagValue(String value) {
        if (value == null || value.isEmpty()) return "<none>";
        String out = value.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').trim();
        if (out.length() > 900) out = out.substring(0, 900) + "...";
        return out;
    }

    private static boolean isInstagramUrl(String url) {
        if (url == null || url.isEmpty()) return false;
        try {
            String host = new URI(stripFragment(url)).getHost();
            return isInstagramLikeHost(host);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean hasCookieNamed(String cookieHeader, String name) {
        if (cookieHeader == null || cookieHeader.isEmpty() || name == null || name.isEmpty()) return false;
        String needle = name.toLowerCase(Locale.ROOT) + "=";
        for (String part : cookieHeader.split(";")) {
            if (part.trim().toLowerCase(Locale.ROOT).startsWith(needle)) return true;
        }
        return false;
    }

    private boolean retryInstagramDetail(Node node, long expectedLoad, String reason) {
        return recoverInstagramDetail(node, expectedLoad, reason);
    }

    private boolean recoverInstagramDetail(Node node, long expectedLoad, String reason) {
        return restartInstagramPostFromBeginning(node, expectedLoad, reason);
    }

    private void recoverOrSkipInstagramDetail(Node node, long expectedLoad, String reason) {
        restartInstagramPostFromBeginning(node, expectedLoad, reason);
    }

    private void markInstagramMeaningfulProgress(String stage) {
        if (!isInstagramLikeHost(rootHost)) return;
        activeInstagramLastMeaningfulProgressAt = System.currentTimeMillis();
    }

    private void scheduleInstagramStallWatchdog(long run, long load, Node node) {
        handler.postDelayed(() -> {
            if (cancelled || doneEmitted || current != node || generation != run || activeLoadSequence != load) return;
            long now = System.currentTimeMillis();
            long last = activeInstagramLastMeaningfulProgressAt > 0L
                    ? activeInstagramLastMeaningfulProgressAt : now;
            long idle = Math.max(0L, now - last);
            if (idle >= INSTAGRAM_STALL_RECOVERY_MS) {
                recoverOrSkipInstagramDetail(node, load, "no_progress_" + idle + "ms");
                return;
            }
            scheduleInstagramStallWatchdog(run, load, node);
        }, INSTAGRAM_STALL_WATCHDOG_TICK_MS);
    }

    public boolean recoverFromStall() {
        if (cancelled || doneEmitted || !isInstagramLikeHost(rootHost)) return false;
        final Node node = current;
        final long load = activeLoadSequence;
        if (node != null && node.detail) {
            handler.post(() -> restartInstagramPostFromBeginning(node, load, "ui_watchdog"));
            return true;
        }
        if (node == null && !queue.isEmpty()) {
            handler.post(this::loadNext);
            return true;
        }
        return false;
    }

    private void skipCurrentDetail(Node node, long expectedLoad, String reason, long timeoutMs) {
        if (cancelled || node == null || !node.detail || current != node || activeLoadSequence != expectedLoad) return;
        if (isInstagramLikeHost(rootHost)) {
            DiagnosticLog.log("SNS_IG_TIMEOUT_RESTART reason=" + reason + " timeoutMs=" + timeoutMs + " url=" + node.url);
            restartInstagramPostFromBeginning(node, expectedLoad, reason);
            return;
        }
        DiagnosticLog.log("DETAIL_TIMEOUT_SKIP reason=" + reason + " timeoutMs=" + timeoutMs + " url=" + node.url);
        listener.onProgressPulse("DETAIL_TIMEOUT_SKIP");
        listener.onStatus("詳細追跡をスキップ  " + node.url);
        try { webView.stopLoading(); } catch (Exception ignored) {}
        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = "";
        activeStartedUrl = "";
        detailCount++;
        current = null;
        loadNext();
    }

    public boolean hasPendingWork() {
        return !cancelled && !doneEmitted
                && (current != null || !queue.isEmpty() || pendingImageProbes > 0
                || !baseTraversalDone || !detailTraversalDone || !traversalDone);
    }

    public String progressSnapshot() {
        String currentUrl = current == null ? "none" : current.url;
        return "current=" + currentUrl
                + ",queue=" + queue.size()
                + ",pendingImageProbes=" + pendingImageProbes
                + ",activePageFinished=" + activePageFinished
                + ",deferredDetails=" + deferredDetails.size()
                + ",baseTraversalDone=" + baseTraversalDone
                + ",detailPhaseStarted=" + detailPhaseStarted
                + ",detailTraversalDone=" + detailTraversalDone
                + ",traversalDone=" + traversalDone
                + ",pages=" + pageCount
                + ",details=" + detailCount;
    }

    private static boolean sameNavigationUrl(String a, String b) {
        if (a == null || b == null) return false;
        try {
            URI ua = new URI(stripFragment(a));
            URI ub = new URI(stripFragment(b));
            String sa = ua.getScheme() == null ? "" : ua.getScheme();
            String sb = ub.getScheme() == null ? "" : ub.getScheme();
            String ha = ua.getHost() == null ? "" : ua.getHost();
            String hb = ub.getHost() == null ? "" : ub.getHost();
            String pa = ua.getPath() == null || ua.getPath().isEmpty() ? "/" : ua.getPath();
            String pb = ub.getPath() == null || ub.getPath().isEmpty() ? "/" : ub.getPath();
            return sa.equalsIgnoreCase(sb)
                    && ha.equalsIgnoreCase(hb)
                    && effectivePort(ua) == effectivePort(ub)
                    && pa.equals(pb)
                    && normalizedNavigationQueryParts(ua).equals(normalizedNavigationQueryParts(ub));
        } catch (Exception e) {
            return stripFragment(a).equals(stripFragment(b));
        }
    }

    private static ArrayList<String> normalizedNavigationQueryParts(URI uri) {
        ArrayList<String> out = normalizedQueryParts(uri == null ? null : uri.getRawQuery());
        if (uri == null || !isInstagramCarouselNavigationUri(uri)) return out;
        out.removeIf(part -> part != null && part.regionMatches(true, 0, "img_index\u0000", 0, 10));
        return out;
    }

    private static boolean isInstagramCarouselNavigationUri(URI uri) {
        if (uri == null) return false;
        String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
        if (!(host.equals("instagram.com") || host.endsWith(".instagram.com"))) return false;
        String path = uri.getPath() == null ? "" : uri.getPath();
        return path.matches("^/(p|reel|tv)/[^/]+/?$");
    }

    private static int instagramCarouselIndex(String url) {
        if (url == null || url.isEmpty()) return -1;
        try {
            URI uri = new URI(stripFragment(url));
            if (!isInstagramCarouselNavigationUri(uri)) return -1;
            String raw = uri.getRawQuery();
            if (raw == null || raw.isEmpty()) return 1;
            for (String part : raw.split("&", -1)) {
                int eq = part.indexOf('=');
                String rawKey = eq >= 0 ? part.substring(0, eq) : part;
                if (!"img_index".equalsIgnoreCase(decodeQueryComponent(rawKey))) continue;
                String value = decodeQueryComponent(eq >= 0 ? part.substring(eq + 1) : "");
                try { return Math.max(1, Integer.parseInt(value)); } catch (Exception ignored) { return -1; }
            }
            return 1;
        } catch (Exception e) {
            return -1;
        }
    }

    private static ArrayList<String> normalizedQueryParts(String rawQuery) {
        ArrayList<String> out = new ArrayList<>();
        if (rawQuery == null || rawQuery.isEmpty()) return out;
        String[] parts = rawQuery.split("&", -1);
        for (String part : parts) {
            int eq = part.indexOf('=');
            String rawKey = eq >= 0 ? part.substring(0, eq) : part;
            String rawValue = eq >= 0 ? part.substring(eq + 1) : "";
            out.add(decodeQueryComponent(rawKey) + "\u0000" + decodeQueryComponent(rawValue));
        }
        Collections.sort(out);
        return out;
    }

    private static String decodeQueryComponent(String raw) {
        try {
            return URLDecoder.decode(raw == null ? "" : raw, "UTF-8");
        } catch (Exception e) {
            return raw == null ? "" : raw;
        }
    }

    private static int effectivePort(URI uri) {
        int port = uri.getPort();
        if (port >= 0) return port;
        String scheme = uri.getScheme();
        if (scheme != null && scheme.equalsIgnoreCase("https")) return 443;
        if (scheme != null && scheme.equalsIgnoreCase("http")) return 80;
        return -1;
    }

    private void configureSnsBrowserUserAgent() {
        try {
            WebSettings settings = webView.getSettings();
            String ua = settings.getUserAgentString();
            if (ua == null) ua = "";
            ua = browserLikeUserAgent(ua.replace(" ImgStalker/0.1.80", ""));
            settings.setUserAgentString(ua);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(false);
            settings.setTextZoom(100);
            settings.setCacheMode(WebSettings.LOAD_DEFAULT);
            imageProbeUserAgent = ua;
            applySnsBrowserUaMetadata(settings, ua);
            DiagnosticLog.log("SNS_CRAWLER_UA service=" + snsServiceName()
                    + " webviewMarker=" + containsWebViewMarker(ua));
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_CRAWLER_UA_FAIL service=" + snsServiceName()
                    + " reason=" + t.getClass().getSimpleName());
        }
    }

    private static boolean containsWebViewMarker(String ua) {
        if (ua == null) return false;
        String lower = ua.toLowerCase(Locale.ROOT);
        return lower.contains("; wv)") || lower.contains(" version/4.0 ");
    }

    private static String browserLikeUserAgent(String ua) {
        if (ua == null || ua.trim().isEmpty()) return ua;
        String out = ua.replace("; wv)", ")");
        out = out.replaceAll("\\s+Version/4\\.0\\s+", " ");
        out = out.replaceAll("\\s{2,}", " ").trim();
        return out;
    }

    private void applySnsBrowserUaMetadata(WebSettings settings, String ua) {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
                DiagnosticLog.log("SNS_CRAWLER_UACH service=" + snsServiceName() + " supported=false");
                return;
            }
            Matcher m = Pattern.compile("Chrome/([0-9]+(?:\\.[0-9]+){0,3})").matcher(ua == null ? "" : ua);
            if (!m.find()) {
                DiagnosticLog.log("SNS_CRAWLER_UACH service=" + snsServiceName() + " supported=true chromeVersion=missing");
                return;
            }
            String full = m.group(1);
            String major = full.contains(".") ? full.substring(0, full.indexOf('.')) : full;
            ArrayList<UserAgentMetadata.BrandVersion> brands = new ArrayList<>();
            brands.add(new UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Chromium").setMajorVersion(major).setFullVersion(full).build());
            brands.add(new UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Google Chrome").setMajorVersion(major).setFullVersion(full).build());
            UserAgentMetadata metadata = new UserAgentMetadata.Builder()
                    .setBrandVersionList(brands)
                    .setFullVersion(full)
                    .setPlatform("Android")
                    .setPlatformVersion(Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE)
                    .setModel(Build.MODEL == null ? "" : Build.MODEL)
                    .setMobile(true)
                    .build();
            WebSettingsCompat.setUserAgentMetadata(settings, metadata);
            DiagnosticLog.log("SNS_CRAWLER_UACH service=" + snsServiceName() + " chrome=" + full + " platform=Android");
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_CRAWLER_UACH_FAIL service=" + snsServiceName()
                    + " reason=" + t.getClass().getSimpleName());
        }
    }

    private String snsServiceName() {
        if (isXLikeHost(rootHost)) return "X";
        if (isInstagramLikeHost(rootHost)) return "Instagram";
        return "web";
    }

    private static boolean isSnsLikeHost(String host) {
        return isXLikeHost(host) || isInstagramLikeHost(host);
    }

    private static boolean isInstagramLikeHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("instagram.com") || h.endsWith(".instagram.com");
    }

    private static boolean isInstagramPostUrl(String url) {
        try {
            String p = new URI(stripFragment(url)).getPath();
            if (p == null) return false;
            return Pattern.compile("/(p|reel|tv)/[^/?#]+", Pattern.CASE_INSENSITIVE).matcher(p).find();
        } catch (Exception e) {
            return false;
        }
    }

    private static String normalizeSnsImageUrl(String raw) {
        String u = cleanUrl(raw);
        if (u.toLowerCase(Locale.ROOT).contains("pbs.twimg.com/media/") && u.matches(".*([?&])name=[^&]+.*")) {
            u = u.replaceAll("([?&])name=[^&]+", "$1name=orig");
        }
        return u;
    }

    private static String buildSnsHarvestScript(boolean xMode, boolean instagramMode) {
        String mode = xMode ? "x" : (instagramMode ? "ig" : "web");
        return "(function(){try{" +
                "const mode='" + mode + "';" +
                "const abs=(u)=>{try{if(!u||/^(data:|blob:|javascript:|#)/i.test(u))return '';return new URL(u,document.baseURI).href}catch(e){return ''}};" +
                "const uniq=(a)=>Array.from(new Set(a.filter(Boolean)));" +
                "const largest=(i)=>{let rows=[];let ss=i.getAttribute('srcset')||i.getAttribute('data-srcset')||'';" +
                "if(ss){ss.split(',').forEach(p=>{let z=p.trim().split(/\\s+/),u=abs(z[0]);if(!u)return;let d=z[1]||'',w=0;if(/^[0-9.]+w$/i.test(d))w=parseFloat(d);else if(/^[0-9.]+x$/i.test(d))w=(i.clientWidth||i.width||640)*parseFloat(d);rows.push({u:u,w:w})});" +
                "rows.sort((a,b)=>a.w-b.w);if(rows.length)return rows[rows.length-1].u;}" +
                "return [i.getAttribute('data-original'),i.getAttribute('data-src'),i.currentSrc,i.src].map(abs).find(Boolean)||''};" +
                "let images=[],videos=[],streams=[],postLinks=[],statusLinks=[];" +
                "document.querySelectorAll('img').forEach(i=>{let u=largest(i);if(!u)return;" +
                "if(mode==='x'){if(/pbs\\.twimg\\.com\\/media\\//i.test(u))images.push(u);}" +
                "else if(mode==='ig'){let a=i.closest('a[href]'),href=a?abs(a.href):'';let inPost=!!i.closest('article')||/\\/(p|reel|tv)\\//i.test(href);if(inPost&&/(cdninstagram\\.com|fbcdn\\.net)/i.test(u))images.push(u);}" +
                "});" +
                "document.querySelectorAll('video').forEach(v=>{[v.currentSrc,v.src,v.getAttribute('src')].map(abs).filter(Boolean).forEach(u=>{if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);else if(/\\.mp4(\\?|$)/i.test(u))videos.push(u)})});" +
                "document.querySelectorAll('video source,source[type^=\\\"video/\\\"]').forEach(s=>{let u=abs(s.src||s.getAttribute('src'));if(u){if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);else videos.push(u)}});" +
                "if(mode==='x'){let arts=Array.from(document.querySelectorAll('article[data-testid=tweet],article'));arts.forEach(ar=>{let user='';" +
                "let un=ar.querySelector('[data-testid=User-Name]');if(un){Array.from(un.querySelectorAll('a[href]')).some(a=>{try{let p=new URL(a.href,document.baseURI).pathname,m=p.match(/^\\/([^/]+)\\/?$/);if(m){user=m[1];return true}}catch(e){}return false})}" +
                "let chosen='';Array.from(ar.querySelectorAll('a[href]')).some(a=>{let u=abs(a.href);try{let x=new URL(u),m=x.pathname.match(/^\\/([^/]+)\\/status\\/(\\d+)/);if(!m)return false;let cu='https://x.com/'+m[1]+'/status/'+m[2];if(!chosen)chosen=cu;if(user&&m[1].toLowerCase()===user.toLowerCase()){chosen=cu;return true}}catch(e){}return false});if(chosen)statusLinks.push(chosen)});" +
                "if(!arts.length){document.querySelectorAll('a[href]').forEach(a=>{let u=abs(a.href);try{let x=new URL(u),m=x.pathname.match(/^\\/([^/]+)\\/status\\/(\\d+)/);if(m)statusLinks.push('https://x.com/'+m[1]+'/status/'+m[2])}catch(e){}});}}" +
                "if(mode==='ig'){document.querySelectorAll('a[href]').forEach(a=>{let u=abs(a.href);try{let p=new URL(u).pathname,m=p.match(/\\/(p|reel|tv)\\/([^/?#]+)/i);if(m)postLinks.push('https://www.instagram.com/'+m[1].toLowerCase()+'/'+m[2]+'/')}catch(e){}});}" +
                "return JSON.stringify({title:document.title||'',images:uniq(images),videos:uniq(videos),streams:uniq(streams),postLinks:uniq(postLinks),statusLinks:uniq(statusLinks)});" +
                "}catch(e){return JSON.stringify({title:'',images:[],videos:[],streams:[],postLinks:[],statusLinks:[],error:String(e)})}})()";
    }

    private boolean sameHost(String url) {
        try {
            String h = new URI(url).getHost();
            if (h == null) return false;
            if (h.equalsIgnoreCase(rootHost)) return true;
            return h.toLowerCase(Locale.ROOT).endsWith("." + rootHost.toLowerCase(Locale.ROOT));
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isDetailCandidate(String url, String fromUrl) {
        try {
            URI target = new URI(stripFragment(url));
            URI from = new URI(stripFragment(fromUrl));
            String targetPath = target.getPath() == null ? "/" : target.getPath();
            String fromPath = from.getPath() == null ? "/" : from.getPath();
            if (targetPath.equals(fromPath) && safeEquals(target.getQuery(), from.getQuery())) return false;

            String path = targetPath.toLowerCase(Locale.ROOT);
            if (path.isEmpty() || "/".equals(path)) return false;
            if (path.matches("^/(page/\\d+/?|tag/.*|tags/.*|category/.*|categories/.*|author/.*|search/?.*|feed/?.*|wp-.*)$")) {
                return false;
            }
            if (path.contains("/login") || path.contains("/register") || path.contains("/privacy")
                    || path.contains("/contact") || path.contains("/about")) {
                return false;
            }

            String[] segments = path.split("/");
            int useful = 0;
            for (String segment : segments) if (!segment.isEmpty()) useful++;
            boolean contentLike = path.matches(".*\\.(html?|php)(/\\d+)?$")
                    || path.matches(".*/\\d{3,}([./].*)?$")
                    || useful >= 2;
            return contentLike;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isXLikeHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("x.com") || h.endsWith(".x.com")
                || h.equals("twitter.com") || h.endsWith(".twitter.com");
    }

    private static boolean safeEquals(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private static boolean isLikelyTrackingImage(String url) {
        try {
            URI u = new URI(url);
            String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase(Locale.ROOT);
            String query = u.getQuery() == null ? "" : u.getQuery().toLowerCase(Locale.ROOT);
            String all = host + path + "?" + query;
            if (host.contains("ad-stir") || host.contains("shinobi") || host.contains("jp1media")
                    || host.contains("doubleclick") || host.contains("googlesyndication")
                    || host.contains("adservice") || host.contains("adnxs") || host.contains("criteo")
                    || host.contains("rubiconproject") || host.contains("openx") || host.contains("bance")) {
                return true;
            }
            if (!looksDirectMedia(url) && (all.contains("/sync") || all.contains("push_sync")
                    || all.contains("/pixel") || all.contains("/beacon") || all.contains("/track"))) {
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static String canonicalizeSnsEntryUrl(String raw) {
        try {
            URI uri = new URI(stripFragment(raw));
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!isInstagramLikeHost(host)) return raw;
            String q = uri.getRawQuery();
            if (q == null || q.isEmpty()) return raw;
            ArrayList<String> keep = new ArrayList<>();
            for (String part : q.split("&", -1)) {
                int eq = part.indexOf('=');
                String rawKey = eq >= 0 ? part.substring(0, eq) : part;
                String key = decodeQueryComponent(rawKey).toLowerCase(Locale.ROOT);
                if (key.equals("stkn") || key.equals("igsh") || key.equals("igshid")
                        || key.equals("fbclid") || key.startsWith("utm_")) continue;
                keep.add(part);
            }
            if (keep.size() == q.split("&", -1).length) return raw;
            StringBuilder out = new StringBuilder();
            if (uri.getScheme() != null) out.append(uri.getScheme()).append("://");
            if (uri.getRawAuthority() != null) out.append(uri.getRawAuthority());
            String path = uri.getRawPath();
            out.append(path == null || path.isEmpty() ? "/" : path);
            if (!keep.isEmpty()) out.append('?').append(String.join("&", keep));
            return out.toString();
        } catch (Exception e) {
            return raw;
        }
    }

    private static String normalizeInputUrl(String s) {
        s = s == null ? "" : s.trim();
        if (!s.matches("(?i)^https?://.*")) s = "https://" + s;
        return s;
    }

    private static boolean looksDirectImage(String u) {
        String x = u.toLowerCase(Locale.ROOT).split("\\?")[0];
        return x.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif)$");
    }

    private static boolean looksDirectMedia(String u) {
        String x = u.toLowerCase(Locale.ROOT).split("\\?")[0];
        return x.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif|mp4|webm|mov|m4v|3gp|m3u8|mpd)$");
    }

    private static boolean isHttp(String u) {
        return u != null && (u.startsWith("http://") || u.startsWith("https://"));
    }

    private static String cleanUrl(String s) {
        if (s == null) return "";
        return s.trim().replace("&amp;", "&");
    }

    private static String stripFragment(String s) {
        int i = s.indexOf('#');
        return i >= 0 ? s.substring(0, i) : s;
    }

    private static String unquoteJsResult(String raw) throws JSONException {
        if (raw == null || raw.equals("null")) return "{}";
        if (raw.startsWith("\"") && raw.endsWith("\"")) {
            return new JSONArray("[" + raw + "]").getString(0);
        }
        return raw;
    }

    private static String buildSimpleGateScript(boolean allowClick) {
        String click = allowClick ? "true" : "false";
        return "(function(){try{" +
                "const allowClick=" + click + ";" +
                "const clean=s=>(s||'').replace(/\\s+/g,' ').trim();" +
                "const label=e=>clean((e.tagName==='INPUT'?(e.value||''):(e.innerText||e.textContent||''))||e.getAttribute('aria-label')||e.getAttribute('title')||'');" +
                "const gateRe=/(18\\s*(?:\\u6b73|\\u624d)|18\\s*\\+|\\u6210\\u4eba|\\u672a\\u6210\\u5e74|\\u5e74\\u9f62|\\u30bb\\u30f3\\u30b7\\u30c6\\u30a3\\u30d6|\\u95b2\\u89a7.{0,24}(?:\\u78ba\\u8a8d|\\u3057\\u307e\\u3059\\u304b|\\u3088\\u308d\\u3057\\u3044)|\\u5165\\u5834.{0,24}(?:\\u78ba\\u8a8d|\\u3057\\u307e\\u3059\\u304b|\\u3088\\u308d\\u3057\\u3044)|age\\s*(?:verification|check)|adult|mature|sensitive\\s*content|are\\s*you.{0,16}(?:18|legal\\s*age)|over\\s*18|under\\s*18)/i;" +
                "const yesRe=/(?:^|[\\uff08(\\s])(\\u306f\\u3044|yes|18\\s*(?:\\u6b73|\\u624d)\\u4ee5\\u4e0a|\\u6210\\u4eba(?:\\u3067\\u3059)?|\\u95b2\\u89a7(?:\\u3059\\u308b|\\u3057\\u307e\\u3059)|\\u5165\\u5834(?:\\u3059\\u308b|\\u3057\\u307e\\u3059)|\\u540c\\u610f(?:\\u3059\\u308b|\\u3057\\u307e\\u3059)|\\u7d9a\\u3051\\u308b|continue|enter|accept|agree|over\\s*18|i\\s*(?:am|'m)\\s*18)(?:$|[\\uff09)\\s])/i;" +
                "const noRe=/(?:^|[\\uff08(\\s])(\\u3044\\u3044\\u3048|no|18\\s*(?:\\u6b73|\\u624d)\\u672a\\u6e80|\\u672a\\u6210\\u5e74|\\u623b\\u308b|\\u9000\\u5834|exit|leave|under\\s*18|decline)(?:$|[\\uff09)\\s])/i;" +
                "const all=Array.from(document.querySelectorAll('a[href],button,input[type=submit],input[type=button],[role=button]')).filter(e=>!e.disabled&&e.getClientRects().length>0);" +
                "let pos=null,neg=null;for(const e of all){let t=label(e);if(!pos&&yesRe.test(t))pos=e;if(!neg&&noRe.test(t))neg=e;if(pos&&neg)break;}" +
                "if(!pos||!neg)return JSON.stringify({found:false,clicked:false,accept:'',reject:''});" +
                "let ctx=null;let p=pos;for(let i=0;p&&i<6;i++,p=p.parentElement){if(p.contains(neg)){let tx=clean(p.innerText||p.textContent||'');if(tx.length<=5000&&gateRe.test(tx)){ctx=p;break;}}}" +
                "if(!ctx){let body=clean((document.body&&(document.body.innerText||document.body.textContent))||'');if(body.length<=5000&&gateRe.test(body))ctx=document.body;}" +
                "if(!ctx)return JSON.stringify({found:false,clicked:false,accept:'',reject:''});" +
                "let a=label(pos),n=label(neg);if(allowClick){setTimeout(()=>{try{pos.click()}catch(e){}},0);}" +
                "return JSON.stringify({found:true,clicked:allowClick,accept:a,reject:n});" +
                "}catch(e){return JSON.stringify({found:false,clicked:false,accept:'',reject:'',error:String(e)});}})()";
    }

    private static String buildXDetailCollectorScript() {
        return "(function(){try{" +
                "const abs=(u)=>{try{if(!u||/^(data:|blob:|javascript:|#)/i.test(u))return '';return new URL(u,document.baseURI).href}catch(e){return ''}};" +
                "const uniq=(a)=>Array.from(new Set(a.filter(Boolean)));" +
                "const largest=(i)=>{let rows=[];let ss=i.getAttribute('srcset')||i.getAttribute('data-srcset')||'';" +
                "if(ss){ss.split(',').forEach(p=>{let z=p.trim().split(/\\s+/),u=abs(z[0]);if(!u)return;let d=z[1]||'',w=0;if(/^[0-9.]+w$/i.test(d))w=parseFloat(d);else if(/^[0-9.]+x$/i.test(d))w=(i.clientWidth||i.width||640)*parseFloat(d);rows.push({u:u,w:w})});rows.sort((a,b)=>a.w-b.w);if(rows.length)return rows[rows.length-1].u;}" +
                "return [i.getAttribute('data-original'),i.getAttribute('data-src'),i.currentSrc,i.src].map(abs).find(Boolean)||''};" +
                "let images=[],videos=[],streams=[];let article=document.querySelector('article[data-testid=\"tweet\"]')||document.querySelector('article')||document.body;" +
                "article.querySelectorAll('img').forEach(i=>{let u=largest(i);if(u&&/pbs\\.twimg\\.com\\/media\\//i.test(u))images.push(u)});" +
                "article.querySelectorAll('video').forEach(v=>{[v.currentSrc,v.src,v.getAttribute('src')].map(abs).filter(Boolean).forEach(u=>{if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);else videos.push(u)})});" +
                "article.querySelectorAll('video source,source[type^=\"video/\"]').forEach(x=>{let u=abs(x.src||x.getAttribute('src'));if(u){if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);else videos.push(u)}});" +
                "return JSON.stringify({title:document.title||'',images:uniq(images),videos:uniq(videos),streams:uniq(streams),links:[],thumbLinks:[]});" +
                "}catch(e){return JSON.stringify({title:'',images:[],videos:[],streams:[],links:[],thumbLinks:[],error:String(e)})}})()";
    }

    private static String buildCollectorScript(int targetPx) {
        return "(function(){" +
                "const target=" + targetPx + ";" +
                "const abs=(u)=>{try{if(!u||/^(data:|blob:|javascript:|#)/i.test(u))return '';return new URL(u,document.baseURI).href}catch(e){return ''}};" +
                "const uniq=(a)=>Array.from(new Set(a.filter(Boolean)));" +
                "const chooseSrcset=(img)=>{" +
                " let rows=[]; let ss=img.getAttribute('srcset')||img.getAttribute('data-srcset')||'';" +
                " if(ss){ss.split(',').forEach(part=>{let p=part.trim().split(/\\s+/);let u=abs(p[0]);if(!u)return;let d=p[1]||'';let w=0;" +
                "  if(/^[0-9.]+w$/i.test(d))w=parseFloat(d);" +
                "  else if(/^[0-9.]+x$/i.test(d)){let base=img.clientWidth||img.width||target;w=base*parseFloat(d);}" +
                "  rows.push({u:u,w:w});});}" +
                " let known=rows.filter(x=>x.w>0).sort((a,b)=>a.w-b.w);" +
                " if(known.length){let hit=known.find(x=>x.w>=target);return (hit||known[known.length-1]).u;}" +
                " return rows.length?rows[rows.length-1].u:'';" +
                "};" +
                "let images=[],videos=[],streams=[],links=[],thumbLinks=[];" +
                "document.querySelectorAll('img').forEach(i=>{" +
                " let iw=i.naturalWidth||i.width||i.clientWidth||0, ih=i.naturalHeight||i.height||i.clientHeight||0;if(iw>0&&ih>0&&(iw<=2||ih<=2))return;" +
                " let chosen=chooseSrcset(i);" +
                " if(!chosen){let c=[i.getAttribute('data-original'),i.getAttribute('data-src'),i.getAttribute('data-lazy-src'),i.currentSrc,i.src];chosen=c.map(abs).find(Boolean)||'';}" +
                " if(chosen){images.push(chosen);let a=i.closest('a[href]');if(a){let href=abs(a.getAttribute('href')||a.href);if(href)thumbLinks.push({img:chosen,href:href});}}" +
                "});" +
                "document.querySelectorAll('meta[property=\"og:image\"],meta[name=\"twitter:image\"],link[rel=\"image_src\"]').forEach(m=>images.push(abs(m.content||m.href)));" +
                "document.querySelectorAll('video').forEach(v=>{[v.currentSrc,v.src,v.getAttribute('data-src')].map(abs).filter(Boolean).forEach(x=>{if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)})});" +
                "document.querySelectorAll('video source,source[type^=\"video/\"]').forEach(s=>{let x=abs(s.src||s.getAttribute('src'));if(x){if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)}});" +
                "document.querySelectorAll('meta[property=\"og:video\"],meta[property=\"og:video:url\"],meta[property=\"og:video:secure_url\"]').forEach(m=>{let x=abs(m.content);if(x){if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)}});" +
                "let allAnchors=Array.from(document.querySelectorAll('a[href]'));" +
                "let pageNumText=t=>{let x=(t||'').replace(/\\xA0/g,' ').trim();let m=x.match(/^[\\[\\(（\\{<＜【［]?\\s*(\\d{1,4})\\s*[\\]\\)）\\}>＞】］]?$/);return m?m[1]:'';};" +
                "let bracketPageNum=t=>/^[\\[\\(（\\{<＜【［]\\s*\\d{1,4}\\s*[\\]\\)）\\}>＞】］]$/.test((t||'').trim());" +
                "let pageParam=/^(page|paged|page_no|pageno|pageindex|page_index|pg|p|start|offset)$/i;" +
                "let hrefPageKind=(u,t,rel)=>{try{let here=new URL(location.href),x=new URL(u,document.baseURI);if(x.origin!==here.origin||x.pathname!==here.pathname)return '';let keys=new Set([...here.searchParams.keys(),...x.searchParams.keys()]);let changed=[],otherChanged=false;keys.forEach(k=>{let av=JSON.stringify(here.searchParams.getAll(k)),bv=JSON.stringify(x.searchParams.getAll(k));if(av!==bv){if(pageParam.test(k))changed.push(k);else otherChanged=true;}});if(!changed.length||otherChanged)return '';if(!changed.every(k=>/^\\d+$/.test(x.searchParams.get(k)||'')))return '';let tx=(t||'').trim();let nav=!!pageNumText(tx)||/^(next|next page|prev|previous|previous page|次へ|次のページ|前へ|前のページ|›|»|‹|«|>|<|→|←)$/i.test(tx)||(rel||'').toLowerCase().includes('next')||(rel||'').toLowerCase().includes('prev');return nav?'href_param':'';}catch(e){return '';}};" +
                "let groupedPageLinks=new Set();" +
                "allAnchors.forEach(a=>{if(!pageNumText(a.textContent))return;let e=a.parentElement;for(let level=0;e&&level<5;level++,e=e.parentElement){let aa=Array.from(e.querySelectorAll('a[href]'));if(aa.length<1||aa.length>40)continue;let nums=aa.filter(x=>pageNumText(x.textContent));let txt=(e.textContent||'').trim();let bt=txt.match(/[\\[\\(（\\{<＜【［]\\s*\\d{1,4}\\s*[\\]\\)）\\}>＞】］]/g)||[];let compact=txt.length<=180;let strong=nums.length>=3||(nums.length>=2&&nums.length/aa.length>=0.55&&(bt.length>=2||nums.every(x=>bracketPageNum(x.textContent))))||(nums.length>=1&&bt.length>=3&&compact);if(strong){nums.forEach(x=>groupedPageLinks.add(x));break;}}});" +
                "allAnchors.forEach(a=>{" +
                " let u=abs(a.href);if(!u)return;" +
                " if(/\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif)(\\?|$)/i.test(u)&&!a.querySelector('img'))images.push(u);" +
                " if(/\\.(mp4|webm|mov|m4v|3gp)(\\?|$)/i.test(u))videos.push(u);" +
                " if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);" +
                " let t=(a.textContent||'').trim(); let rel=(a.rel||'').toLowerCase();" +
                " let ctx=((a.className||'')+' '+(a.id||'')+' '+((a.parentElement&&(a.parentElement.className||''))||'')).toLowerCase();" +
                " let numeric=!!pageNumText(t);" +
                " let next=/^(next|next page|次へ|次のページ|›|»|>|→)$/i.test(t);" +
                " let pageClass=/(pagination|pager|paging|page-numbers|pagenavi)/i.test(ctx);" +
                " let groupedNumeric=groupedPageLinks.has(a);" +
                " let hrefKind=hrefPageKind(u,t,rel);" +
                " let pagination=!!hrefKind||rel.includes('next')||next||(numeric&&pageClass)||groupedNumeric;" +
                " links.push({url:u,pagination:pagination,paginationKind:(hrefKind||(groupedNumeric?'numeric_group':((numeric&&pageClass)?'numeric_class':((rel.includes('next')||next)?'next':''))))});" +
                "});" +
                "document.querySelectorAll('[style]').forEach(e=>{let b=getComputedStyle(e).backgroundImage||'';let m=b.match(/url\\([\"']?([^\"')]+)[\"']?\\)/i);if(m)images.push(abs(m[1]))});" +
                "return JSON.stringify({title:document.title||'',images:uniq(images),videos:uniq(videos),streams:uniq(streams),links:links,thumbLinks:thumbLinks});" +
                "})()";
    }
}
