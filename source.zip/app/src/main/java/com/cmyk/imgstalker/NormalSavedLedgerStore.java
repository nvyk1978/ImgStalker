package com.cmyk.imgstalker;

import android.content.Context;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.LinkedHashSet;

/**
 * NORMAL-only, per-target record of successfully downloaded media.
 * This is not a crawler checkpoint or disposable cache. Neither SNS mode can
 * address this namespace. A cleared/restarted scan must not erase save marks.
 */
final class NormalSavedLedgerStore {
    private static final int SCHEMA = 1;
    private NormalSavedLedgerStore() { }

    static String key(String url) { return NormalCheckpointStore.key(url); }

    static String mediaKey(MediaItem item) {
        if (item == null || item.kind == MediaItem.Kind.STREAM) return "";
        String dedup = item.dedupKey == null ? "" : item.dedupKey.trim();
        if (!dedup.isEmpty()) return dedup;
        String url = item.url == null ? "" : item.url.trim();
        return url.isEmpty() ? "" : item.kind.name() + "|" + url;
    }

    /** Dedicated NORMAL saved-ledger namespace, separate from NORMAL progress JSON. */
    private static AtomicFile file(Context context, String url) throws Exception {
        if (context == null || key(url).isEmpty())
            throw new IllegalArgumentException("NORMAL saved ledger requires a NORMAL URL");
        File checkpoint = NormalCheckpointStore.checkpoint(context, url);
        File dir = new File(new File(context.getFilesDir(), "NormalSavedLedgers"),
                checkpoint.getParentFile().getName());
        if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory())
            throw new java.io.IOException("Cannot create NORMAL saved-ledger directory");
        String filename = checkpoint.getName();
        if (filename.endsWith(".json")) filename = filename.substring(0, filename.length() - 5);
        return new AtomicFile(new File(dir, filename + ".saved.json"));
    }

    static LinkedHashSet<String> load(Context context, String url) {
        LinkedHashSet<String> result = new LinkedHashSet<>();
        String target = key(url);
        if (context == null || target.isEmpty()) return result;
        try (FileInputStream in = file(context, url).openRead()) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] bytes = new byte[8192];
            int count;
            while ((count = in.read(bytes)) >= 0) buffer.write(bytes, 0, count);
            JSONObject json = new JSONObject(buffer.toString(StandardCharsets.UTF_8.name()));
            if (json.optInt("schema", 0) != SCHEMA
                    || !target.equals(json.optString("target", ""))
                    || !"NORMAL".equals(json.optString("mode", ""))) {
                DiagnosticLog.log("NORMAL_SAVED_LEDGER_REJECT target_mismatch=" + target);
                return result;
            }
            JSONArray saved = json.optJSONArray("saved_media_keys");
            if (saved != null) for (int i = 0; i < saved.length(); i++) {
                String savedKey = saved.optString(i, "").trim();
                if (!savedKey.isEmpty()) result.add(savedKey);
            }
        } catch (java.io.FileNotFoundException ignored) {
            // First save on this NORMAL target.
        } catch (Throwable e) {
            DiagnosticLog.logException("NORMAL_SAVED_LEDGER_LOAD_FAIL", e);
        }
        DiagnosticLog.log("NORMAL_SAVED_LEDGER_LOAD target=" + target + " saved=" + result.size());
        return result;
    }

    /** Only grows: delayed writes never discard previously committed success entries. */
    static boolean save(Context context, String url, Collection<String> newKeys) {
        String target = key(url);
        if (context == null || target.isEmpty()) return false;
        LinkedHashSet<String> saved = load(context, url);
        if (newKeys != null) for (String newKey : newKeys) {
            if (newKey != null && !newKey.trim().isEmpty()) saved.add(newKey.trim());
        }
        AtomicFile atomic = null;
        FileOutputStream output = null;
        try {
            atomic = file(context, url);
            JSONObject json = new JSONObject();
            json.put("schema", SCHEMA);
            json.put("mode", "NORMAL");
            json.put("target", target);
            json.put("updated_at", System.currentTimeMillis());
            JSONArray values = new JSONArray();
            for (String value : saved) values.put(value);
            json.put("saved_media_keys", values);
            output = atomic.startWrite();
            output.write(json.toString().getBytes(StandardCharsets.UTF_8));
            atomic.finishWrite(output);
            output = null;
            DiagnosticLog.log("NORMAL_SAVED_LEDGER_COMMIT target=" + target + " saved=" + saved.size());
            return true;
        } catch (Throwable e) {
            if (output != null && atomic != null) {
                try { atomic.failWrite(output); } catch (Throwable ignored) { }
            }
            DiagnosticLog.logException("NORMAL_SAVED_LEDGER_WRITE_FAIL", e);
            return false;
        }
    }
}
