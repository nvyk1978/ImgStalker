# ImgStalker 0.1.166 (versionCode 167)

GitBuild upload-light source archive. Application sources, assets, tests,
Gradle files, signing keystore and all non-README files are byte-identical
to ImgStalker_0.1.166_source.zip. The full release history and longer
notes are preserved in that original archive. Only this README is shortened
to reduce upload size for timeout diagnosis.
