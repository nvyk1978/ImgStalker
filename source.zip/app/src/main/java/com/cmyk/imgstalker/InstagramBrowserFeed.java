package com.cmyk.imgstalker;

import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Strictly Instagram-only, first-party browser feed observer.
 * The page, not ImgStalker, initiates GraphQL requests. WebView's document-start script
 * records only responses already received by that page. The observer never issues a
 * synthetic GraphQL POST, guesses a doc_id, or touches NORMAL/X execution state.
 */
final class InstagramBrowserFeed {
    interface Observer {
        void onPostUrl(String url);
        void onTimelineResponse(String response);
    }

    static final class Result {
        final int links;
        final int responses;
        final boolean blocked;
        final String blockReason;
        final boolean timedOut;
        final boolean endReached;
        Result(int links, int responses, boolean blocked, String blockReason,
               boolean timedOut, boolean endReached) {
            this.links = links;
            this.responses = responses;
            this.blocked = blocked;
            this.blockReason = blockReason == null ? "" : blockReason;
            this.timedOut = timedOut;
            this.endReached = endReached;
        }
    }

    private static final long PAGE_LOAD_TIMEOUT_MS = 24000L;
    private static final long MAX_SCAN_MS = 60000L;
    private static final long POLL_INTERVAL_MS = 1700L;
    private static final int MAX_POLLS = 36;
    private static final int STAGNANT_POLLS = 5;
    private final WebView webView;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LinkedBlockingQueue<String> snapshots = new LinkedBlockingQueue<>(2);
    private final AtomicBoolean active = new AtomicBoolean(false);
    private volatile CountDownLatch pageLoaded;
    private volatile ScriptHandler documentStartScript;
    private volatile String expectedUsername = "";
    private volatile String profileUrl = "";
    private volatile String scriptSource = "";

    InstagramBrowserFeed(WebView webView) {
        this.webView = webView;
    }

    private static boolean safeInstagramProfile(String url, String username) {
        if (url == null || username == null || username.isEmpty()) return false;
        try {
            java.net.URI u = new java.net.URI(url);
            String h = u.getHost();
            if (!"https".equalsIgnoreCase(u.getScheme()) || h == null ||
                !(h.equalsIgnoreCase("www.instagram.com") || h.equalsIgnoreCase("instagram.com"))) return false;
            return ("/" + username + "/").equalsIgnoreCase(u.getPath()) ||
                    ("/" + username).equalsIgnoreCase(u.getPath());
        } catch (Exception ignored) { return false; }
    }

    void onPageFinished(String url) {
        if (!active.get()) return;
        if (safeInstagramProfile(url, expectedUsername)) {
            CountDownLatch latch = pageLoaded;
            if (latch != null) latch.countDown();
        } else if (url != null && (url.contains("/accounts/login") || url.contains("/challenge/"))) {
            DiagnosticLog.log("SNS_IG_BROWSER_AUTH_PAGE detected=true");
            CountDownLatch latch = pageLoaded;
            if (latch != null) latch.countDown();
        }
    }

    void cancel() {
        active.set(false);
        CountDownLatch latch = pageLoaded;
        if (latch != null) latch.countDown();
        snapshots.offer("");
        main.post(() -> {
            if (documentStartScript != null) {
                try { documentStartScript.remove(); } catch (Throwable ignored) { }
                documentStartScript = null;
            }
            try { webView.stopLoading(); } catch (Throwable ignored) { }
        });
    }

    Result collect(String username, int limit, boolean pagination, Observer observer)
            throws InterruptedException {
        if (username == null || !username.matches("[A-Za-z0-9._]{1,30}") ||
                observer == null || !active.compareAndSet(false, true)) {
            return new Result(0, 0, false, "invalid_profile", false, false);
        }
        expectedUsername = username;
        profileUrl = "https://www.instagram.com/" + username + "/";
        pageLoaded = new CountDownLatch(1);
        snapshots.clear();
        final CountDownLatch initialized = new CountDownLatch(1);
        main.post(() -> {
            try {
                if (!active.get()) return;
                scriptSource = loadScript();
                boolean documentStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
                if (documentStart) {
                    documentStartScript = WebViewCompat.addDocumentStartJavaScript(webView,
                            scriptSource, new java.util.HashSet<>(java.util.Arrays.asList(
                                    "https://www.instagram.com", "https://instagram.com")));
                }
                DiagnosticLog.log("SNS_IG_BROWSER_FEED_START docStart=" + documentStart
                        + " username=" + expectedUsername);
                webView.loadUrl(profileUrl);
            } catch (Throwable t) {
                DiagnosticLog.log("SNS_IG_BROWSER_FEED_OPEN_FAIL error=" + t.getClass().getSimpleName());
                pageLoaded.countDown();
            } finally { initialized.countDown(); }
        });
        final Set<String> seen = new HashSet<>();
        int responses = 0;
        boolean blocked = false;
        boolean ended = false;
        String reason = "";
        boolean timedOut = false;
        int stagnant = 0;
        int previousResponseCount = 0;
        try {
            if (!initialized.await(6, TimeUnit.SECONDS)) {
                timedOut = true;
                return new Result(0, 0, false, "webview_start_timeout", true, false);
            }
            if (!pageLoaded.await(PAGE_LOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                timedOut = true;
                return new Result(0, 0, false, "page_load_timeout", true, false);
            }
            long start = System.currentTimeMillis();
            for (int poll = 0; poll < MAX_POLLS && active.get() &&
                    System.currentTimeMillis() - start < MAX_SCAN_MS; poll++) {
                final CountDownLatch callbackDone = new CountDownLatch(1);
                main.post(() -> {
                    if (!active.get()) { callbackDone.countDown(); return; }
                    try {
                        // Document-start captures requests before website scripts run.
                        // If unavailable, observe subsequent scrolling requests and DOM links.
                        webView.evaluateJavascript(scriptSource, ignored -> {
                            try {
                                webView.evaluateJavascript(
                                        "window.__imgStalkerFeedSnapshot ? window.__imgStalkerFeedSnapshot() : ''",
                                        raw -> { snapshots.offer(raw == null ? "" : raw); callbackDone.countDown(); });
                            } catch (Throwable t) { callbackDone.countDown(); }
                        });
                    } catch (Throwable t) { callbackDone.countDown(); }
                });
                String raw = snapshots.poll(6, TimeUnit.SECONDS);
                if (raw == null || raw.isEmpty()) {
                    callbackDone.await(1, TimeUnit.SECONDS);
                    stagnant++;
                    continue;
                }
                try {
                    // evaluateJavascript returns a JSON-quoted string containing snapshot JSON.
                    String decoded = new JSONArray("[" + raw + "]").optString(0, "");
                    JSONObject snap = new JSONObject(decoded);
                    String host = snap.optString("host", "");
                    if (!("www.instagram.com".equalsIgnoreCase(host) ||
                            "instagram.com".equalsIgnoreCase(host))) {
                        reason = "outside_instagram";
                        break;
                    }
                    String path = snap.optString("path", "");
                    String block = snap.optString("blocked", "");
                    if (path.startsWith("/accounts/login") || path.startsWith("/challenge")
                            || path.startsWith("/checkpoint")) block = "login";
                    if (!block.isEmpty()) {
                        blocked = true;
                        reason = block;
                        break;
                    }
                    int before = seen.size();
                    JSONArray responseList = snap.optJSONArray("responses");
                    if (responseList != null) for (int i = 0; i < responseList.length(); i++) {
                        String payload = responseList.optString(i, "");
                        if (payload.length() > 0) {
                            responses++;
                            observer.onTimelineResponse(payload);
                        }
                    }
                    JSONArray links = snap.optJSONArray("links");
                    if (links != null) for (int i = 0; i < links.length() && seen.size() < limit; i++) {
                        String link = links.optString(i, "");
                        if (link.matches("https://www\\.instagram\\.com/(p|reel)/[A-Za-z0-9_-]{5,30}/")) {
                            if (seen.add(link)) observer.onPostUrl(link);
                        }
                    }
                    int totalResponses = responses;
                    if (seen.size() > before || totalResponses > previousResponseCount) stagnant = 0;
                    else stagnant++;
                    previousResponseCount = totalResponses;
                    long scrollY = snap.optLong("scrollY", 0L);
                    long scrollHeight = snap.optLong("scrollHeight", 0L);
                    long viewport = snap.optLong("viewport", 0L);
                    boolean atBottom = scrollHeight > 0 && viewport > 0 &&
                            scrollY + viewport >= scrollHeight - 80;
                    if (seen.size() >= limit || (!pagination && seen.size() > 0)) { ended = true; break; }
                    if (stagnant >= STAGNANT_POLLS && seen.size() > 0 && atBottom) {
                        ended = true;
                        break;
                    }
                    if (stagnant >= STAGNANT_POLLS + 4) break;
                    final String scrollJs = "(function(){var e=document.scrollingElement||document.documentElement;"
                            + "if(e)e.scrollBy(0,Math.max(650,Math.round(innerHeight*0.8)));return 1;})()";
                    main.post(() -> { if (active.get()) {
                        try { webView.evaluateJavascript(scrollJs, null); } catch (Throwable ignored) { }
                    }});
                    Thread.sleep(POLL_INTERVAL_MS);
                } catch (InterruptedException e) { throw e; }
                catch (Throwable t) {
                    reason = "parse_" + t.getClass().getSimpleName();
                    DiagnosticLog.log("SNS_IG_BROWSER_FEED_POLL_FAIL error=" + t.getClass().getSimpleName());
                    stagnant++;
                }
            }
            timedOut = !ended && !blocked && seen.size() > 0;
            DiagnosticLog.log("SNS_IG_BROWSER_FEED_DONE posts=" + seen.size() +
                    " responses=" + responses + " blocked=" + blocked +
                    " exhausted=" + ended + " timeout=" + timedOut +
                    " reason=" + reason);
            return new Result(seen.size(), responses, blocked, reason, timedOut, ended);
        } finally {
            cancel();
        }
    }

    private String loadScript() throws Exception {
        try (InputStream in = webView.getContext().getAssets().open("instagram_browser_feed.js");
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) != -1) out.write(buffer, 0, len);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
}
