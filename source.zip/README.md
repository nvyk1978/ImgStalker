# ImgStalker v0.1.50 (51)

## v0.1.50
- Instagram detail traversal no longer lets one failed post block the whole profile.
- A failed carousel/detail load is moved to the back of the detail queue and retried from slide 1 after other queued posts get a turn.
- Instagram retry has no completion/skip cap; the crawler continues cycling unfinished posts until they complete or the user presses Stop.
- Empty-media/reel waits are bounded per visit, then deferred instead of ending analysis.
- Missing/un-clickable Next and slide-change failures get short in-page recovery, then defer/retry rather than completion.
- A first-slide terminal state with multiple loaded media items is treated as ambiguous carousel state and is never accepted as completed; it is retried later.
- Normal single-media/final-slide terminal confirmation uses the v0.1.43-style grace period without a full reload.
- Existing Instagram image/video de-duplication remains based on actual CDN image identity and video asset/path identity, not only slide number.
- Header gear and diagnostic icons retain the slightly reduced visual size while keeping the same 44dp touch targets.

## Package
- versionCode 51 / versionName 0.1.50.
- applicationId and fixed signing key are unchanged.
