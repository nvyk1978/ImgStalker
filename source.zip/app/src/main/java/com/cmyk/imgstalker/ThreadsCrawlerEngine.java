package com.cmyk.imgstalker;

import android.os.Handler;
import android.os.Looper;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.net.URI;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * Original Threads-only page engine. Uses its own WebViewClient and asset-based DOM
 * extraction; neither X's endpoints nor Instagram's GraphQL implementation is used.
 * An empty/blocked profile always produces an incomplete result, never success=0.
 */
final class ThreadsCrawlerEngine {
    private final WebView view;
    private final CrawlerEngine.Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final HashSet<String> mediaIds = new HashSet<>();
    private final LinkedHashSet<String> postIds = new LinkedHashSet<>();
    private String sourceUrl = "";
    private String script = "";
    private String title = "Threads";
    private int generation = 0;
    private int passes = 0;
    private int stalled = 0;
    private int images = 0;
    private int videos = 0;
    private int lastPostCount = 0;
    private int redirects = 0;
    private boolean running = false;
    private boolean scrolling = true;
    private boolean imagesEnabled = true;
    private boolean videosEnabled = true;
    private boolean incomplete = false;
    private String reason = "";

    ThreadsCrawlerEngine(WebView webView, CrawlerEngine.Listener cb) {
        view = webView;
        listener = cb;
    }

    void start(String url, boolean pages, boolean wantImages, boolean wantVideos, int minPx) {
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.THREADS)
            throw new IllegalArgumentException("Foreign site refused by Threads engine");
        sourceUrl = url;
        imagesEnabled = wantImages;
        videosEnabled = wantVideos;
        scrolling = pages;
        title = "Threads";
        running = true;
        incomplete = false;
        reason = "";
        passes = stalled = redirects = 0;
        int token = ++generation;
        script = readScript();
        try {
            String ua = view.getSettings().getUserAgentString();
            if (ua != null && !ua.isEmpty())
                view.getSettings().setUserAgentString(ua.replace("; wv)", ")").replace(" Version/4.0 ", " "));
            view.getSettings().setJavaScriptEnabled(true);
            view.getSettings().setDomStorageEnabled(true);
        } catch (Exception e) { DiagnosticLog.logException("THREADS_WEB_SETTINGS",e); }
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                return intercept(req == null ? null : req.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u) { return intercept(u); }
            @Override public void onPageFinished(WebView v, String u) {
                if (token != generation || !running) return;
                if (AnalysisModeRouter.fromUrl(u) != AnalysisModeRouter.Mode.THREADS) {
                    DiagnosticLog.log("THREADS_NAV_REFUSED finished=" + u);
                    return;
                }
                DiagnosticLog.log("THREADS_PAGE_READY url=" + u);
                main.postDelayed(() -> scan(token), 1700);
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError error) {
                if (token != generation || !running) return;
                if (req != null && req.isForMainFrame()) {
                    DiagnosticLog.log("THREADS_PAGE_ERROR url=" + req.getUrl() + " code="
                            + (error == null ? "unknown" : error.getErrorCode()));
                }
            }
        });
        listener.onStatus("Threadsを解析中");
        listener.onProgressPulse("THREADS_START");
        DiagnosticLog.log("THREADS_CRAWLER_START url=" + url);
        view.loadUrl(url);
        // Guard against perpetual navigation loops or blank pages.
        main.postDelayed(() -> {
            if (running && generation == token && passes == 0) fail("threads_page_timeout");
        }, 30000L);
    }

    private boolean intercept(String url) {
        if (url == null) return true;
        if (url.startsWith("intent:") || url.startsWith("market:")
                || url.startsWith("instagram:") || url.startsWith("threads:")) {
            DiagnosticLog.log("THREADS_APP_LINK_BLOCK url=" + url.substring(0,Math.min(url.length(),180)));
            if (++redirects > 1) {
                // Never mark an app-only redirect as a successful crawl.
                incomplete = true;
                reason = "app_redirect_blocked";
            }
            return true;
        }
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.THREADS) {
            DiagnosticLog.log("THREADS_EXTERNAL_NAV_BLOCK url=" + url.substring(0,Math.min(url.length(),180)));
            return true;
        }
        return false;
    }

    private String readScript() {
        try (InputStream in = view.getContext().getAssets().open("threads_feed.js");
             ByteArrayOutputStream b = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) >= 0) b.write(buf,0,n);
            return new String(b.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) { DiagnosticLog.logException("THREADS_JS_LOAD",e); return ""; }
    }

    private void scan(int token) {
        if (token != generation || !running) return;
        if (script.isEmpty()) { fail("threads_js_missing"); return; }
        String live = view.getUrl();
        if (AnalysisModeRouter.fromUrl(live) != AnalysisModeRouter.Mode.THREADS) {
            if (redirects > 0) { fail("threads_app_link_redirect"); return; }
            main.postDelayed(() -> scan(token), 1200); return;
        }
        ++passes;
        try {
            view.evaluateJavascript(script, result -> consume(token,result));
        } catch (Throwable e) { DiagnosticLog.logException("THREADS_DOM_EVAL_FAIL",e); fail("threads_dom_evaluation_failed"); }
    }

    private void consume(int token, String raw) {
        if (token != generation || !running) return;
        try {
            Object outer = new JSONTokener(raw == null ? "null" : raw).nextValue();
            JSONObject data = new JSONObject(outer instanceof String ? (String)outer : String.valueOf(outer));
            String observed = data.optString("href", "");
            if (AnalysisModeRouter.fromUrl(observed) != AnalysisModeRouter.Mode.THREADS) {
                fail("threads_url_mismatch"); return;
            }
            String error = data.optString("error", "");
            if (!error.isEmpty()) { DiagnosticLog.log("THREADS_DOM_FAIL reason=" + error); fail("threads_dom_parse_error"); return; }
            title = data.optString("title", "Threads");
            if (data.optBoolean("blocked", false) && postIds.isEmpty() && images == 0 && videos == 0) {
                fail("threads_login_or_access_required"); return;
            }
            JSONArray posts = data.optJSONArray("posts");
            if (posts != null) for (int i=0;i<posts.length();i++) postIds.add(posts.optString(i, ""));
            int before = images+videos;
            emit(data.optJSONArray("images"), MediaItem.Kind.IMAGE, imagesEnabled);
            emit(data.optJSONArray("videos"), MediaItem.Kind.VIDEO, videosEnabled);
            int delta = images+videos-before;
            if (delta == 0 && postIds.size() == lastPostCount) ++stalled;
            else stalled = 0;
            lastPostCount = postIds.size();
            DiagnosticLog.log("THREADS_DOM_PASS pass=" + passes + " posts=" + postIds.size()
                    + " images=" + images + " videos=" + videos + " new=" + delta
                    + " stalled=" + stalled + " body=" + data.optInt("bodyLength")
                    + " height=" + data.optInt("height") + " redirect=" + redirects);
            listener.onProgressPulse("THREADS_DOM_PASS");
            listener.onStatus("Threads 投稿 " + postIds.size() + "件 / 画像 " + images + "件 / 動画 " + videos + "件");
            if (!scrolling || stalled >= 5 || passes >= 180) {
                if (images+videos == 0 && (imagesEnabled || videosEnabled)) fail("threads_no_media_or_access_blocked");
                else finish();
                return;
            }
            view.evaluateJavascript("(function(){var d=document.scrollingElement||document.documentElement;"
                    + "var y=Math.max(480,window.innerHeight*0.80);window.scrollBy(0,y);"
                    + "for(var x of document.querySelectorAll('[role=feed],[style*=overflow]'))"
                    + "{try{if(x.scrollHeight>x.clientHeight*1.5)x.scrollTop+=y;}catch(e){}}"
                    + "return d.scrollTop;})()", unused -> main.postDelayed(() -> scan(token), 1350));
        } catch (Exception e) {
            DiagnosticLog.logException("THREADS_DOM_RESULT",e);
            fail("threads_dom_result_invalid");
        }
    }

    private void emit(JSONArray array, MediaItem.Kind kind, boolean enabled) {
        if (!enabled || array == null) return;
        for (int i=0;i<array.length();i++) {
            JSONObject m = array.optJSONObject(i);
            if (m == null) continue;
            String url = m.optString("url", "");
            String ref = m.optString("post", sourceUrl);
            if (!isHttp(url)) continue;
            if (AnalysisModeRouter.fromUrl(ref) != AnalysisModeRouter.Mode.THREADS) ref = sourceUrl;
            String key = ThreadsMediaIdentity.key(kind,url,ref);
            if (key.isEmpty()) continue;
            if (!mediaIds.add(key)) continue;
            long order = ((long)passes)*1_000_000L+m.optLong("order", i);
            MediaItem item = new MediaItem(url,ref,kind,false,0,0,0L,key,order);
            if (kind == MediaItem.Kind.IMAGE) ++images; else ++videos;
            listener.onItem(item);
        }
    }

    private static boolean isHttp(String u) {
        try { URI uri = new URI(u); String scheme = uri.getScheme();
            return uri.getHost() != null && ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
        } catch (Exception e) { return false; }
    }

    private void fail(String why) {
        if (!running) return;
        reason = why;
        incomplete = true;
        running = false;
        ++generation;
        DiagnosticLog.log("THREADS_INCOMPLETE reason=" + why + " posts=" + postIds.size()
                + " images=" + images + " videos=" + videos);
        listener.onError("Threadsの解析が完了していません（" + why + "）");
    }
    private void finish() {
        if (!running) return;
        running = false;
        DiagnosticLog.log("THREADS_DONE posts=" + postIds.size()+ " images=" + images+ " videos=" + videos);
        listener.onDone(title, Math.max(1,passes), images, videos, 0);
    }
    void cancel() { running = false; ++generation; }
    void requestGracefulStop() {
        if (running) { incomplete = true; reason="stopped_by_user"; finish(); }
    }
    boolean recoverFromStall() {
        if (running) { main.post(() -> scan(generation)); return true; }
        return false;
    }
    boolean hasPendingWork() { return running; }
    String progressSnapshot() { return "threads_posts="+postIds.size()+",images="+images+",videos="+videos+",passes="+passes; }
    void seedExternalResumeMedia(List<MediaItem> items) {
        if (items == null) return;
        for (MediaItem item : items) if (item != null && item.dedupKey != null && !item.dedupKey.isEmpty()) {
            mediaIds.add(item.dedupKey);
            if (item.kind == MediaItem.Kind.IMAGE) ++images;
            if (item.kind == MediaItem.Kind.VIDEO) ++videos;
        }
    }
    boolean isIncompleteCompletion() { return incomplete; }
    String getIncompleteCompletionReason() { return reason; }
}
