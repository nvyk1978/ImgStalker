package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.webkit.CookieManager;
import android.webkit.WebSettings;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

final class OriginalImageLoader {
    private OriginalImageLoader() {}

    static Bitmap load(Context context, MediaItem item) throws Exception {
        Exception last = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpURLConnection con = null;
            try {
                URL url = new URL(item.url);
                con = (HttpURLConnection) url.openConnection();
                con.setInstanceFollowRedirects(true);
                con.setConnectTimeout(12000);
                con.setReadTimeout(20000);
                String ua;
                try {
                    ua = WebSettings.getDefaultUserAgent(context) + " ImgStalker/0.1.85";
                } catch (Exception e) {
                    ua = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36 ImgStalker/0.1.85";
                }
                con.setRequestProperty("User-Agent", ua);
                con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
                con.setRequestProperty("Accept-Encoding", "identity");
                con.setRequestProperty("Sec-Fetch-Dest", "image");
                con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
                if (item.referrer != null && !item.referrer.isEmpty()) con.setRequestProperty("Referer", item.referrer);
                String cookie = SessionCookies.getCookie(item.url);
                if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
                DiagnosticLog.log("ORIGINAL_HTTP_BEGIN attempt=" + attempt + " url=" + item.url
                        + " ref=" + item.referrer + " cookie=" + (cookie == null ? 0 : cookie.length()));
                con.connect();
                int code = con.getResponseCode();
                DiagnosticLog.log("ORIGINAL_HTTP_RESPONSE attempt=" + attempt + " code=" + code
                        + " type=" + con.getContentType() + " length=" + con.getContentLengthLong()
                        + " finalUrl=" + con.getURL());
                if (code < 200 || code >= 300) throw new FileNotFoundException("HTTP " + code);
                try (BufferedInputStream in = new BufferedInputStream(con.getInputStream())) {
                    Bitmap bitmap = BitmapFactory.decodeStream(in);
                    if (bitmap == null) throw new IOException("image decode returned null");
                    DiagnosticLog.log("ORIGINAL_DECODED size=" + bitmap.getWidth() + "x" + bitmap.getHeight());
                    return bitmap;
                }
            } catch (Exception e) {
                last = e;
                if (attempt == 0) {
                    try { Thread.sleep(180L); } catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        throw interrupted;
                    }
                }
            } finally {
                if (con != null) con.disconnect();
            }
        }
        throw last == null ? new IOException("original image load failed") : last;
    }
}
