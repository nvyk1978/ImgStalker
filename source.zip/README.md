# ImgStalker v0.1.40 (41)

## v0.1.40
- Instagram post discovery now canonicalizes any internal URL containing `/p/`, `/reel/` or `/tv/`, including username-prefixed paths, into `https://www.instagram.com/<type>/<shortcode>/`.
- Readiness probe and scrolling harvest use the same canonical extraction rule, so links counted by `SNS_DOM_PROBE` are also queued for detail traversal.
- Instagram profile scrolling can continue up to 180 passes while the DOM height or newly discovered post shortcodes keep growing.
- Instagram detail queue safety limit increased to 300 posts; duplicate shortcodes are suppressed.
- Existing carousel, Instagram video network capture, incomplete-completion/continue-cell behavior, X media/status traversal and repost toggle are retained.
- versionCode 41 / versionName 0.1.40. applicationId and fixed signing are unchanged.
