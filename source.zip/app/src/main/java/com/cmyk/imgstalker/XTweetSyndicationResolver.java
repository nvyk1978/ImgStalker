package com.cmyk.imgstalker;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Optional first-party X embed-data fallback for a video status whose WebView has no media.
 * Must only be called from a worker thread; this is not a replacement for normal DOM/network capture.
 */
final class XTweetSyndicationResolver {
    static final class Result {
        final String url;
        final boolean animatedGif;
        final boolean stream;
        final String reason;
        Result(String url, boolean animatedGif, boolean stream, String reason) {
            this.url = url; this.animatedGif = animatedGif; this.stream = stream; this.reason = reason;
        }
    }

    private static final Pattern STATUS = Pattern.compile("/status/(\\d{5,25})(?:[/?#]|$)");
    private static final int MAX_BYTES = 2 * 1024 * 1024;
    private XTweetSyndicationResolver() {}

    static Result resolve(String statusUrl, String userAgent) {
        Matcher matcher = STATUS.matcher(statusUrl == null ? "" : statusUrl);
        if (!matcher.find()) return new Result("", false, false, "invalid_status_id");
        String id = matcher.group(1);
        HttpURLConnection connection = null;
        try {
            URL api = new URL("https://cdn.syndication.twimg.com/tweet-result?id=" + id + "&token=0");
            connection = (HttpURLConnection) api.openConnection();
            connection.setConnectTimeout(7000);
            connection.setReadTimeout(9000);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Accept-Encoding", "identity");
            connection.setRequestProperty("User-Agent", userAgent == null || userAgent.isEmpty()
                    ? "Mozilla/5.0" : userAgent);
            int code = connection.getResponseCode();
            if (code != 200) return new Result("", false, false, "http_" + code);
            String mime = connection.getContentType();
            if (mime != null && !mime.toLowerCase(Locale.ROOT).contains("json"))
                return new Result("", false, false, "unexpected_content_type");
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            try (InputStream stream = connection.getInputStream()) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = stream.read(buffer)) != -1) {
                    if (output.size() + read > MAX_BYTES) return new Result("", false, false, "response_too_large");
                    output.write(buffer, 0, read);
                }
            }
            JSONObject root = new JSONObject(output.toString("UTF-8"));
            Candidate best = new Candidate();
            inspectVideo(root.optJSONObject("video"), false, best);
            inspectMedia(root.optJSONArray("mediaDetails"), best);
            JSONObject ext = root.optJSONObject("extended_entities");
            if (ext != null) inspectMedia(ext.optJSONArray("media"), best);
            JSONObject entities = root.optJSONObject("entities");
            if (entities != null) inspectMedia(entities.optJSONArray("media"), best);
            if (best.url.isEmpty()) return new Result("", false, false, "no_playable_variant");
            return new Result(best.url, best.gif, best.stream, "ok");
        } catch (Exception e) {
            return new Result("", false, false, "fetch_" + e.getClass().getSimpleName());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static final class Candidate {
        String url = "";
        int bitrate = -1;
        boolean gif;
        boolean stream;
    }

    private static void inspectMedia(JSONArray entries, Candidate best) {
        if (entries == null) return;
        for (int i = 0; i < entries.length(); i++) {
            JSONObject item = entries.optJSONObject(i);
            if (item == null) continue;
            String type = item.optString("type", "");
            boolean gif = "animated_gif".equalsIgnoreCase(type);
            JSONObject videoInfo = item.optJSONObject("video_info");
            if (videoInfo == null) videoInfo = item.optJSONObject("videoInfo");
            if (videoInfo != null) inspectVideo(videoInfo, gif, best);
        }
    }

    private static void inspectVideo(JSONObject video, boolean gif, Candidate best) {
        if (video == null) return;
        JSONArray variants = video.optJSONArray("variants");
        if (variants == null) return;
        for (int i = 0; i < variants.length(); i++) {
            JSONObject v = variants.optJSONObject(i);
            if (v == null) continue;
            String url = v.optString("url", v.optString("src", ""));
            if (!url.startsWith("https://video.twimg.com/")) continue;
            String type = v.optString("content_type", v.optString("type", "")).toLowerCase(Locale.ROOT);
            String low = url.toLowerCase(Locale.ROOT);
            boolean mp4 = type.contains("video/mp4") || low.matches(".*\\.mp4(\\?.*)?$");
            boolean stream = !mp4 && (type.contains("mpegurl") || low.matches(".*\\.m3u8(\\?.*)?$"));
            if (!mp4 && !stream) continue;
            int bitrate = v.optInt("bitrate", 0);
            // Prefer a playable MP4. Keep HLS only when no MP4 variant exists.
            int score = (mp4 ? 100000000 : 0) + Math.max(0, bitrate);
            int existing = best.url.isEmpty() ? -1
                    : (best.stream ? 0 : 100000000) + Math.max(0, best.bitrate);
            if (score <= existing) continue;
            best.url = url;
            best.bitrate = bitrate;
            best.stream = stream;
            best.gif = gif || low.contains("/tweet_video/");
        }
    }
}
