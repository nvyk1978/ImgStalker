package com.cmyk.imgstalker;
import java.io.File;
import android.content.Context;
public class NormalCheckpointIdentityTest {
 static void eq(boolean ok, String message) {if(!ok)throw new AssertionError(message);}
 public static void main(String[] args) {
  Context ctx = new Context(new File("/tmp/normal-checkpoint-test"));
  String base = "https://legmemory.com/bbs/officelady/joyfulyy.cgi?page=0";
  String next = "https://legmemory.com/bbs/officelady/joyfulyy.cgi?page=15";
  String board = "https://legmemory.com/bbs/other/joyfulyy.cgi?page=0";
  String other = "https://example.com/bbs/officelady/joyfulyy.cgi?page=0";
  eq(NormalCheckpointStore.matches(base,next), "paged URLs not recognized as same target");
  eq(!NormalCheckpointStore.matches(base,board), "different boards collide");
  eq(!NormalCheckpointStore.matches(base,other), "different sites collide");
  eq(!NormalCheckpointStore.matches(base,"https://x.com/a"), "X mode leaked into NORMAL");
  eq(!NormalCheckpointStore.matches(base,"https://instagram.com/a"), "Instagram mode leaked into NORMAL");
  eq(NormalCheckpointStore.checkpoint(ctx,base).equals(NormalCheckpointStore.checkpoint(ctx,next)), "page path differed");
  eq(!NormalCheckpointStore.checkpoint(ctx,base).equals(NormalCheckpointStore.checkpoint(ctx,board)), "board path collided");
  eq(!NormalCheckpointStore.matches("https://example.org/path?q=a", "https://example.org/path?q=b"), "query target collided");
  String expected="/tmp/normal-checkpoint-test/Normal/legmemory.com/";
  eq(NormalCheckpointStore.checkpoint(ctx,base).getPath().startsWith(expected), "wrong checkpoint directory");
  System.out.println("PASS: NORMAL site/board/page identity; X/Instagram isolation; file paths");
 }
}
