# ImgStalker v0.1.61 (62)

## Base
- Behavior base: v0.1.60, itself rebuilt from the exact v0.1.52 source.
- Existing browser-style Instagram detail navigation (`window.location.assign`) is retained.
- Existing 2500 ms pre-detail wait is retained.
- Existing HTTP 429 immediate stop / zero-retry behavior is retained.

## Instagram diagnostics
- Corrected the detail-navigation cookie diagnostic to read the active SNS profile cookie manager through `SessionCookies` instead of the default WebView cookie manager.
- Logs cookie presence only (`cookieChars`, `sessionid`, `ds_user_id`, `csrftoken`); cookie values are never logged.
- Logs the first main-frame request for each Instagram post/reel with method, gesture/redirect state, selected browser request headers, and header names.
- Selected request headers: User-Agent, Referer, Sec-Fetch-Site, Sec-Fetch-Mode, Sec-Fetch-Dest, Sec-Fetch-User, sec-ch-ua, sec-ch-ua-mobile, sec-ch-ua-platform, Accept-Language.
- Logs pre-navigation JavaScript environment: navigator.userAgent, document.referrer, navigator.language, and navigator.userAgentData summary.
- UA string and UserAgentMetadata behavior remain the same as v0.1.60 except for the app version suffix.

## Package
- applicationId: com.cmyk.imgstalker
- versionCode 62 / versionName 0.1.61
- fixed signing key unchanged.
