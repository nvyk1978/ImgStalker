package com.cmyk.imgstalker;

import java.net.URI;
import java.util.Locale;

/**
 * NORMAL-only download destination. The owner is the scanned PAGE, never the
 * media CDN, page title, current time, or another mode's account namespace.
 * Same host (including www. and changed pagination) always resolves to one
 * folder under the currently selected ImgStalker save directory.
 */
final class NormalSiteFolder {
    private NormalSiteFolder() { }

    static String forPage(String pageUrl) {
        if (pageUrl == null || pageUrl.trim().isEmpty()) return "";
        if (AnalysisModeRouter.fromUrl(pageUrl) != AnalysisModeRouter.Mode.NORMAL) return "";
        try {
            String input = pageUrl.trim();
            if (input.matches("(?i)^[a-z][a-z0-9+.-]*:.*")
                    && !input.matches("(?i)^https?://.*")) return "";
            if (!input.matches("(?i)^https?://.*")) input = "https://" + input;
            URI parsed = new URI(input);
            String scheme = parsed.getScheme();
            if (scheme == null || !(scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http"))) return "";
            String host = parsed.getHost();
            if (host == null) return "";
            host = host.toLowerCase(Locale.ROOT);
            while (host.endsWith(".")) host = host.substring(0, host.length() - 1);
            if (host.startsWith("www.")) host = host.substring(4);
            // A folder name must be a single safe component; never accept paths.
            if (host.isEmpty() || host.length() > 120
                    || !host.matches("[a-z0-9](?:[a-z0-9._-]*[a-z0-9])?")) return "";
            if (host.equals(".") || host.equals("..") || host.contains("..")) return "";
            return "Normal/" + host;
        } catch (Exception ignored) {
            return "";
        }
    }
}
