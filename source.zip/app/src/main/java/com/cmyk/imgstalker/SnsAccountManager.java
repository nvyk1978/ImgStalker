package com.cmyk.imgstalker;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;
import android.webkit.WebView;

import androidx.webkit.Profile;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class SnsAccountManager {
    // Any service exposed by an SNS icon must also have its own dedicated crawler logic.
    // Do not route a Service value through generic intelligent traversal.
    public enum Service {
        X("x", "X", "https://x.com/login", "https://x.com", "auth_token="),
        INSTAGRAM("ig", "Instagram", "https://www.instagram.com/accounts/login/?next=%2F", "https://www.instagram.com", "sessionid=");

        final String key;
        final String label;
        final String loginUrl;
        final String cookieUrl;
        final String authCookieMarker;

        Service(String key, String label, String loginUrl, String cookieUrl, String authCookieMarker) {
            this.key = key;
            this.label = label;
            this.loginUrl = loginUrl;
            this.cookieUrl = cookieUrl;
            this.authCookieMarker = authCookieMarker;
        }
    }

    public static final class Account {
        public final Service service;
        public final String profileName;
        public final int order;
        public String userId;

        Account(Service service, String profileName, int order) {
            this(service, profileName, order, "");
        }

        Account(Service service, String profileName, int order, String userId) {
            this.service = service;
            this.profileName = profileName;
            this.order = order;
            this.userId = sanitizeUserId(service, userId);
        }

        public String displayName() {
            return userId == null || userId.isEmpty() ? service.label : "@" + userId;
        }
    }

    private static final String PREFS = "sns_accounts";
    private final Context appContext;
    private final SharedPreferences prefs;

    public SnsAccountManager(Context context) {
        appContext = context.getApplicationContext();
        prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean supportsMultiProfile() {
        try {
            return WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
        } catch (Throwable t) {
            return false;
        }
    }

    public List<Account> getAccounts(Service service) {
        String raw = prefs.getString(service.key + "_profiles", "");
        if (raw == null || raw.trim().isEmpty()) return Collections.emptyList();
        ArrayList<Account> out = new ArrayList<>();
        int order = 1;
        for (String p : raw.split("\\n")) {
            String profile = p.trim();
            if (!profile.isEmpty()) {
                String userId = prefs.getString(userIdKey(service, profile), "");
                out.add(new Account(service, profile, order++, userId));
            }
        }
        return out;
    }

    public Account allocateAccount(Service service) {
        List<Account> current = getAccounts(service);
        if (!supportsMultiProfile() && !current.isEmpty()) return current.get(0);
        if (!supportsMultiProfile()) return new Account(service, Profile.DEFAULT_PROFILE_NAME, 1);

        // Reuse the smallest uncommitted slot. A failed login no longer leaves x_01, x_02, ...
        // profiles growing forever; once x_01 is committed, the next account becomes x_02.
        int serial = 1;
        while (true) {
            String candidate = String.format("imgstalker_%s_%02d", service.key, serial);
            boolean used = false;
            for (Account a : current) {
                if (candidate.equals(a.profileName)) { used = true; break; }
            }
            if (!used) return new Account(service, candidate, current.size() + 1);
            serial++;
        }
    }

    public boolean isCommitted(Account account) {
        if (account == null) return false;
        for (Account a : getAccounts(account.service)) {
            if (a.profileName.equals(account.profileName)) return true;
        }
        return false;
    }

    public boolean discardUncommitted(Account account) {
        if (account == null || isCommitted(account)) return true;
        if (!supportsMultiProfile() || Profile.DEFAULT_PROFILE_NAME.equals(account.profileName)) return true;
        try {
            ProfileStore.getInstance().deleteProfile(account.profileName);
            DiagnosticLog.log("SNS_PROFILE_DISCARD profile=" + account.profileName);
            return true;
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_PROFILE_DISCARD_DEFERRED profile=" + account.profileName
                    + " reason=" + t.getClass().getSimpleName());
            return false;
        }
    }

    public void commitAccount(Account account) {
        List<Account> current = getAccounts(account.service);
        for (Account a : current) if (a.profileName.equals(account.profileName)) return;
        StringBuilder sb = new StringBuilder();
        for (Account a : current) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(a.profileName);
        }
        if (sb.length() > 0) sb.append('\n');
        sb.append(account.profileName);
        prefs.edit().putString(account.service.key + "_profiles", sb.toString()).apply();
    }

    public void removeAccount(Account target) {
        List<Account> current = getAccounts(target.service);
        StringBuilder sb = new StringBuilder();
        for (Account a : current) {
            if (a.profileName.equals(target.profileName)) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(a.profileName);
        }
        SharedPreferences.Editor editor = prefs.edit().putString(target.service.key + "_profiles", sb.toString());
        editor.remove(userIdKey(target.service, target.profileName));
        editor.remove(verifiedKey(target.service, target.profileName)).apply();
        if (supportsMultiProfile() && !Profile.DEFAULT_PROFILE_NAME.equals(target.profileName)) {
            try {
                ProfileStore.getInstance().deleteProfile(target.profileName);
            } catch (Throwable t) {
                DiagnosticLog.log("SNS_PROFILE_DELETE_DEFERRED profile=" + target.profileName + " reason=" + t.getClass().getSimpleName());
            }
        }
    }

    public void applyProfile(WebView webView, String profileName) {
        if (webView == null || profileName == null || profileName.isEmpty()) return;
        if (!supportsMultiProfile() || Profile.DEFAULT_PROFILE_NAME.equals(profileName)) return;
        WebViewCompat.setProfile(webView, profileName);
    }

    public CookieManager cookieManager(String profileName) {
        try {
            if (supportsMultiProfile() && profileName != null && !profileName.isEmpty()) {
                return ProfileStore.getInstance().getOrCreateProfile(profileName).getCookieManager();
            }
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_COOKIE_MANAGER_FALLBACK profile=" + profileName + " reason=" + t.getClass().getSimpleName());
        }
        return CookieManager.getInstance();
    }


    public void prepareLoginCookies(WebView webView, String profileName) {
        if (webView == null) return;
        try {
            CookieManager manager = cookieManager(profileName);
            manager.setAcceptCookie(true);
            manager.setAcceptThirdPartyCookies(webView, true);
            DiagnosticLog.log("SNS_COOKIE_POLICY profile=" + profileName + " accept=true thirdParty=true");
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_COOKIE_POLICY_FAIL profile=" + profileName + " reason=" + t.getClass().getSimpleName());
        }
    }

    public void flushCookies(String profileName) {
        try {
            cookieManager(profileName).flush();
            DiagnosticLog.log("SNS_COOKIE_FLUSH profile=" + profileName);
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_COOKIE_FLUSH_FAIL profile=" + profileName + " reason=" + t.getClass().getSimpleName());
        }
    }

    public boolean hasAuthCookie(Account account) {
        if (account == null) return false;
        try {
            String cookies = cookieManager(account.profileName).getCookie(account.service.cookieUrl);
            return cookies != null && cookies.contains(account.service.authCookieMarker);
        } catch (Throwable t) {
            return false;
        }
    }

    public boolean isLoggedIn(Account account) {
        if (account == null || !hasAuthCookie(account)) return false;
        String id = getUserId(account);
        if (id.isEmpty()) return false;
        return prefs.getBoolean(verifiedKey(account.service, account.profileName), false);
    }

    // X can have a fully valid auth_token while its current DOM does not expose the
    // account handle. Treat that cookie as an authenticated session and resolve @ID
    // independently as optional display metadata. Instagram keeps the stricter rule.
    public boolean isSessionAuthenticated(Account account) {
        if (account == null || !hasAuthCookie(account)) return false;
        if (account.service == Service.X) return true;
        return isLoggedIn(account);
    }

    public void clearVerification(Account account) {
        if (account == null) return;
        prefs.edit().putBoolean(verifiedKey(account.service, account.profileName), false).apply();
        DiagnosticLog.log("SNS_ACCOUNT_VERIFY_CLEAR service=" + account.service.label
                + " profile=" + account.profileName);
    }

    public String getCookie(String profileName, String url) {
        try {
            String value = cookieManager(profileName).getCookie(url);
            return value == null ? "" : value;
        } catch (Throwable t) {
            return "";
        }
    }


    public String getUserId(Account account) {
        if (account == null) return "";
        String id = sanitizeUserId(account.service, account.userId);
        if (!id.isEmpty()) return id;
        String stored = prefs.getString(userIdKey(account.service, account.profileName), "");
        id = sanitizeUserId(account.service, stored);
        if (id.isEmpty() && stored != null && !stored.trim().isEmpty()) {
            prefs.edit().remove(userIdKey(account.service, account.profileName))
                    .putBoolean(verifiedKey(account.service, account.profileName), false).apply();
            DiagnosticLog.log("SNS_ACCOUNT_ID_REJECT service=" + account.service.label
                    + " profile=" + account.profileName + " raw=" + stored);
        }
        account.userId = id;
        return id;
    }

    public void setUserId(Account account, String rawUserId) {
        if (account == null) return;
        String id = sanitizeUserId(account.service, rawUserId);
        if (id.isEmpty()) return;
        account.userId = id;
        prefs.edit()
                .putString(userIdKey(account.service, account.profileName), id)
                .putBoolean(verifiedKey(account.service, account.profileName), true)
                .apply();
        DiagnosticLog.log("SNS_ACCOUNT_ID service=" + account.service.label
                + " profile=" + account.profileName + " userId=@" + id + " verified=true");
    }

    private static String userIdKey(Service service, String profileName) {
        return service.key + "_user_id_" + (profileName == null ? "" : profileName);
    }

    private static String verifiedKey(Service service, String profileName) {
        return service.key + "_verified_" + (profileName == null ? "" : profileName);
    }

    private static String sanitizeUserId(Service service, String raw) {
        if (raw == null) return "";
        String id = raw.trim();
        while (id.startsWith("@")) id = id.substring(1).trim();
        int slash = id.indexOf('/');
        if (slash >= 0) id = id.substring(0, slash);
        int q = id.indexOf('?');
        if (q >= 0) id = id.substring(0, q);
        int hash = id.indexOf('#');
        if (hash >= 0) id = id.substring(0, hash);
        if (service == Service.X) {
            if (!id.matches("[A-Za-z0-9_]{1,32}")) return "";
            String x = id.toLowerCase();
            if (x.matches("login|logout|signup|signin|home|explore|notification|notifications|messages|compose|settings|search|i|intent|share|tos|privacy|account|accounts|download|help|about|jobs|premium|communities")) return "";
            return id;
        }
        if (!id.matches("[A-Za-z0-9._]{1,64}")) return "";
        String x = id.toLowerCase();
        if (x.matches("accounts|account|login|logout|signup|signin|home|explore|search|notification|notifications|activity|direct|inbox|messages|settings|favorites|stories|reels|p|reel|tv|web|challenge|oauth|developer|legal|about|privacy|help|threads")) return "";
        return id;
    }

    public Service serviceForUrl(String value) {
        if (value == null) return null;
        String lower = value.toLowerCase();
        if (lower.contains("x.com/") || lower.contains("twitter.com/")) return Service.X;
        if (lower.contains("instagram.com/")) return Service.INSTAGRAM;
        return null;
    }
}
