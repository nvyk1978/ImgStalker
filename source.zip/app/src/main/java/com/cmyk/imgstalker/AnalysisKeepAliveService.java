package com.cmyk.imgstalker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.os.PowerManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.webkit.WebView;
import android.widget.FrameLayout;

public class AnalysisKeepAliveService extends Service {
    private static final String CHANNEL_ID = "imgstalker_analysis";
    private static final int NOTIFICATION_ID = 1053;
    private static final long WAKE_LOCK_TIMEOUT_MS = 6L * 60L * 60L * 1000L;

    private static volatile AnalysisKeepAliveService instance;
    private static volatile CrawlerEngine retainedCrawler;
    private static volatile WebView retainedWebView;

    private PowerManager.WakeLock wakeLock;
    private FrameLayout retainedHost;

    public static void retainSession(CrawlerEngine crawler, WebView webView) {
        retainedCrawler = crawler;
        retainedWebView = webView;
        DiagnosticLog.log("BACKGROUND_SESSION retain crawler=" + (crawler != null)
                + " webView=" + (webView != null));
        AnalysisKeepAliveService s = instance;
        if (s != null) s.keepRendererActive("retain");
    }

    public static void releaseSession(CrawlerEngine crawler, WebView webView) {
        boolean crawlerMatch = crawler != null && retainedCrawler == crawler;
        boolean webViewMatch = webView != null && retainedWebView == webView;
        if (crawlerMatch) retainedCrawler = null;
        if (webViewMatch) {
            AnalysisKeepAliveService s = instance;
            if (s != null) s.releaseAdoptedWebView(webView);
            retainedWebView = null;
        }
        DiagnosticLog.log("BACKGROUND_SESSION release crawlerMatch=" + crawlerMatch
                + " webViewMatch=" + webViewMatch);
    }

    public static boolean isRetaining(CrawlerEngine crawler, WebView webView) {
        return crawler != null && webView != null && retainedCrawler == crawler && retainedWebView == webView;
    }

    public static void adoptRetainedWebView() {
        AnalysisKeepAliveService s = instance;
        if (s != null) s.adoptWebView(retainedWebView);
    }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        DiagnosticLog.install(this);
        createNotificationChannel();
        retainedHost = new FrameLayout(this);
        retainedHost.setVisibility(View.VISIBLE);
        acquireWakeLock();
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE onCreate");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification = buildNotification();
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        keepRendererActive("foreground_start");
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE foreground startId=" + startId
                + " session=" + (retainedCrawler != null && retainedWebView != null));
        return START_NOT_STICKY;
    }

    private void keepRendererActive(String reason) {
        WebView w = retainedWebView;
        if (w == null) return;
        try {
            w.resumeTimers();
            w.onResume();
            w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
            DiagnosticLog.log("BACKGROUND_WEBVIEW active reason=" + reason
                    + " attached=" + w.isAttachedToWindow()
                    + " parent=" + (w.getParent() == null ? "none" : w.getParent().getClass().getSimpleName()));
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_WEBVIEW active_fail reason=" + reason, t);
        }
    }

    private void adoptWebView(WebView w) {
        if (w == null || retainedHost == null) return;
        try {
            ViewParent parent = w.getParent();
            if (parent instanceof ViewGroup) ((ViewGroup) parent).removeView(w);

            int densityWidth = Math.max(360, getResources().getDisplayMetrics().widthPixels);
            int densityHeight = Math.max(640, getResources().getDisplayMetrics().heightPixels);
            int width = Math.max(densityWidth, w.getMinimumWidth());
            int height = Math.max(densityHeight, w.getMinimumHeight());
            retainedHost.removeAllViews();
            retainedHost.addView(w, new FrameLayout.LayoutParams(width, height));
            int ws = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
            int hs = View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY);
            retainedHost.measure(ws, hs);
            retainedHost.layout(0, 0, width, height);
            w.measure(ws, hs);
            w.layout(0, 0, width, height);
            keepRendererActive("activity_destroy_adopt");
            DiagnosticLog.log("BACKGROUND_WEBVIEW_ADOPT size=" + width + "x" + height);
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_WEBVIEW_ADOPT_FAIL", t);
        }
    }

    private void releaseAdoptedWebView(WebView target) {
        if (retainedHost == null) return;
        try {
            WebView w = target != null ? target : retainedWebView;
            if (w != null && w.getParent() == retainedHost) retainedHost.removeView(w);
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_WEBVIEW_RELEASE_FAIL", t);
        }
    }

    private void createNotificationChannel() {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "バックグラウンド解析",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("ImgStalkerの解析をバックグラウンドで継続します");
        channel.setSound(null, null);
        channel.enableVibration(false);
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Intent launchIntent = new Intent(this, MainActivity.class);
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("ImgStalker")
                .setContentText("バックグラウンドで解析中")
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ImgStalker:BackgroundAnalysis");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(WAKE_LOCK_TIMEOUT_MS);
            DiagnosticLog.log("BACKGROUND_ANALYSIS_WAKELOCK acquire");
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_ANALYSIS_WAKELOCK acquire_fail", t);
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            DiagnosticLog.log("BACKGROUND_ANALYSIS_WAKELOCK release");
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_ANALYSIS_WAKELOCK release_fail", t);
        }
        wakeLock = null;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE task_removed session="
                + (retainedCrawler != null && retainedWebView != null));
        keepRendererActive("task_removed");
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onTrimMemory(int level) {
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE trim_memory level=" + level
                + " session=" + (retainedCrawler != null && retainedWebView != null));
        if (retainedCrawler != null && retainedWebView != null) keepRendererActive("trim_memory_" + level);
        super.onTrimMemory(level);
    }

    @Override public void onTimeout(int startId, int fgsType) {
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE timeout startId=" + startId + " type=" + fgsType);
        retainedCrawler = null;
        retainedWebView = null;
        stopSelf(startId);
    }

    @Override public void onDestroy() {
        releaseAdoptedWebView(retainedWebView);
        retainedCrawler = null;
        retainedWebView = null;
        releaseWakeLock();
        stopForeground(STOP_FOREGROUND_REMOVE);
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE onDestroy");
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }
}
