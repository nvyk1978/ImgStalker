#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
icon=Path('app/src/main/java/com/cmyk/imgstalker/NavigationIconLoader.java').read_text()
gradle=Path('app/build.gradle').read_text()
assert 'versionCode 167' in gradle and "versionName '0.1.166'" in gradle
assert 'urlInput.setHint("URLを入力")' in s
assert 'https://example.com/gallery' not in s
assert 'urlInput.setImeOptions(EditorInfo.IME_ACTION_GO' in s
assert 'urlInput.setOnEditorActionListener(' in s
assert 'event.getKeyCode() == KeyEvent.KEYCODE_ENTER' in s
assert 'event.getAction() != KeyEvent.ACTION_DOWN' in s
assert 'startAnalysisFromUrlIme();' in s
assert 'private void startAnalysisFromUrlIme()' in s
assert 'AnalysisKeepAliveService.hasOtherRetainedOwner(this)' in s
assert 'if (url == null || url.trim().isEmpty()) view.setImageResource(R.drawable.ic_nav_normal);' in icon
assert 'R.drawable.ic_nav_x' in icon and 'R.drawable.ic_nav_normal' in icon
assert 'private boolean isBatchSelectionLocked()' in s
assert 'return downloading || (mirroredWorkOwner != null && mirroredWorkOwner.downloading);' in s

def method(name):
    # Locate the definition, not earlier callsites like setOnClickListener lambdas.
    import re
    m=re.search(r"    private (?:void|boolean|int) " + re.escape(name) + r"\([^)]*\)\s*\{",s)
    assert m, name
    begin=m.start(); brace=m.end()-1
    depth=1;idx=brace+1
    while depth:
        ch=s[idx]
        if ch=='{': depth+=1
        elif ch=='}': depth-=1
        idx+=1
    return s[begin:idx]
for name in ['handleSelectionButton','enterSelectionMode','exitSelectionMode','selectAllDownloadable','toggleSelectionAt','enterSelectionModeWithItem','selectRangeFromAnchor']:
    assert 'isBatchSelectionLocked()' in method(name), name
assert 'selectAllButton.setEnabled(!isBatchSelectionLocked())' in method('updateSelectionControls')
assert 'final boolean selectionLocked = isBatchSelectionLocked();' in method('updateSummary')
assert 'if (savedState && item.selected && !isBatchSelectionLocked()) item.selected = false;' in s
assert 'if (isBatchSelectionLocked()) return true;' in s
assert 'finishBatchSelectionLock("download_finished")' in s
assert 'finishBatchSelectionLock("download_cancel")' in s
assert 'finishBatchSelectionLock("provider_mismatch")' in s
assert 'finishBatchSelectionLock("force_stop")' in s
assert 'finishBatchSelectionLock("foreground_service_timeout_download")' in s
assert 'downloading = true;\n        updateSelectionControls();' in s
assert 'if (downloading) {\n            if (downloader != null) downloader.cancel();' in method('cancelCurrent')
# Ensure success callbacks do not clear selection while the download is still running.
callback_region=s[s.index('NormalSavedLocationListener saveListener ='):s.index('        // Downloading the currently displayed scan must use')]
assert 'candidate.selected = false' not in callback_region
assert 'item.selected = false' not in callback_region
# Mode engines and protected download files are kept pinned through external hash manifests.
print('PASS: v0.1.166 Enter/placeholder/globe and immutable running bulk selection UI')
PY
