package com.cmyk.imgstalker;

import android.content.Context;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedHashSet;

/** Host-side NORMAL ledger isolation test, using stub Android APIs. */
public final class NormalSavedLedgerTest {
    private static void check(boolean okay, String message) {
        if (!okay) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        File data = new File(args[0]);
        Context context = new Context(data);
        String a0 = "https://legmemory.com/bbs/alpha/joyfulyy.cgi?page=0";
        String a15 = "https://legmemory.com/bbs/alpha/joyfulyy.cgi?page=15";
        String b = "https://legmemory.com/bbs/beta/joyfulyy.cgi?page=0";
        String other = "https://example.com/page?page=0";
        String x = "https://x.com/other";
        String ig = "https://instagram.com/other";
        String one = NormalSavedLedgerStore.mediaKey(new MediaItem("https://cdn.example/a.jpg", a0, MediaItem.Kind.IMAGE, false));
        String two = NormalSavedLedgerStore.mediaKey(new MediaItem("https://cdn.example/b.jpg", a0, MediaItem.Kind.IMAGE, false));
        String dedup = NormalSavedLedgerStore.mediaKey(new MediaItem("https://cdn.example/c.jpg", a0, MediaItem.Kind.IMAGE, false, 0, 0, 0, "fixed-id"));
        check("fixed-id".equals(dedup), "dedup key takes precedence");
        check("".equals(NormalSavedLedgerStore.mediaKey(new MediaItem("https://x", a0, MediaItem.Kind.STREAM, false))), "streams are never marked");
        check(NormalSavedLedgerStore.key(a0).equals(NormalSavedLedgerStore.key(a15)), "pagination shares one target");
        check(NormalSavedLedgerStore.key(x).isEmpty() && NormalSavedLedgerStore.key(ig).isEmpty(), "SNS forbidden");
        check(NormalSavedLedgerStore.load(context, a0).isEmpty(), "fresh ledger empty");
        check(NormalSavedLedgerStore.save(context, a0, Arrays.asList(one)), "first save");
        check(NormalSavedLedgerStore.load(context, a15).contains(one), "restore on another page");
        check(NormalSavedLedgerStore.save(context, a15, Arrays.asList(two)), "second save");
        LinkedHashSet<String> loaded = NormalSavedLedgerStore.load(context, a0);
        check(loaded.size() == 2 && loaded.contains(one) && loaded.contains(two), "monotonic union");
        check(NormalSavedLedgerStore.load(context, b).isEmpty(), "other board separated");
        check(NormalSavedLedgerStore.load(context, other).isEmpty(), "other site separated");
        check(!NormalSavedLedgerStore.save(context, x, Arrays.asList("IMAGE|x")), "X cannot write NORMAL ledger");
        check(!NormalSavedLedgerStore.save(context, ig, Arrays.asList("IMAGE|ig")), "Instagram cannot write NORMAL ledger");
        File progress = NormalCheckpointStore.checkpoint(context, a0);
        progress.getParentFile().mkdirs();
        progress.createNewFile();
        check(progress.delete(), "simulate cache deletion");
        check(NormalSavedLedgerStore.load(context, a0).size() == 2, "cache deletion keeps saved ledger");
        System.out.println("PASS: NORMAL per-site saved marks, rescan, cache-clear survival, and SNS isolation");
    }
}
