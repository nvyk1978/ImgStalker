package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.webkit.CookieManager;
import android.webkit.WebView;

/** One provider owns an entire scan's transport stack. Never compose providers at call sites. */
interface ModeProvider {
    AnalysisModeRouter.Mode mode();
    void useCookies(CookieManager cookies);
    String cookieFor(String mediaUrl);
    ModeCrawler crawler(WebView view, CrawlerEngine.Listener listener);
    ModeThumbnailLoader thumbnails(Context context, Runnable onMetadata);
    ModeDownloader downloader(Context context, boolean saveXGifAsGif, MediaDownloader.Listener listener);
    Bitmap original(Context context, MediaItem item) throws Exception;
    ModePreviewPolicy preview();
}
