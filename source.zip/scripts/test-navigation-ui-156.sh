#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
from xml.etree import ElementTree as ET
ui=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
store=Path('app/src/main/java/com/cmyk/imgstalker/SiteVisitStore.java').read_text()
drag=Path('app/src/main/java/com/cmyk/imgstalker/BookmarkReorderTouch.java').read_text()
icons=Path('app/src/main/java/com/cmyk/imgstalker/NavigationIconLoader.java').read_text()
counts=Path('app/src/main/java/com/cmyk/imgstalker/NavigationMediaCounts.java').read_text()
assert 'reorder.bind(row, group)' in ui and 'reorder.bind(details, group)' in ui
assert 'v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS' in drag
assert 'row.animate().translationY(offset).setDuration(145)' in drag or 'v.animate().translationY(offset).setDuration(145)' in drag
assert 'SiteVisitStore.setBookmarkOrder(context, order)' in drag
assert 'setOnLongClickListener(historyLongPress)' in ui
assert 'confirmBookmarkRemoval(entry.url, entry.displayTitle(), change)' in ui
assert 'new LinearLayout.LayoutParams(dp(101), dp(60))' in ui
assert 'navigationCountExecutor.execute(' in ui
assert 'NavigationMediaCounts.forUrl' in ui
assert 'NavigationMediaCounts.identity' in ui
assert 'deferredNavigationRows' in ui and 'scroll.setOnScrollChangeListener' in ui
assert 'navigationIconLoader.bind(urlSiteIcon' in ui and 'navigationIconLoader.bind(favicon' in ui
assert 'inputIconLp.leftMargin = dp(40)' in ui
assert 'private static final String BOOKMARK_ORDER' in store
assert 'saved_media_keys' not in icons and 'CookieManager' not in icons
assert 'HttpURLConnection' in icons and 'getCacheDir()' in icons
assert 'SnsSavedLedgerStore.load' in counts and 'NormalSavedLedgerStore.load' in counts
assert 'AnalysisSessionStore.load' in counts
for f in ('ic_nav_x.xml','ic_nav_instagram.xml'):
 root=ET.parse(Path('app/src/main/res/drawable')/f).getroot()
 assert root.tag.endswith('vector') and list(root)
print('PASS: long-press/haptic/insert, stable controls, counts, lazy icons, XML')
PY
