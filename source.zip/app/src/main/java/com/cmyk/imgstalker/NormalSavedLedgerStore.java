package com.cmyk.imgstalker;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * NORMAL-only saved-file inventory, independent of the disposable crawl checkpoint.
 * A green check requires BOTH a record and a still-readable saved content URI.
 * No SNS ledger, cache or identifier is ever queried by this store.
 */
final class NormalSavedLedgerStore {
    private static final int SCHEMA = 2;
    private NormalSavedLedgerStore() { }

    static String key(String url) { return NormalCheckpointStore.key(url); }

    static String mediaKey(MediaItem item) {
        if (item == null || item.kind == MediaItem.Kind.STREAM) return "";
        String dedup = item.dedupKey == null ? "" : item.dedupKey.trim();
        if (!dedup.isEmpty()) return dedup;
        String url = item.url == null ? "" : item.url.trim();
        return url.isEmpty() ? "" : item.kind.name() + "|" + url;
    }

    private static AtomicFile file(Context context, String url) throws Exception {
        if (context == null || key(url).isEmpty())
            throw new IllegalArgumentException("NORMAL saved ledger requires a NORMAL URL");
        File checkpoint = NormalCheckpointStore.checkpoint(context, url);
        File dir = new File(new File(context.getFilesDir(), "NormalSavedLedgers"),
                checkpoint.getParentFile().getName());
        if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory())
            throw new java.io.IOException("Cannot create NORMAL saved-ledger directory");
        String filename = checkpoint.getName();
        if (filename.endsWith(".json")) filename = filename.substring(0, filename.length() - 5);
        return new AtomicFile(new File(dir, filename + ".saved.json"));
    }

    /** This check runs on the resume IO executor, not while drawing media cells. */
    private static boolean exists(Context context, String contentUri) {
        if (context == null || contentUri == null || !contentUri.startsWith("content://")) return false;
        try (ParcelFileDescriptor fd = context.getContentResolver()
                .openFileDescriptor(Uri.parse(contentUri), "r")) {
            return fd != null && fd.getStatSize() != 0;
        } catch (Throwable ignored) {
            return false;
        }
    }

    /**
     * Legacy schema 1 held only URL fingerprints, not actual file locations. Those
     * cannot safely be treated as saved after the user deletes the media files.
     */
    static LinkedHashMap<String, String> load(Context context, String url) {
        LinkedHashMap<String, String> result = new LinkedHashMap<>();
        String target = key(url);
        if (context == null || target.isEmpty()) return result;
        try (FileInputStream in = file(context, url).openRead()) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] bytes = new byte[8192];
            int count;
            while ((count = in.read(bytes)) >= 0) buffer.write(bytes, 0, count);
            JSONObject json = new JSONObject(buffer.toString(StandardCharsets.UTF_8.name()));
            if (!target.equals(json.optString("target", ""))
                    || !"NORMAL".equals(json.optString("mode", ""))) {
                DiagnosticLog.log("NORMAL_SAVED_LEDGER_REJECT target_mismatch=" + target);
                return result;
            }
            if (json.optInt("schema", 0) != SCHEMA) {
                DiagnosticLog.log("NORMAL_SAVED_LEDGER_LEGACY_UNVERIFIED target=" + target
                        + " reason=missing_file_uris");
                return result;
            }
            // If a saved-ledger sidecar had been written to the user's chosen tree,
            // deleting THAT JSON intentionally clears all its saved marks.
            if (json.optBoolean("mirror_required", false)
                    && SavePrefs.hasTreeAccess(context)
                    && !NormalSavedLedgerMirror.exists(context, url)) {
                DiagnosticLog.log("NORMAL_SAVED_LEDGER_EXTERNAL_DELETED target=" + target);
                return result;
            }
            JSONArray saved = json.optJSONArray("saved_files");
            int stale = 0;
            if (saved != null) for (int i = 0; i < saved.length(); i++) {
                JSONObject entry = saved.optJSONObject(i);
                if (entry == null) continue;
                String savedKey = entry.optString("key", "").trim();
                String uri = entry.optString("uri", "").trim();
                if (savedKey.isEmpty() || uri.isEmpty()) continue;
                if (exists(context, uri)) result.put(savedKey, uri);
                else stale++;
            }
            DiagnosticLog.log("NORMAL_SAVED_LEDGER_VALIDATE target=" + target
                    + " present=" + result.size() + " missing=" + stale);
        } catch (java.io.FileNotFoundException ignored) {
            // The user removed the ledger or this is the first NORMAL save.
        } catch (Throwable e) {
            DiagnosticLog.logException("NORMAL_SAVED_LEDGER_LOAD_FAIL", e);
        }
        return result;
    }

    /** Replaces the inventory with live saved file URIs; no monotonic stale-key union. */
    static boolean save(Context context, String url, Map<String, String> knownLocations) {
        String target = key(url);
        if (context == null || target.isEmpty()) return false;
        LinkedHashMap<String, String> live = new LinkedHashMap<>();
        if (knownLocations != null) for (Map.Entry<String, String> entry : knownLocations.entrySet()) {
            if (entry.getKey() != null && !entry.getKey().trim().isEmpty()
                    && exists(context, entry.getValue())) live.put(entry.getKey().trim(), entry.getValue());
        }
        AtomicFile atomic = null;
        FileOutputStream output = null;
        try {
            JSONObject json = new JSONObject();
            json.put("schema", SCHEMA);
            json.put("mode", "NORMAL");
            json.put("target", target);
            json.put("updated_at", System.currentTimeMillis());
            JSONArray values = new JSONArray();
            for (Map.Entry<String, String> e : live.entrySet()) {
                JSONObject item = new JSONObject();
                item.put("key", e.getKey());
                item.put("uri", e.getValue());
                values.put(item);
            }
            json.put("saved_files", values);
            boolean mirrorCommitted = NormalSavedLedgerMirror.write(context, url,
                    json.toString().getBytes(StandardCharsets.UTF_8));
            json.put("mirror_required", mirrorCommitted);
            atomic = file(context, url);
            output = atomic.startWrite();
            output.write(json.toString().getBytes(StandardCharsets.UTF_8));
            atomic.finishWrite(output);
            output = null;
            DiagnosticLog.log("NORMAL_SAVED_LEDGER_COMMIT target=" + target
                    + " saved=" + live.size() + " mirror=" + mirrorCommitted);
            return true;
        } catch (Throwable e) {
            if (output != null && atomic != null) {
                try { atomic.failWrite(output); } catch (Throwable ignored) { }
            }
            DiagnosticLog.logException("NORMAL_SAVED_LEDGER_WRITE_FAIL", e);
            return false;
        }
    }
}
