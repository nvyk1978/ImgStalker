package com.cmyk.imgstalker;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = 0xFF303030;
    private static final int DARK_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int LIGHT_GRAY = 0xFF656060;
    private static final int BLUE = 0xFF223355;
    private static final int LIGHT_BLUE = 0xFF445577;
    private static final int ORANGE = 0xFF775500;
    private static final int N_WHITE = 0xFFA9A999;
    private static final int TEXT_WHITE = 0xFFFFFFFF;

    private EditText urlInput;
    private TextView status;
    private TextView summary;
    private Button analyzeButton;
    private Button selectAllButton;
    private Button cancelButton;
    private Button saveButton;
    private NToggleSwitch pageToggle;
    private NToggleSwitch detailToggle;
    private NToggleSwitch imageToggle;
    private NToggleSwitch videoToggle;
    private WebView webView;
    private CrawlerEngine crawler;
    private MediaDownloader downloader;
    private ThumbnailLoader thumbnailLoader;
    private final ArrayList<MediaItem> items = new ArrayList<>();
    private MediaAdapter adapter;
    private String pageTitle = "ImgStalker";
    private boolean analyzing = false;
    private boolean downloading = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DiagnosticLog.install(this);
        DiagnosticLog.log("ACTIVITY onCreate");
        setTitle("ImgStalker");
        buildUi();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        DiagnosticLog.log("ACTIVITY onNewIntent action=" + (intent == null ? "null" : intent.getAction()));
        setIntent(intent);
        handleIntent(intent);
    }

    private void buildUi() {
        getWindow().setStatusBarColor(DARK_GRAY);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(BG);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("ImgStalker", 24, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1f));
        Button menu = button("⋮", DARK_GRAY);
        menu.setTextColor(N_WHITE);
        menu.setTextSize(24);
        menu.setPadding(0, 0, 0, 0);
        titleRow.addView(menu, new LinearLayout.LayoutParams(dp(44), dp(44)));
        root.addView(titleRow, lpMatchWrap(0, 0, dp(12)));
        menu.setOnClickListener(this::showOverflowMenu);

        LinearLayout urlRow = new LinearLayout(this);
        urlRow.setOrientation(LinearLayout.HORIZONTAL);
        urlRow.setGravity(Gravity.CENTER_VERTICAL);
        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextColor(TEXT_WHITE);
        urlInput.setHintTextColor(N_WHITE);
        urlInput.setHint("https://example.com/gallery");
        urlInput.setTextSize(14);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setPadding(dp(12), 0, dp(12), 0);
        urlInput.setBackground(rounded(DARK_GRAY, 10));
        urlRow.addView(urlInput, new LinearLayout.LayoutParams(0, dp(46), 1f));
        analyzeButton = button("解析", ORANGE);
        LinearLayout.LayoutParams abp = new LinearLayout.LayoutParams(dp(78), dp(46));
        abp.leftMargin = dp(10);
        urlRow.addView(analyzeButton, abp);
        root.addView(urlRow, lpMatchWrap(0, 0, dp(12)));

        LinearLayout toggles = new LinearLayout(this);
        toggles.setOrientation(LinearLayout.VERTICAL);
        toggles.setPadding(dp(12), dp(8), dp(12), dp(8));
        toggles.setBackground(rounded(DARK_GRAY, 12));
        pageToggle = addToggleRow(toggles, "ページ送りを追跡", true);
        detailToggle = addToggleRow(toggles, "サムネイル先を追跡", true);
        imageToggle = addToggleRow(toggles, "画像を取得", true);
        videoToggle = addToggleRow(toggles, "動画を取得", true);
        root.addView(toggles, lpMatchWrap(0, 0, dp(12)));

        status = text("URLを入力して解析", 13, N_WHITE);
        status.setMaxLines(2);
        root.addView(status, lpMatchWrap(0, 0, dp(4)));
        summary = text("画像 0   動画 0   ストリーム 0", 14, TEXT_WHITE);
        root.addView(summary, lpMatchWrap(0, 0, dp(10)));

        thumbnailLoader = new ThumbnailLoader();
        adapter = new MediaAdapter(this, items);
        ListView list = new ListView(this);
        list.setAdapter(adapter);
        list.setDivider(new ColorDrawable(GRAY));
        list.setDividerHeight(1);
        list.setBackgroundColor(BG);
        list.setFastScrollEnabled(true);
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        selectAllButton = button("全選択", ORANGE);
        cancelButton = button("キャンセル", GRAY);
        saveButton = button("一括保存", BLUE);
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        buttons.addView(selectAllButton, cloneParams(bp, 0, 0, dp(8), 0));
        buttons.addView(cancelButton, cloneParams(bp, 0, 0, dp(8), 0));
        buttons.addView(saveButton, bp);
        root.addView(buttons, lpMatchWrap(dp(8), 0, 0));

        webView = new WebView(this);
        webView.setAlpha(0.01f);
        root.addView(webView, new LinearLayout.LayoutParams(1, 1));

        setContentView(root);

        analyzeButton.setOnClickListener(v -> startAnalysis());
        selectAllButton.setOnClickListener(v -> toggleSelectAll());
        cancelButton.setOnClickListener(v -> cancelCurrent());
        saveButton.setOnClickListener(v -> startDownload());

        crawler = new CrawlerEngine(webView, new CrawlerEngine.Listener() {
            @Override public void onStatus(String text) {
                runOnUiThread(() -> status.setText(text));
            }

            @Override public void onItem(MediaItem item) {
                runOnUiThread(() -> {
                    items.add(item);
                    adapter.notifyDataSetChanged();
                    updateSummary();
                });
            }

            @Override public void onDone(String title, int visitedPages, int imageCount, int videoCount, int streamCount) {
                runOnUiThread(() -> {
                    analyzing = false;
                    DiagnosticLog.log("ANALYZE_DONE pages=" + visitedPages + " images=" + imageCount + " videos=" + videoCount + " streams=" + streamCount);
                    pageTitle = title == null || title.trim().isEmpty() ? hostFromUrl(urlInput.getText().toString()) : title.trim();
                    status.setText("解析完了  " + visitedPages + "ページ");
                    analyzeButton.setText("解析");
                    saveButton.setEnabled(countSelectedDownloadable() > 0);
                    applyButtonEnabledStyle(saveButton);
                    updateSummary();
                });
            }

            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    analyzing = false;
                    DiagnosticLog.log("ANALYZE_ERROR " + message);
                    status.setText(message);
                    analyzeButton.setText("解析");
                });
            }
        });
    }

    private NToggleSwitch addToggleRow(LinearLayout parent, String label, boolean checked) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(label, 14, TEXT_WHITE);
        row.addView(t, new LinearLayout.LayoutParams(0, dp(42), 1f));
        NToggleSwitch sw = new NToggleSwitch(this);
        sw.setChecked(checked);
        row.addView(sw, new LinearLayout.LayoutParams(dp(48), dp(26)));
        parent.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        return sw;
    }

    private void startAnalysis() {
        String url = urlInput.getText().toString().trim();
        if (url.isEmpty()) {
            Toast.makeText(this, "URLを入力してください", Toast.LENGTH_SHORT).show();
            return;
        }
        if (downloading) return;
        if (analyzing) crawler.cancel();
        DiagnosticLog.log("ANALYZE_START url=" + url
                + " pagination=" + pageToggle.isChecked()
                + " details=" + detailToggle.isChecked()
                + " images=" + imageToggle.isChecked()
                + " videos=" + videoToggle.isChecked());
        items.clear();
        adapter.notifyDataSetChanged();
        pageTitle = "ImgStalker";
        analyzing = true;
        status.setText("解析開始");
        summary.setText("画像 0   動画 0   ストリーム 0");
        analyzeButton.setText("再解析");
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        crawler.start(url, pageToggle.isChecked(), detailToggle.isChecked(), imageToggle.isChecked(), videoToggle.isChecked());
    }

    private void startDownload() {
        if (analyzing || downloading) return;
        int selected = countSelectedDownloadable();
        if (selected == 0) {
            Toast.makeText(this, "保存する画像・動画を選択してください", Toast.LENGTH_SHORT).show();
            return;
        }
        downloading = true;
        DiagnosticLog.log("DOWNLOAD_START selected=" + selected + " title=" + pageTitle);
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        status.setText("保存開始  " + selected + "ファイル");
        downloader = new MediaDownloader(this, new MediaDownloader.Listener() {
            @Override public void onProgress(int done, int total, String message) {
                runOnUiThread(() -> status.setText("保存中  " + done + " / " + total));
            }

            @Override public void onFinished(String folderName, int success, int failed) {
                runOnUiThread(() -> {
                    downloading = false;
                    DiagnosticLog.log("DOWNLOAD_DONE folder=" + folderName + " success=" + success + " failed=" + failed);
                    saveButton.setEnabled(countSelectedDownloadable() > 0);
                    applyButtonEnabledStyle(saveButton);
                    if (folderName.isEmpty()) {
                        status.setText("保存対象がありません");
                    } else {
                        status.setText("保存完了  " + success + "件 / 失敗 " + failed + "件\nDownloads/ImgStalker/" + folderName);
                    }
                });
            }
        });
        downloader.download(items, pageTitle);
    }

    private void cancelCurrent() {
        if (analyzing) {
            crawler.cancel();
            DiagnosticLog.log("ANALYZE_CANCEL");
            analyzing = false;
            analyzeButton.setText("解析");
            status.setText("解析をキャンセル");
            saveButton.setEnabled(countSelectedDownloadable() > 0);
            applyButtonEnabledStyle(saveButton);
            return;
        }
        if (downloading && downloader != null) {
            downloader.cancel();
            DiagnosticLog.log("DOWNLOAD_CANCEL");
            downloading = false;
            status.setText("保存をキャンセル");
            return;
        }
        items.clear();
        adapter.notifyDataSetChanged();
        updateSummary();
        status.setText("結果をクリア");
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
    }

    private void toggleSelectAll() {
        boolean hasUnselected = false;
        for (MediaItem i : items) {
            if (i.kind != MediaItem.Kind.STREAM && !i.selected) {
                hasUnselected = true;
                break;
            }
        }
        for (MediaItem i : items) if (i.kind != MediaItem.Kind.STREAM) i.selected = hasUnselected;
        adapter.notifyDataSetChanged();
        selectAllButton.setText(hasUnselected ? "全解除" : "全選択");
        saveButton.setEnabled(countSelectedDownloadable() > 0 && !downloading);
        applyButtonEnabledStyle(saveButton);
    }

    private void updateSummary() {
        int images = 0, videos = 0, streams = 0;
        for (MediaItem i : items) {
            if (i.kind == MediaItem.Kind.IMAGE) images++;
            else if (i.kind == MediaItem.Kind.VIDEO) videos++;
            else streams++;
        }
        summary.setText("画像 " + images + "   動画 " + videos + "   ストリーム " + streams + "   選択 " + countSelectedDownloadable());
        if (!analyzing && !downloading) {
            saveButton.setEnabled(countSelectedDownloadable() > 0);
            applyButtonEnabledStyle(saveButton);
        }
    }

    private int countSelectedDownloadable() {
        int n = 0;
        for (MediaItem i : items) if (i.selected && i.kind != MediaItem.Kind.STREAM) n++;
        return n;
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null) {
                String url = firstHttpUrl(text);
                if (!url.isEmpty()) { urlInput.setText(url); DiagnosticLog.log("SHARE_URL " + url); }
            }
        }
    }

    private static String firstHttpUrl(String text) {
        if (text == null) return "";
        for (String p : text.split("\\s+")) if (p.startsWith("http://") || p.startsWith("https://")) return p;
        return "";
    }

    private static String hostFromUrl(String text) {
        try {
            String x = text.trim();
            if (!x.matches("(?i)^https?://.*")) x = "https://" + x;
            String h = new URI(x).getHost();
            return h == null ? "WebMedia" : h;
        } catch (Exception e) { return "WebMedia"; }
    }

    private void showOverflowMenu(View anchor) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(6), dp(6), dp(6), dp(6));
        panel.setBackground(rounded(DARK_GRAY, 10));

        TextView diagnostics = text("診断ログ", 14, TEXT_WHITE);
        diagnostics.setPadding(dp(14), dp(10), dp(14), dp(10));
        panel.addView(diagnostics, new LinearLayout.LayoutParams(dp(160), dp(44)));

        PopupWindow popup = new PopupWindow(panel, dp(172), ViewGroup.LayoutParams.WRAP_CONTENT, true);
        popup.setBackgroundDrawable(new ColorDrawable(DARK_GRAY));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(8));
        diagnostics.setOnClickListener(v -> {
            popup.dismiss();
            showDiagnosticLog();
        });
        popup.showAsDropDown(anchor, -dp(128), 0);
    }

    private void showDiagnosticLog() {
        DiagnosticLog.log("DIAGNOSTIC_OPEN");
        String report = DiagnosticLog.report(this);

        Dialog dialog = new Dialog(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(BG);

        TextView title = text("診断ログ", 20, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        TextView body = text(report, 11, TEXT_WHITE);
        body.setTypeface(Typeface.MONOSPACE);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setTextIsSelectable(true);
        body.setPadding(dp(10), dp(10), dp(10), dp(10));
        body.setBackground(rounded(DARK_GRAY, 10));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        Button copy = button("コピー", GRAY);
        Button share = button("共有", ORANGE);
        Button close = button("閉じる", BLUE);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        buttons.addView(copy, cloneParams(bp, 0, dp(12), dp(8), 0));
        buttons.addView(share, cloneParams(bp, 0, dp(12), dp(8), 0));
        buttons.addView(close, cloneParams(bp, 0, dp(12), 0, 0));
        root.addView(buttons, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("ImgStalker diagnostic report", report));
            Toast.makeText(this, "診断ログをコピー", Toast.LENGTH_SHORT).show();
        });
        share.setOnClickListener(v -> {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, "ImgStalker diagnostic report");
            send.putExtra(Intent.EXTRA_TEXT, report);
            startActivity(Intent.createChooser(send, "診断ログを共有"));
        });
        close.setOnClickListener(v -> dialog.dismiss());

        dialog.setContentView(root);
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(BG));
            int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.94f);
            int height = (int) (getResources().getDisplayMetrics().heightPixels * 0.82f);
            w.setLayout(width, height);
        }
    }

    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(TEXT_WHITE);
        b.setAllCaps(false);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(rounded(color, 12));
        return b;
    }

    private void applyButtonEnabledStyle(Button b) {
        if (b.isEnabled()) {
            b.setTextColor(TEXT_WHITE);
            b.setBackground(rounded(BLUE, 12));
        } else {
            b.setTextColor(N_WHITE);
            b.setBackground(rounded(GRAY, 12));
        }
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int top, int left, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(left, top, 0, bottom);
        return p;
    }

    private LinearLayout.LayoutParams cloneParams(LinearLayout.LayoutParams src, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(src.width, src.height, src.weight);
        p.setMargins(left, top, right, bottom);
        return p;
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onDestroy() {
        DiagnosticLog.log("ACTIVITY onDestroy");
        if (crawler != null) crawler.cancel();
        if (downloader != null) downloader.cancel();
        if (thumbnailLoader != null) thumbnailLoader.shutdown();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private final class MediaAdapter extends ArrayAdapter<MediaItem> {
        MediaAdapter(Context context, ArrayList<MediaItem> data) { super(context, 0, data); }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            RowHolder h;
            if (convertView == null) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(4), dp(6), dp(4), dp(6));

                CheckBox cb = new CheckBox(MainActivity.this);
                cb.setButtonTintList(new ColorStateList(
                        new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                        new int[]{LIGHT_BLUE, N_WHITE}));
                row.addView(cb, new LinearLayout.LayoutParams(dp(42), dp(42)));

                ImageView thumb = new ImageView(MainActivity.this);
                thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                thumb.setBackground(rounded(DARK_GRAY, 8));
                LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(92), dp(72));
                tp.rightMargin = dp(10);
                row.addView(thumb, tp);

                LinearLayout texts = new LinearLayout(MainActivity.this);
                texts.setOrientation(LinearLayout.VERTICAL);
                TextView kind = text("", 12, N_WHITE);
                TextView url = text("", 13, TEXT_WHITE);
                url.setMaxLines(2);
                texts.addView(kind, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(20)));
                texts.addView(url, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                h = new RowHolder(cb, thumb, kind, url);
                row.setTag(h);
                convertView = row;
            } else {
                h = (RowHolder) convertView.getTag();
            }

            MediaItem item = getItem(position);
            h.check.setOnCheckedChangeListener(null);
            h.check.setChecked(item.selected);
            h.check.setEnabled(item.kind != MediaItem.Kind.STREAM);
            thumbnailLoader.load(h.thumb, item);
            h.kind.setText(item.kindLabel() + (item.kind == MediaItem.Kind.STREAM ? "  検出のみ" : ""));
            h.url.setText(item.url);
            h.kind.setTextColor(item.kind == MediaItem.Kind.STREAM ? ORANGE : N_WHITE);
            h.check.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (item.kind == MediaItem.Kind.STREAM) return;
                item.selected = isChecked;
                updateSummary();
            });
            convertView.setOnClickListener(v -> {
                if (item.kind == MediaItem.Kind.STREAM) return;
                item.selected = !item.selected;
                notifyDataSetChanged();
                updateSummary();
            });
            convertView.setOnLongClickListener(v -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("media url", item.url));
                Toast.makeText(MainActivity.this, "URLをコピー", Toast.LENGTH_SHORT).show();
                return true;
            });
            return convertView;
        }
    }

    private static final class RowHolder {
        final CheckBox check;
        final ImageView thumb;
        final TextView kind;
        final TextView url;
        RowHolder(CheckBox check, ImageView thumb, TextView kind, TextView url) {
            this.check = check;
            this.thumb = thumb;
            this.kind = kind;
            this.url = url;
        }
    }
}
