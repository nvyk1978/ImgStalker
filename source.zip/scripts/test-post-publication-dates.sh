#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
mkdir -p "$T/src/android/content" "$T/src/org/json" "$T/src/com/cmyk/imgstalker" "$T/out"
cat > "$T/src/android/content/SharedPreferences.java" <<'JAVA'
package android.content;
import java.util.concurrent.ConcurrentHashMap;
public class SharedPreferences {
 private final ConcurrentHashMap<String,Long> values=new ConcurrentHashMap<>();
 public long getLong(String k,long d){return values.getOrDefault(k,d);}
 public Editor edit(){return new Editor();}
 public class Editor {private final java.util.Map<String,Long> pending=new java.util.HashMap<>();
  public Editor putLong(String key,long value){pending.put(key,value);return this;}
  public void apply(){values.putAll(pending);}
 }
}
JAVA
cat > "$T/src/android/content/Context.java" <<'JAVA'
package android.content;
public class Context {
 public static final int MODE_PRIVATE=0;
 private final SharedPreferences prefs=new SharedPreferences();
 public Context getApplicationContext(){return this;}
 public SharedPreferences getSharedPreferences(String key,int flags){return prefs;}
}
JAVA
cat > "$T/src/org/json/JSONArray.java" <<'JAVA'
package org.json;
public class JSONArray {
 private final java.util.ArrayList<Object> data = new java.util.ArrayList<>();
 public JSONArray(String ignored){}
 JSONArray(Object... contents){for(Object o:contents)data.add(o);}
 public int length(){return data.size();}
 public String optString(int n){return String.valueOf(opt(n));}
 public Object opt(int n){return n>=0&&n<data.size()?data.get(n):null;}
}
JAVA
cat > "$T/src/org/json/JSONObject.java" <<'JAVA'
package org.json;
public class JSONObject {
 public static final Object NULL = new Object();
 private final java.util.Map<String,Object> data=new java.util.LinkedHashMap<>();
 public JSONObject(String source) {
  // Test fixture simulating an already-received first-party nested GraphQL result.
  if(source.contains("fixture_valid")){
   JSONObject post=new JSONObject();post.data.put("code","ABC12345");post.data.put("taken_at",1700000000L);
   JSONObject edge=new JSONObject();edge.data.put("node",post);
   JSONObject timeline=new JSONObject();timeline.data.put("edges",new JSONArray(edge));
   data.put("data",timeline);
  }
 }
 public JSONObject(){}
 public String optString(String k,String def){Object v=data.get(k);return v==null?def:String.valueOf(v);}
 public boolean has(String k){return data.containsKey(k);}
 public Object opt(String k){return data.get(k);}
 public JSONArray names(){return new JSONArray(data.keySet().toArray());}
}
JAVA
cat > "$T/src/com/cmyk/imgstalker/MediaItem.java" <<'JAVA'
package com.cmyk.imgstalker;
final class MediaItem {final String url,referrer;MediaItem(String url,String referrer){this.url=url;this.referrer=referrer;}}
JAVA
cat > "$T/src/com/cmyk/imgstalker/PostDateTest.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.content.Context;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
public final class PostDateTest{
 static void eq(Object expected,Object actual){if(!expected.equals(actual))throw new AssertionError("expected "+expected+" got "+actual);}
 public static void main(String[] args){
  Context c=new Context();
  long epoch=1288834974657L;
  long published=1700000000000L;
  String xId=Long.toString(((published-epoch)<<22)|4095L);
  eq(published,PostPublicationDates.twitterPublishedAt("https://x.com/user/status/"+xId));
  eq("2023/11/15 07:13",PostPublicationDates.formatForItem(c,new MediaItem("https://pbs.twimg.com/media/a.jpg","https://x.com/user/status/"+xId)));
  eq(0L,PostPublicationDates.twitterPublishedAt("https://x.com/user/"));
  eq("",PostPublicationDates.formatForItem(c,new MediaItem("https://example.com/cat.jpg","https://example.com/")));
  eq("",PostPublicationDates.formatForItem(c,new MediaItem("https://cdn.instagram.com/a.jpg","https://www.instagram.com/p/ABC12345/")));
  PostPublicationDates.observeInstagramResponse(c,"{\"fixture_valid\":123456789}");
  eq("2023/11/15 07:13",PostPublicationDates.formatForItem(c,new MediaItem("https://cdn.instagram.com/a.jpg","https://www.instagram.com/p/ABC12345/")));
  eq("",PostPublicationDates.formatForItem(c,new MediaItem("https://cdn.instagram.com/a.jpg","https://www.instagram.com/p/UNKNOWN987/")));
  System.out.println("PASS: X snowflake posting time, Instagram observed timestamp persistence, JST and unknown-date blank");
 }
}
JAVA
javac -encoding UTF-8 -d "$T/out" $(find "$T/src" -name '*.java') \
 app/src/main/java/com/cmyk/imgstalker/PostPublicationDates.java
java -cp "$T/out" com.cmyk.imgstalker.PostDateTest
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
assert 'h.fileName.setText(fileNameFromUrl(item.url))' in s
assert 'h.postedAt.setText(PostPublicationDates.formatForItem(MainActivity.this, item))' in s
assert 'h.resolutionOverlay.setText(resolutionText)' in s
assert 'Gravity.BOTTOM | Gravity.END' in s
assert 'h.postedAt.setOnClickListener(itemTap)' in s and 'h.postedAt.setOnLongClickListener(itemLongPress)' in s
print('PASS: filename unchanged, resolution inside thumb, timestamp below filename, selection preserved')
PY
