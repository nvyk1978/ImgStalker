package com.cmyk.imgstalker;

public final class MediaItem {
    public enum Kind { IMAGE, VIDEO, STREAM }

    public final String url;
    public final String referrer;
    public final Kind kind;
    public final String dedupKey;
    public final long displayOrder;
    public boolean selected;
    public volatile int width;
    public volatile int height;
    public volatile long durationMs;

    public MediaItem(String url, String referrer, Kind kind, boolean selected) {
        this(url, referrer, kind, selected, 0, 0, 0L, "", Long.MAX_VALUE);
    }

    public MediaItem(String url, String referrer, Kind kind, boolean selected,
                     int width, int height, long durationMs) {
        this(url, referrer, kind, selected, width, height, durationMs, "", Long.MAX_VALUE);
    }

    public MediaItem(String url, String referrer, Kind kind, boolean selected,
                     int width, int height, long durationMs, String dedupKey) {
        this(url, referrer, kind, selected, width, height, durationMs, dedupKey, Long.MAX_VALUE);
    }

    public MediaItem(String url, String referrer, Kind kind, boolean selected,
                     int width, int height, long durationMs, String dedupKey, long displayOrder) {
        this.url = url;
        this.referrer = referrer;
        this.kind = kind;
        this.selected = selected;
        this.width = Math.max(0, width);
        this.height = Math.max(0, height);
        this.durationMs = Math.max(0L, durationMs);
        this.dedupKey = dedupKey == null ? "" : dedupKey;
        this.displayOrder = displayOrder;
    }

    public String kindLabel() {
        if (kind == Kind.IMAGE) return "画像";
        if (kind == Kind.VIDEO) return "動画";
        return "ストリーム";
    }
}
