package com.cmyk.imgstalker;

import java.net.URI;
import java.util.Locale;

/** IG-only failover decisions; no shared NORMAL/X state and no Android dependencies. */
final class InstagramRecoveryPolicy {
    private InstagramRecoveryPolicy() {}

    static boolean sourceNeedsBrowser(int discovered, int resolved, int skipped, int emittedMedia) {
        return discovered <= 0 || resolved <= 0 || skipped > 0 || emittedMedia <= 0;
    }

    static boolean mayReloadGrid(boolean knownPostsBelowTarget, int reloads, int maxReloads) {
        return knownPostsBelowTarget && reloads < maxReloads;
    }

    static String authGateType(String raw) {
        if (raw == null) return "none";
        try {
            URI uri = new URI(raw);
            if (!"https".equalsIgnoreCase(uri.getScheme())
                    && !"http".equalsIgnoreCase(uri.getScheme())) return "none";
            String host = uri.getHost();
            if (host == null) return "none";
            host = host.toLowerCase(Locale.ROOT);
            if (!host.equals("instagram.com") && !host.endsWith(".instagram.com")) return "none";
            String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
            if (path.startsWith("/accounts/login") || path.startsWith("/accounts/onetap")) return "login";
            if (path.startsWith("/challenge")) return "challenge";
            if (path.startsWith("/accounts/suspended")) return "suspended";
        } catch (Exception ignored) {}
        return "none";
    }
}
