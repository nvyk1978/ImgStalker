package com.cmyk.imgstalker;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Backward-compatible lookup aliases for saved SNS media. Not used for crawler deduplication.
 * Only same-kind identifiers are compared; no post-level or thumbnail-level guessing.
 */
final class SnsSavedMediaIdentity {
    private SnsSavedMediaIdentity() { }

    static String key(MediaItem item) {
        if (item == null || item.kind == MediaItem.Kind.STREAM) return "";
        String old = item.dedupKey == null ? "" : item.dedupKey.trim();
        if (!old.isEmpty()) return old;
        String url = item.url == null ? "" : item.url.trim();
        return url.isEmpty() ? "" : item.kind.name() + "|" + url;
    }

    static Set<String> savedAliases(Collection<String> savedKeys) {
        Set<String> result = new HashSet<>();
        if (savedKeys != null) for (String saved : savedKeys) {
            if (saved != null && !saved.isEmpty()) result.addAll(aliases(saved, null));
        }
        return result;
    }

    static boolean isSaved(MediaItem item, Set<String> savedAliases) {
        if (item == null || savedAliases == null || savedAliases.isEmpty()) return false;
        for (String candidate : aliases(key(item), item.url)) {
            if (savedAliases.contains(candidate)) return true;
        }
        return false;
    }

    static Set<String> aliases(String savedKey, String mediaUrl) {
        LinkedHashSet<String> result = new LinkedHashSet<>();
        if (savedKey == null || savedKey.trim().isEmpty()) return result;
        String key = savedKey.trim();
        result.add(key);
        int delimiter = key.indexOf('|');
        if (delimiter <= 0) return result;
        String kind = key.substring(0, delimiter);
        if (!"IMAGE".equals(kind) && !"VIDEO".equals(kind)) return result;
        String identity = key.substring(delimiter + 1);
        if (identity.startsWith("IG|cache:")) addIgCacheId(result, kind, identity.substring(9));
        if (identity.startsWith("IG|file:")) addIgFilename(result, kind, identity.substring(8));
        if (identity.startsWith("IG|path:")) {
            String oldPath = identity.substring(8);
            result.add(kind + "|IG|path:" + oldPath);
            // Old Instagram keys sometimes used a CDN path before ig_cache_key was
            // available. Match the exact long filename, never a whole post or host.
            if ("IMAGE".equals(kind)) addIgFilename(result, kind, basename(oldPath));
        }
        if (identity.startsWith("IG|url:")) {
            // Legacy crawler fallback kept an unsigned URL after IG|url:.
            addUrlAliases(result, kind, identity.substring(7));
        }
        if (identity.startsWith("IG|asset:")) result.add(kind + "|IG|asset:" + identity.substring(9));
        if (identity.startsWith("http://") || identity.startsWith("https://")) addUrlAliases(result, kind, identity);
        if (mediaUrl != null && !mediaUrl.isEmpty()) addUrlAliases(result, kind, mediaUrl);
        return result;
    }

    private static String basename(String path) {
        if (path == null || path.isEmpty()) return "";
        int slash = path.lastIndexOf('/');
        String file = slash >= 0 ? path.substring(slash + 1) : path;
        int question = file.indexOf('?');
        return question >= 0 ? file.substring(0, question) : file;
    }

    private static void addIgCacheId(Set<String> out, String kind, String rawCache) {
        String cache = decode(rawCache);
        if (cache.isEmpty()) return;
        String first = cache.split("\\.", 2)[0];
        String numeric = first;
        try {
            numeric = new String(Base64.getDecoder().decode(first), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException ignored) { }
        // The encoded Instagram media PK is independent of expiring CDN signatures and encodes.
        if (numeric.matches("[0-9]{10,25}")) out.add(kind + "|IG|media:" + numeric);
    }

    private static void addIgFilename(Set<String> out, String kind, String rawFile) {
        String file = decode(rawFile);
        if (file.length() >= 12 && file.indexOf('/') < 0 && file.indexOf('\\') < 0) {
            out.add(kind + "|IG|filename:" + file.toLowerCase(Locale.ROOT));
        }
    }

    private static void addUrlAliases(Set<String> out, String kind, String raw) {
        try {
            URI uri = new URI(raw.trim());
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            String path = uri.getPath() == null ? "" : uri.getPath();
            boolean instagram = host.equals("cdninstagram.com") || host.endsWith(".cdninstagram.com")
                    || host.equals("fbcdn.net") || host.endsWith(".fbcdn.net");
            boolean twitter = host.equals("pbs.twimg.com") || host.equals("video.twimg.com")
                    || host.endsWith(".twimg.com");
            if (!instagram && !twitter) return;
            // URL query includes expiring signatures and different CDN rendition options.
            if (twitter && !path.isEmpty() && path.length() >= 12)
                out.add(kind + "|X|path:" + path.toLowerCase(Locale.ROOT));
            int last = path.lastIndexOf('/');
            String file = last >= 0 ? path.substring(last + 1) : path;
            if (instagram) {
                addIgFilename(out, kind, file);
                String cache = queryParam(uri.getRawQuery(), "ig_cache_key");
                if (!cache.isEmpty()) addIgCacheId(out, kind, cache);
            }
        } catch (Exception ignored) { }
    }

    private static String queryParam(String query, String name) {
        if (query == null) return "";
        for (String segment : query.split("&")) {
            int eq = segment.indexOf('=');
            if (eq >= 0 && name.equals(segment.substring(0, eq))) return segment.substring(eq + 1);
        }
        return "";
    }

    private static String decode(String value) {
        try { return URLDecoder.decode(value, StandardCharsets.UTF_8.name()); }
        catch (Exception ignored) { return value == null ? "" : value; }
    }

    /** Exact original-name match only. A numbered download prefix may differ between runs. */
    static boolean hasVerifiedFile(MediaItem item, Set<String> imageNames, Set<String> videoNames) {
        if (item == null || item.kind == MediaItem.Kind.STREAM) return false;
        String url = item.url == null ? "" : item.url;
        String original;
        try {
            URI uri = new URI(url);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!(host.equals("fbcdn.net") || host.endsWith(".fbcdn.net")
                    || host.equals("cdninstagram.com") || host.endsWith(".cdninstagram.com")
                    || host.equals("pbs.twimg.com") || host.equals("video.twimg.com")
                    || host.endsWith(".twimg.com"))) return false;
            String path = uri.getPath();
            if (path == null) return false;
            original = decode(path.substring(path.lastIndexOf('/') + 1)).toLowerCase(Locale.ROOT);
        } catch (Exception error) { return false; }
        // Do not accept generic names or small, collision-prone labels.
        if (original.length() < 12 || !original.matches("[a-z0-9_.-]+")
                || !original.matches(".*\\.(jpg|jpeg|png|gif|webp|avif|heic|heif|mp4|m4v|mov|webm)$")) return false;
        Set<String> names = item.kind == MediaItem.Kind.IMAGE ? imageNames : videoNames;
        if (names == null || names.isEmpty()) return false;
        return names.contains(original);
    }
}
