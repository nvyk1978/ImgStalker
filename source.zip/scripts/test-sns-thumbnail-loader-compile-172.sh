#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/content" "$TMP/src/android/graphics" "$TMP/src/android/media" "$TMP/src/android/os" "$TMP/src/android/util" "$TMP/src/android/view" "$TMP/src/android/webkit" "$TMP/src/android/widget" "$TMP/src/com/cmyk/imgstalker"
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content; import java.io.*; public class Context {
 public Context getApplicationContext(){return this;}
 public File getCacheDir(){return new File("/tmp");}
}
JAVA
cat > "$TMP/src/android/graphics/Bitmap.java" <<'JAVA'
package android.graphics; import java.io.*; public class Bitmap {
 public static enum Config { RGB_565 }
 public static enum CompressFormat { JPEG }
 public boolean compress(CompressFormat f,int q,OutputStream o){return true;}
 public int getByteCount(){return 10;} public int getWidth(){return 10;} public int getHeight(){return 10;}
 public boolean isRecycled(){return false;} public void recycle(){}
 public static Bitmap createScaledBitmap(Bitmap b,int w,int h,boolean f){return b;}
}
JAVA
cat > "$TMP/src/android/graphics/BitmapFactory.java" <<'JAVA'
package android.graphics; public class BitmapFactory {
 public static class Options {public int outWidth=10,outHeight=10,inSampleSize=1; public boolean inJustDecodeBounds; public Bitmap.Config inPreferredConfig;}
 public static Bitmap decodeByteArray(byte[] a,int off,int len,Options o){return new Bitmap();}
 public static Bitmap decodeFile(String path){return new Bitmap();}
}
JAVA
cat > "$TMP/src/android/media/MediaMetadataRetriever.java" <<'JAVA'
package android.media; import android.graphics.Bitmap; public class MediaMetadataRetriever {
 public static final int METADATA_KEY_DURATION=9,METADATA_KEY_VIDEO_WIDTH=18,METADATA_KEY_VIDEO_HEIGHT=19,METADATA_KEY_VIDEO_ROTATION=24,OPTION_CLOSEST_SYNC=2;
 public void setDataSource(String s){} public String extractMetadata(int i){return "0";}
 public Bitmap getFrameAtTime(long t,int o){return new Bitmap();} public void release(){}
}
JAVA
cat > "$TMP/src/android/os/Looper.java" <<'JAVA'
package android.os; public class Looper {public static Looper getMainLooper(){return new Looper();}}
JAVA
cat > "$TMP/src/android/os/Handler.java" <<'JAVA'
package android.os; public class Handler {public Handler(Looper l){} public boolean post(Runnable r){r.run();return true;}}
JAVA
cat > "$TMP/src/android/util/LruCache.java" <<'JAVA'
package android.util; import java.util.*; public class LruCache<K,V>{Map<K,V> map=new HashMap<>(); public LruCache(int m){} protected int sizeOf(K k,V v){return 1;} public V get(K k){return map.get(k);} public V put(K k,V v){return map.put(k,v);} public V remove(K k){return map.remove(k);} public Map<K,V> snapshot(){return new HashMap<>(map);} public void evictAll(){map.clear();}}
JAVA
cat > "$TMP/src/android/view/View.java" <<'JAVA'
package android.view; public class View {public static int VISIBLE=0; private Object tag; public void setVisibility(int v){} public Object getTag(){return tag;} public void setTag(Object tag){this.tag=tag;} public void setAlpha(float a){}}
JAVA
cat > "$TMP/src/android/widget/ImageView.java" <<'JAVA'
package android.widget; import android.view.View; import android.graphics.Bitmap; public class ImageView extends View {public void setImageBitmap(Bitmap b){} public void setImageDrawable(Object x){} public Object getDrawable(){return null;}}
JAVA
cat > "$TMP/src/android/webkit/WebSettings.java" <<'JAVA'
package android.webkit; import android.content.Context; public class WebSettings {public static String getDefaultUserAgent(Context c){return "Mozilla";}}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/Stubs.java" <<'JAVA'
package com.cmyk.imgstalker;
class MediaItem {
 enum Kind {IMAGE,VIDEO,STREAM} Kind kind=Kind.IMAGE;
 String url="https://example.org/x",referrer=""; int width,height; long durationMs;
}
class DiagnosticLog {static void log(String s){} static void logException(String s,Throwable t){} }
class InstagramSessionCookies {static String getCookie(String s){return "";}}
class ThreadsSessionCookies {static String getCookie(String s){return "";}}
class InstagramVideoUrl {static String resolvedOrOriginal(String s){return s;} static String stripTag(String s){return s;} static void markRecovered(String u,String s){}}
class ThreadsVideoUrl {static String resolvedOrOriginal(String s){return s;} static String stripTag(String s){return s;} static void markRecovered(String u,String s){}}
JAVA
SRC=app/src/main/java/com/cmyk/imgstalker
javac -encoding UTF-8 -d "$TMP/classes" \
 $(find "$TMP/src" -name '*.java') \
 "$SRC/SnsThumbnailDiskCache.java" "$SRC/InstagramThumbnailLoader.java" "$SRC/ThreadsThumbnailLoader.java"
echo 'PASS: full Instagram/Threads thumbnail loader Java compilation with Android API stubs'
