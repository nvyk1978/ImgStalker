# ImgStalker v0.1.91 (92)

Android 16 / SDK 36 source package for ImgStalker.

## v0.1.91 — X GIF decoder fallback

- Xの動画GIFをGIF保存する経路で、Android標準 `MediaMetadataRetriever` がduration/frameを取得できないMP4にMedia3 Inspectorをフォールバック使用。
- durationは platform extractor → Media3 metadata の順でも補完。
- 通常動画のMP4保存経路は変更しない。
- GIF選択時にGIF変換へ失敗した場合はMP4へフォールバック保存せず、従来どおり失敗（赤チェック）として扱う。

## v0.1.90 — X GIF save conversion

- SNS設定の「リポストを取得」直下に「動画GIFをGIFとして保存」Nトグルを追加（デフォルトON）。
- Xのanimated GIF/tweet_video MP4だけを保存時に実GIFへ変換。通常動画は従来どおりMP4保存。
- 追加ネイティブ依存なしのGIF89a/LZW変換を内蔵。

## v0.1.89 — X media-candidate resolver

Based on v0.1.88 (89).

### X / Twitter video + animated GIF
- Profile/timeline harvesting still discovers canonical status URLs, but status-detail analysis is now queued only for posts that visibly contain video/GIF indicators.
- `pbs.twimg.com/tweet_video_thumb/...` is treated as an animated-GIF media signal instead of a disposable non-post image.
- For `tweet_video_thumb`, ImgStalker derives the corresponding `https://video.twimg.com/tweet_video/<id>.mp4` candidate immediately and registers it as VIDEO against the owning status.
- `ext_tw_video_thumb`, live `<video>`/`<source>` nodes, X video-player test IDs, and GIF accessibility labels also mark a status as a media candidate.
- Only candidate statuses are deferred to the existing detail resolver; ordinary text/image statuses are no longer opened one-by-one just to prove they contain no video.
- Existing v0.1.88 detail-page fallback remains for candidate posts: animated_gif / video_info.variants parsing, Performance Resource Timing, WebView network capture, and bounded late-media polling.
- Added diagnostics: `SNS_X_MEDIA_CANDIDATES`, `SNS_X_TWEET_VIDEO_DIRECT`, and `SNS_X_STATUS_DEFER reason=media_candidate`.

### Retained from v0.1.88
- X detail pages keep the primary tweet near the viewport and can wait up to five 600 ms passes for late video/GIF materialization.
- Automatic gradual SNS thumbnail sweep with visible-cell priority.
- Instagram timeline-direct media path and existing rate-limit/resume behavior.
- Saved media circular green check / selection blocked; failed media circular dark-red check / retry selectable.
- N White #A9A999 title.
- SAF-first video saving with MediaStore Movies fallback.
- Fixed applicationId and stable signing keystore for overwrite install.

Package: versionName 0.1.91 / versionCode 92.
