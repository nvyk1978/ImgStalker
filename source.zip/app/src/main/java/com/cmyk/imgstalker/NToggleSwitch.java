package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class NToggleSwitch extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean checked = true;
    private int onColor = 0xFF445577;
    private int offColor = 0xFF454040;
    private int thumbColor = 0xFFA9A999;
    private OnCheckedChangeListener listener;

    public interface OnCheckedChangeListener {
        void onCheckedChanged(NToggleSwitch view, boolean checked);
    }

    public NToggleSwitch(Context context) { super(context); init(); }
    public NToggleSwitch(Context context, AttributeSet attrs) { super(context, attrs); init(); }

    private void init() {
        setClickable(true);
        setFocusable(true);
    }

    public void setChecked(boolean value) {
        if (checked == value) return;
        checked = value;
        invalidate();
        if (listener != null) listener.onCheckedChanged(this, checked);
    }

    public boolean isChecked() { return checked; }
    public void setOnColor(int color) { onColor = color; invalidate(); }
    public void setOnCheckedChangeListener(OnCheckedChangeListener listener) { this.listener = listener; }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int w = dp(48);
        int h = dp(26);
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float h = getHeight();
        float w = getWidth();
        float pad = dp(2);
        float r = h / 2f;
        paint.setColor(checked ? onColor : offColor);
        canvas.drawRoundRect(new RectF(0, 0, w, h), r, r, paint);
        float tr = (h - pad * 2) / 2f;
        float cx = checked ? w - pad - tr : pad + tr;
        paint.setColor(thumbColor);
        canvas.drawCircle(cx, h / 2f, tr, paint);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            performClick();
            setChecked(!checked);
            return true;
        }
        return true;
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
