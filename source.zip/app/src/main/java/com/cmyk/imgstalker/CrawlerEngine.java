package com.cmyk.imgstalker;

import android.os.Handler;
import android.os.Looper;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URI;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class CrawlerEngine {
    public interface Listener {
        void onStatus(String text);
        void onItem(MediaItem item);
        void onDone(String title, int visitedPages, int imageCount, int videoCount, int streamCount);
        void onError(String message);
    }

    private static final class Node {
        final String url;
        final int depth;
        final boolean detail;
        Node(String url, int depth, boolean detail) {
            this.url = url;
            this.depth = depth;
            this.detail = detail;
        }
    }

    private final WebView webView;
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Node> queue = new ArrayDeque<>();
    private final Set<String> queuedOrVisited = new HashSet<>();
    private final Set<String> mediaSeen = new HashSet<>();

    private boolean followPagination = true;
    private boolean followDetails = false;
    private boolean wantImages = true;
    private boolean wantVideos = true;
    private boolean cancelled = true;
    private String rootHost = "";
    private String pageTitle = "ImgStalker";
    private int pageCount = 0;
    private int detailCount = 0;
    private int imageCount = 0;
    private int videoCount = 0;
    private int streamCount = 0;
    private int maxPages = 30;
    private int maxDetails = 120;
        private int targetImagePx = 1280;
    private Node current;

    public CrawlerEngine(WebView webView, Listener listener) {
        this.webView = webView;
        this.listener = listener;
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString() + " ImgStalker/0.1.8");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                DiagnosticLog.log("WEB_PAGE_FINISHED url=" + url);
                if (cancelled || current == null) return;
                handler.postDelayed(() -> autoScroll(0), 450);
            }

            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                                                  android.webkit.WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    DiagnosticLog.log("WEB_MAIN_ERROR url=" + request.getUrl() + " error=" + error);
                    listener.onStatus("読込失敗: " + request.getUrl());
                }
            }
        });
    }

    public void start(String startUrl, boolean followPagination, boolean followDetails,
                      boolean wantImages, boolean wantVideos, int targetImagePx) {
        cancel();
        cancelled = false;
        queue.clear();
        queuedOrVisited.clear();
        mediaSeen.clear();
        pageCount = detailCount = imageCount = videoCount = streamCount = 0;
        pageTitle = "ImgStalker";
        this.followPagination = followPagination;
        this.followDetails = followDetails;
        this.wantImages = wantImages;
        this.wantVideos = wantVideos;
        this.targetImagePx = Math.max(64, Math.min(8192, targetImagePx));
        DiagnosticLog.log("CRAWLER_START url=" + startUrl
                + " pagination=" + followPagination
                + " details=" + followDetails
                + " images=" + wantImages
                + " videos=" + wantVideos
                + " targetImagePx=" + this.targetImagePx);

        String normalized = normalizeInputUrl(startUrl);
        try {
            rootHost = new URI(normalized).getHost();
            if (rootHost == null) rootHost = "";
        } catch (Exception e) {
            DiagnosticLog.logException("CRAWLER_BAD_URL " + normalized, e);
            listener.onError("URLを確認してください");
            return;
        }
        enqueue(new Node(normalized, 0, false));
        loadNext();
    }

    public void cancel() {
        if (!cancelled) DiagnosticLog.log("CRAWLER_CANCEL");
        cancelled = true;
        current = null;
        try { webView.stopLoading(); } catch (Exception ignored) {}
        handler.removeCallbacksAndMessages(null);
    }

    private void autoScroll(int pass) {
        if (cancelled || current == null) return;
        if (pass >= 3) {
            collectDom();
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{window.scrollTo(0,document.body.scrollHeight);return String(document.body.scrollHeight)}catch(e){return '0'}})()",
                value -> handler.postDelayed(() -> autoScroll(pass + 1), 350));
    }

    private void collectDom() {
        if (cancelled || current == null) return;
        DiagnosticLog.log("DOM_COLLECT url=" + current.url + " detail=" + current.detail + " depth=" + current.depth
                + " targetImagePx=" + targetImagePx);
        listener.onStatus("解析中 " + (pageCount + detailCount + 1) + "ページ目");
        webView.evaluateJavascript(buildCollectorScript(targetImagePx), raw -> {
            if (cancelled || current == null) return;
            try {
                String jsonText = unquoteJsResult(raw);
                JSONObject obj = new JSONObject(jsonText);
                String title = obj.optString("title", "").trim();
                if (!title.isEmpty() && pageCount == 0 && detailCount == 0) pageTitle = title;
                processThumbnailLinks(obj.optJSONArray("thumbLinks"), current);
                processMediaArray(obj.optJSONArray("images"), MediaItem.Kind.IMAGE, current.url);
                processMediaArray(obj.optJSONArray("videos"), MediaItem.Kind.VIDEO, current.url);
                processMediaArray(obj.optJSONArray("streams"), MediaItem.Kind.STREAM, current.url);
                processLinks(obj.optJSONArray("links"), current);
            } catch (Exception e) {
                DiagnosticLog.logException("DOM_PARSE_FAIL url=" + (current == null ? "null" : current.url), e);
                listener.onStatus("ページ解析を一部スキップ: " + e.getClass().getSimpleName());
            }

            if (current.detail) detailCount++; else pageCount++;
            current = null;
            loadNext();
        });
    }

    private void processMediaArray(JSONArray array, MediaItem.Kind kind, String referrer) throws JSONException {
        if (array == null) return;
        if (kind == MediaItem.Kind.IMAGE && !wantImages) return;
        if ((kind == MediaItem.Kind.VIDEO || kind == MediaItem.Kind.STREAM) && !wantVideos) return;
        for (int i = 0; i < array.length(); i++) {
            addMediaUrl(array.optString(i, ""), kind, referrer, null);
        }
    }

    private boolean addMediaUrl(String rawUrl, MediaItem.Kind kind, String referrer, String sourceLogPrefix) {
        String u = cleanUrl(rawUrl);
        if (!isHttp(u)) return false;
        if (kind == MediaItem.Kind.IMAGE && !wantImages) return false;
        if ((kind == MediaItem.Kind.VIDEO || kind == MediaItem.Kind.STREAM) && !wantVideos) return false;
        if (kind == MediaItem.Kind.IMAGE && isLikelyTrackingImage(u)) {
            DiagnosticLog.log("MEDIA_SKIP_TRACKER url=" + u);
            return false;
        }
        String key = kind.name() + "|" + stripFragment(u);
        if (!mediaSeen.add(key)) return false;
        MediaItem item = new MediaItem(u, referrer, kind, kind != MediaItem.Kind.STREAM);
        DiagnosticLog.log("MEDIA_FOUND kind=" + kind.name() + " url=" + u + " ref=" + referrer);
        if (sourceLogPrefix != null && !sourceLogPrefix.isEmpty()) {
            DiagnosticLog.log(sourceLogPrefix + " image=" + u);
        }
        if (kind == MediaItem.Kind.IMAGE) imageCount++;
        else if (kind == MediaItem.Kind.VIDEO) videoCount++;
        else streamCount++;
        listener.onItem(item);
        return true;
    }

    private void processThumbnailLinks(JSONArray thumbLinks, Node from) throws JSONException {
        if (!followDetails || thumbLinks == null) return;
        // Thumbnail-parent crawling is deliberately one hop only. Pagination pages stay depth=0;
        // a thumbnail parent page is depth=1, and depth=1 never queues another detail page.
        if (from.detail || from.depth != 0) return;

        for (int i = 0; i < thumbLinks.length(); i++) {
            JSONObject entry = thumbLinks.optJSONObject(i);
            if (entry == null) continue;
            String img = cleanUrl(entry.optString("img", ""));
            String href = cleanUrl(entry.optString("href", ""));
            if (!isHttp(href)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=non_http href=" + href);
                continue;
            }

            DiagnosticLog.log("THUMB_LINK_FOUND img=" + img + " href=" + href);
            String normalizedHref = stripFragment(href);
            String normalizedImg = stripFragment(img);
            if (!normalizedImg.isEmpty() && normalizedHref.equals(normalizedImg)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=same_image href=" + href);
                continue;
            }

            if (looksDirectImage(href)) {
                boolean added = addMediaUrl(href, MediaItem.Kind.IMAGE, from.url, "THUMB_LINK_RESOLVED");
                if (!added) DiagnosticLog.log("THUMB_LINK_SKIP reason=duplicate_or_filtered href=" + href);
                continue;
            }

            if (looksDirectMedia(href)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=non_image_media href=" + href);
                continue;
            }
            if (!sameHost(href)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=external_page href=" + href);
                continue;
            }
            if (!isDetailCandidate(href, from.url)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=not_detail_candidate href=" + href);
                continue;
            }
            if (detailCount + countQueued(true) >= maxDetails) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=detail_limit href=" + href);
                continue;
            }
            if (enqueue(new Node(href, 1, true))) {
                DiagnosticLog.log("THUMB_LINK_QUEUE href=" + href);
            } else {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=duplicate href=" + href);
            }
        }
    }

    private void processLinks(JSONArray links, Node from) throws JSONException {
        if (links == null) return;
        for (int i = 0; i < links.length(); i++) {
            JSONObject link = links.optJSONObject(i);
            if (link == null) continue;
            String u = cleanUrl(link.optString("url", ""));
            if (!isHttp(u) || !sameHost(u)) continue;
            if (looksDirectMedia(u)) continue;
            boolean pagination = link.optBoolean("pagination", false);
            String paginationKind = link.optString("paginationKind", "");

            // Pagination is always a depth=0 lane. Detail pages never fan out to pagination/detail pages.
            if (!from.detail && from.depth == 0 && pagination && followPagination
                    && pageCount + countQueued(false) < maxPages) {
                if (enqueue(new Node(u, 0, false))) {
                    DiagnosticLog.log("QUEUE_PAGE kind=" + (paginationKind.isEmpty() ? "unknown" : paginationKind) + " url=" + u);
                } else {
                    DiagnosticLog.log("PAGE_LINK_SKIP reason=duplicate kind=" + (paginationKind.isEmpty() ? "unknown" : paginationKind) + " url=" + u);
                }
            }
        }
    }

    private int countQueued(boolean detail) {
        int n = 0;
        for (Node q : queue) if (q.detail == detail) n++;
        return n;
    }

    private boolean enqueue(Node node) {
        String key = stripFragment(node.url);
        if (!queuedOrVisited.add(key)) return false;
        queue.add(node);
        return true;
    }

    private void loadNext() {
        if (cancelled) return;
        current = queue.poll();
        if (current == null) {
            int visited = pageCount + detailCount;
            DiagnosticLog.log("CRAWLER_DONE pages=" + pageCount + " details=" + detailCount + " visited=" + visited
                    + " images=" + imageCount + " videos=" + videoCount + " streams=" + streamCount);
            listener.onDone(pageTitle, visited, imageCount, videoCount, streamCount);
            return;
        }
        DiagnosticLog.log("WEB_LOAD detail=" + current.detail + " depth=" + current.depth + " url=" + current.url);
        listener.onStatus((current.detail ? "詳細追跡: " : "ページ追跡: ") + current.url);
        webView.loadUrl(current.url);
    }

    private boolean sameHost(String url) {
        try {
            String h = new URI(url).getHost();
            if (h == null) return false;
            if (h.equalsIgnoreCase(rootHost)) return true;
            return h.toLowerCase(Locale.ROOT).endsWith("." + rootHost.toLowerCase(Locale.ROOT));
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isDetailCandidate(String url, String fromUrl) {
        try {
            URI target = new URI(stripFragment(url));
            URI from = new URI(stripFragment(fromUrl));
            String targetPath = target.getPath() == null ? "/" : target.getPath();
            String fromPath = from.getPath() == null ? "/" : from.getPath();
            if (targetPath.equals(fromPath) && safeEquals(target.getQuery(), from.getQuery())) return false;

            String path = targetPath.toLowerCase(Locale.ROOT);
            if (path.isEmpty() || "/".equals(path)) return false;
            if (path.matches("^/(page/\\d+/?|tag/.*|tags/.*|category/.*|categories/.*|author/.*|search/?.*|feed/?.*|wp-.*)$")) {
                return false;
            }
            if (path.contains("/login") || path.contains("/register") || path.contains("/privacy")
                    || path.contains("/contact") || path.contains("/about")) {
                return false;
            }

            String[] segments = path.split("/");
            int useful = 0;
            for (String segment : segments) if (!segment.isEmpty()) useful++;
            boolean contentLike = path.matches(".*\\.(html?|php)(/\\d+)?$")
                    || path.matches(".*/\\d{3,}([./].*)?$")
                    || useful >= 2;
            return contentLike;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean safeEquals(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private static boolean isLikelyTrackingImage(String url) {
        try {
            URI u = new URI(url);
            String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase(Locale.ROOT);
            String query = u.getQuery() == null ? "" : u.getQuery().toLowerCase(Locale.ROOT);
            String all = host + path + "?" + query;
            if (host.contains("ad-stir") || host.contains("shinobi") || host.contains("jp1media")
                    || host.contains("doubleclick") || host.contains("googlesyndication")
                    || host.contains("adservice") || host.contains("adnxs") || host.contains("criteo")
                    || host.contains("rubiconproject") || host.contains("openx") || host.contains("bance")) {
                return true;
            }
            if (!looksDirectMedia(url) && (all.contains("/sync") || all.contains("push_sync")
                    || all.contains("/pixel") || all.contains("/beacon") || all.contains("/track"))) {
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static String normalizeInputUrl(String s) {
        s = s == null ? "" : s.trim();
        if (!s.matches("(?i)^https?://.*")) s = "https://" + s;
        return s;
    }

    private static boolean looksDirectImage(String u) {
        String x = u.toLowerCase(Locale.ROOT).split("\\?")[0];
        return x.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif)$");
    }

    private static boolean looksDirectMedia(String u) {
        String x = u.toLowerCase(Locale.ROOT).split("\\?")[0];
        return x.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif|mp4|webm|mov|m4v|3gp|m3u8|mpd)$");
    }

    private static boolean isHttp(String u) {
        return u != null && (u.startsWith("http://") || u.startsWith("https://"));
    }

    private static String cleanUrl(String s) {
        if (s == null) return "";
        return s.trim().replace("&amp;", "&");
    }

    private static String stripFragment(String s) {
        int i = s.indexOf('#');
        return i >= 0 ? s.substring(0, i) : s;
    }

    private static String unquoteJsResult(String raw) throws JSONException {
        if (raw == null || raw.equals("null")) return "{}";
        if (raw.startsWith("\"") && raw.endsWith("\"")) {
            return new JSONArray("[" + raw + "]").getString(0);
        }
        return raw;
    }

    private static String buildCollectorScript(int targetPx) {
        return "(function(){" +
                "const target=" + targetPx + ";" +
                "const abs=(u)=>{try{if(!u||/^(data:|blob:|javascript:|#)/i.test(u))return '';return new URL(u,document.baseURI).href}catch(e){return ''}};" +
                "const uniq=(a)=>Array.from(new Set(a.filter(Boolean)));" +
                "const chooseSrcset=(img)=>{" +
                " let rows=[]; let ss=img.getAttribute('srcset')||img.getAttribute('data-srcset')||'';" +
                " if(ss){ss.split(',').forEach(part=>{let p=part.trim().split(/\\s+/);let u=abs(p[0]);if(!u)return;let d=p[1]||'';let w=0;" +
                "  if(/^[0-9.]+w$/i.test(d))w=parseFloat(d);" +
                "  else if(/^[0-9.]+x$/i.test(d)){let base=img.clientWidth||img.width||target;w=base*parseFloat(d);}" +
                "  rows.push({u:u,w:w});});}" +
                " let known=rows.filter(x=>x.w>0).sort((a,b)=>a.w-b.w);" +
                " if(known.length){let hit=known.find(x=>x.w>=target);return (hit||known[known.length-1]).u;}" +
                " return rows.length?rows[rows.length-1].u:'';" +
                "};" +
                "let images=[],videos=[],streams=[],links=[],thumbLinks=[];" +
                "document.querySelectorAll('img').forEach(i=>{" +
                " let iw=i.naturalWidth||i.width||i.clientWidth||0, ih=i.naturalHeight||i.height||i.clientHeight||0;if(iw>0&&ih>0&&(iw<=2||ih<=2))return;" +
                " let chosen=chooseSrcset(i);" +
                " if(!chosen){let c=[i.getAttribute('data-original'),i.getAttribute('data-src'),i.getAttribute('data-lazy-src'),i.currentSrc,i.src];chosen=c.map(abs).find(Boolean)||'';}" +
                " if(chosen){images.push(chosen);let a=i.closest('a[href]');if(a){let href=abs(a.getAttribute('href')||a.href);if(href)thumbLinks.push({img:chosen,href:href});}}" +
                "});" +
                "document.querySelectorAll('meta[property=\"og:image\"],meta[name=\"twitter:image\"],link[rel=\"image_src\"]').forEach(m=>images.push(abs(m.content||m.href)));" +
                "document.querySelectorAll('video').forEach(v=>{[v.currentSrc,v.src,v.getAttribute('data-src')].map(abs).filter(Boolean).forEach(x=>{if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)})});" +
                "document.querySelectorAll('video source,source[type^=\"video/\"]').forEach(s=>{let x=abs(s.src||s.getAttribute('src'));if(x){if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)}});" +
                "document.querySelectorAll('meta[property=\"og:video\"],meta[property=\"og:video:url\"],meta[property=\"og:video:secure_url\"]').forEach(m=>{let x=abs(m.content);if(x){if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)}});" +
                "let allAnchors=Array.from(document.querySelectorAll('a[href]'));" +
                "let pageNumText=t=>{let x=(t||'').replace(/\\xA0/g,' ').trim();let m=x.match(/^[\\[\\(（\\{<＜【［]?\\s*(\\d{1,4})\\s*[\\]\\)）\\}>＞】］]?$/);return m?m[1]:'';};" +
                "let bracketPageNum=t=>/^[\\[\\(（\\{<＜【［]\\s*\\d{1,4}\\s*[\\]\\)）\\}>＞】］]$/.test((t||'').trim());" +
                "let groupedPageLinks=new Set();" +
                "allAnchors.forEach(a=>{if(!pageNumText(a.textContent))return;let e=a.parentElement;for(let level=0;e&&level<5;level++,e=e.parentElement){let aa=Array.from(e.querySelectorAll('a[href]'));if(aa.length<1||aa.length>40)continue;let nums=aa.filter(x=>pageNumText(x.textContent));let txt=(e.textContent||'').trim();let bt=txt.match(/[\\[\\(（\\{<＜【［]\\s*\\d{1,4}\\s*[\\]\\)）\\}>＞】］]/g)||[];let compact=txt.length<=180;let strong=nums.length>=3||(nums.length>=2&&nums.length/aa.length>=0.55&&(bt.length>=2||nums.every(x=>bracketPageNum(x.textContent))))||(nums.length>=1&&bt.length>=3&&compact);if(strong){nums.forEach(x=>groupedPageLinks.add(x));break;}}});" +
                "allAnchors.forEach(a=>{" +
                " let u=abs(a.href);if(!u)return;" +
                " if(/\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif)(\\?|$)/i.test(u)&&!a.querySelector('img'))images.push(u);" +
                " if(/\\.(mp4|webm|mov|m4v|3gp)(\\?|$)/i.test(u))videos.push(u);" +
                " if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);" +
                " let t=(a.textContent||'').trim(); let rel=(a.rel||'').toLowerCase();" +
                " let ctx=((a.className||'')+' '+(a.id||'')+' '+((a.parentElement&&(a.parentElement.className||''))||'')).toLowerCase();" +
                " let numeric=!!pageNumText(t);" +
                " let next=/^(next|next page|次へ|次のページ|›|»|>|→)$/i.test(t);" +
                " let pageClass=/(pagination|pager|paging|page-numbers|pagenavi)/i.test(ctx);" +
                " let groupedNumeric=groupedPageLinks.has(a);" +
                " let pagination=rel.includes('next')||next||(numeric&&pageClass)||groupedNumeric;" +
                " links.push({url:u,pagination:pagination,paginationKind:(groupedNumeric?'numeric_group':((numeric&&pageClass)?'numeric_class':((rel.includes('next')||next)?'next':'')))});" +
                "});" +
                "document.querySelectorAll('[style]').forEach(e=>{let b=getComputedStyle(e).backgroundImage||'';let m=b.match(/url\\([\"']?([^\"')]+)[\"']?\\)/i);if(m)images.push(abs(m[1]))});" +
                "return JSON.stringify({title:document.title||'',images:uniq(images),videos:uniq(videos),streams:uniq(streams),links:links,thumbLinks:thumbLinks});" +
                "})()";
    }
}
