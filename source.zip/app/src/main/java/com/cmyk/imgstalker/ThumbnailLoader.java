package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class ThumbnailLoader {
    private static final int MAX_THUMB_BYTES = 32 * 1024 * 1024;
    private static final int THUMB_MAX_EDGE = 320;

    private static final class Pending {
        final int generation;
        final ArrayList<WeakReference<ImageView>> waiters = new ArrayList<>();
        Future<?> future;

        Pending(int generation) {
            this.generation = generation;
        }
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final String userAgent;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final LruCache<String, Bitmap> cache;
    private final Object pendingLock = new Object();
    private final Map<String, Pending> pendingByUrl = new HashMap<>();
    private volatile int generation = 1;

    public ThumbnailLoader(Context context) {
        String baseUa;
        try {
            baseUa = WebSettings.getDefaultUserAgent(context);
        } catch (Exception e) {
            baseUa = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36";
        }
        userAgent = baseUa + " ImgStalker/0.1.31";
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024L);
        int cacheKb = Math.max(8192, Math.min(49152, maxKb / 8));
        cache = new LruCache<String, Bitmap>(cacheKb) {
            @Override protected int sizeOf(String key, Bitmap value) {
                return Math.max(1, value.getByteCount() / 1024);
            }
        };
        DiagnosticLog.log("THUMB_CACHE_INIT kb=" + cacheKb + " workers=3 edge=" + THUMB_MAX_EDGE);
    }

    /** Starts thumbnail fetch/decode without requiring a visible ImageView.
     *  Visible cells can later join the same in-flight request or hit the cache immediately. */
    public void prefetch(MediaItem item) {
        if (item == null || item.kind != MediaItem.Kind.IMAGE || item.url == null || item.url.isEmpty()) return;
        String key = item.url;
        Bitmap hit = cache.get(key);
        if (hit != null && !hit.isRecycled()) return;

        final int requestGeneration = generation;
        final Pending request;
        synchronized (pendingLock) {
            Pending existing = pendingByUrl.get(key);
            if (existing != null && existing.generation == requestGeneration) return;
            request = new Pending(requestGeneration);
            pendingByUrl.put(key, request);
            request.future = pool.submit(() -> runRequest(key, item, request));
        }
        DiagnosticLog.log("THUMB_PREFETCH url=" + key + " generation=" + requestGeneration);
    }

    public void load(ImageView view, MediaItem item) {
        if (view == null || item == null) return;
        if (item.kind != MediaItem.Kind.IMAGE) {
            clear(view);
            view.setVisibility(View.VISIBLE);
            return;
        }

        view.setVisibility(View.VISIBLE);
        String key = item.url;
        Object previousTag = view.getTag();
        boolean sameBinding = key.equals(previousTag);
        view.setTag(key);

        Bitmap hit = cache.get(key);
        if (hit != null && !hit.isRecycled()) {
            view.setImageBitmap(hit);
            view.setAlpha(1f);
            return;
        }

        // Rebinding the same row/key should not blank a thumbnail that is already visible.
        // A recycled row bound to a different URL must be cleared so it never shows the wrong image.
        if (!sameBinding) view.setImageDrawable(null);
        view.setAlpha(0.55f);

        final Pending request;
        final int requestGeneration = generation;
        synchronized (pendingLock) {
            Pending existing = pendingByUrl.get(key);
            if (existing != null && existing.generation == requestGeneration) {
                if (addWaiter(existing, view)) {
                    DiagnosticLog.log("THUMB_JOIN url=" + key + " waiters=" + existing.waiters.size());
                }
                return;
            }

            request = new Pending(requestGeneration);
            addWaiter(request, view);
            pendingByUrl.put(key, request);
            request.future = pool.submit(() -> runRequest(key, item, request));
        }
    }

    private void runRequest(String key, MediaItem item, Pending request) {
        Bitmap bitmap = null;
        try {
            if (Thread.currentThread().isInterrupted()) return;
            bitmap = fetch(item);
            if (bitmap != null) cache.put(key, bitmap);
        } catch (Exception e) {
            if (request.generation == generation && !Thread.currentThread().isInterrupted()) {
                DiagnosticLog.logException("THUMB_FAIL url=" + key, e);
            } else {
                DiagnosticLog.log("THUMB_ABORT url=" + key + " generation=" + request.generation);
            }
        } finally {
            synchronized (pendingLock) {
                if (pendingByUrl.get(key) == request) pendingByUrl.remove(key);
            }
        }

        final Bitmap ready = bitmap;
        if (request.generation != generation) return;
        main.post(() -> {
            if (request.generation != generation) return;
            for (WeakReference<ImageView> ref : request.waiters) {
                ImageView target = ref.get();
                if (target == null) continue;
                Object tag = target.getTag();
                if (!(tag instanceof String) || !key.equals(tag)) continue;
                if (ready != null && !ready.isRecycled()) {
                    target.setImageBitmap(ready);
                    target.setAlpha(1f);
                } else {
                    target.setImageDrawable(null);
                    target.setAlpha(0.55f);
                }
            }
        });
    }

    private static boolean addWaiter(Pending pending, ImageView view) {
        for (WeakReference<ImageView> ref : pending.waiters) {
            if (ref.get() == view) return false;
        }
        pending.waiters.add(new WeakReference<>(view));
        return true;
    }

    public void clear(ImageView view) {
        if (view == null) return;
        view.setTag(null);
        view.setImageDrawable(null);
        view.setAlpha(0.55f);
    }

    /** Cancels only outstanding network/decode work; the LRU cache is deliberately retained. */
    public void cancelPending() {
        ArrayList<Future<?>> futures = new ArrayList<>();
        int newGeneration = generation + 1;
        generation = newGeneration;
        synchronized (pendingLock) {
            for (Pending p : pendingByUrl.values()) {
                if (p.future != null) futures.add(p.future);
            }
            pendingByUrl.clear();
        }
        for (Future<?> future : futures) future.cancel(true);
        DiagnosticLog.log("THUMB_CANCEL_PENDING count=" + futures.size() + " generation=" + newGeneration);
    }

    public void shutdown() {
        cancelPending();
        pool.shutdownNow();
        cache.evictAll();
    }

    private Bitmap fetch(MediaItem item) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(item.url).openConnection();
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(12000);
        con.setReadTimeout(16000);
        con.setRequestProperty("User-Agent", userAgent);
        con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
        con.setRequestProperty("Accept-Encoding", "identity");
        con.setRequestProperty("Sec-Fetch-Dest", "image");
        con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
        if (item.referrer != null && !item.referrer.isEmpty()) con.setRequestProperty("Referer", item.referrer);
        String cookie = SessionCookies.getCookie(item.url);
        if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
        con.connect();
        int code = con.getResponseCode();
        String contentType = con.getContentType();
        long contentLength = con.getContentLengthLong();
        DiagnosticLog.log("THUMB_HTTP code=" + code
                + " type=" + contentType
                + " length=" + contentLength
                + " finalUrl=" + con.getURL()
                + " ref=" + item.referrer
                + " cookie=" + (cookie == null ? 0 : cookie.length()));
        if (code < 200 || code >= 400) throw new IllegalStateException("HTTP " + code);
        if (contentType != null && !contentType.toLowerCase().startsWith("image/")) {
            throw new IllegalStateException("unexpected content-type " + contentType);
        }
        if (contentLength > MAX_THUMB_BYTES) {
            throw new IllegalStateException("thumbnail source too large: " + contentLength);
        }

        byte[] data;
        try (InputStream in = con.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[32 * 1024];
            int total = 0;
            int n;
            while ((n = in.read(buf)) >= 0) {
                if (Thread.currentThread().isInterrupted()) throw new InterruptedException("thumbnail cancelled");
                total += n;
                if (total > MAX_THUMB_BYTES) throw new IllegalStateException("thumbnail source too large");
                out.write(buf, 0, n);
            }
            data = out.toByteArray();
        } finally {
            con.disconnect();
        }

        if (Thread.currentThread().isInterrupted()) throw new InterruptedException("thumbnail cancelled");

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new IllegalStateException("decode bounds failed bytes=" + data.length);
        }

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        opts.inSampleSize = calculateSample(bounds.outWidth, bounds.outHeight, THUMB_MAX_EDGE, THUMB_MAX_EDGE);
        Bitmap decoded = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
        if (decoded == null) throw new IllegalStateException("bitmap decode failed bytes=" + data.length);
        Bitmap bitmap = scaleToMaxEdge(decoded, THUMB_MAX_EDGE);
        DiagnosticLog.log("THUMB_OK url=" + item.url + " source=" + bounds.outWidth + "x" + bounds.outHeight
                + " decoded=" + bitmap.getWidth() + "x" + bitmap.getHeight()
                + " bytes=" + data.length + " sample=" + opts.inSampleSize);
        return bitmap;
    }

    private static Bitmap scaleToMaxEdge(Bitmap source, int maxEdge) {
        int w = source.getWidth();
        int h = source.getHeight();
        int edge = Math.max(w, h);
        if (edge <= maxEdge) return source;
        float scale = maxEdge / (float) edge;
        int nw = Math.max(1, Math.round(w * scale));
        int nh = Math.max(1, Math.round(h * scale));
        Bitmap scaled = Bitmap.createScaledBitmap(source, nw, nh, true);
        if (scaled != source) source.recycle();
        return scaled;
    }

    private static int calculateSample(int width, int height, int reqWidth, int reqHeight) {
        int sample = 1;
        if (width <= 0 || height <= 0) return sample;
        while ((width / (sample * 2)) >= reqWidth && (height / (sample * 2)) >= reqHeight) sample *= 2;
        return Math.max(1, sample);
    }
}
