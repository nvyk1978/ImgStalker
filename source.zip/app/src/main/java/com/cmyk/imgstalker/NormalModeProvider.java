package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.webkit.CookieManager;
import android.webkit.WebView;

/** Dedicated NORMAL backend; all classes referenced here belong to NORMAL. */
final class NormalModeProvider implements ModeProvider {
    @Override public AnalysisModeRouter.Mode mode() { return AnalysisModeRouter.Mode.NORMAL; }
    @Override public void useCookies(CookieManager cookies) { NormalSessionCookies.use(cookies); }
    @Override public String cookieFor(String url) { return NormalSessionCookies.getCookie(url); }
    @Override public ModeCrawler crawler(WebView view, CrawlerEngine.Listener listener) {
        return new NormalCrawlerAdapter(view, listener);
    }
    @Override public ModeThumbnailLoader thumbnails(Context context, Runnable onMetadata) {
        return new NormalThumbnailAdapter(context, onMetadata);
    }
    @Override public ModeDownloader downloader(Context context, boolean saveXGifAsGif, MediaDownloader.Listener listener) {
        return new NormalDownloaderAdapter(context, saveXGifAsGif, listener);
    }
    private final ModePreviewPolicy preview = new NormalPreviewPolicy();
    @Override public ModePreviewPolicy preview() { return preview; }
    @Override public Bitmap original(Context context, MediaItem item) throws Exception {
        return NormalOriginalImageLoader.load(context, item);
    }
}
