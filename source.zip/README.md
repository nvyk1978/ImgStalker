# ImgStalker v0.1.87 (88)

Android 16 / SDK 36 source package for ImgStalker.

## v0.1.87 — X animated GIF media + automatic SNS thumbnail sweep

Based on v0.1.86 (87).

### X / Twitter animated GIF
- X GIF posts are treated as video media, matching X's delivery model.
- X status-detail collection now inspects `video_info.variants` found in page JSON and accepts MP4 variants, including `type=animated_gif`.
- Loaded `video.twimg.com` resources are also inspected through Performance Resource Timing so a `blob:` video element does not hide the real MP4/HLS URL.
- WebView network requests to `video.twimg.com` are captured while an X status detail is active and drained into the normal media queue.
- `/tweet_video/` and animated-gif-labelled video URLs are recognized as GIF-origin media and logged separately.
- GIF-origin media is emitted as a normal VIDEO cell and follows the existing preview/download/saved-state path.
- Added diagnostics: `SNS_X_ANIMATED_GIF_NETWORK`, `SNS_X_VIDEO_NETWORK`, `SNS_X_NETWORK_MEDIA_DRAIN`, and `SNS_X_ANIMATED_GIF_RESOLVE`.

### SNS thumbnail collection
- SNS thumbnails no longer depend only on scrolling near a cell.
- Visible cells and the existing ±6-cell window retain priority.
- Remaining image/video cells are gradually prefetched from the top in the background while the Activity is alive.
- Automatic background prefetch is throttled to at most two pending thumbnail jobs; it pauses behind visible-cell work instead of flooding the loader.
- Video thumbnails are included in the gradual sweep; STREAM cells remain excluded.
- Added diagnostics: `SNS_THUMB_AUTO_SCHEDULE`, `SNS_THUMB_AUTO_PREFETCH`, and `SNS_THUMB_AUTO_RESET`.

### Retained from v0.1.86
- Instagram timeline-direct media path and existing rate-limit/resume behavior.
- Saved media: circular green check and selection blocked.
- Failed media: circular dark-red check and retry remains selectable; successful retry changes red to green.
- N White `#A9A999` title.
- SAF-first video saving with MediaStore Movies fallback.
- Fixed applicationId and stable signing keystore for overwrite install.

Package: versionName 0.1.87 / versionCode 88.
