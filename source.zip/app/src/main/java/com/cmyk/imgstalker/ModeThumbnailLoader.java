package com.cmyk.imgstalker;
import android.widget.ImageView;
interface ModeThumbnailLoader {
    void prefetch(MediaItem item);
    boolean isCachedOrPending(MediaItem item);
    // Default supports pinned legacy loaders. SNS-specific loaders also check disk.
    default boolean isReady(MediaItem item) {
        return pendingCount() == 0 && isCachedOrPending(item);
    }
    int pendingCount();
    void load(ImageView view, MediaItem item);
    void cancelPending();
    void clearCache();
    void shutdown();
}
