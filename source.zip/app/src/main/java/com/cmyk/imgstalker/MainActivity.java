package com.cmyk.imgstalker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.EditorInfo;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.GridView;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.OptIn;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.io.File;
import java.util.concurrent.atomic.AtomicInteger;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@OptIn(markerClass = UnstableApi.class)
public class MainActivity extends Activity implements AnalysisKeepAliveService.RetainedWorkOwner {
    private enum HeaderIconKind { SETTINGS, X, INSTAGRAM, DIAGNOSTIC }

    private static final String STATE_URL = "state_url";
    private static final String STATE_RESOLUTION = "state_resolution";
    private static final String STATE_PAGE_TOGGLE = "state_page_toggle";
    private static final String STATE_DETAIL_TOGGLE = "state_detail_toggle";
    private static final String STATE_INTELLIGENT_TOGGLE = "state_intelligent_toggle";
    private static final String STATE_IMAGE_TOGGLE = "state_image_toggle";
    private static final String STATE_VIDEO_TOGGLE = "state_video_toggle";
    private static final String STATE_BACKGROUND_ANALYSIS_TOGGLE = "state_background_analysis_toggle";
    private static final String STATE_X_REPOST_TOGGLE = "state_x_repost_toggle";
    private static final String STATE_X_GIF_AS_GIF_TOGGLE = "state_x_gif_as_gif_toggle";
    private static final String STATE_RESUME_TOGGLE = "state_resume_toggle";
    private static final String STATE_SNS_SEARCH_SERVICE = "state_sns_search_service";
    private static final String STATE_SNS_SEARCH_QUERY = "state_sns_search_query";
    private static final String PREFS_UI = "imgstalker_ui_prefs";
    private static final String PREF_RESUME_ENABLED = "resume_enabled";
    private static final String PREF_BACKGROUND_ENABLED = "background_enabled";
    private static final String STATE_SETTINGS_EXPANDED = "state_settings_expanded";
    private static final String STATE_PAGE_TITLE = "state_page_title";
    private static final String STATE_SELECTION_MODE = "state_selection_mode";
    private static final String STATE_SELECTION_ANCHOR = "state_selection_anchor";
    private static final String STATE_ITEM_URLS = "state_item_urls";
    private static final String STATE_ITEM_REFS = "state_item_refs";
    private static final String STATE_ITEM_KINDS = "state_item_kinds";
    private static final String STATE_ITEM_SELECTED = "state_item_selected";
    private static final String STATE_ITEM_WIDTHS = "state_item_widths";
    private static final String STATE_ITEM_HEIGHTS = "state_item_heights";
    private static final String STATE_ITEM_DURATIONS = "state_item_durations";
    private static final String STATE_ITEM_DEDUP_KEYS = "state_item_dedup_keys";
    private static final String STATE_ITEM_DISPLAY_ORDERS = "state_item_display_orders";
    private static final String STATE_GRID_FIRST = "state_grid_first";
    private static final String STATE_GRID_TOP = "state_grid_top";
    private static final String STATE_WAS_ANALYZING = "state_was_analyzing";
    private static final String STATE_CONTINUATION_VISIBLE = "state_continuation_visible";
    private static final String STATE_CONTINUATION_REASON = "state_continuation_reason";
    private static final String STATE_IG_SESSION_COMPLETED = "state_ig_session_completed";
    private static final String STATE_IG_SESSION_DISCOVERED = "state_ig_session_discovered";
    private static final String STATE_SNS_SAVED_MEDIA_KEYS = "state_sns_saved_media_keys";
    private static final String STATE_NORMAL_SAVED_MEDIA_KEYS = "state_normal_saved_media_keys";
    private static final String STATE_NORMAL_SAVED_TARGET = "state_normal_saved_target";
    private static final String STATE_SNS_FAILED_MEDIA_KEYS = "state_sns_failed_media_keys";
    private static final String STATE_RESUME_SESSION_COMPLETE = "state_resume_session_complete";
    private static final int REQ_RESUME_TREE_ACCESS = 9301;

    private static final int BG = 0xFF303030;
    private static final int DARK_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int LIGHT_GRAY = 0xFF656060;
    private static final int BLUE = 0xFF223355;
    private static final int LIGHT_BLUE = 0xFF445577;
    private static final int ORANGE = 0xFF775500;
    private static final int DARK_RED = 0xFF441100;
    private static final int GREEN = 0xFF227733;
    private static final int N_WHITE = 0xFFA9A999;
    private static final int TEXT_WHITE = 0xFFFFFFFF;

    private EditText urlInput;
    private TextView urlFavoriteStar;
    private final Handler cacheProbeHandler = new Handler(Looper.getMainLooper());
    private final Runnable cacheProbeRunnable = this::performCacheAvailability;
    private EditText resolutionInput;
    private Button resolutionSmall;
    private Button resolutionMedium;
    private Button resolutionLarge;
    private Button selectedResolutionPreset;
    private boolean applyingResolutionPreset;
    private TextView status;
    // Visual mode identification only.  It never selects, mutates or creates any mode engine.
    private TextView detectedModeBadge;
    private TextView summary;
    private TextView postProgress;
    private FrameLayout analysisIndicatorHost;
    private ProgressBar analysisSpinner;
    private TextView analysisInterruptedIcon;
    private final Handler analysisWatchdogHandler = new Handler(Looper.getMainLooper());
    private long lastAnalysisProgressAt = 0L;
    private boolean interruptionSuspected = false;
    private static final long ANALYSIS_STALL_MS = 75000L;
    private static final long ANALYSIS_WATCHDOG_TICK_MS = 5000L;
    private static final int SNS_THUMB_PREFETCH_MARGIN = 6;
    private static final int SNS_THUMB_BACKGROUND_MAX_PENDING = 2;
    private static final long SNS_THUMB_BACKGROUND_TICK_MS = 900L;
    private final Handler snsThumbnailHandler = new Handler(Looper.getMainLooper());
    private int snsThumbnailSweepCursor = 0;
    private boolean snsThumbnailSweepScheduled = false;
    private final Runnable snsThumbnailSweepRunnable = this::runSnsThumbnailSweep;
    private Button analyzeButton;
    private Button selectAllButton;
    private Button cancelButton;
    private Button saveButton;
    private LinearLayout settingsPanel;
    private ValueAnimator settingsAnimator;
    private boolean settingsExpanded = true;
    private NToggleSwitch pageToggle;
    private NToggleSwitch detailToggle;
    private NToggleSwitch intelligentToggle;
    private NToggleSwitch imageToggle;
    private NToggleSwitch videoToggle;
    private NToggleSwitch backgroundAnalysisToggle;
    private Button forceStopButton;
    private final ExecutorService cacheInspectExecutor = Executors.newSingleThreadExecutor();
    private final AtomicInteger cacheProbeGeneration = new AtomicInteger();
    private volatile boolean cacheResetInProgress = false;
    private int cacheResetEpoch = 0;
    private boolean cacheAvailable = false;
    private String detectedCacheUrl = "";
    private NToggleSwitch xRepostToggle;
    private NToggleSwitch xGifAsGifToggle;
    private NToggleSwitch resumeToggle;
    private RadioButton snsSearchXRadio;
    private RadioButton snsSearchInstagramRadio;
    private EditText snsSearchInput;
    private Button snsSearchButton;
    private WebView webView;
    private ModeCrawler crawler;
    private ModeProvider modeProvider = ModeProviders.forMode(AnalysisModeRouter.Mode.NORMAL);
    private AnalysisModeRouter.Mode activeCrawlerMode = AnalysisModeRouter.Mode.NORMAL;
    private long crawlerGeneration = 0L;
    private ModeDownloader downloader;
    private ModeThumbnailLoader thumbnailLoader;
    private GridView mediaGrid;
    private FrameLayout mediaGridHost;
    private FastScrollThumbView mediaFastScrollThumb;
    private ExoPlayer previewPlayer;
    private PlayerView previewPlayerView;
    private SquareFrameLayout previewFrame;
    private MediaItem previewItem;
    private int previewPosition = -1;
    private boolean previewPreparing = false;
    private boolean previewStopping = false;
    private final ArrayList<MediaItem> items = new ArrayList<>();
    private final HashSet<String> emittedItemKeys = new HashSet<>();
    private MediaAdapter adapter;
    private String pageTitle = "ImgStalker";
    private boolean analyzing = false;
    private boolean analysisPreparing = false;
    private int analysisPrepareGeneration = 0;
    private boolean analysisStopRequested = false;
    private boolean analyzeClearPending = false;
    private boolean downloading = false;
    private boolean forceStopInProgress = false;
    private boolean selectionMode = false;
    private int selectionAnchorPosition = -1;
    private SnsAccountManager snsAccounts;
    private SnsUiController snsUi;
    private FrameLayout crawlerWebViewHost;
    private View crawlerTouchShield;
    private static final float CRAWLER_DEBUG_SCALE = 0.30f;
    private static final long CRAWLER_DEBUG_LONG_PRESS_MS = 350L;
    private float crawlerDebugDownRawX = 0f;
    private float crawlerDebugDownRawY = 0f;
    private float crawlerDebugStartX = 0f;
    private float crawlerDebugStartY = 0f;
    private long crawlerDebugDownAt = 0L;
    private boolean crawlerDebugDragging = false;
    private boolean activityResumed = false;
    private boolean crawlerPausedByForegroundPolicy = false;
    private String activeCrawlerProfile = "";
    private SnsAccountManager.Service activeSnsService;
    private final ArrayList<SnsAccountManager.Account> snsAnalysisCandidates = new ArrayList<>();
    private int snsAnalysisIndex = -1;
    private String activeAnalysisUrl = "";
    private int activeAnalysisTargetPx = 640;
    private boolean continuationCellVisible = false;
    private boolean continuationReloading = false;
    private boolean continuationNeededForRun = false;
    private String continuationReason = "";
    // v0.1.70: continuation belongs to the whole analysis session, not only the most
    // recent crawler run. This prevents a failed reload from erasing earlier progress.
    private final LinkedHashSet<String> instagramSessionCompletedPosts = new LinkedHashSet<>();
    private final LinkedHashSet<String> instagramSessionDiscoveredPosts = new LinkedHashSet<>();
    // Loaded from / persisted to the per-account SNS sidecar. Contains only successful saves.
    private final LinkedHashSet<String> snsSessionSavedMediaKeys = new LinkedHashSet<>();
    // NORMAL is never allowed to share either the saved-media set or the JSON of an SNS mode.
    private final LinkedHashSet<String> normalSavedMediaKeys = new LinkedHashSet<>();
    // NORMAL-only URI-backed inventory. Never shared with X/Instagram states.
    private final java.util.LinkedHashMap<String, String> normalSavedFileUris = new java.util.LinkedHashMap<>();
    private String normalSavedTarget = "";
    // Persistent ledger of media whose last save attempt failed. Successful saves remove the key.
    private final LinkedHashSet<String> snsSessionFailedMediaKeys = new LinkedHashSet<>();
    private final ExecutorService resumeIoExecutor = Executors.newSingleThreadExecutor();
    private final Handler resumeCheckpointHandler = new Handler(Looper.getMainLooper());
    private final Runnable resumeCheckpointRunnable = () -> writeResumeCheckpoint(false, "debounced");
    private long lastUniversalCheckpointAt = 0L;
    private SnsResumeStore.Target activeResumeTarget;
    // Last terminal crawler state for this analysis session. Download-only JSON updates must not
    // turn a completed crawl back into an incomplete resume.
    private boolean activeResumeComplete = false;
    private int pendingResumeGrantGeneration = -1;
    private String pendingResumeGrantUrl = "";
    private int pendingResumeGrantTargetPx = 640;
    private boolean taskRemovedKeepAlive = false;
    private volatile int resumeWritesInFlight = 0;
    private MainActivity mirroredWorkOwner;
    private final Handler mirrorHandler = new Handler(Looper.getMainLooper());
    private final Runnable mirrorPoll = new Runnable() {
        @Override public void run() {
            if (mirroredWorkOwner == null) return;
            syncMirroredWorkUi();
            if (mirroredWorkOwner != null) mirrorHandler.postDelayed(this, 750L);
        }
    };

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (event != null && event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            boolean inputFocused = (urlInput != null && urlInput.hasFocus())
                    || (resolutionInput != null && resolutionInput.hasFocus());
            if (inputFocused && !isTouchInside(event, urlInput) && !isTouchInside(event, resolutionInput)) {
                dismissKeyboardAndFocus();
            }
        }
        return super.dispatchTouchEvent(event);
    }

    private boolean isTouchInside(MotionEvent event, View view) {
        if (event == null || view == null || !view.isShown()) return false;
        Rect rect = new Rect();
        if (!view.getGlobalVisibleRect(rect)) return false;
        return rect.contains((int) event.getRawX(), (int) event.getRawY());
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DiagnosticLog.install(this);
        DiagnosticLog.log("ACTIVITY onCreate");
        setTitle("ImgStalker");
        snsAccounts = new SnsAccountManager(this);
        snsUi = new SnsUiController(this, snsAccounts);
        buildUi();
        if (savedInstanceState != null) {
            restoreInstanceState(savedInstanceState);
        } else {
            handleIntent(getIntent());
            // A process can die without onSaveInstanceState. The private checkpoint is
            // independent of the visible Activity and covers non-SNS URLs too.
            if (getIntent() == null || Intent.ACTION_MAIN.equals(getIntent().getAction())) {
                restoreInterruptedAnalysisOnLaunch();
            }
        }
        connectRetainedWorkIfAny();
        requestCacheAvailability();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        DiagnosticLog.log("ACTIVITY onNewIntent action=" + (intent == null ? "null" : intent.getAction()));
        setIntent(intent);
        handleIntent(intent);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_RESUME_TREE_ACCESS) {
            int generation = pendingResumeGrantGeneration;
            String url = pendingResumeGrantUrl;
            int targetPx = pendingResumeGrantTargetPx;
            pendingResumeGrantGeneration = -1;
            pendingResumeGrantUrl = "";
            DiagnosticLog.log("SNS_RESUME_SAF_RESULT result=" + resultCode
                    + " treeAccess=" + SavePrefs.hasTreeAccess(this)
                    + " generation=" + generation);
            if (generation == analysisPrepareGeneration && analysisPreparing) {
                if (!SavePrefs.hasTreeAccess(this)) {
                    Toast.makeText(this, "リジュームファイル用の保存先許可がありません。今回はリジュームなしで解析します", Toast.LENGTH_LONG).show();
                }
                continuePreparedAnalysis(generation, url, targetPx);
            }
            return;
        }
        if (snsUi != null && snsUi.onActivityResult(requestCode, resultCode, data)) return;
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void buildUi() {
        getWindow().setStatusBarColor(DARK_GRAY);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(BG);
        root.setFocusableInTouchMode(true);
        root.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        root.requestFocus();
        root.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) dismissKeyboardAndFocus();
            return false;
        });

        Space topOffset = new Space(this);
        root.addView(topOffset, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("ImgStalker", 24, N_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1f));
        HeaderIconView settingsIcon = new HeaderIconView(this, HeaderIconKind.SETTINGS);
        settingsIcon.setContentDescription("設定");
        HeaderIconView xIcon = new HeaderIconView(this, HeaderIconKind.X);
        xIcon.setContentDescription("Xアカウント");
        HeaderIconView instagramIcon = new HeaderIconView(this, HeaderIconKind.INSTAGRAM);
        instagramIcon.setContentDescription("Instagramアカウント");
        HeaderIconView diagnosticIcon = new HeaderIconView(this, HeaderIconKind.DIAGNOSTIC);
        diagnosticIcon.setContentDescription("診断ログ");
        titleRow.addView(settingsIcon, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout.LayoutParams snsLp1 = new LinearLayout.LayoutParams(dp(44), dp(44));
        snsLp1.leftMargin = dp(6);
        titleRow.addView(xIcon, snsLp1);
        LinearLayout.LayoutParams snsLp2 = new LinearLayout.LayoutParams(dp(44), dp(44));
        snsLp2.leftMargin = dp(6);
        titleRow.addView(instagramIcon, snsLp2);
        LinearLayout.LayoutParams diagnosticLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        diagnosticLp.leftMargin = dp(6);
        titleRow.addView(diagnosticIcon, diagnosticLp);
        root.addView(titleRow, lpMatchWrap(0, 0, dp(12)));
        settingsIcon.setOnClickListener(v -> toggleSettingsPanel());
        xIcon.setOnClickListener(v -> snsUi.showAccountDialog(SnsAccountManager.Service.X));
        instagramIcon.setOnClickListener(v -> snsUi.showAccountDialog(SnsAccountManager.Service.INSTAGRAM));
        diagnosticIcon.setOnClickListener(v -> showDiagnosticLog());

        LinearLayout urlRow = new LinearLayout(this);
        urlRow.setOrientation(LinearLayout.HORIZONTAL);
        urlRow.setGravity(Gravity.CENTER_VERTICAL);

        FrameLayout urlBox = new FrameLayout(this);
        urlBox.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextColor(TEXT_WHITE);
        urlInput.setHintTextColor(N_WHITE);
        urlInput.setHint("https://example.com/gallery");
        urlInput.setTextSize(14);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        urlInput.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        urlInput.setAutofillHints((String[]) null);
        urlInput.setSaveEnabled(false);
        urlInput.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        urlInput.setPrivateImeOptions("com.google.android.inputmethod.latin.noMicrophoneKey;disableLearning=true");
        urlInput.setPadding(dp(44), 0, dp(44), 0);
        urlInput.setBackground(rounded(DARK_GRAY, 23));
        urlBox.addView(urlInput, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        urlFavoriteStar = text("★", 22, LIGHT_GRAY);
        urlFavoriteStar.setGravity(Gravity.CENTER);
        urlFavoriteStar.setContentDescription("このURLをブックマークに追加・解除");
        urlFavoriteStar.setClickable(true);
        urlBox.addView(urlFavoriteStar, new FrameLayout.LayoutParams(dp(44), dp(46),
                Gravity.START | Gravity.CENTER_VERTICAL));
        urlFavoriteStar.setOnClickListener(v -> toggleInputFavorite());

        TextView clearUrl = text("×", 26, N_WHITE);
        clearUrl.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams clearParams = new FrameLayout.LayoutParams(dp(44), dp(46), Gravity.END | Gravity.CENTER_VERTICAL);
        urlBox.addView(clearUrl, clearParams);
        clearUrl.setVisibility(View.GONE);
        clearUrl.setOnClickListener(v -> {
            if (urlInput.length() > 0) {
                DiagnosticLog.log("URL_CLEAR");
                urlInput.setText("");
            }
        });
        urlInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                clearUrl.setVisibility(s != null && s.length() > 0 ? View.VISIBLE : View.GONE);
                updateInputFavoriteStar();
                requestCacheAvailability();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        urlRow.addView(urlBox, new LinearLayout.LayoutParams(0, dp(46), 1f));
        analyzeButton = button("解析", ORANGE);
        LinearLayout.LayoutParams abp = new LinearLayout.LayoutParams(dp(78), dp(46));
        abp.leftMargin = dp(10);
        urlRow.addView(analyzeButton, abp);
        root.addView(urlRow, lpMatchWrap(0, 0, dp(10)));

        settingsPanel = new LinearLayout(this);
        settingsPanel.setOrientation(LinearLayout.VERTICAL);
        settingsPanel.setClipChildren(true);

        LinearLayout resolutionRow = new LinearLayout(this);
        resolutionRow.setOrientation(LinearLayout.HORIZONTAL);
        resolutionRow.setGravity(Gravity.CENTER_VERTICAL);

        Button saveLocationButton = button("保存場所変更", LIGHT_BLUE);
        saveLocationButton.setGravity(Gravity.CENTER);
        saveLocationButton.setTextSize(13);
        saveLocationButton.setSingleLine(true);
        saveLocationButton.setPadding(dp(4), 0, dp(4), 0);
        LinearLayout.LayoutParams saveLocationLp = new LinearLayout.LayoutParams(dp(88), dp(36));
        resolutionRow.addView(saveLocationButton, saveLocationLp);
        saveLocationButton.setOnClickListener(v -> {
            DiagnosticLog.log("SAVE_LOCATION_OPEN current=" + SavePrefs.directory(this).getAbsolutePath());
            Intent picker = new Intent(this, FolderPickerActivity.class);
            startActivity(picker);
        });

        Space resolutionSpacer = new Space(this);
        resolutionRow.addView(resolutionSpacer, new LinearLayout.LayoutParams(0, dp(1), 1f));

        LinearLayout resolutionGroup = new LinearLayout(this);
        resolutionGroup.setOrientation(LinearLayout.HORIZONTAL);
        resolutionGroup.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        TextView resolutionLabel = text("解像度下限", 13, TEXT_WHITE);
        LinearLayout.LayoutParams resolutionLabelLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(43));
        resolutionLabelLp.rightMargin = dp(6);
        resolutionGroup.addView(resolutionLabel, resolutionLabelLp);

        resolutionSmall = presetButton("小");
        resolutionMedium = presetButton("中");
        resolutionLarge = presetButton("大");
        LinearLayout.LayoutParams presetLp = new LinearLayout.LayoutParams(dp(38), dp(36));
        resolutionGroup.addView(resolutionSmall, cloneParams(presetLp, 0, 0, dp(4), 0));
        resolutionGroup.addView(resolutionMedium, cloneParams(presetLp, 0, 0, dp(4), 0));
        resolutionGroup.addView(resolutionLarge, cloneParams(presetLp, 0, 0, dp(6), 0));

        resolutionInput = new EditText(this);
        resolutionInput.setSingleLine(true);
        resolutionInput.setGravity(Gravity.CENTER);
        resolutionInput.setTextColor(TEXT_WHITE);
        resolutionInput.setHintTextColor(N_WHITE);
        resolutionInput.setHint("px");
        resolutionInput.setTextSize(13);
        resolutionInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        resolutionInput.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        resolutionInput.setAutofillHints((String[]) null);
        resolutionInput.setSaveEnabled(false);
        resolutionInput.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        resolutionInput.setPrivateImeOptions("disableLearning=true");
        resolutionInput.setPadding(dp(4), 0, dp(4), 0);
        resolutionInput.setBackground(rounded(DARK_GRAY, 18));
        resolutionGroup.addView(resolutionInput, new LinearLayout.LayoutParams(dp(66), dp(36)));
        resolutionRow.addView(resolutionGroup, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        settingsPanel.addView(resolutionRow, lpMatchWrap(0, 0, dp(10)));

        resolutionSmall.setOnClickListener(v -> applyResolutionPreset(640, resolutionSmall));
        resolutionMedium.setOnClickListener(v -> applyResolutionPreset(1280, resolutionMedium));
        resolutionLarge.setOnClickListener(v -> applyResolutionPreset(1920, resolutionLarge));
        resolutionInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!applyingResolutionPreset) {
                    selectedResolutionPreset = null;
                    updateResolutionPresetStyles();
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        applyResolutionPreset(640, resolutionSmall);

        LinearLayout toggles = new LinearLayout(this);
        toggles.setOrientation(LinearLayout.VERTICAL);
        toggles.setPadding(dp(12), dp(8), dp(12), dp(8));
        toggles.setBackground(rounded(DARK_GRAY, 12));
        intelligentToggle = addToggleRow(toggles, "インテリジェント巡回", true);
        pageToggle = addToggleRow(toggles, "ページ送りを追跡", true);
        detailToggle = addToggleRow(toggles, "サムネイル先を追跡", true);
        imageToggle = addToggleRow(toggles, "画像を取得", true);
        videoToggle = addToggleRow(toggles, "動画を取得", true);
        intelligentToggle.setOnCheckedChangeListener((view, checked) -> syncIntelligentTraversalUi());
        syncIntelligentTraversalUi();
        settingsPanel.addView(toggles, lpMatchWrap(0, 0, dp(10)));

        TextView xSettingsTitle = text("SNS", 14, N_WHITE);
        xSettingsTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams xTitleLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        xTitleLp.setMargins(dp(4), 0, 0, dp(4));
        settingsPanel.addView(xSettingsTitle, xTitleLp);

        LinearLayout xSettingsBox = new LinearLayout(this);
        xSettingsBox.setOrientation(LinearLayout.VERTICAL);
        xSettingsBox.setPadding(dp(12), dp(8), dp(12), dp(8));
        xSettingsBox.setBackground(rounded(DARK_GRAY, 12));
        boolean resumeDefault = getSharedPreferences(PREFS_UI, MODE_PRIVATE).getBoolean(PREF_RESUME_ENABLED, true);
        resumeToggle = addToggleRow(xSettingsBox, "リジューム機能", resumeDefault);
        resumeToggle.setOnCheckedChangeListener((view, checked) -> {
            getSharedPreferences(PREFS_UI, MODE_PRIVATE).edit().putBoolean(PREF_RESUME_ENABLED, checked).apply();
            DiagnosticLog.log("SNS_RESUME_SETTING enabled=" + checked);
            if (!checked) setContinuationCell(false, "resume_disabled");
        });
        xRepostToggle = addToggleRow(xSettingsBox, "リポストを取得", false);
        xGifAsGifToggle = addToggleRow(xSettingsBox, "動画GIFをGIFとして保存", true);

        RadioGroup snsSearchService = new RadioGroup(this);
        snsSearchService.setOrientation(RadioGroup.HORIZONTAL);
        snsSearchService.setGravity(Gravity.CENTER_VERTICAL);
        snsSearchService.setPadding(0, dp(8), 0, dp(4));
        ColorStateList snsRadioTint = new ColorStateList(
                new int[][] { new int[] { android.R.attr.state_checked }, new int[] {} },
                new int[] { GREEN, N_WHITE });
        snsSearchXRadio = new RadioButton(this);
        snsSearchXRadio.setId(View.generateViewId());
        snsSearchXRadio.setText("X");
        snsSearchXRadio.setTextColor(TEXT_WHITE);
        snsSearchXRadio.setTextSize(13);
        snsSearchXRadio.setButtonTintList(snsRadioTint);
        snsSearchXRadio.setChecked(true);
        snsSearchService.addView(snsSearchXRadio, new RadioGroup.LayoutParams(0, dp(38), 1f));
        snsSearchInstagramRadio = new RadioButton(this);
        snsSearchInstagramRadio.setId(View.generateViewId());
        snsSearchInstagramRadio.setText("Instagram");
        snsSearchInstagramRadio.setTextColor(TEXT_WHITE);
        snsSearchInstagramRadio.setTextSize(13);
        snsSearchInstagramRadio.setButtonTintList(snsRadioTint);
        snsSearchService.addView(snsSearchInstagramRadio, new RadioGroup.LayoutParams(0, dp(38), 1f));
        xSettingsBox.addView(snsSearchService, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout snsSearchRow = new LinearLayout(this);
        snsSearchRow.setOrientation(LinearLayout.HORIZONTAL);
        snsSearchRow.setGravity(Gravity.CENTER_VERTICAL);
        snsSearchInput = new EditText(this);
        snsSearchInput.setSingleLine(true);
        snsSearchInput.setTextColor(TEXT_WHITE);
        snsSearchInput.setHintTextColor(N_WHITE);
        snsSearchInput.setHint("ハッシュタグ / キーワード");
        snsSearchInput.setTextSize(13);
        snsSearchInput.setPadding(dp(12), 0, dp(12), 0);
        snsSearchInput.setBackground(rounded(GRAY, 18));
        snsSearchInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        snsSearchInput.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        snsSearchInput.setAutofillHints((String[]) null);
        snsSearchInput.setSaveEnabled(false);
        snsSearchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        snsSearchInput.setPrivateImeOptions("disableLearning=true");
        snsSearchRow.addView(snsSearchInput, new LinearLayout.LayoutParams(0, dp(40), 1f));
        snsSearchButton = button("検索", LIGHT_BLUE);
        LinearLayout.LayoutParams snsSearchButtonLp = new LinearLayout.LayoutParams(dp(74), dp(40));
        snsSearchButtonLp.leftMargin = dp(8);
        snsSearchRow.addView(snsSearchButton, snsSearchButtonLp);
        xSettingsBox.addView(snsSearchRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        snsSearchButton.setOnClickListener(v -> startSnsKeywordSearch());
        snsSearchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                startSnsKeywordSearch();
                return true;
            }
            return false;
        });

        settingsPanel.addView(xSettingsBox, lpMatchWrap(0, 0, dp(12)));

        root.addView(settingsPanel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout analysisStatusBlock = new LinearLayout(this);
        analysisStatusBlock.setOrientation(LinearLayout.VERTICAL);

        LinearLayout statusTopRow = new LinearLayout(this);
        statusTopRow.setOrientation(LinearLayout.HORIZONTAL);
        statusTopRow.setGravity(Gravity.CENTER_VERTICAL);
        detectedModeBadge = text("", 11, BG);
        detectedModeBadge.setSingleLine(true);
        detectedModeBadge.setGravity(Gravity.CENTER);
        detectedModeBadge.setPadding(dp(7), 0, dp(7), 0);
        // N-white slim rounded-square: N-white surface with background-gray lettering.
        // Keep the outline itself 1dp and never apply the BG color as a chip fill.
        GradientDrawable modeBadgeBackground = rounded(N_WHITE, 6);
        modeBadgeBackground.setStroke(dp(1), N_WHITE);
        detectedModeBadge.setBackground(modeBadgeBackground);
        detectedModeBadge.setVisibility(View.GONE);
        LinearLayout.LayoutParams modeBadgeLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(20));
        modeBadgeLp.rightMargin = dp(8);
        statusTopRow.addView(detectedModeBadge, modeBadgeLp);
        status = text("URLを入力して解析", 13, N_WHITE);
        status.setSingleLine(true);
        status.setEllipsize(TextUtils.TruncateAt.END);
        statusTopRow.addView(status, new LinearLayout.LayoutParams(0, dp(24), 1f));

        analysisIndicatorHost = new FrameLayout(this);
        analysisSpinner = new ProgressBar(this);
        analysisSpinner.setIndeterminate(true);
        if (analysisSpinner.getIndeterminateDrawable() != null) {
            analysisSpinner.getIndeterminateDrawable().setTint(N_WHITE);
        }
        FrameLayout.LayoutParams spinnerLp = new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER);
        analysisIndicatorHost.addView(analysisSpinner, spinnerLp);
        analysisInterruptedIcon = text("!", 15, TEXT_WHITE);
        analysisInterruptedIcon.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        analysisInterruptedIcon.setGravity(Gravity.CENTER);
        analysisInterruptedIcon.setBackground(rounded(ORANGE, 12));
        analysisInterruptedIcon.setVisibility(View.GONE);
        analysisInterruptedIcon.setContentDescription("解析中断の可能性");
        analysisInterruptedIcon.setOnClickListener(v -> showDiagnosticLog());
        FrameLayout.LayoutParams interruptedLp = new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER);
        analysisIndicatorHost.addView(analysisInterruptedIcon, interruptedLp);
        analysisIndicatorHost.setVisibility(View.GONE);
        LinearLayout.LayoutParams indicatorLp = new LinearLayout.LayoutParams(dp(40), dp(24));
        indicatorLp.leftMargin = dp(6);
        statusTopRow.addView(analysisIndicatorHost, indicatorLp);
        analysisStatusBlock.addView(statusTopRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        LinearLayout summaryRow = new LinearLayout(this);
        summaryRow.setOrientation(LinearLayout.HORIZONTAL);
        summaryRow.setGravity(Gravity.CENTER_VERTICAL);
        summary = text("画像 0  動画 0  ストリーム 0  選択 0", 14, TEXT_WHITE);
        summary.setSingleLine(true);
        summary.setEllipsize(TextUtils.TruncateAt.END);
        summaryRow.addView(summary, new LinearLayout.LayoutParams(0, dp(24), 1f));
        postProgress = text("", 14, N_WHITE);
        postProgress.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        postProgress.setSingleLine(true);
        LinearLayout.LayoutParams postProgressLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(24));
        postProgressLp.leftMargin = dp(6);
        summaryRow.addView(postProgress, postProgressLp);
        analysisStatusBlock.addView(summaryRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

        root.addView(analysisStatusBlock, lpMatchWrap(0, 0, 0));

        LinearLayout backgroundAnalysisRow = new LinearLayout(this);
        backgroundAnalysisRow.setOrientation(LinearLayout.HORIZONTAL);
        backgroundAnalysisRow.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        backgroundAnalysisRow.setMinimumHeight(dp(50));
        backgroundAnalysisToggle = new NToggleSwitch(this);
        backgroundAnalysisToggle.setChecked(getSharedPreferences(PREFS_UI, MODE_PRIVATE)
                .getBoolean(PREF_BACKGROUND_ENABLED, false));
        backgroundAnalysisToggle.setOnColor(ORANGE);
        backgroundAnalysisToggle.setContentDescription("バックグラウンドでも解析");
        backgroundAnalysisRow.addView(backgroundAnalysisToggle, new LinearLayout.LayoutParams(dp(48), dp(26)));
        TextView backgroundAnalysisLabel = text("バックグラウンドでも解析", 14, TEXT_WHITE);
        LinearLayout.LayoutParams backgroundLabelLp = new LinearLayout.LayoutParams(0, dp(43), 1f);
        backgroundLabelLp.leftMargin = dp(10);
        backgroundAnalysisRow.addView(backgroundAnalysisLabel, backgroundLabelLp);
        forceStopButton = new Button(this);
        forceStopButton.setAllCaps(false);
        forceStopButton.setText("キャッシュ\n削除");
        forceStopButton.setTextSize(13);
        forceStopButton.setSingleLine(false);
        forceStopButton.setMaxLines(2);
        forceStopButton.setTextColor(TEXT_WHITE);
        forceStopButton.setGravity(Gravity.CENTER);
        forceStopButton.setPadding(dp(10), 0, dp(10), 0);
        forceStopButton.setMinWidth(0);
        forceStopButton.setMinHeight(0);
        forceStopButton.setBackground(rounded(0xFF662211, 12));
        forceStopButton.setOnClickListener(v -> deleteAnalysisCache());
        LinearLayout.LayoutParams forceStopLp = new LinearLayout.LayoutParams(dp(104), dp(38));
        forceStopLp.leftMargin = dp(8);
        // Both elements keep their original dimensions; shift the taller button
        // up by half the height difference so their lower edges align.
        forceStopButton.setTranslationY(-dp(6));
        backgroundAnalysisRow.addView(forceStopButton, forceStopLp);
        View.OnClickListener toggleBackgroundAnalysis = v ->
                backgroundAnalysisToggle.setChecked(!backgroundAnalysisToggle.isChecked());
        backgroundAnalysisLabel.setClickable(true);
        backgroundAnalysisLabel.setOnClickListener(toggleBackgroundAnalysis);
        backgroundAnalysisToggle.setOnCheckedChangeListener((view, checked) -> {
            getSharedPreferences(PREFS_UI, MODE_PRIVATE).edit()
                    .putBoolean(PREF_BACKGROUND_ENABLED, checked).apply();
            DiagnosticLog.log("BACKGROUND_ANALYSIS_TOGGLE checked=" + checked + " analyzing=" + analyzing
                    + " activityResumed=" + activityResumed);
            if (checked && activityResumed) requestBatteryExemptionForBackground();
            syncBackgroundAnalysisService(checked ? "toggle_on" : "toggle_off");
            applyCrawlerForegroundPolicy(checked ? "toggle_on" : "toggle_off");
        });
        updateForceStopButtonState();
        root.addView(backgroundAnalysisRow, lpMatchWrap(0, 0, dp(8)));
        requestCacheAvailability();

        crawlerWebViewHost = new FrameLayout(this);
        crawlerWebViewHost.setVisibility(View.INVISIBLE);
        crawlerWebViewHost.setBackgroundColor(Color.BLACK);
        crawlerWebViewHost.setClipChildren(true);
        crawlerWebViewHost.setElevation(dp(8));

        thumbnailLoader = modeProvider.thumbnails(this, () -> {
            if (adapter != null) adapter.notifyDataSetChanged();
        });
        adapter = new MediaAdapter(this, items);
        mediaGrid = new GridView(this);
        mediaGrid.setAdapter(adapter);
        mediaGrid.setNumColumns(3);
        mediaGrid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        mediaGrid.setHorizontalSpacing(dp(6));
        mediaGrid.setVerticalSpacing(dp(8));
        mediaGrid.setPadding(0, 0, 0, 0);
        mediaGrid.setClipToPadding(false);
        mediaGrid.setBackgroundColor(BG);
        // Leave space for the two floating navigation controls at the end of the grid.
        mediaGrid.setPadding(0, 0, 0, dp(62));
        // Android's built-in fast-scroll track can start dragging from the whole track.
        // Use our own movable thumb so fast scrolling begins only when the cursor itself is grabbed.
        mediaGrid.setFastScrollEnabled(false);
        mediaGrid.setVerticalScrollBarEnabled(false);

        mediaGridHost = new FrameLayout(this);
        mediaGridHost.addView(mediaGrid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mediaFastScrollThumb = new FastScrollThumbView(this);
        mediaFastScrollThumb.attach(mediaGrid, mediaGridHost);
        FrameLayout.LayoutParams fastThumbLp = new FrameLayout.LayoutParams(dp(16), dp(46), Gravity.TOP | Gravity.END);
        fastThumbLp.setMargins(0, 0, dp(1), 0);
        mediaGridHost.addView(mediaFastScrollThumb, fastThumbLp);
        FrameLayout.LayoutParams debugFloatLp = new FrameLayout.LayoutParams(dp(108), dp(216), Gravity.START | Gravity.BOTTOM);
        debugFloatLp.setMargins(dp(8), 0, 0, dp(8));
        mediaGridHost.addView(crawlerWebViewHost, debugFloatLp);

        // Navigation controls float above the selection / cancel / bulk-save row.
        FrameLayout historyFloat = historyNavigationFloatButton();
        historyFloat.setContentDescription("サイト履歴");
        FrameLayout.LayoutParams historyFloatLp = new FrameLayout.LayoutParams(
                dp(50), dp(50), Gravity.START | Gravity.BOTTOM);
        historyFloatLp.setMargins(dp(4), 0, 0, dp(10));
        mediaGridHost.addView(historyFloat, historyFloatLp);
        historyFloat.setOnClickListener(v -> showNavigationDialog(false));

        TextView favoritesFloat = navigationFloatButton("★", 24);
        favoritesFloat.setContentDescription("ブックマーク一覧");
        FrameLayout.LayoutParams favoritesFloatLp = new FrameLayout.LayoutParams(
                dp(50), dp(50), Gravity.END | Gravity.BOTTOM);
        favoritesFloatLp.setMargins(0, 0, dp(4), dp(10));
        mediaGridHost.addView(favoritesFloat, favoritesFloatLp);
        favoritesFloat.setOnClickListener(v -> showNavigationDialog(true));

        mediaGrid.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (mediaFastScrollThumb != null) {
                    mediaFastScrollThumb.onGridScrollStateChanged(scrollState);
                }
            }

            @Override public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                if (mediaFastScrollThumb != null) {
                    mediaFastScrollThumb.updateFromGrid(firstVisibleItem, visibleItemCount, totalItemCount);
                }
                if (isSnsThumbnailLazyMode()) {
                    prefetchSnsThumbnailWindow(firstVisibleItem, visibleItemCount);
                }
                if (previewPosition >= 0
                        && (previewPosition < firstVisibleItem || previewPosition >= firstVisibleItem + visibleItemCount)) {
                    stopVideoPreview("scrolled_offscreen");
                }
            }
        });
        root.addView(mediaGridHost, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        selectAllButton = button("選択", LIGHT_BLUE);
        cancelButton = button("キャンセル", GRAY);
        saveButton = button("一括保存", BLUE);
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        buttons.addView(selectAllButton, cloneParams(bp, 0, 0, dp(8), 0));
        buttons.addView(cancelButton, cloneParams(bp, 0, 0, dp(8), 0));
        buttons.addView(saveButton, bp);
        root.addView(buttons, lpMatchWrap(dp(8), 0, 0));

        setContentView(root);

        analyzeButton.setOnClickListener(v -> handleAnalyzeButton());
        selectAllButton.setOnClickListener(v -> handleSelectionButton());
        cancelButton.setOnClickListener(v -> cancelCurrent());
        saveButton.setOnClickListener(v -> startDownload());

        createCrawlerForProfile(null);
    }

    private TextView navigationFloatButton(String caption, int sp) {
        TextView view = text(caption, sp, N_WHITE);
        view.setGravity(Gravity.CENTER);
        view.setBackground(rounded(DARK_GRAY, 25));
        view.setElevation(dp(8));
        view.setClickable(true);
        view.setFocusable(true);
        return view;
    }

    /** History icon is a real VectorDrawable, not a raster asset or rendered text. */
    private FrameLayout historyNavigationFloatButton() {
        FrameLayout button = new FrameLayout(this);
        button.setBackground(rounded(DARK_GRAY, 25));
        button.setElevation(dp(8));
        button.setClickable(true);
        button.setFocusable(true);
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_history_stalker);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        button.addView(icon, new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER));
        return button;
    }

    private void updateInputFavoriteStar() {
        if (urlFavoriteStar == null || urlInput == null) return;
        String url = SiteVisitStore.normalize(urlInput.getText().toString());
        urlFavoriteStar.setTextColor(!url.isEmpty() && SiteVisitStore.isFavorite(this, url)
                ? 0xFFFFC400 : LIGHT_GRAY);
    }

    private void toggleInputFavorite() {
        String url = SiteVisitStore.normalize(urlInput.getText().toString());
        if (url.isEmpty()) {
            Toast.makeText(this, "有効なURLを入力してください", Toast.LENGTH_SHORT).show();
            return;
        }
        if (SiteVisitStore.isFavorite(this, url)) {
            confirmBookmarkRemoval(url, SiteVisitStore.displayTitleForUrl(url, ""), () -> {
                if (SiteVisitStore.isFavorite(this, url)) SiteVisitStore.toggleFavorite(this, url);
                updateInputFavoriteStar();
            });
        } else {
            SiteVisitStore.toggleFavorite(this, url);
            updateInputFavoriteStar();
        }
    }

    /** Bookmark removal must be confirmed outside the history list. */
    private void confirmBookmarkRemoval(String url, String displayName, Runnable removal) {
        final String label = displayName == null || displayName.trim().isEmpty()
                ? SiteVisitStore.host(url) : displayName;
        showStableNavigationConfirmation("ブックマークを解除",
                "「" + label + "」をブックマークから解除しますか？", "解除", removal);
    }

    /** A long press removes the history record only; bookmarks and downloaded media survive. */
    private void confirmHistoryRemoval(SiteVisitStore.Entry entry, Runnable removal) {
        showStableNavigationConfirmation("履歴を削除",
                "「" + entry.displayTitle() + "」の履歴を削除しますか？", "削除", removal);
    }

    /**
     * All navigation / confirmation dialogs use the same fixed full-window geometry.
     * The shell is sized and centered BEFORE show(); its window never measures to
     * the message's wrap_content height or changes layout after becoming visible.
     */
    private void showStableNavigationDialog(Dialog dialog, LinearLayout shell,
                                            int cardWidth, int cardHeight) {
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams panel = new FrameLayout.LayoutParams(
                cardWidth, cardHeight, Gravity.CENTER);
        overlay.addView(shell, panel);
        overlay.setOnClickListener(v -> dialog.dismiss());
        shell.setClickable(true); // Taps on the card never fall through to the overlay.
        dialog.setContentView(overlay, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setDimAmount(0.65f);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                    | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
            window.setGravity(Gravity.CENTER);
            window.setWindowAnimations(0);
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
        }
        dialog.show();
    }

    /** Fixed-height non-AlertDialog confirmation: avoids the visible AlertDialog resize. */
    private void showStableNavigationConfirmation(String heading, String message,
                                                  String positiveLabel, Runnable positiveAction) {
        dismissKeyboardAndFocus();
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackground(rounded(DARK_GRAY, 14));
        shell.setPadding(dp(15), dp(8), dp(15), dp(10));

        TextView title = text(heading, 18, N_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        shell.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        TextView detail = text(message, 14, TEXT_WHITE);
        detail.setMaxLines(3);
        detail.setEllipsize(TextUtils.TruncateAt.END);
        shell.addView(detail, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(86)));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView cancel = text("キャンセル", 15, N_WHITE);
        cancel.setGravity(Gravity.CENTER);
        cancel.setBackground(rounded(BG, 9));
        cancel.setClickable(true);
        cancel.setOnClickListener(v -> dialog.dismiss());
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        cancelLp.setMargins(0, 0, dp(9), 0);
        actions.addView(cancel, cancelLp);
        TextView confirm = text(positiveLabel, 15, N_WHITE);
        confirm.setGravity(Gravity.CENTER);
        confirm.setBackground(rounded(GRAY, 9));
        confirm.setClickable(true);
        confirm.setOnClickListener(v -> {
            dialog.dismiss();
            positiveAction.run();
        });
        actions.addView(confirm, new LinearLayout.LayoutParams(0, dp(48), 1f));
        shell.addView(actions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        int width = getResources().getDisplayMetrics().widthPixels - dp(30);
        showStableNavigationDialog(dialog, shell, width, dp(202));
    }

    /**
     * Fixed window geometry is assigned before show(), so the first visible frame
     * uses the final width/height. Only the rows scroll; opening never resizes the shell.
     */
    private void showNavigationDialog(boolean bookmarksOnly) {
        dismissKeyboardAndFocus();
        List<SiteVisitStore.Entry> records = SiteVisitStore.entries(this, bookmarksOnly);
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackground(rounded(DARK_GRAY, 14));

        TextView title = text(bookmarksOnly ? "ブックマーク" : "履歴", 19, N_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(20), dp(10), dp(20), 0);
        shell.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(8), dp(12), dp(8));
        scroll.addView(content);
        shell.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        if (records.isEmpty()) {
            TextView none = text(bookmarksOnly ? "ブックマークはありません" : "履歴はありません", 14, N_WHITE);
            none.setPadding(dp(8), dp(16), dp(8), dp(16));
            content.addView(none, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
        }
        for (SiteVisitStore.Entry entry : records) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setMinimumHeight(dp(60));

            TextView star = text("★", 23, entry.favorite ? 0xFFFFC400 : LIGHT_GRAY);
            star.setGravity(Gravity.CENTER);
            star.setContentDescription("ブックマーク切り替え");
            star.setClickable(true);
            row.addView(star, new LinearLayout.LayoutParams(dp(46), dp(56)));

            LinearLayout details = new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setPadding(dp(4), dp(6), dp(6), dp(6));
            TextView siteTitle = text(entry.displayTitle(), 15, TEXT_WHITE);
            siteTitle.setSingleLine(true);
            siteTitle.setEllipsize(TextUtils.TruncateAt.END);
            details.addView(siteTitle);
            TextView address = text(entry.url, 11, N_WHITE);
            address.setSingleLine(true);
            address.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            details.addView(address);
            row.addView(details, new LinearLayout.LayoutParams(0, dp(60), 1f));

            View.OnClickListener open = v -> {
                if (analysisPreparing || analyzing || downloading
                        || AnalysisKeepAliveService.hasOtherRetainedOwner(this)) {
                    Toast.makeText(this, "解析・保存を終了してから開いてください", Toast.LENGTH_SHORT).show();
                    return;
                }
                dialog.dismiss();
                urlInput.setText(entry.url);
                urlInput.setSelection(urlInput.length());
                startAnalysis();
            };
            details.setOnClickListener(open);
            row.setOnClickListener(open);

            LinearLayout group = new LinearLayout(this);
            group.setOrientation(LinearLayout.VERTICAL);
            group.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
            View line = new View(this);
            line.setBackgroundColor(GRAY);
            group.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));
            content.addView(group, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(61)));

            if (!bookmarksOnly) {
                View.OnLongClickListener historyLongPress = v -> {
                    confirmHistoryRemoval(entry, () -> {
                        if (!SiteVisitStore.removeHistory(this, entry.url)) return;
                        content.removeView(group);
                        if (content.getChildCount() == 0) {
                            TextView none = text("履歴はありません", 14, N_WHITE);
                            none.setPadding(dp(8), dp(16), dp(8), dp(16));
                            content.addView(none, new LinearLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
                        }
                    });
                    return true;
                };
                row.setOnLongClickListener(historyLongPress);
                details.setOnLongClickListener(historyLongPress);
                // The star has a separate tap action: holding it must not delete history.
                star.setOnLongClickListener(v -> true);
            }

            star.setOnClickListener(v -> {
                boolean currentlyBookmarked = SiteVisitStore.isFavorite(this, entry.url);
                Runnable change = () -> {
                    // Recheck persisted state: a pending dialog must not remove a newly changed item.
                    if (SiteVisitStore.isFavorite(this, entry.url) != currentlyBookmarked) return;
                    boolean added = SiteVisitStore.toggleFavorite(this, entry.url);
                    star.setTextColor(added ? 0xFFFFC400 : LIGHT_GRAY);
                    updateInputFavoriteStar();
                    if (bookmarksOnly && !added) {
                        content.removeView(group);
                        if (content.getChildCount() == 0) {
                            TextView none = text("ブックマークはありません", 14, N_WHITE);
                            none.setPadding(dp(8), dp(16), dp(8), dp(16));
                            content.addView(none, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)));
                        }
                    }
                };
                if (bookmarksOnly && currentlyBookmarked) {
                    confirmBookmarkRemoval(entry.url, entry.displayTitle(), change);
                } else {
                    change.run();
                }
            });
        }

        TextView close = text("閉じる", 15, N_WHITE);
        close.setGravity(Gravity.CENTER);
        close.setClickable(true);
        close.setOnClickListener(v -> dialog.dismiss());
        shell.addView(close, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        int width = getResources().getDisplayMetrics().widthPixels - dp(30);
        int requestedHeight = dp(54 + 52 + 16 + 61 * Math.max(1, records.size()));
        int maxHeight = getResources().getDisplayMetrics().heightPixels - dp(156);
        int height = Math.min(requestedHeight, Math.max(dp(180), maxHeight));
        showStableNavigationDialog(dialog, shell, width, height);
    }

    private void requestBatteryExemptionForBackground() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            DiagnosticLog.log("BACKGROUND_ANALYSIS_BATTERY_EXEMPTION requested=true");
            Intent request = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(request);
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_ANALYSIS_BATTERY_EXEMPTION_FAIL", t);
        }
    }

    /** Ignore late media/errors/completions from an engine switched to a different mode. */
    private CrawlerEngine.Listener newGuardedCrawlerListener(final long epoch) {
        final CrawlerEngine.Listener delegate = newCrawlerListener();
        return new CrawlerEngine.Listener() {
            private boolean valid() { return epoch == crawlerGeneration; }
            private void dispatch(Runnable task) {
                runOnUiThread(() -> { if (valid()) task.run(); });
            }
            @Override public void onStatus(String value) { dispatch(() -> delegate.onStatus(value)); }
            @Override public void onProgressPulse(String value) { dispatch(() -> delegate.onProgressPulse(value)); }
            @Override public void onItem(MediaItem value) { dispatch(() -> delegate.onItem(value)); }
            @Override public void onItemSuppressed(String key, String reason) { dispatch(() -> delegate.onItemSuppressed(key, reason)); }
            @Override public void onDone(String title, int pages, int images, int videos, int streams) {
                dispatch(() -> delegate.onDone(title, pages, images, videos, streams));
            }
            @Override public void onError(String error) { dispatch(() -> delegate.onError(error)); }
            @Override public void onInstagramManualTapReady() { dispatch(() -> delegate.onInstagramManualTapReady()); }
            @Override public void onInstagramManualTapResult(boolean opened, String message) {
                dispatch(() -> delegate.onInstagramManualTapResult(opened, message));
            }
        };
    }

    private InstagramCrawlerSession instagramCrawlerSession() {
        return activeCrawlerMode == AnalysisModeRouter.Mode.INSTAGRAM && crawler instanceof InstagramCrawlerSession
                ? (InstagramCrawlerSession) crawler : null;
    }

    private NormalCrawlerSession normalCrawlerSession() {
        return activeCrawlerMode == AnalysisModeRouter.Mode.NORMAL && crawler instanceof NormalCrawlerSession
                ? (NormalCrawlerSession) crawler : null;
    }

    private XCrawlerSession xCrawlerSession() {
        return activeCrawlerMode == AnalysisModeRouter.Mode.X && crawler instanceof XCrawlerSession
                ? (XCrawlerSession) crawler : null;
    }

    private CrawlerEngine.Listener newCrawlerListener() {
        return new CrawlerEngine.Listener() {
            @Override public void onStatus(String text) {
                runOnUiThread(() -> {
                    markAnalysisProgress("status");
                    if (isPostProgressStatus(text)) {
                        postProgress.setText(text == null ? "" : text.trim());
                    } else {
                        status.setText(statusWithoutUrl(text));
                    }
                });
            }

            @Override public void onProgressPulse(String stage) {
                runOnUiThread(() -> {
                    if (stage != null && (stage.contains("STALL_SKIP")
                            || stage.contains("TIMEOUT_SKIP")
                            || stage.contains("INTERRUPTED"))) {
                        continuationNeededForRun = true;
                        setContinuationCell(true, stage.toLowerCase(java.util.Locale.ROOT));
                    }
                    if (stage != null && (stage.equals("SNS_IG_RESOLVER_DONE")
                            || stage.equals("SNS_IG_SOURCE_DISCOVERED")
                            || stage.equals("SNS_IG_CAROUSEL_DONE")
                            || stage.equals("SNS_IG_POST_RETRY_DEFER")
                            || stage.equals("SNS_IG_POST_RETRY_SKIP")
                            || stage.equals("SNS_IG_RATE_LIMIT")
                            || stage.equals("SNS_IG_DISCOVERY_RELOAD"))) {
                        mergeInstagramSessionProgress("checkpoint_" + stage);
                        scheduleResumeCheckpoint(stage);
                    }
                    markAnalysisProgress(stage);
                    if (analyzing && isResumeEnabled()
                            && SystemClock.uptimeMillis() - lastUniversalCheckpointAt >= 4000L) {
                        writeInternalCheckpoint(false, "crawler_progress_" + safeText(stage));
                    }
                });
            }

            @Override public void onItem(MediaItem item) {
                runOnUiThread(() -> {
                    markAnalysisProgress("media_item");
                    String uiKey = item == null ? "" : item.dedupKey;
                    if (uiKey == null || uiKey.isEmpty()) {
                        uiKey = item == null ? "" : item.kind.name() + "|" + item.url;
                    }
                    if (!uiKey.isEmpty() && !emittedItemKeys.add(uiKey)) {
                        DiagnosticLog.log("UI_MEDIA_DUPLICATE_SKIP key=" + uiKey
                                + " url=" + (item == null ? "" : item.url));
                        return;
                    }
                    if (item == null) return;
                    int insertIndex = items.size();
                    if (item.displayOrder != Long.MAX_VALUE) {
                        for (int i = 0; i < items.size(); i++) {
                            MediaItem existing = items.get(i);
                            if (existing.displayOrder > item.displayOrder) {
                                insertIndex = i;
                                break;
                            }
                        }
                    }
                    items.add(insertIndex, item);
                    DiagnosticLog.log("UI_MEDIA_CELL_ADDED index=" + insertIndex
                            + " order=" + item.displayOrder
                            + " kind=" + item.kind + " url=" + item.url);
                    if (thumbnailLoader != null && item.kind == MediaItem.Kind.IMAGE && !isSnsThumbnailLazyMode()) {
                        thumbnailLoader.prefetch(item);
                    }
                    if (isSnsThumbnailLazyMode()) {
                        snsThumbnailSweepCursor = Math.min(snsThumbnailSweepCursor, insertIndex);
                        scheduleSnsThumbnailSweep("media_item");
                    }
                    adapter.notifyDataSetChanged();
                    updateSummary();
                    scheduleResumeCheckpoint("media_item");
                });
            }

            @Override public void onItemSuppressed(String dedupKey, String reason) {
                runOnUiThread(() -> {
                    if (dedupKey == null || dedupKey.isEmpty()) return;
                    boolean removed = false;
                    for (int i = items.size() - 1; i >= 0; i--) {
                        MediaItem item = items.get(i);
                        if (item != null && dedupKey.equals(item.dedupKey)) {
                            DiagnosticLog.log("UI_MEDIA_CELL_REMOVED index=" + i
                                    + " key=" + dedupKey + " reason=" + reason
                                    + " url=" + item.url);
                            items.remove(i);
                            removed = true;
                        }
                    }
                    // Keep emittedItemKeys intact: suppression is terminal for this run and the
                    // same cell must not reappear if another page reports the URL again.
                    if (removed) {
                        adapter.notifyDataSetChanged();
                        updateSummary();
                        markAnalysisProgress("media_suppressed");
                    }
                });
            }

            @Override public void onDone(String title, int visitedPages, int imageCount, int videoCount, int streamCount) {
                runOnUiThread(() -> {
                    if (forceStopInProgress) {
                        DiagnosticLog.log("ANALYZE_DONE_IGNORED reason=force_stop");
                        return;
                    }
                    hideInstagramManualTapBrowser();
                    mergeInstagramSessionProgress("crawler_done");
                    boolean stoppedByUser = analysisStopRequested;
                    if (!stoppedByUser && activeSnsService != null && !continuationReloading
                            && imageCount + videoCount + streamCount == 0 && items.isEmpty()
                            && tryNextSnsAccount("no_media")) return;
                    analyzing = false;
                    analysisStopRequested = false;
                    analyzeClearPending = stoppedByUser;
                    continuationReloading = false;
                    if (postProgress != null) postProgress.setText("");
                    boolean incomplete = crawler != null && crawler.isIncompleteCompletion();
                    String incompleteReason = crawler == null ? "" : crawler.getIncompleteCompletionReason();
                    InstagramCrawlerSession igSession = instagramCrawlerSession();
                    int failedPosts = igSession == null ? 0 : igSession.getInstagramFailedPostCount();
                    if (incomplete || failedPosts > 0 || stoppedByUser) continuationNeededForRun = true;
                    boolean showContinuation = stoppedByUser || incomplete || failedPosts > 0 || continuationNeededForRun;
                    String continueReason = incomplete ? incompleteReason
                            : (failedPosts > 0 ? "instagram_failed_posts"
                            : (continuationNeededForRun ? "recovery_or_interruption" : "completed"));
                    boolean resumeComplete = !stoppedByUser && !incomplete && failedPosts == 0 && !continuationNeededForRun;
                    activeResumeComplete = resumeComplete;
                    writeResumeCheckpoint(resumeComplete, "crawler_done");
                    syncBackgroundAnalysisService(stoppedByUser ? "analysis_safe_stop_done" : "analysis_done");
                    setContinuationCell(showContinuation, continueReason);
                    setAnalysisRunningUi(false);
                    DiagnosticLog.log("ANALYZE_DONE pages=" + visitedPages + " images=" + imageCount + " videos=" + videoCount + " streams=" + streamCount
                            + " incomplete=" + incomplete + " reason=" + incompleteReason + " failedPosts=" + failedPosts
                            + " stoppedByUser=" + stoppedByUser);
                    pageTitle = title == null || title.trim().isEmpty() ? hostFromUrl(urlInput.getText().toString()) : title.trim();
                    SiteVisitStore.recordTitle(MainActivity.this, activeAnalysisUrl, pageTitle);
                    status.setText(stoppedByUser ? "解析停止（受信済みデータを保持）"
                            : incomplete ? "解析完了（続きあり）  " + visitedPages + "ページ"
                            : failedPosts > 0 ? "解析完了（取得失敗 " + failedPosts + "件）  " + visitedPages + "ページ"
                            : "解析完了  " + visitedPages + "ページ");
                    saveButton.setEnabled(countSelectedPendingSave() > 0);
                    applyButtonEnabledStyle(saveButton);
                    updateSummary();
                });
            }

            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    if (forceStopInProgress) {
                        DiagnosticLog.log("ANALYZE_ERROR_IGNORED reason=force_stop");
                        return;
                    }
                    hideInstagramManualTapBrowser();
                    mergeInstagramSessionProgress("crawler_error");
                    boolean stoppedByUser = analysisStopRequested;
                    if (!stoppedByUser && activeSnsService != null && !continuationReloading
                            && tryNextSnsAccount("crawler_error")) return;
                    analyzing = false;
                    analysisStopRequested = false;
                    analyzeClearPending = stoppedByUser;
                    continuationReloading = false;
                    if (postProgress != null) postProgress.setText("");
                    continuationNeededForRun = true;
                    activeResumeComplete = false;
                    writeResumeCheckpoint(false, stoppedByUser ? "manual_stop_error" : "crawler_error");
                    syncBackgroundAnalysisService(stoppedByUser ? "analysis_safe_stop_error" : "analysis_error");
                    setContinuationCell(true, stoppedByUser ? "manual_stop_error" : "crawler_error");
                    setAnalysisRunningUi(false);
                    DiagnosticLog.log("ANALYZE_ERROR stoppedByUser=" + stoppedByUser + " " + message);
                    status.setText(stoppedByUser ? "解析停止（受信済みデータを保持）" : message);
                });
            }

            @Override public void onInstagramManualTapReady() {
                // v0.1.81 Instagram source pipeline never exposes or asks the user to operate a browser.
                runOnUiThread(() -> {
                    hideInstagramManualTapBrowser();
                    DiagnosticLog.log("UI_IG_MANUAL_TAP_BROWSER ignored=source_pipeline");
                });
            }

            @Override public void onInstagramManualTapResult(boolean opened, String message) {
                // Legacy diagnostic callback is intentionally non-interactive in the source pipeline build.
                runOnUiThread(() -> {
                    hideInstagramManualTapBrowser();
                    DiagnosticLog.log("UI_IG_MANUAL_TAP_RESULT ignored=source_pipeline opened=" + opened);
                });
            }
        };
    }

    private void showInstagramManualTapBrowser() {
        if (crawlerWebViewHost == null || webView == null) return;
        crawlerWebViewHost.setVisibility(View.VISIBLE);
        crawlerWebViewHost.setBackgroundColor(Color.BLACK);
        crawlerWebViewHost.bringToFront();
        webView.setAlpha(1f);
        webView.setVisibility(View.VISIBLE);
        if (crawlerTouchShield != null) {
            crawlerTouchShield.bringToFront();
            crawlerTouchShield.setVisibility(View.VISIBLE);
        }
        if (mediaGridHost != null) mediaGridHost.setVisibility(View.VISIBLE);
        crawlerWebViewHost.requestLayout();
        DiagnosticLog.log("UI_IG_DEBUG_FLOAT visible=true x=" + Math.round(crawlerWebViewHost.getX())
                + " y=" + Math.round(crawlerWebViewHost.getY()));
    }

    private void hideInstagramManualTapBrowser() {
        if (webView != null) webView.setAlpha(0.01f);
        if (crawlerTouchShield != null) crawlerTouchShield.setVisibility(View.GONE);
        if (crawlerWebViewHost != null) crawlerWebViewHost.setVisibility(View.INVISIBLE);
        if (mediaGridHost != null) mediaGridHost.setVisibility(View.VISIBLE);
    }

    private void clampCrawlerDebugFloat() {
        if (crawlerWebViewHost == null || mediaGridHost == null) return;
        float maxX = Math.max(0f, mediaGridHost.getWidth() - crawlerWebViewHost.getWidth());
        float maxY = Math.max(0f, mediaGridHost.getHeight() - crawlerWebViewHost.getHeight());
        crawlerWebViewHost.setX(Math.max(0f, Math.min(maxX, crawlerWebViewHost.getX())));
        crawlerWebViewHost.setY(Math.max(0f, Math.min(maxY, crawlerWebViewHost.getY())));
    }

    private void createCrawlerForProfile(String profileName) {
        ++crawlerGeneration;  // invalidate callbacks from all previous mode engines
        hideInstagramManualTapBrowser();
        if (crawler != null) crawler.cancel();
        if (webView != null) {
            try { webView.stopLoading(); webView.destroy(); } catch (Throwable ignored) {}
        }
        ModeProvider provider = ModeProviders.forUrl(activeAnalysisUrl);
        AnalysisModeRouter.Mode desiredMode = provider.mode();
        webView = new WebView(this);
        snsAccounts.applyProfile(webView, profileName);
        provider.useCookies(snsAccounts.cookieManager(profileName));
        snsAccounts.prepareLoginCookies(webView, profileName);
        if (activeSnsService != null) {
            String cookie = snsAccounts.getCookie(profileName, activeSnsService.cookieUrl);
            boolean auth = cookie != null && cookie.contains(activeSnsService.authCookieMarker);
            boolean csrf = cookie != null && cookie.contains("ct0=");
            DiagnosticLog.log("SNS_CRAWLER_AUTH service=" + activeSnsService.label
                    + " profile=" + (profileName == null || profileName.isEmpty() ? "default" : profileName)
                    + " auth=" + auth + " csrf=" + csrf
                    + " cookieChars=" + (cookie == null ? 0 : cookie.length()));
        }
        // This WebView backs the same crawler regardless of whether the Activity is visible.
        // Avoid renderer priority dropping for a hidden browser during background scans.
        if (android.os.Build.VERSION.SDK_INT >= 26
                && activeSnsService != SnsAccountManager.Service.INSTAGRAM) {
            webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        }
        webView.getSettings().setOffscreenPreRaster(activeSnsService != SnsAccountManager.Service.INSTAGRAM);
        webView.setAlpha(0.01f);
        int crawlerViewportWidth = Math.max(dp(360), getResources().getDisplayMetrics().widthPixels);
        int crawlerViewportHeight = Math.max(dp(640), getResources().getDisplayMetrics().heightPixels);
        webView.setMinimumWidth(crawlerViewportWidth);
        webView.setMinimumHeight(crawlerViewportHeight);
        webView.setPivotX(0f);
        webView.setPivotY(0f);
        webView.setScaleX(CRAWLER_DEBUG_SCALE);
        webView.setScaleY(CRAWLER_DEBUG_SCALE);
        if (crawlerWebViewHost != null) {
            crawlerWebViewHost.removeAllViews();
            int debugWidth = Math.max(dp(96), Math.round(crawlerViewportWidth * CRAWLER_DEBUG_SCALE));
            int debugHeight = Math.max(dp(176), Math.round(crawlerViewportHeight * CRAWLER_DEBUG_SCALE));
            FrameLayout.LayoutParams hostLp = new FrameLayout.LayoutParams(debugWidth, debugHeight, Gravity.START | Gravity.BOTTOM);
            hostLp.setMargins(dp(8), 0, 0, dp(8));
            crawlerWebViewHost.setLayoutParams(hostLp);
            crawlerWebViewHost.setClipChildren(true);
            crawlerWebViewHost.addView(webView, new FrameLayout.LayoutParams(crawlerViewportWidth, crawlerViewportHeight));
            crawlerTouchShield = new View(this);
            crawlerTouchShield.setBackgroundColor(Color.TRANSPARENT);
            crawlerTouchShield.setClickable(true);
            crawlerTouchShield.setFocusable(true);
            crawlerTouchShield.setContentDescription("Instagramデバッグ表示（長押しで移動）");
            crawlerTouchShield.setOnTouchListener((v, event) -> {
                if (event == null) return true;
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN) {
                    crawlerDebugDownAt = SystemClock.uptimeMillis();
                    crawlerDebugDownRawX = event.getRawX();
                    crawlerDebugDownRawY = event.getRawY();
                    crawlerDebugStartX = crawlerWebViewHost.getX();
                    crawlerDebugStartY = crawlerWebViewHost.getY();
                    crawlerDebugDragging = false;
                    DiagnosticLog.log("UI_IG_DEBUG_TOUCH_BLOCKED x=" + Math.round(event.getX())
                            + " y=" + Math.round(event.getY()));
                    return true;
                }
                if (action == MotionEvent.ACTION_MOVE) {
                    if (!crawlerDebugDragging
                            && SystemClock.uptimeMillis() - crawlerDebugDownAt >= CRAWLER_DEBUG_LONG_PRESS_MS) {
                        crawlerDebugDragging = true;
                        DiagnosticLog.log("UI_IG_DEBUG_DRAG_START x=" + Math.round(crawlerDebugStartX)
                                + " y=" + Math.round(crawlerDebugStartY));
                    }
                    if (crawlerDebugDragging) {
                        crawlerWebViewHost.setX(crawlerDebugStartX + event.getRawX() - crawlerDebugDownRawX);
                        crawlerWebViewHost.setY(crawlerDebugStartY + event.getRawY() - crawlerDebugDownRawY);
                        clampCrawlerDebugFloat();
                    }
                    return true;
                }
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (crawlerDebugDragging) {
                        clampCrawlerDebugFloat();
                        DiagnosticLog.log("UI_IG_DEBUG_DRAG_END x=" + Math.round(crawlerWebViewHost.getX())
                                + " y=" + Math.round(crawlerWebViewHost.getY()));
                    }
                    crawlerDebugDragging = false;
                    return true;
                }
                return true;
            });
            crawlerWebViewHost.addView(crawlerTouchShield, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            crawlerTouchShield.setVisibility(View.GONE);
        }
        activeCrawlerProfile = profileName == null ? "" : profileName;
        DiagnosticLog.log("SNS_CRAWLER_PROFILE profile=" + (activeCrawlerProfile.isEmpty() ? "default" : activeCrawlerProfile));
        DiagnosticLog.log("CRAWLER_VIEWPORT size=" + crawlerViewportWidth + "x" + crawlerViewportHeight
                + " profile=" + (activeCrawlerProfile.isEmpty() ? "default" : activeCrawlerProfile));
        activeCrawlerMode = desiredMode;
        modeProvider = provider;
        showDetectedModeBadge(desiredMode);
        if (thumbnailLoader != null) thumbnailLoader.shutdown();
        Runnable metadataChanged = () -> { if (adapter != null) adapter.notifyDataSetChanged(); };
        thumbnailLoader = provider.thumbnails(this, metadataChanged);
        CrawlerEngine.Listener guardedListener = newGuardedCrawlerListener(crawlerGeneration);
        crawler = provider.crawler(webView, guardedListener);
        DiagnosticLog.log("MODE_FIREWALL_BOUND mode=" + modeProvider.mode() + " generation=" + crawlerGeneration);
        DiagnosticLog.log("MODE_ENGINE_CREATED mode=" + desiredMode
                + " profile=" + (activeCrawlerProfile.isEmpty() ? "default" : activeCrawlerProfile)
                + " owner=" + crawler.getClass().getSimpleName());
    }

    /** Display-only badge: all data and routing stay with the existing isolated engines. */
    private void showDetectedModeBadge(AnalysisModeRouter.Mode detectedMode) {
        if (detectedModeBadge == null) return;
        if (detectedMode == null) {
            detectedModeBadge.setVisibility(View.GONE);
            return;
        }
        final String label;
        switch (detectedMode) {
            case X:
                label = "Xモード";
                break;
            case INSTAGRAM:
                label = "Instagramモード";
                break;
            case NORMAL:
            default:
                label = "ノーマルモード";
                break;
        }
        if (!label.contentEquals(detectedModeBadge.getText())) detectedModeBadge.setText(label);
        detectedModeBadge.setVisibility(View.VISIBLE);
    }

    private void prepareSnsAnalysis(String url) {
        AnalysisModeRouter.Mode desiredMode = AnalysisModeRouter.fromUrl(url);
        activeSnsService = desiredMode == AnalysisModeRouter.Mode.X ? SnsAccountManager.Service.X
                : desiredMode == AnalysisModeRouter.Mode.INSTAGRAM ? SnsAccountManager.Service.INSTAGRAM : null;
        DiagnosticLog.log("ANALYSIS_MODE_AUTO_SELECT mode=" + desiredMode + " url=" + url);
        showDetectedModeBadge(desiredMode);
        snsAnalysisCandidates.clear();
        snsAnalysisIndex = -1;
        if (activeSnsService == null) {
            createCrawlerForProfile(null);
            return;
        }
        List<SnsAccountManager.Account> serviceAccounts = snsAccounts.getAccounts(activeSnsService);
        for (SnsAccountManager.Account a : serviceAccounts) {
            if (snsAccounts.isLoggedIn(a)) {
                snsAnalysisCandidates.add(a);
                DiagnosticLog.log("SNS_ACCOUNT_CANDIDATE service=" + activeSnsService.label
                        + " account=" + a.displayName() + " state=verified");
            }
        }
        // Migration / recovery lane: an older build may have a valid auth cookie but no
        // verified-ID marker yet. Try those only after verified accounts. Completely logged-out
        // profiles are never used for background SNS analysis.
        for (SnsAccountManager.Account a : serviceAccounts) {
            if (!snsAccounts.isLoggedIn(a) && snsAccounts.hasAuthCookie(a)) {
                snsAnalysisCandidates.add(a);
                DiagnosticLog.log("SNS_ACCOUNT_CANDIDATE service=" + activeSnsService.label
                        + " account=" + a.displayName() + " state=auth_cookie_unverified");
            }
        }
        // Instagram legacy compatibility (v0.1.84): an account may be registered
        // without a sessionid cookie or a newer verified-ID flag. Keep it as the
        // final fallback, AFTER authenticated candidates. X and NORMAL are unchanged.
        if (activeSnsService == SnsAccountManager.Service.INSTAGRAM) {
            for (SnsAccountManager.Account a : serviceAccounts) {
                if (!snsAccounts.isLoggedIn(a) && !snsAccounts.hasAuthCookie(a)) {
                    snsAnalysisCandidates.add(a);
                    DiagnosticLog.log("SNS_ACCOUNT_CANDIDATE service=Instagram account="
                            + a.displayName() + " state=legacy_unverified");
                }
            }
        }
        if (!snsAnalysisCandidates.isEmpty()) {
            snsAnalysisIndex = 0;
            SnsAccountManager.Account a = snsAnalysisCandidates.get(0);
            createCrawlerForProfile(a.profileName);
            DiagnosticLog.log(activeSnsService.label + "_ACCOUNT_TRY account=" + a.displayName() + " profile=" + a.profileName);
        } else if (!activeCrawlerProfile.isEmpty() || activeCrawlerMode != desiredMode || crawler == null) {
            createCrawlerForProfile(null);
        }
    }

    private boolean tryNextSnsAccount(String reason) {
        if (activeSnsService == null || snsAnalysisCandidates.isEmpty()) return false;
        int next = snsAnalysisIndex + 1;
        if (next >= snsAnalysisCandidates.size()) return false;
        SnsAccountManager.Account previous = snsAnalysisCandidates.get(Math.max(0, snsAnalysisIndex));
        SnsAccountManager.Account account = snsAnalysisCandidates.get(next);
        snsAnalysisIndex = next;
        DiagnosticLog.log(activeSnsService.label + "_ACCOUNT_FALLBACK from=" + previous.displayName()
                + " to=" + account.displayName() + " reason=" + reason);

        // Keep fallback fully in-memory. Re-reading the external sidecar here used to put
        // storage I/O back on the UI thread and could reintroduce the start/fallback freeze.
        SnsResumeStore.State fallbackResume = null;
        if (isResumeEnabled() && activeResumeTarget != null) {
            fallbackResume = new SnsResumeStore.State();
            fallbackResume.sourceUrl = activeAnalysisUrl == null ? "" : activeAnalysisUrl;
            fallbackResume.complete = false;
            fallbackResume.completedInstagramPosts.addAll(instagramSessionCompletedPosts);
            fallbackResume.discoveredInstagramPosts.addAll(instagramSessionDiscoveredPosts);
            fallbackResume.savedMediaKeys.addAll(snsSessionSavedMediaKeys);
            fallbackResume.failedMediaKeys.addAll(snsSessionFailedMediaKeys);
            for (MediaItem item : items) {
                if (item == null) continue;
                fallbackResume.mediaItems.add(new MediaItem(item.url, item.referrer, item.kind, false,
                        item.width, item.height, item.durationMs, item.dedupKey, item.displayOrder));
            }
            if (fallbackResume.mediaItems.isEmpty()
                    && fallbackResume.completedInstagramPosts.isEmpty()
                    && fallbackResume.discoveredInstagramPosts.isEmpty()
                    && fallbackResume.savedMediaKeys.isEmpty()
                    && fallbackResume.failedMediaKeys.isEmpty()) fallbackResume = null;
        }

        stopVideoPreview("sns_account_fallback");
        resetSnsThumbnailSweep("sns_account_fallback");
        if (thumbnailLoader != null) thumbnailLoader.cancelPending();
        items.clear();
        emittedItemKeys.clear();
        adapter.notifyDataSetChanged();
        updateSummary();
        createCrawlerForProfile(account.profileName);
        if (xCrawlerSession() != null) xCrawlerSession().setIncludeXReposts(xRepostToggle != null && xRepostToggle.isChecked());
        if (fallbackResume != null) {
            restoreExternalResumeState(fallbackResume);
            crawler.seedExternalResumeMedia(items);
            if (activeResumeTarget.service == SnsAccountManager.Service.INSTAGRAM) {
                if (instagramCrawlerSession() != null) instagramCrawlerSession().seedInstagramContinuationState(instagramSessionCompletedPosts, instagramSessionDiscoveredPosts);
            }
            DiagnosticLog.log("SNS_RESUME_FALLBACK_REAPPLY service=" + activeResumeTarget.categoryName
                    + " account=" + activeResumeTarget.accountName
                    + " media=" + items.size());
        }
        markAnalysisProgress("sns_fallback");
        status.setText(activeSnsService.label + " 別アカウントで再試行");
        crawler.start(activeAnalysisUrl, pageToggle.isChecked(), detailToggle.isChecked(), intelligentToggle.isChecked(),
                imageToggle.isChecked(), videoToggle.isChecked(), activeAnalysisTargetPx);
        return true;
    }

    private boolean isSnsThumbnailLazyMode() {
        if (activeSnsService != null) return true;
        if (snsAccounts == null || activeAnalysisUrl == null || activeAnalysisUrl.trim().isEmpty()) return false;
        try {
            return snsAccounts.serviceForUrl(activeAnalysisUrl) != null;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void prefetchSnsThumbnailWindow(int firstVisibleItem, int visibleItemCount) {
        if (thumbnailLoader == null || items.isEmpty()) return;
        int start = Math.max(0, firstVisibleItem - SNS_THUMB_PREFETCH_MARGIN);
        int end = Math.min(items.size() - 1, firstVisibleItem + Math.max(0, visibleItemCount - 1) + SNS_THUMB_PREFETCH_MARGIN);
        for (int i = start; i <= end; i++) {
            MediaItem item = items.get(i);
            if (item != null && item.kind != MediaItem.Kind.STREAM) thumbnailLoader.prefetch(item);
        }
        // Keep thumbnails already loaded while scrolling. LruCache owns eviction;
        // position-based trimming caused visible cells to blank and reload on return scroll.
    }

    private void scheduleSnsThumbnailSweep(String reason) {
        if (thumbnailLoader == null || !isSnsThumbnailLazyMode() || items.isEmpty()) return;
        if (snsThumbnailSweepScheduled) return;
        snsThumbnailSweepScheduled = true;
        snsThumbnailHandler.postDelayed(snsThumbnailSweepRunnable, SNS_THUMB_BACKGROUND_TICK_MS);
        DiagnosticLog.log("SNS_THUMB_AUTO_SCHEDULE reason=" + safeText(reason)
                + " cursor=" + snsThumbnailSweepCursor + " items=" + items.size());
    }

    private void runSnsThumbnailSweep() {
        snsThumbnailSweepScheduled = false;
        if (thumbnailLoader == null || !isSnsThumbnailLazyMode() || items.isEmpty()) return;
        if (thumbnailLoader.pendingCount() >= SNS_THUMB_BACKGROUND_MAX_PENDING) {
            scheduleSnsThumbnailSweep("pending_busy");
            return;
        }

        int size = items.size();
        if (snsThumbnailSweepCursor < 0 || snsThumbnailSweepCursor >= size) snsThumbnailSweepCursor = 0;
        int picked = -1;
        for (int step = 0; step < size; step++) {
            int index = (snsThumbnailSweepCursor + step) % size;
            MediaItem item = items.get(index);
            if (item == null || item.kind == MediaItem.Kind.STREAM) continue;
            if (thumbnailLoader.isCachedOrPending(item)) continue;
            picked = index;
            snsThumbnailSweepCursor = (index + 1) % Math.max(1, size);
            thumbnailLoader.prefetch(item);
            DiagnosticLog.log("SNS_THUMB_AUTO_PREFETCH index=" + index
                    + " kind=" + item.kind.name() + " url=" + item.url);
            break;
        }
        if (picked >= 0) scheduleSnsThumbnailSweep("next");
    }

    private void resetSnsThumbnailSweep(String reason) {
        snsThumbnailHandler.removeCallbacks(snsThumbnailSweepRunnable);
        snsThumbnailSweepScheduled = false;
        snsThumbnailSweepCursor = 0;
        DiagnosticLog.log("SNS_THUMB_AUTO_RESET reason=" + safeText(reason));
    }

    private Button presetButton(String label) {
        Button b = button(label, DARK_GRAY);
        b.setTextSize(13);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(rounded(DARK_GRAY, 18));
        return b;
    }

    private void applyResolutionPreset(int px, Button source) {
        selectedResolutionPreset = source;
        applyingResolutionPreset = true;
        resolutionInput.setText(String.valueOf(px));
        resolutionInput.setSelection(resolutionInput.length());
        applyingResolutionPreset = false;
        updateResolutionPresetStyles();
        DiagnosticLog.log("RESOLUTION_PRESET value=" + px);
    }

    private void updateResolutionPresetStyles() {
        styleResolutionPreset(resolutionSmall, selectedResolutionPreset == resolutionSmall);
        styleResolutionPreset(resolutionMedium, selectedResolutionPreset == resolutionMedium);
        styleResolutionPreset(resolutionLarge, selectedResolutionPreset == resolutionLarge);
    }

    private void styleResolutionPreset(Button button, boolean selected) {
        if (button == null) return;
        button.setTextColor(TEXT_WHITE);
        button.setBackground(rounded(selected ? LIGHT_BLUE : DARK_GRAY, 18));
    }

    private int getTargetResolution() {
        try {
            int px = Integer.parseInt(resolutionInput.getText().toString().trim());
            if (px < 64 || px > 8192) return -1;
            return px;
        } catch (Exception e) {
            return -1;
        }
    }

    private void syncIntelligentTraversalUi() {
        if (intelligentToggle == null || pageToggle == null || detailToggle == null) return;
        boolean intelligent = intelligentToggle.isChecked();
        if (intelligent) {
            pageToggle.setChecked(true);
            detailToggle.setChecked(true);
        }
        setToggleRowEnabled(pageToggle, !intelligent);
        setToggleRowEnabled(detailToggle, !intelligent);
        DiagnosticLog.log("INTELLIGENT_UI enabled=" + intelligent
                + " paginationForced=" + (intelligent && pageToggle.isChecked())
                + " detailsForced=" + (intelligent && detailToggle.isChecked()));
    }

    private void setToggleRowEnabled(NToggleSwitch toggle, boolean enabled) {
        if (toggle == null) return;
        toggle.setEnabled(enabled);
        ViewParent parent = toggle.getParent();
        if (parent instanceof View) {
            View row = (View) parent;
            row.setEnabled(enabled);
            row.setAlpha(enabled ? 1f : 0.42f);
            if (row instanceof ViewGroup) {
                ViewGroup group = (ViewGroup) row;
                for (int i = 0; i < group.getChildCount(); i++) {
                    group.getChildAt(i).setEnabled(enabled);
                }
            }
        }
    }

    private NToggleSwitch addToggleRow(LinearLayout parent, String label, boolean checked) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(label, 14, TEXT_WHITE);
        row.addView(t, new LinearLayout.LayoutParams(0, dp(43), 1f));
        NToggleSwitch sw = new NToggleSwitch(this);
        sw.setChecked(checked);
        row.addView(sw, new LinearLayout.LayoutParams(dp(48), dp(26)));
        View.OnClickListener toggleFromLabel = v -> sw.setChecked(!sw.isChecked());
        t.setClickable(true);
        t.setOnClickListener(toggleFromLabel);
        row.setOnClickListener(toggleFromLabel);
        parent.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(43)));
        return sw;
    }

    private void syncBackgroundAnalysisService(String reason) {
        boolean enabled = backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked();
        boolean shouldRun = enabled && hasActiveKeepAliveWork() && !forceStopInProgress;
        updateForceStopButtonState();
        Intent serviceIntent = new Intent(this, AnalysisKeepAliveService.class);
        try {
            if (shouldRun) {
                AnalysisKeepAliveService.retainOwner(this);
                startForegroundService(serviceIntent);
                DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE start reason=" + reason
                        + " preparing=" + analysisPreparing + " analyzing=" + analyzing
                        + " downloading=" + downloading + " backgroundToggle=" + enabled);
            } else {
                if (AnalysisKeepAliveService.hasOtherRetainedOwner(this)) {
                    DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE stop_skip reason=" + reason
                            + " otherRetainedOwner=true");
                    return;
                }
                AnalysisKeepAliveService.releaseOwner(this);
                stopService(serviceIntent);
                DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE stop reason=" + reason
                        + " preparing=" + analysisPreparing + " analyzing=" + analyzing
                        + " downloading=" + downloading + " backgroundToggle=" + enabled);
            }
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_ANALYSIS_SERVICE_FAIL reason=" + reason
                    + " shouldRun=" + shouldRun, t);
        }
    }

    private void applyCrawlerForegroundPolicy(String reason) {
        boolean backgroundEnabled = backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked();
        boolean shouldPauseWebView = analyzing && !activityResumed && !backgroundEnabled;
        if (webView == null) return;
        // Activity visibility must gate the X crawler state machine as well as WebView.
        // OFF: retain the exact scroll/cursor and resume later, not a false end-of-images.
        // ON: the crawler stays active regardless of Activity visibility.
        if (xCrawlerSession() != null) xCrawlerSession().setXSearchExecutionAllowed(!shouldPauseWebView, reason);
        keepCrawlerRenderAttached(reason);
        if (shouldPauseWebView && !crawlerPausedByForegroundPolicy) {
            crawlerPausedByForegroundPolicy = true;
            try {
                webView.onPause();
                webView.pauseTimers();
                DiagnosticLog.log("BACKGROUND_ANALYSIS_EXECUTION pause reason=" + reason
                        + " enabled=" + backgroundEnabled + " resumed=" + activityResumed);
            } catch (Throwable t) {
                DiagnosticLog.logException("BACKGROUND_ANALYSIS_EXECUTION pause_fail reason=" + reason, t);
            }
        } else if (!shouldPauseWebView && crawlerPausedByForegroundPolicy) {
            crawlerPausedByForegroundPolicy = false;
            try {
                webView.onResume();
                webView.resumeTimers();
                DiagnosticLog.log("BACKGROUND_ANALYSIS_EXECUTION resume reason=" + reason
                        + " enabled=" + backgroundEnabled + " resumed=" + activityResumed);
            } catch (Throwable t) {
                DiagnosticLog.logException("BACKGROUND_ANALYSIS_EXECUTION resume_fail reason=" + reason, t);
            }
        } else {
            DiagnosticLog.log("BACKGROUND_ANALYSIS_EXECUTION unchanged reason=" + reason
                    + " paused=" + crawlerPausedByForegroundPolicy
                    + " enabled=" + backgroundEnabled + " resumed=" + activityResumed);
        }
    }

    /** Chromium deprioritizes a WebView whose entire ancestor tree is INVISIBLE.
     * Keep a 1-pixel visible edge of the ordinary web/X crawler attached while background
     * analysis is requested, without creating an input-blocking overlay on the media grid.
     * Instagram's established source pipeline and its optional debug view are unchanged. */
    private void keepCrawlerRenderAttached(String reason) {
        if (crawlerWebViewHost == null || mediaGridHost == null) return;
        if (activeSnsService == SnsAccountManager.Service.INSTAGRAM) return;
        boolean keepVisible = analyzing && backgroundAnalysisToggle != null
                && backgroundAnalysisToggle.isChecked();
        if (keepVisible) {
            crawlerWebViewHost.setVisibility(View.VISIBLE);
            crawlerWebViewHost.setAlpha(0.02f);
            mediaGridHost.post(() -> {
                if (!analyzing || backgroundAnalysisToggle == null
                        || !backgroundAnalysisToggle.isChecked() || crawlerWebViewHost == null) return;
                // A 1dp sliver remains intersecting its parent viewport for WebView timers.
                crawlerWebViewHost.setX(Math.max(0f, mediaGridHost.getWidth() - dp(1)));
                crawlerWebViewHost.setY(Math.max(0f, mediaGridHost.getHeight() - dp(1)));
            });
        } else {
            crawlerWebViewHost.setVisibility(View.INVISIBLE);
            crawlerWebViewHost.setAlpha(1f);
            crawlerWebViewHost.setX(0f);
            crawlerWebViewHost.setY(0f);
        }
        DiagnosticLog.log("BACKGROUND_WEBVIEW_RENDER visible=" + keepVisible
                + " reason=" + reason + " activityResumed=" + activityResumed);
    }

    private void startSnsKeywordSearch() {
        if (snsSearchInput == null) return;
        String query = snsSearchInput.getText().toString().trim();
        if (query.isEmpty()) {
            Toast.makeText(this, "検索ワードを入力してください", Toast.LENGTH_SHORT).show();
            return;
        }
        if (analysisPreparing || analyzing || downloading) {
            Toast.makeText(this, "解析中の処理を終了してから検索してください", Toast.LENGTH_SHORT).show();
            return;
        }
        SnsAccountManager.Service service = snsSearchInstagramRadio != null && snsSearchInstagramRadio.isChecked()
                ? SnsAccountManager.Service.INSTAGRAM : SnsAccountManager.Service.X;
        String url = buildSnsSearchUrl(service, query);
        if (url.isEmpty()) {
            Toast.makeText(this, "検索ワードを確認してください", Toast.LENGTH_SHORT).show();
            return;
        }
        if (imageToggle != null) imageToggle.setChecked(true);
        urlInput.setText(url);
        urlInput.setSelection(urlInput.length());
        DiagnosticLog.log("SNS_SEARCH_START service=" + service.label
                + " query=" + query + " url=" + url);
        startAnalysis();
    }

    private String buildSnsSearchUrl(SnsAccountManager.Service service, String rawQuery) {
        String query = rawQuery == null ? "" : rawQuery.trim().replaceAll("\\s+", " ");
        if (query.isEmpty()) return "";
        if (service == SnsAccountManager.Service.X) {
            return "https://x.com/search?q=" + Uri.encode(query) + "&src=typed_query&f=live";
        }
        String tag = query;
        while (tag.startsWith("#") || tag.startsWith("＃")) tag = tag.substring(1).trim();
        if (!tag.isEmpty() && tag.indexOf(' ') < 0 && tag.indexOf('\t') < 0) {
            return "https://www.instagram.com/explore/search/keyword/?q=" + Uri.encode("#" + tag);
        }
        return "https://www.instagram.com/explore/search/keyword/?q=" + Uri.encode(query);
    }

    private void startAnalysis() {
        // Snapshot the currently visible values before focus/IME teardown.
        final String url = urlInput.getText().toString().trim();
        dismissKeyboardAndFocus();
        if (url.isEmpty()) {
            Toast.makeText(this, "URLを入力してください", Toast.LENGTH_SHORT).show();
            return;
        }
        final int targetPx = getTargetResolution();
        if (targetPx < 0) {
            Toast.makeText(this, "解像度下限は64〜8192pxで入力してください", Toast.LENGTH_SHORT).show();
            return;
        }
        if (downloading || analysisPreparing) return;
        SiteVisitStore.recordVisit(this, url);
        forceStopInProgress = false;
        updateForceStopButtonState();

        // v0.1.78: reflect the tap immediately. Resume-file lookup can take seconds on some
        // providers, so it must never run on the UI thread or leave the button looking idle.
        analysisPreparing = true;
        final int prepareGeneration = ++analysisPrepareGeneration;
        setAnalysisPreparingUi(true);

        continuationReloading = false;
        continuationNeededForRun = false;
        instagramSessionCompletedPosts.clear();
        instagramSessionDiscoveredPosts.clear();
        snsSessionSavedMediaKeys.clear();
        snsSessionFailedMediaKeys.clear();
        normalSavedMediaKeys.clear();
        normalSavedFileUris.clear();
        normalSavedTarget = NormalSavedLedgerStore.key(url);
        activeResumeComplete = false;
        setContinuationCell(false, "new_analysis");
        setSettingsExpanded(false, true);
        DiagnosticLog.clear();
        DiagnosticLog.log("LOG_RESET analyze_start url=" + url);
        if (analyzing && crawler != null) crawler.cancel();
        stopVideoPreview("analysis_start");
        resetSnsThumbnailSweep("analysis_start");
        thumbnailLoader.cancelPending();
        ModeProviders.forUrl(url).preview().reset();
        DiagnosticLog.log("ANALYZE_START url=" + url
                + " pagination=" + pageToggle.isChecked()
                + " details=" + detailToggle.isChecked()
                + " intelligent=" + (intelligentToggle != null && intelligentToggle.isChecked())
                + " images=" + imageToggle.isChecked()
                + " videos=" + videoToggle.isChecked()
                + " xReposts=" + (xRepostToggle != null && xRepostToggle.isChecked())
                + " targetImagePx=" + targetPx);
        items.clear();
        emittedItemKeys.clear();
        selectionMode = false;
        selectionAnchorPosition = -1;
        updateSelectionControls();
        adapter.notifyDataSetChanged();
        pageTitle = "ImgStalker";
        activeAnalysisUrl = url;
        activeAnalysisTargetPx = targetPx;

        activeResumeTarget = SnsResumeStore.targetForUrl(url);
        syncBackgroundAnalysisService("analysis_prepare");

        // The external sidecar lives beside downloaded media.  On Android 11+ that location
        // needs a persisted SAF tree grant.  Ask once, at the first SNS analysis, instead of
        // silently deferring every checkpoint forever on the default Pictures/ImgStalker path.
        if (isResumeEnabled() && activeResumeTarget != null && !SavePrefs.hasTreeAccess(this)) {
            pendingResumeGrantGeneration = prepareGeneration;
            pendingResumeGrantUrl = url;
            pendingResumeGrantTargetPx = targetPx;
            DiagnosticLog.log("SNS_RESUME_SAF_REQUIRED service=" + activeResumeTarget.categoryName
                    + " account=" + activeResumeTarget.accountName
                    + " path=" + SavePrefs.directory(this).getAbsolutePath());
            try {
                Intent grant = new Intent(this, FolderPickerActivity.class);
                grant.putExtra(FolderPickerActivity.EXTRA_AUTO_GRANT_PATH,
                        SavePrefs.directory(this).getAbsolutePath());
                startActivityForResult(grant, REQ_RESUME_TREE_ACCESS);
                return;
            } catch (Throwable t) {
                DiagnosticLog.logException("SNS_RESUME_SAF_OPEN_FAIL", t);
                pendingResumeGrantGeneration = -1;
                pendingResumeGrantUrl = "";
            }
        }
        continuePreparedAnalysis(prepareGeneration, url, targetPx);
    }

    private void continuePreparedAnalysis(int prepareGeneration, String url, int targetPx) {
        if (prepareGeneration != analysisPrepareGeneration || !analysisPreparing) return;

        // WebView/profile creation remains on the UI thread, but the external resume lookup stays
        // on resumeIoExecutor.  This keeps the analyze tap responsive even with a slow provider.
        prepareSnsAnalysis(url);
        final SnsResumeStore.Target target = activeResumeTarget;
        DiagnosticLog.log("ANALYSIS_RESUME_LOAD_ASYNC_START url=" + url
                + " sns=" + (target != null) + " enabled=" + isResumeEnabled());
        try {
            resumeIoExecutor.execute(() -> {
                AnalysisSessionStore.State generic = isResumeEnabled()
                        ? AnalysisSessionStore.load(getApplicationContext(), url) : null;
                SnsResumeStore.State loaded = target != null
                        ? SnsResumeStore.load(getApplicationContext(), target) : null;
                java.util.LinkedHashSet<String> savedKeys = target == null ? new java.util.LinkedHashSet<>()
                        : SnsSavedLedgerStore.load(getApplicationContext(), target);
                java.util.LinkedHashMap<String, String> normalSavedKeys =
                        AnalysisModeRouter.fromUrl(url) == AnalysisModeRouter.Mode.NORMAL
                                ? NormalSavedLedgerStore.load(getApplicationContext(), url)
                                : new java.util.LinkedHashMap<>();
                if (loaded != null && !loaded.savedMediaKeys.isEmpty() && target != null) {
                    // Migrate v0.1.134 and earlier sidecar save marks before any new writes
                    // can modify the legacy resume JSON. Failed migration leaves it intact.
                    savedKeys.addAll(loaded.savedMediaKeys);
                    boolean migrated = SnsSavedLedgerStore.save(getApplicationContext(), target, savedKeys);
                    DiagnosticLog.log("SNS_SAVED_LEDGER_MIGRATE ok=" + migrated
                            + " saved=" + savedKeys.size());
                }
                runOnUiThread(() -> finishPreparedAnalysis(prepareGeneration, url, targetPx,
                        loaded, generic, savedKeys, normalSavedKeys));
            });
        } catch (Throwable t) {
            DiagnosticLog.logException("ANALYSIS_RESUME_LOAD_QUEUE_FAIL", t);
            finishPreparedAnalysis(prepareGeneration, url, targetPx, null, null,
                    new java.util.LinkedHashSet<>(), new java.util.LinkedHashMap<>());
        }
    }

    private void finishPreparedAnalysis(int prepareGeneration, String url, int targetPx,
                                        SnsResumeStore.State externalResume,
                                        AnalysisSessionStore.State universalResume,
                                        java.util.Collection<String> preservedSavedKeys,
                                        java.util.Map<String, String> preservedNormalSavedKeys) {
        if (prepareGeneration != analysisPrepareGeneration || !analysisPreparing) {
            DiagnosticLog.log("ANALYZE_PREPARE_STALE generation=" + prepareGeneration
                    + " active=" + analysisPrepareGeneration);
            return;
        }
        if (isFinishing() || (android.os.Build.VERSION.SDK_INT >= 17 && isDestroyed())) return;

        if (externalResume != null) {
            // Save history is independent from whether the crawl itself is complete. A completed
            // sidecar is ignored only for crawl continuation, never for duplicate-save prevention.
            snsSessionSavedMediaKeys.clear();
            snsSessionSavedMediaKeys.addAll(externalResume.savedMediaKeys);
            snsSessionFailedMediaKeys.clear();
            snsSessionFailedMediaKeys.addAll(externalResume.failedMediaKeys);
            snsSessionFailedMediaKeys.removeAll(snsSessionSavedMediaKeys);
        }
        if (isResumeEnabled() && externalResume != null && !externalResume.complete) {
            restoreExternalResumeState(externalResume);
            DiagnosticLog.log("SNS_RESUME_AUTO_APPLY service=" + activeResumeTarget.categoryName
                    + " account=" + activeResumeTarget.accountName
                    + " media=" + externalResume.mediaItems.size()
                    + " igCompleted=" + externalResume.completedInstagramPosts.size()
                    + " igDiscovered=" + externalResume.discoveredInstagramPosts.size()
                    + " saved=" + externalResume.savedMediaKeys.size()
                    + " failed=" + externalResume.failedMediaKeys.size());
        } else if (externalResume != null) {
            DiagnosticLog.log("SNS_RESUME_AUTO_IGNORE reason=complete_or_disabled service="
                    + activeResumeTarget.categoryName + " account=" + activeResumeTarget.accountName
                    + " saved=" + snsSessionSavedMediaKeys.size()
                    + " failed=" + snsSessionFailedMediaKeys.size());
            externalResume = null;
        }

        // Preserve Instagram's established, site-specific post-level resume and media
        // resolution unchanged. Generic queue resume applies to X and other web modes.
        boolean canUseUniversal = isResumeEnabled() && universalResume != null && !universalResume.complete
                && (AnalysisModeRouter.fromUrl(url) == AnalysisModeRouter.Mode.NORMAL
                    ? NormalCheckpointStore.matches(url, universalResume.sourceUrl)
                    : url.equals(universalResume.sourceUrl))
                // Instagram account profiles retain their mature post-level sidecar path.
                // Other Instagram URLs (e.g. search/posts without that sidecar) can still
                // restore their media list through the generic checkpoint.
                && (activeSnsService != SnsAccountManager.Service.INSTAGRAM
                    || activeResumeTarget == null);
        if (canUseUniversal) {
            pageToggle.setChecked(universalResume.pages);
            detailToggle.setChecked(universalResume.details);
            intelligentToggle.setChecked(universalResume.intelligent);
            imageToggle.setChecked(universalResume.images);
            videoToggle.setChecked(universalResume.videos);
            if (xRepostToggle != null) xRepostToggle.setChecked(universalResume.xReposts);
            if (xGifAsGifToggle != null) xGifAsGifToggle.setChecked(universalResume.xGifAsGif);
            targetPx = universalResume.targetPx;
            activeAnalysisTargetPx = targetPx;
            resolutionInput.setText(String.valueOf(targetPx));
            for (MediaItem source : universalResume.mediaItems) {
                String key = source.dedupKey == null || source.dedupKey.isEmpty()
                        ? source.kind.name() + "|" + source.url : source.dedupKey;
                if (emittedItemKeys.add(key)) items.add(source);
            }
            if (adapter != null) adapter.notifyDataSetChanged();
            updateSummary();
            DiagnosticLog.log("ANALYSIS_RESUME_APPLY media=" + items.size()
                    + " queue=" + (universalResume.cursor != null)
                    + " url=" + url);
        }

        // NORMAL save success has its own per-site ledger, independent of the SNS state.
        // Never seed SNS saved keys with NORMAL entries (or vice versa).
        if (AnalysisModeRouter.fromUrl(url) == AnalysisModeRouter.Mode.NORMAL) {
            normalSavedTarget = NormalSavedLedgerStore.key(url);
            normalSavedMediaKeys.clear();
            normalSavedFileUris.clear();
            if (preservedNormalSavedKeys != null)
                normalSavedFileUris.putAll(preservedNormalSavedKeys);
            normalSavedMediaKeys.addAll(normalSavedFileUris.keySet());
            DiagnosticLog.log("NORMAL_SAVED_LEDGER_RESTORED target=" + normalSavedTarget
                    + " saved=" + normalSavedMediaKeys.size());
        }
        // Final authority is the separate, durable saved ledger. A saved-mark must survive
        // deleting all analysis/resume checkpoints and also work with Resume toggled OFF.
        if (preservedSavedKeys != null) snsSessionSavedMediaKeys.addAll(preservedSavedKeys);
        snsSessionFailedMediaKeys.removeAll(snsSessionSavedMediaKeys);
        if (adapter != null) adapter.notifyDataSetChanged();
        updateSummary();
        DiagnosticLog.log("SNS_SAVED_LEDGER_RESTORED count=" + snsSessionSavedMediaKeys.size());

        if (crawler != null) {
            if (xCrawlerSession() != null) xCrawlerSession().setIncludeXReposts(xRepostToggle != null && xRepostToggle.isChecked());
            if (externalResume != null || canUseUniversal) {
                crawler.seedExternalResumeMedia(items);
                if (externalResume != null && activeResumeTarget != null
                        && activeResumeTarget.service == SnsAccountManager.Service.INSTAGRAM) {
                    if (instagramCrawlerSession() != null) instagramCrawlerSession().seedInstagramContinuationState(instagramSessionCompletedPosts, instagramSessionDiscoveredPosts);
                }
            }
            if (canUseUniversal && universalResume.cursor != null) {
                if (normalCrawlerSession() != null) normalCrawlerSession().seedQueueCursor(universalResume.cursor);
                if (xCrawlerSession() != null) xCrawlerSession().seedQueueCursor(universalResume.cursor);
            }
        }

        analysisPreparing = false;
        setAnalysisPreparingUi(false);
        analyzing = true;
        analysisStopRequested = false;
        analyzeClearPending = false;
        status.setText("解析開始");
        if (postProgress != null) postProgress.setText("");
        updateSummary();
        setAnalysisRunningUi(true);
        syncBackgroundAnalysisService("analysis_start");
        markAnalysisProgress("start");
        // Do not overwrite the loaded resume cursor with an empty crawler state
        // before CrawlerEngine.start() has actually installed the restored queue.
        // Do not write an empty resume file at analysis start. Checkpoints begin only after
        // useful media/post progress, an incomplete state, or a safe stop.
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        DiagnosticLog.log("ANALYZE_PREPARE_DONE generation=" + prepareGeneration
                + " resume=" + (externalResume != null || canUseUniversal));
        crawler.start(url, pageToggle.isChecked(), detailToggle.isChecked(), intelligentToggle.isChecked(), imageToggle.isChecked(), videoToggle.isChecked(), targetPx);
        writeInternalCheckpoint(false, "analysis_start");
        applyCrawlerForegroundPolicy("analysis_start");
    }

    private void setAnalysisPreparingUi(boolean preparing) {
        if (analyzeButton != null) {
            analyzeButton.setEnabled(!preparing);
            if (preparing) {
                analyzeButton.setText("準備中…");
                analyzeButton.setTextColor(N_WHITE);
                analyzeButton.setBackground(rounded(GRAY, 12));
            }
        }
        setViewTreeEnabled(settingsPanel, !preparing);
        if (!preparing) syncIntelligentTraversalUi();
        if (!preparing && !analyzing) refreshAnalyzeButtonIdleState();
        if (preparing) status.setText("準備中…");
        updateForceStopButtonState();
        DiagnosticLog.log("ANALYZE_PREPARE_UI active=" + preparing);
    }

    private void setViewTreeEnabled(View view, boolean enabled) {
        if (view == null) return;
        view.setEnabled(enabled);
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) setViewTreeEnabled(group.getChildAt(i), enabled);
        }
    }

    private final Runnable analysisWatchdog = new Runnable() {
        @Override public void run() {
            if (!analyzing) return;
            long idleMs = Math.max(0L, SystemClock.uptimeMillis() - lastAnalysisProgressAt);
            boolean pending = crawler != null && crawler.hasPendingWork();
            boolean expectedPaused = analyzing && !activityResumed
                    && (backgroundAnalysisToggle == null || !backgroundAnalysisToggle.isChecked());
            if (pending && !expectedPaused && idleMs >= ANALYSIS_STALL_MS) {
                boolean autoRecovered = crawler != null && crawler.recoverFromStall();
                if (autoRecovered) {
                    lastAnalysisProgressAt = SystemClock.uptimeMillis();
                    interruptionSuspected = false;
                    DiagnosticLog.log("ANALYSIS_STALL_AUTO_RECOVER idleMs=" + idleMs
                            + " snapshot=" + crawler.progressSnapshot());
                    if (analysisIndicatorHost != null) analysisIndicatorHost.setVisibility(View.VISIBLE);
                    if (analysisSpinner != null) analysisSpinner.setVisibility(View.VISIBLE);
                    if (analysisInterruptedIcon != null) analysisInterruptedIcon.setVisibility(View.GONE);
                } else if (!interruptionSuspected) {
                    interruptionSuspected = true;
                    continuationNeededForRun = true;
                    DiagnosticLog.log("ANALYSIS_INTERRUPTED suspected=true idleMs=" + idleMs
                            + " snapshot=" + (crawler == null ? "none" : crawler.progressSnapshot()));
                    showInterruptedIndicator();
                    setContinuationCell(true, "watchdog_stall");
                }
            }
            analysisWatchdogHandler.postDelayed(this, ANALYSIS_WATCHDOG_TICK_MS);
        }
    };

    private void markAnalysisProgress(String stage) {
        if (!analyzing) return;
        lastAnalysisProgressAt = SystemClock.uptimeMillis();
        if (interruptionSuspected) {
            interruptionSuspected = false;
            DiagnosticLog.log("ANALYSIS_INTERRUPTED_CLEAR stage=" + stage
                    + " continuationSticky=" + continuationNeededForRun);
        }
        if (analysisIndicatorHost != null) analysisIndicatorHost.setVisibility(View.VISIBLE);
        if (analysisSpinner != null) analysisSpinner.setVisibility(View.VISIBLE);
        if (analysisInterruptedIcon != null) analysisInterruptedIcon.setVisibility(View.GONE);
    }

    private void showInterruptedIndicator() {
        if (analysisIndicatorHost != null) analysisIndicatorHost.setVisibility(View.VISIBLE);
        if (analysisSpinner != null) analysisSpinner.setVisibility(View.GONE);
        if (analysisInterruptedIcon != null) analysisInterruptedIcon.setVisibility(View.VISIBLE);
    }

    private void setAnalysisRunningUi(boolean running) {
        analysisWatchdogHandler.removeCallbacks(analysisWatchdog);
        if (running) {
            analyzeButton.setText("停止");
            analyzeButton.setTextColor(TEXT_WHITE);
            analyzeButton.setBackground(rounded(DARK_RED, 12));
            interruptionSuspected = false;
            lastAnalysisProgressAt = SystemClock.uptimeMillis();
            if (analysisIndicatorHost != null) analysisIndicatorHost.setVisibility(View.VISIBLE);
            if (analysisSpinner != null) analysisSpinner.setVisibility(View.VISIBLE);
            if (analysisInterruptedIcon != null) analysisInterruptedIcon.setVisibility(View.GONE);
            analysisWatchdogHandler.postDelayed(analysisWatchdog, ANALYSIS_WATCHDOG_TICK_MS);
        } else {
            refreshAnalyzeButtonIdleState();
            interruptionSuspected = false;
            if (analysisSpinner != null) analysisSpinner.setVisibility(View.GONE);
            if (analysisInterruptedIcon != null) analysisInterruptedIcon.setVisibility(View.GONE);
            if (analysisIndicatorHost != null) analysisIndicatorHost.setVisibility(View.GONE);
        }
        updateForceStopButtonState();
        if (!running) requestCacheAvailability();
    }

    private void handleAnalyzeButton() {
        if (mirroredWorkOwner != null && mirroredWorkOwner.hasActiveKeepAliveWork()) {
            if (mirroredWorkOwner.analyzing) mirroredWorkOwner.stopAnalysisByUser("attached_activity");
            return;
        }
        if (AnalysisKeepAliveService.hasOtherRetainedOwner(this)) {
            DiagnosticLog.log("ANALYZE_BUTTON_IGNORED reason=other_retained_work");
            Toast.makeText(this, "バックグラウンドで処理中です", Toast.LENGTH_SHORT).show();
            return;
        }
        if (analysisPreparing) {
            DiagnosticLog.log("ANALYZE_BUTTON_IGNORED reason=preparing");
            return;
        }
        if (analyzing) {
            if (!analysisStopRequested) stopAnalysisByUser("analyze_button");
            return;
        }
        if (analyzeClearPending) {
            clearAnalysisCells();
            return;
        }
        startAnalysis();
    }

    private void refreshAnalyzeButtonIdleState() {
        if (analyzeButton == null) return;
        analyzeButton.setEnabled(true);
        analyzeButton.setText(analyzeClearPending ? "クリア" : "解析");
        analyzeButton.setTextColor(TEXT_WHITE);
        analyzeButton.setBackground(rounded(analyzeClearPending ? GRAY : ORANGE, 12));
    }

    private void clearAnalysisCells() {
        stopVideoPreview("analyze_clear");
        resetSnsThumbnailSweep("analyze_clear");
        if (thumbnailLoader != null) thumbnailLoader.cancelPending();
        items.clear();
        emittedItemKeys.clear();
        selectionMode = false;
        selectionAnchorPosition = -1;
        continuationReloading = false;
        continuationNeededForRun = false;
        setContinuationCell(false, "analyze_clear");
        updateSelectionControls();
        if (adapter != null) adapter.notifyDataSetChanged();
        updateSummary();
        if (postProgress != null) postProgress.setText("");
        status.setText("結果をクリア");
        showDetectedModeBadge(null);
        analysisStopRequested = false;
        analyzeClearPending = false;
        refreshAnalyzeButtonIdleState();
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        DiagnosticLog.log("ANALYZE_CLEAR cells=0");
    }

    private boolean isPostProgressStatus(String text) {
        return text != null && text.trim().startsWith("投稿を取得中（");
    }

    private String statusWithoutUrl(String text) {
        if (text == null) return "";
        String cleaned = text.replaceAll("https?://\\S+", "")
                .replaceAll("\\s{2,}", " ").trim();
        while (cleaned.endsWith(":") || cleaned.endsWith("：")) {
            cleaned = cleaned.substring(0, cleaned.length() - 1).trim();
        }
        return cleaned.isEmpty() ? "解析中" : cleaned;
    }

    private boolean isResumeEnabled() {
        return resumeToggle == null || resumeToggle.isChecked();
    }

    private void restoreExternalResumeState(SnsResumeStore.State state) {
        if (state == null) return;
        items.clear();
        emittedItemKeys.clear();
        instagramSessionCompletedPosts.clear();
        instagramSessionDiscoveredPosts.clear();
        snsSessionSavedMediaKeys.clear();
        snsSessionSavedMediaKeys.addAll(state.savedMediaKeys);
        snsSessionFailedMediaKeys.clear();
        snsSessionFailedMediaKeys.addAll(state.failedMediaKeys);
        snsSessionFailedMediaKeys.removeAll(snsSessionSavedMediaKeys);
        instagramSessionCompletedPosts.addAll(state.completedInstagramPosts);
        instagramSessionDiscoveredPosts.addAll(state.discoveredInstagramPosts);
        instagramSessionDiscoveredPosts.addAll(state.completedInstagramPosts);
        for (MediaItem source : state.mediaItems) {
            if (source == null || source.url == null || source.url.trim().isEmpty()) continue;
            MediaItem item = new MediaItem(source.url, source.referrer, source.kind, false,
                    source.width, source.height, source.durationMs, source.dedupKey, source.displayOrder);
            String key = item.dedupKey == null || item.dedupKey.isEmpty()
                    ? item.kind.name() + "|" + item.url : item.dedupKey;
            if (!key.isEmpty() && !emittedItemKeys.add(key)) continue;
            items.add(item);
        }
        if (adapter != null) adapter.notifyDataSetChanged();
        updateSummary();
        resetSnsThumbnailSweep("resume_restore");
        scheduleSnsThumbnailSweep("resume_restore");
        DiagnosticLog.log("SNS_RESUME_UI_RESTORE media=" + items.size()
                + " igCompleted=" + instagramSessionCompletedPosts.size()
                + " igDiscovered=" + instagramSessionDiscoveredPosts.size()
                + " saved=" + snsSessionSavedMediaKeys.size()
                + " failed=" + snsSessionFailedMediaKeys.size());
    }

    private void scheduleResumeCheckpoint(String reason) {
        if (cacheResetInProgress || !isResumeEnabled() || activeAnalysisUrl == null || activeAnalysisUrl.isEmpty()) return;
        resumeCheckpointHandler.removeCallbacks(resumeCheckpointRunnable);
        resumeCheckpointHandler.postDelayed(resumeCheckpointRunnable, 350L);
        DiagnosticLog.log("ANALYSIS_RESUME_CHECKPOINT_SCHEDULE reason=" + safeText(reason));
    }

    private void persistSavedLedger(String reason) {
        if (cacheResetInProgress || activeResumeTarget == null) return;
        final SnsResumeStore.Target target = activeResumeTarget;
        final java.util.LinkedHashSet<String> snapshot = new java.util.LinkedHashSet<>(snsSessionSavedMediaKeys);
        try {
            // Single ordered queue: older resume writes cannot overwrite the save record.
            resumeIoExecutor.execute(() -> {
                boolean ok = SnsSavedLedgerStore.save(getApplicationContext(), target, snapshot);
                DiagnosticLog.log("SNS_SAVED_LEDGER_COMMIT reason=" + safeText(reason)
                        + " ok=" + ok + " saved=" + snapshot.size());
            });
        } catch (Throwable t) { DiagnosticLog.logException("SNS_SAVED_LEDGER_QUEUE_FAIL", t); }
    }

    /** Recheck media deleted outside the app; only the NORMAL owner can receive this result. */
    private void refreshNormalSavedFiles(String reason) {
        if (activeCrawlerMode != AnalysisModeRouter.Mode.NORMAL || downloading || analysisPreparing
                || activeAnalysisUrl == null || activeAnalysisUrl.isEmpty()) return;
        final String url = activeAnalysisUrl;
        final String target = normalSavedTarget;
        if (target.isEmpty()) return;
        try {
            resumeIoExecutor.execute(() -> {
                java.util.LinkedHashMap<String, String> verified =
                        NormalSavedLedgerStore.load(getApplicationContext(), url);
                runOnUiThread(() -> {
                    if (downloading || analysisPreparing || activeCrawlerMode != AnalysisModeRouter.Mode.NORMAL
                            || !target.equals(normalSavedTarget)
                            || !NormalCheckpointStore.matches(url, activeAnalysisUrl)) return;
                    int removed = normalSavedMediaKeys.size() - verified.size();
                    normalSavedFileUris.clear();
                    normalSavedFileUris.putAll(verified);
                    normalSavedMediaKeys.clear();
                    normalSavedMediaKeys.addAll(verified.keySet());
                    DiagnosticLog.log("NORMAL_SAVED_REFRESH reason=" + safeText(reason)
                            + " present=" + verified.size() + " removed=" + Math.max(0, removed));
                    if (adapter != null) adapter.notifyDataSetChanged();
                    updateSummary();
                });
            });
        } catch (Throwable e) { DiagnosticLog.logException("NORMAL_SAVED_REFRESH_FAIL", e); }
    }

    /** Persist verified NORMAL save successes outside disposable scan caches. */
    private void persistNormalSavedLedger(String sourceUrl, String reason) {
        if (sourceUrl == null || NormalSavedLedgerStore.key(sourceUrl).isEmpty()) return;
        final java.util.LinkedHashMap<String, String> snapshot = new java.util.LinkedHashMap<>(normalSavedFileUris);
        try {
            resumeIoExecutor.execute(() -> {
                boolean ok = NormalSavedLedgerStore.save(getApplicationContext(), sourceUrl, snapshot);
                DiagnosticLog.log("NORMAL_SAVED_LEDGER_WRITE reason=" + safeText(reason)
                        + " ok=" + ok + " saved=" + snapshot.size());
            });
        } catch (Throwable t) { DiagnosticLog.logException("NORMAL_SAVED_LEDGER_QUEUE_FAIL", t); }
    }

    private void writeResumeCheckpoint(boolean complete, String reason) {
        if (cacheResetInProgress) return;
        writeInternalCheckpoint(complete, reason);
        if (!isResumeEnabled() || activeResumeTarget == null || activeSnsService == null) return;
        resumeCheckpointHandler.removeCallbacks(resumeCheckpointRunnable);
        if (activeSnsService == SnsAccountManager.Service.INSTAGRAM && crawler != null) {
            mergeInstagramSessionProgress("resume_" + safeText(reason));
        }
        final SnsResumeStore.Target target = activeResumeTarget;
        final SnsResumeStore.State state = new SnsResumeStore.State();
        state.sourceUrl = activeAnalysisUrl == null ? "" : activeAnalysisUrl;
        state.complete = complete;
        if (activeCrawlerMode == AnalysisModeRouter.Mode.INSTAGRAM) {
            state.completedInstagramPosts.addAll(instagramSessionCompletedPosts);
            state.discoveredInstagramPosts.addAll(instagramSessionDiscoveredPosts);
        }
        state.savedMediaKeys.addAll(snsSessionSavedMediaKeys);
        state.failedMediaKeys.addAll(snsSessionFailedMediaKeys);
        for (MediaItem item : items) {
            if (item == null) continue;
            state.mediaItems.add(new MediaItem(item.url, item.referrer, item.kind, false,
                    item.width, item.height, item.durationMs, item.dedupKey, item.displayOrder));
        }
        if (!complete && state.mediaItems.isEmpty()
                && state.completedInstagramPosts.isEmpty()
                && state.discoveredInstagramPosts.isEmpty()
                && state.savedMediaKeys.isEmpty()
                && state.failedMediaKeys.isEmpty()) {
            DiagnosticLog.log("SNS_RESUME_CHECKPOINT_SKIP_EMPTY reason=" + safeText(reason));
            return;
        }
        DiagnosticLog.log("SNS_RESUME_CHECKPOINT_WRITE reason=" + safeText(reason)
                + " complete=" + complete
                + " media=" + state.mediaItems.size()
                + " igCompleted=" + state.completedInstagramPosts.size()
                + " igDiscovered=" + state.discoveredInstagramPosts.size()
                + " saved=" + state.savedMediaKeys.size()
                + " failed=" + state.failedMediaKeys.size());
        resumeWritesInFlight++;
        syncBackgroundAnalysisService("resume_checkpoint_write");
        try {
            resumeIoExecutor.execute(() -> {
                boolean ok = SnsResumeStore.write(getApplicationContext(), target, state);
                runOnUiThread(() -> {
                    resumeWritesInFlight = Math.max(0, resumeWritesInFlight - 1);
                    DiagnosticLog.log("SNS_RESUME_CHECKPOINT_DONE reason=" + safeText(reason) + " ok=" + ok
                            + " pendingWrites=" + resumeWritesInFlight);
                    if (!analysisPreparing && !analyzing && !downloading) {
                        syncBackgroundAnalysisService("resume_checkpoint_done");
                    }
                });
            });
        } catch (Throwable t) {
            resumeWritesInFlight = Math.max(0, resumeWritesInFlight - 1);
            DiagnosticLog.logException("SNS_RESUME_CHECKPOINT_QUEUE_FAIL reason=" + safeText(reason), t);
            if (!analysisPreparing && !analyzing && !downloading) {
                syncBackgroundAnalysisService("resume_checkpoint_queue_fail");
            }
        }
    }

    /** Save a durable continuation for every mode; never block the main/WebView thread on I/O. */
    private void writeInternalCheckpoint(boolean complete, String reason) {
        if (cacheResetInProgress) return;
        if (!isResumeEnabled() || activeAnalysisUrl == null || activeAnalysisUrl.trim().isEmpty()) return;
        AnalysisSessionStore.State snapshot = new AnalysisSessionStore.State();
        snapshot.sourceUrl = activeAnalysisUrl;
        snapshot.complete = complete || (!analyzing && activeResumeComplete);
        snapshot.pages = pageToggle.isChecked();
        snapshot.details = detailToggle.isChecked();
        snapshot.intelligent = intelligentToggle == null || intelligentToggle.isChecked();
        snapshot.images = imageToggle.isChecked();
        snapshot.videos = videoToggle.isChecked();
        snapshot.background = backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked();
        snapshot.xReposts = xRepostToggle != null && xRepostToggle.isChecked();
        snapshot.xGifAsGif = xGifAsGifToggle == null || xGifAsGifToggle.isChecked();
        snapshot.targetPx = activeAnalysisTargetPx;
        snapshot.updatedAt = System.currentTimeMillis();
        snapshot.cursor = normalCrawlerSession() != null ? normalCrawlerSession().checkpointCursor()
                : xCrawlerSession() == null ? null : xCrawlerSession().checkpointCursor();
        for (MediaItem item : items) {
            if (item == null) continue;
            snapshot.mediaItems.add(new MediaItem(item.url, item.referrer, item.kind, false,
                    item.width, item.height, item.durationMs, item.dedupKey, item.displayOrder));
        }
        lastUniversalCheckpointAt = android.os.SystemClock.uptimeMillis();
        DiagnosticLog.log("ANALYSIS_CHECKPOINT_SCHEDULE reason=" + safeText(reason)
                + " complete=" + snapshot.complete + " media=" + snapshot.mediaItems.size());
        try {
            resumeWritesInFlight++;
            // Avoid restarting the foreground service on every heartbeat. Restarting it
            // dispatches an immediate new heartbeat and otherwise forms an endless loop.
            if (backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked()
                    && !AnalysisKeepAliveService.isRetaining(this)) {
                syncBackgroundAnalysisService("analysis_checkpoint_first_write");
            }
            resumeIoExecutor.execute(() -> {
                AnalysisSessionStore.write(getApplicationContext(), snapshot);
                runOnUiThread(() -> {
                    resumeWritesInFlight = Math.max(0, resumeWritesInFlight - 1);
                    if (!analysisPreparing && !analyzing && !downloading) {
                        syncBackgroundAnalysisService("analysis_checkpoint_done");
                    }
                });
            });
        } catch (Throwable t) {
            resumeWritesInFlight = Math.max(0, resumeWritesInFlight - 1);
            DiagnosticLog.logException("ANALYSIS_CHECKPOINT_QUEUE_FAIL", t);
        }
    }

    /** Re-open a genuinely incomplete persisted scan, even if the process was killed
     * without an Activity state callback. The existing per-site collector is reused. */
    private void restoreInterruptedAnalysisOnLaunch() {
        if (!isResumeEnabled()) return;
        if (AnalysisKeepAliveService.hasOtherRetainedOwner(this)) {
            DiagnosticLog.log("ANALYSIS_AUTO_RESUME_SKIP active_retained_worker=true");
            status.setText("別画面でバックグラウンド解析が継続中");
            return;
        }
        try {
            final int restoreEpoch = cacheResetEpoch;
            resumeIoExecutor.execute(() -> {
                AnalysisSessionStore.State saved = AnalysisSessionStore.load(getApplicationContext());
                runOnUiThread(() -> {
                    if (cacheResetInProgress || cacheResetEpoch != restoreEpoch || saved == null || saved.complete || !isResumeEnabled()
                            || analysisPreparing || analyzing || downloading || isFinishing() || isDestroyed()) return;
                    if (saved.updatedAt <= 0L || System.currentTimeMillis() - saved.updatedAt > 7L * 86400000L) {
                        DiagnosticLog.log("ANALYSIS_AUTO_RESUME_SKIP reason=stale");
                        return;
                    }
                    if (AnalysisKeepAliveService.hasOtherRetainedOwner(this)) return;
                    urlInput.setText(saved.sourceUrl);
                    resolutionInput.setText(String.valueOf(saved.targetPx));
                    pageToggle.setChecked(saved.pages);
                    detailToggle.setChecked(saved.details);
                    if (intelligentToggle != null) intelligentToggle.setChecked(saved.intelligent);
                    imageToggle.setChecked(saved.images);
                    videoToggle.setChecked(saved.videos);
                    if (xRepostToggle != null) xRepostToggle.setChecked(saved.xReposts);
                    if (xGifAsGifToggle != null) xGifAsGifToggle.setChecked(saved.xGifAsGif);
                    DiagnosticLog.log("ANALYSIS_AUTO_RESUME_BEGIN url=" + saved.sourceUrl
                            + " media=" + saved.mediaItems.size());
                    startAnalysis();
                });
            });
        } catch (Throwable t) { DiagnosticLog.logException("ANALYSIS_AUTO_RESUME_FAIL", t); }
    }

    private void mergeInstagramSessionProgress(String reason) {
        if (crawler == null) return;
        InstagramCrawlerSession igSession = instagramCrawlerSession();
        if (igSession == null) return;
        java.util.List<String> completed = igSession.getCompletedInstagramPostUrls();
        java.util.List<String> discovered = igSession.getDiscoveredInstagramPostUrls();
        int completedBefore = instagramSessionCompletedPosts.size();
        int discoveredBefore = instagramSessionDiscoveredPosts.size();
        if (discovered != null) instagramSessionDiscoveredPosts.addAll(discovered);
        if (completed != null) {
            instagramSessionCompletedPosts.addAll(completed);
            instagramSessionDiscoveredPosts.addAll(completed);
        }
        DiagnosticLog.log("IG_SESSION_PROGRESS_MERGE reason=" + reason
                + " completed=" + completedBefore + "->" + instagramSessionCompletedPosts.size()
                + " discovered=" + discoveredBefore + "->" + instagramSessionDiscoveredPosts.size());
    }

    private void stopAnalysisByUser(String source) {
        if (!analyzing || analysisStopRequested) return;
        analysisStopRequested = true;
        continuationNeededForRun = true;
        analysisWatchdogHandler.removeCallbacks(analysisWatchdog);
        analyzeButton.setText("停止中…");
        analyzeButton.setTextColor(TEXT_WHITE);
        analyzeButton.setBackground(rounded(DARK_RED, 12));
        analyzeButton.setEnabled(false);
        status.setText("停止処理中…");
        DiagnosticLog.log("ANALYZE_SAFE_STOP_REQUEST source=" + source
                + " items=" + items.size()
                + " crawler=" + (crawler == null ? "none" : crawler.progressSnapshot()));
        if (crawler != null) {
            crawler.requestGracefulStop();
        } else {
            analyzing = false;
            analysisStopRequested = false;
            analyzeClearPending = true;
            setContinuationCell(true, "manual_stop_no_crawler");
            setAnalysisRunningUi(false);
            status.setText("解析停止");
        }
    }

    private void updateForceStopButtonState() {
        if (forceStopButton == null) return;
        // A newly opened Activity can be locked by a retained (old) worker. In this
        // situation cache deletion is explicitly the recovery route, even if the
        // worker is still busy. Normal local analysis remains protected.
        boolean blockedByRetainedWorker = AnalysisKeepAliveService.hasOtherRetainedOwner(this);
        boolean busyHere = analysisPreparing || analyzing || downloading;
        boolean enabled = !cacheResetInProgress && !busyHere
                && (blockedByRetainedWorker || cacheAvailable);
        forceStopButton.setEnabled(enabled);
        forceStopButton.setAlpha(enabled ? 1f : 0.38f);
    }

    private String cacheTargetUrl() {
        String url = urlInput == null ? "" : urlInput.getText().toString().trim();
        if (!url.isEmpty()) return url;
        if (activeAnalysisUrl != null && !activeAnalysisUrl.trim().isEmpty()) return activeAnalysisUrl.trim();
        return safeText(detectedCacheUrl).trim();
    }

    private void requestCacheAvailability() {
        if (forceStopButton == null || cacheResetInProgress) return;
        // TextWatcher invokes this on every keystroke. Do not run storage parsers on
        // incomplete URL fragments or create an unbounded queue of background probes.
        cacheProbeGeneration.incrementAndGet();
        cacheProbeHandler.removeCallbacks(cacheProbeRunnable);
        cacheProbeHandler.postDelayed(cacheProbeRunnable, 350L);
    }

    private void performCacheAvailability() {
        if (forceStopButton == null || cacheResetInProgress) return;
        final int request = cacheProbeGeneration.get();
        final String url = cacheTargetUrl();
        final boolean memory = url.equals(activeAnalysisUrl) && (!items.isEmpty()
                || !snsSessionFailedMediaKeys.isEmpty() || !instagramSessionDiscoveredPosts.isEmpty());
        cacheAvailable = false;
        updateForceStopButtonState();
        try {
            cacheInspectExecutor.execute(() -> {
                try {
                    String resolved = url;
                    if (resolved.isEmpty()) {
                        AnalysisSessionStore.State previous = AnalysisSessionStore.load(getApplicationContext());
                        if (previous != null) resolved = previous.sourceUrl;
                    }
                    // Incomplete text is a valid editing state, never an exception-worthy URL.
                    boolean valid = SiteVisitStore.normalize(resolved).length() > 0;
                    boolean found = memory;
                    if (valid) {
                        found |= AnalysisSessionStore.existsForUrl(getApplicationContext(), resolved);
                        SnsResumeStore.Target target = SnsResumeStore.targetForUrl(resolved);
                        if (target != null) found |= SnsResumeStore.exists(getApplicationContext(), target);
                    }
                    if (!found) found = hasDisposableCacheFiles(getCacheDir());
                    final boolean result = found;
                    final String resolvedUrl = resolved;
                    runOnUiThread(() -> {
                        if (cacheProbeGeneration.get() != request || cacheResetInProgress) return;
                        cacheAvailable = result;
                        detectedCacheUrl = resolvedUrl;
                        updateForceStopButtonState();
                    });
                } catch (Throwable probeError) {
                    // An exception inside Executor.execute used to terminate the Android
                    // process. Catch on the worker, including previous-session lookup.
                    DiagnosticLog.logException("CACHE_PROBE_WORKER_FAIL", probeError);
                    runOnUiThread(() -> {
                        if (cacheProbeGeneration.get() != request || cacheResetInProgress) return;
                        cacheAvailable = false;
                        updateForceStopButtonState();
                    });
                }
            });
        } catch (Throwable e) { DiagnosticLog.logException("CACHE_PROBE_FAIL", e); }
    }

    private static boolean hasDisposableCacheFiles(File dir) {
        if (dir == null || !dir.isDirectory()) return false;
        File[] contents = dir.listFiles();
        if (contents == null) return false;
        for (File entry : contents) {
            if (entry.isFile()) return true;
            if (entry.isDirectory() && hasDisposableCacheFiles(entry)) return true;
        }
        return false;
    }

    private static int deleteDisposableFiles(File dir) {
        if (dir == null || !dir.isDirectory()) return 0;
        int removed = 0;
        File[] files = dir.listFiles();
        if (files == null) return removed;
        for (File file : files) {
            if (file.isDirectory()) removed += deleteDisposableFiles(file);
            if (file.delete()) removed++;
        }
        return removed;
    }

    private void resetCacheInMemory() {
        analysisWatchdogHandler.removeCallbacks(analysisWatchdog);
        resumeCheckpointHandler.removeCallbacks(resumeCheckpointRunnable);
        analysisPreparing = false;
        analysisPrepareGeneration++;
        analyzing = false;
        analysisStopRequested = false;
        downloading = false;
        continuationReloading = false;
        continuationNeededForRun = false;
        activeResumeComplete = false;
        analyzeClearPending = false;
        try { if (crawler != null) crawler.cancel(); }
        catch (Throwable t) { DiagnosticLog.logException("CACHE_CLEAR_CRAWLER_FAIL", t); }
        try { if (downloader != null) downloader.cancel(); }
        catch (Throwable t) { DiagnosticLog.logException("CACHE_CLEAR_DOWNLOAD_FAIL", t); }
        stopVideoPreview("cache_clear");
        resetSnsThumbnailSweep("cache_clear");
        if (thumbnailLoader != null) thumbnailLoader.clearCache();
        if (webView != null) {
            try { webView.stopLoading(); webView.clearCache(true); webView.clearHistory(); }
            catch (Throwable t) { DiagnosticLog.logException("CACHE_CLEAR_WEBVIEW_FAIL", t); }
        }
        modeProvider.preview().reset();
        items.clear();
        emittedItemKeys.clear();
        instagramSessionCompletedPosts.clear();
        instagramSessionDiscoveredPosts.clear();
        snsSessionSavedMediaKeys.clear();
        snsSessionFailedMediaKeys.clear();
        normalSavedMediaKeys.clear(); // Disk ledger belongs outside the disposable cache.
        normalSavedFileUris.clear();
        normalSavedTarget = "";
        activeResumeTarget = null;
        activeSnsService = null;
        detectedCacheUrl = "";
        selectionMode = false;
        selectionAnchorPosition = -1;
        setContinuationCell(false, "cache_clear");
        if (adapter != null) adapter.notifyDataSetChanged();
        updateSelectionControls();
        updateSummary();
        if (postProgress != null) postProgress.setText("");
        if (saveButton != null) {
            saveButton.setEnabled(false);
            applyButtonEnabledStyle(saveButton);
        }
        setAnalysisPreparingUi(false);
        setAnalysisRunningUi(false);
        AnalysisKeepAliveService.releaseOwner(this);
    }

    private void deleteAnalysisCache() {
        if (cacheResetInProgress || analysisPreparing || analyzing || downloading) return;
        AnalysisKeepAliveService.RetainedWorkOwner retained = AnalysisKeepAliveService.getActiveOwner();
        MainActivity worker = retained instanceof MainActivity && retained != this
                ? (MainActivity) retained : null;
        if (!cacheAvailable && worker == null) return;
        final String url = worker != null && worker.activeAnalysisUrl != null
                && !worker.activeAnalysisUrl.trim().isEmpty()
                ? worker.activeAnalysisUrl.trim() : cacheTargetUrl();
        final SnsResumeStore.Target target = SnsResumeStore.targetForUrl(url);
        final java.util.LinkedHashSet<String> memorySavedKeys = new java.util.LinkedHashSet<>(snsSessionSavedMediaKeys);
        if (worker != null) memorySavedKeys.addAll(worker.snsSessionSavedMediaKeys);
        cacheResetInProgress = true;
        cacheResetEpoch++;
        cacheProbeGeneration.incrementAndGet();
        DiagnosticLog.log("CACHE_CLEAR_BEGIN url=" + url + " retainedWorker=" + (worker != null)
                + " savedInMemory=" + memorySavedKeys.size());
        if (worker != null) {
            worker.cacheResetInProgress = true;
            worker.cacheResetEpoch++;
            worker.forceStopAll("cache_clear_retained_worker");
            worker.resetCacheInMemory();
            mirrorHandler.removeCallbacks(mirrorPoll);
            mirroredWorkOwner = null;
        }
        resetCacheInMemory();
        status.setText("キャッシュ削除中…");
        updateForceStopButtonState();
        try {
            // This work must run after both the retained worker's pending writes AND
            // this Activity's own queued writes. Neither queue can resurrect a cleared
            // checkpoint after the deletion barrier.
            Runnable performDeletion = () -> {
                boolean externalBefore = target != null && SnsResumeStore.exists(getApplicationContext(), target);
                boolean internalBefore = AnalysisSessionStore.existsForUrl(getApplicationContext(), url);
                SnsResumeStore.State oldState = externalBefore
                        ? SnsResumeStore.load(getApplicationContext(), target) : null;
                boolean safeToClear = !externalBefore || oldState != null;
                java.util.LinkedHashSet<String> savedKeys = new java.util.LinkedHashSet<>(memorySavedKeys);
                if (target != null) {
                    savedKeys.addAll(SnsSavedLedgerStore.load(getApplicationContext(), target));
                    if (oldState != null) savedKeys.addAll(oldState.savedMediaKeys);
                    // Save success records are not disposable cache. If the legacy JSON is
                    // unreadable, or the new ledger fails to commit, keep old JSON intact.
                    if (safeToClear && (!savedKeys.isEmpty() || externalBefore)) {
                        boolean ledgerCommitted = SnsSavedLedgerStore.save(getApplicationContext(), target, savedKeys);
                        safeToClear = ledgerCommitted;
                        DiagnosticLog.log("CACHE_CLEAR_LEDGER_MIGRATION ok=" + ledgerCommitted
                                + " saved=" + savedKeys.size());
                    }
                }
                boolean external = false;
                boolean internal = false;
                int tempFiles = 0;
                if (safeToClear) {
                    if (externalBefore) external = SnsResumeStore.delete(getApplicationContext(), target);
                    if (internalBefore) internal = AnalysisSessionStore.deleteForUrl(getApplicationContext(), url);
                    tempFiles = deleteDisposableFiles(getCacheDir());
                }
                boolean externalClean = target == null || !SnsResumeStore.exists(getApplicationContext(), target);
                boolean internalClean = !AnalysisSessionStore.existsForUrl(getApplicationContext(), url);
                final boolean success = safeToClear && externalClean && internalClean;
                DiagnosticLog.log("CACHE_CLEAR_RESULT success=" + success + " safe=" + safeToClear
                        + " savedPreserved=" + savedKeys.size()
                        + " externalBefore=" + externalBefore + " externalDeleted=" + external
                        + " externalClean=" + externalClean + " internalBefore=" + internalBefore
                        + " internalDeleted=" + internal + " internalClean=" + internalClean
                        + " tempEntries=" + tempFiles + " url=" + url);
                runOnUiThread(() -> {
                    cacheResetInProgress = false;
                    if (worker != null) worker.cacheResetInProgress = false;
                    forceStopInProgress = false;
                    cacheAvailable = false;
                    status.setText(success ? "キャッシュ削除完了・再解析できます" : "キャッシュ削除に失敗（診断ログを確認）");
                    refreshAnalyzeButtonIdleState();
                    updateForceStopButtonState();
                    requestCacheAvailability();
                });
            };
            if (worker != null) {
                worker.resumeIoExecutor.execute(() -> {
                    try { resumeIoExecutor.execute(performDeletion); }
                    catch (Throwable enqueueError) {
                        DiagnosticLog.logException("CACHE_CLEAR_HANDOFF_FAIL", enqueueError);
                        performDeletion.run();
                    }
                });
            } else {
                resumeIoExecutor.execute(performDeletion);
            }
        } catch (Throwable t) {
            cacheResetInProgress = false;
            if (worker != null) worker.cacheResetInProgress = false;
            DiagnosticLog.logException("CACHE_CLEAR_QUEUE_FAIL", t);
            status.setText("キャッシュ削除に失敗");
            requestCacheAvailability();
        }
    }

    private void forceStopAll(String source) {
        if (mirroredWorkOwner != null && mirroredWorkOwner.hasActiveKeepAliveWork()) {
            mirroredWorkOwner.forceStopAll("attached_" + source);
            return;
        }
        if (!source.startsWith("cache_clear") && (analyzing || analysisPreparing || downloading))
            writeInternalCheckpoint(true, "force_stop");
        boolean active = analysisPreparing || analyzing || downloading || hasActiveKeepAliveWork();
        if (!active) {
            DiagnosticLog.log("FORCE_STOP_IGNORED source=" + source + " reason=no_active_work");
            Toast.makeText(this, "停止中の処理はありません", Toast.LENGTH_SHORT).show();
            updateForceStopButtonState();
            return;
        }

        forceStopInProgress = true;
        DiagnosticLog.log("FORCE_STOP_BEGIN source=" + source
                + " preparing=" + analysisPreparing
                + " analyzing=" + analyzing
                + " downloading=" + downloading
                + " items=" + items.size());

        analysisWatchdogHandler.removeCallbacks(analysisWatchdog);
        analysisPreparing = false;
        analysisPrepareGeneration++;
        analyzing = false;
        analysisStopRequested = false;
        downloading = false;
        continuationReloading = false;
        continuationNeededForRun = false;
        activeResumeComplete = false;
        taskRemovedKeepAlive = false;
        crawlerPausedByForegroundPolicy = false;

        try { if (crawler != null) crawler.cancel(); }
        catch (Throwable t) { DiagnosticLog.logException("FORCE_STOP_CRAWLER_FAIL", t); }
        try { if (downloader != null) downloader.cancel(); }
        catch (Throwable t) { DiagnosticLog.logException("FORCE_STOP_DOWNLOADER_FAIL", t); }
        try { if (thumbnailLoader != null) thumbnailLoader.cancelPending(); }
        catch (Throwable t) { DiagnosticLog.logException("FORCE_STOP_THUMB_FAIL", t); }
        stopVideoPreview("force_stop");
        resetSnsThumbnailSweep("force_stop");
        resumeCheckpointHandler.removeCallbacks(resumeCheckpointRunnable);
        try {
            if (webView != null) {
                webView.stopLoading();
                webView.onResume();
                webView.resumeTimers();
            }
        } catch (Throwable t) {
            DiagnosticLog.logException("FORCE_STOP_WEBVIEW_FAIL", t);
        }

        setContinuationCell(false, "force_stop");
        analyzeClearPending = false;
        setAnalysisPreparingUi(false);
        setAnalysisRunningUi(false);
        if (postProgress != null) postProgress.setText("");
        status.setText("強制停止（受信済みデータを保持）");
        saveButton.setEnabled(countSelectedPendingSave() > 0);
        applyButtonEnabledStyle(saveButton);
        updateSummary();

        AnalysisKeepAliveService.releaseOwner(this);
        try { stopService(new Intent(this, AnalysisKeepAliveService.class)); }
        catch (Throwable t) { DiagnosticLog.logException("FORCE_STOP_SERVICE_FAIL", t); }
        updateForceStopButtonState();
        DiagnosticLog.log("FORCE_STOP_DONE source=" + source + " items=" + items.size());
    }

    private void setContinuationCell(boolean visible, String reason) {
        if (visible && (!isResumeEnabled() || (activeSnsService == null
                && activeCrawlerMode != AnalysisModeRouter.Mode.NORMAL))) visible = false;
        boolean changed = continuationCellVisible != visible || (visible && !safeText(reason).equals(continuationReason));
        continuationCellVisible = visible;
        if (visible) continuationReason = safeText(reason);
        else continuationReason = "";
        if (changed) {
            DiagnosticLog.log("CONTINUE_CELL visible=" + visible + " reason=" + safeText(reason)
                    + " items=" + items.size() + " reloading=" + continuationReloading);
            if (adapter != null) adapter.notifyDataSetChanged();
        }
    }

    private static String safeText(String value) {
        return value == null ? "" : value;
    }

    private void startContinuationFromReloadCell() {
        if (!continuationCellVisible || downloading) return;
        String url = activeAnalysisUrl == null || activeAnalysisUrl.trim().isEmpty()
                ? urlInput.getText().toString().trim() : activeAnalysisUrl.trim();
        if (url.isEmpty()) return;
        int targetPx = activeAnalysisTargetPx > 0 ? activeAnalysisTargetPx : getTargetResolution();
        if (targetPx < 0) return;

        DiagnosticLog.log("CONTINUE_RELOAD_START reason=" + continuationReason
                + " url=" + url + " existingItems=" + items.size());
        continuationNeededForRun = false;
        mergeInstagramSessionProgress("continue_reload_before_cancel");
        // The "続きを再読込" path previously seeded only media, silently restarting
        // X search at the first page. Carry the executable crawl cursor as well.
        final org.json.JSONObject resumeCursor = normalCrawlerSession() != null ? normalCrawlerSession().checkpointCursor()
                : xCrawlerSession() == null ? null : xCrawlerSession().checkpointCursor();
        DiagnosticLog.log("CONTINUE_RELOAD_CURSOR captured=" + (resumeCursor != null)
                + " current=" + (resumeCursor == null ? "" : resumeCursor.optString("current", "")));
        if (crawler != null) crawler.cancel();
        stopVideoPreview("continue_reload");
        resetSnsThumbnailSweep("continue_reload");
        if (thumbnailLoader != null) thumbnailLoader.cancelPending();
        activeAnalysisUrl = url;
        activeAnalysisTargetPx = targetPx;
        prepareSnsAnalysis(url);
        activeResumeTarget = SnsResumeStore.targetForUrl(url);
        if (crawler == null) return;
        if (xCrawlerSession() != null) xCrawlerSession().setIncludeXReposts(xRepostToggle != null && xRepostToggle.isChecked());
        crawler.seedContinuationResults(items);
        if (resumeCursor != null && normalCrawlerSession() != null) normalCrawlerSession().seedQueueCursor(resumeCursor);
        if (resumeCursor != null && xCrawlerSession() != null) xCrawlerSession().seedQueueCursor(resumeCursor);
        if (instagramCrawlerSession() != null) instagramCrawlerSession().seedInstagramContinuationState(instagramSessionCompletedPosts, instagramSessionDiscoveredPosts);
        DiagnosticLog.log("CONTINUE_RELOAD_IG_SESSION completed=" + instagramSessionCompletedPosts.size()
                + " discovered=" + instagramSessionDiscoveredPosts.size());
        continuationReloading = true;
        activeResumeComplete = false;
        interruptionSuspected = false;
        analyzeClearPending = false;
        analyzing = true;
        analysisStopRequested = false;
        status.setText("続きから再読込");
        setAnalysisRunningUi(true);
        syncBackgroundAnalysisService("continue_reload");
        markAnalysisProgress("continue_reload");
        adapter.notifyDataSetChanged();
        crawler.start(url, pageToggle.isChecked(), detailToggle.isChecked(), intelligentToggle.isChecked(),
                imageToggle.isChecked(), videoToggle.isChecked(), targetPx);
    }

    private void startDownload() {
        if (downloading) return;
        forceStopInProgress = false;
        int selected = countSelectedDownloadable();
        if (selected == 0) {
            Toast.makeText(this, "保存する画像・動画を選択してください", Toast.LENGTH_SHORT).show();
            return;
        }

        // Build an immutable queue before starting worker threads. For SNS targets, the sidecar
        // ledger is authoritative: media successfully saved in an earlier run are not queued again.
        final ArrayList<MediaItem> downloadItems = new ArrayList<>();
        final HashSet<String> queuedKeys = new HashSet<>();
        int skippedSaved = 0;
        int skippedQueueDuplicate = 0;
        for (MediaItem item : items) {
            if (item == null || !item.selected || item.kind == MediaItem.Kind.STREAM) continue;
            String key = SnsResumeStore.savedMediaKey(item);
            if (isAlreadySavedForActiveSns(item)) {
                skippedSaved++;
                DiagnosticLog.log("DOWNLOAD_SAVED_SKIP key=" + key + " kind=" + item.kind + " url=" + item.url);
                continue;
            }
            if (!key.isEmpty() && !queuedKeys.add(key)) {
                skippedQueueDuplicate++;
                DiagnosticLog.log("DOWNLOAD_QUEUE_DUPLICATE_SKIP key=" + key + " kind=" + item.kind + " url=" + item.url);
                continue;
            }
            downloadItems.add(item);
        }
        final int skippedAlreadySaved = skippedSaved;
        final int skippedDuplicate = skippedQueueDuplicate;
        if (downloadItems.isEmpty()) {
            DiagnosticLog.log("DOWNLOAD_ALL_ALREADY_SAVED selected=" + selected
                    + " savedSkip=" + skippedAlreadySaved + " duplicateSkip=" + skippedDuplicate);
            status.setText("保存済み  " + skippedAlreadySaved + "件をスキップ");
            Toast.makeText(this, "選択したメディアは保存済みです", Toast.LENGTH_SHORT).show();
            saveButton.setEnabled(false);
            applyButtonEnabledStyle(saveButton);
            return;
        }

        stopVideoPreview("download_start");
        if (analyzing) {
            crawler.cancel();
            analyzing = false;
            syncBackgroundAnalysisService("download_start");
            setAnalysisRunningUi(false);
            DiagnosticLog.log("ANALYZE_CANCEL_FOR_DOWNLOAD selected=" + selected);
            if ("ImgStalker".equals(pageTitle)) {
                String host = hostFromUrl(urlInput.getText().toString());
                if (host != null && !host.trim().isEmpty()) pageTitle = host;
            }
        }
        downloading = true;
        syncBackgroundAnalysisService("download_start_active");
        DiagnosticLog.log("DOWNLOAD_START selected=" + selected
                + " queued=" + downloadItems.size()
                + " savedSkip=" + skippedAlreadySaved
                + " duplicateSkip=" + skippedDuplicate
                + " title=" + pageTitle
                + " xGifAsGif=" + (xGifAsGifToggle == null || xGifAsGifToggle.isChecked()));
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        status.setText("保存開始  " + downloadItems.size() + "ファイル"
                + (skippedAlreadySaved > 0 ? "（保存済み " + skippedAlreadySaved + "件除外）" : ""));
        final AnalysisModeRouter.Mode downloadMode = AnalysisModeRouter.fromUrl(activeAnalysisUrl);
        final String downloadNormalUrl = downloadMode == AnalysisModeRouter.Mode.NORMAL
                ? activeAnalysisUrl : "";
        final String downloadNormalTarget = NormalSavedLedgerStore.key(downloadNormalUrl);
        showDetectedModeBadge(downloadMode);
        final long downloadEpoch = crawlerGeneration;
        NormalSavedLocationListener saveListener = new NormalSavedLocationListener() {
            @Override public void onProgress(int done, int total, String message) {
                runOnUiThread(() -> {
                    if (downloadEpoch != crawlerGeneration || downloadMode != activeCrawlerMode) return;
                    status.setText("保存中  " + done + " / " + total
                            + (skippedAlreadySaved > 0 ? "  保存済み除外 " + skippedAlreadySaved : ""));
                });
            }

            @Override public void onNormalSavedAtUri(MediaItem item, long bytes, String contentUri) {
                runOnUiThread(() -> {
                    if (downloadEpoch != crawlerGeneration || downloadMode != activeCrawlerMode) return;
                    if (downloadMode != AnalysisModeRouter.Mode.NORMAL || item == null) return;
                    if (downloadNormalTarget.isEmpty() || !downloadNormalTarget.equals(normalSavedTarget)) {
                        DiagnosticLog.log("NORMAL_SAVED_MARK_REFUSED wrong_target=" + downloadNormalTarget);
                        return;
                    }
                    String key = NormalSavedLedgerStore.mediaKey(item);
                    if (key.isEmpty() || contentUri == null || !contentUri.startsWith("content://")) {
                        DiagnosticLog.log("NORMAL_SAVED_MARK_REFUSED missing_content_uri=" + key);
                        return;
                    }
                    normalSavedFileUris.put(key, contentUri);
                    normalSavedMediaKeys.add(key);
                    for (MediaItem candidate : items) {
                        if (candidate != null && key.equals(NormalSavedLedgerStore.mediaKey(candidate)))
                            candidate.selected = false;
                    }
                    DiagnosticLog.log("NORMAL_SAVED_MEDIA_MARK target=" + downloadNormalTarget
                            + " key=" + key + " kind=" + item.kind + " bytes=" + bytes);
                    persistNormalSavedLedger(downloadNormalUrl, "download_saved");
                    if (adapter != null) adapter.notifyDataSetChanged();
                    updateSummary();
                });
            }

            @Override public void onSaved(MediaItem item, long bytes) {
                runOnUiThread(() -> {
                    if (downloadEpoch != crawlerGeneration || downloadMode != activeCrawlerMode) return;
                    if (downloadMode == AnalysisModeRouter.Mode.NORMAL) {
                        // NORMAL cannot claim success without a verifiable file URI.
                        DiagnosticLog.log("NORMAL_SAVED_MARK_REFUSED callback_without_uri");
                        return;
                    }
                    if (item == null) return;
                    String key = SnsResumeStore.savedMediaKey(item);
                    if (key.isEmpty()) return;
                    boolean changed = false;
                    if (snsSessionFailedMediaKeys.remove(key)) changed = true;
                    if (snsSessionSavedMediaKeys.add(key)) changed = true;
                    // A successful save immediately makes every matching cell non-selectable.
                    for (MediaItem candidate : items) {
                        if (candidate != null && key.equals(SnsResumeStore.savedMediaKey(candidate))) {
                            candidate.selected = false;
                        }
                    }
                    DiagnosticLog.log("SNS_SAVED_MEDIA_MARK key=" + key
                            + " kind=" + item.kind + " bytes=" + bytes
                            + " saved=" + snsSessionSavedMediaKeys.size()
                            + " failed=" + snsSessionFailedMediaKeys.size());
                    if (activeResumeTarget != null && changed) {
                        persistSavedLedger("download_saved");
                        if (isResumeEnabled()) writeResumeCheckpoint(activeResumeComplete, "download_saved");
                    }
                    if (adapter != null) adapter.notifyDataSetChanged();
                    updateSummary();
                });
            }

            @Override public void onFailed(MediaItem item, String reason) {
                runOnUiThread(() -> {
                    if (downloadEpoch != crawlerGeneration || downloadMode != activeCrawlerMode) return;
                    if (downloadMode == AnalysisModeRouter.Mode.NORMAL) {
                        DiagnosticLog.log("NORMAL_MEDIA_SAVE_FAILED reason=" + safeText(reason));
                        return;
                    }
                    if (item == null) return;
                    String key = SnsResumeStore.savedMediaKey(item);
                    if (key.isEmpty() || snsSessionSavedMediaKeys.contains(key)) return;
                    if (snsSessionFailedMediaKeys.add(key)) {
                        DiagnosticLog.log("SNS_FAILED_MEDIA_MARK key=" + key
                                + " kind=" + item.kind + " reason=" + safeText(reason)
                                + " failed=" + snsSessionFailedMediaKeys.size());
                        if (isResumeEnabled() && activeResumeTarget != null) {
                            writeResumeCheckpoint(activeResumeComplete, "download_failed");
                        }
                    }
                    if (adapter != null) adapter.notifyDataSetChanged();
                    updateSummary();
                });
            }

            @Override public void onFinished(String folderName, int success, int failed) {
                runOnUiThread(() -> {
                    if (downloadEpoch != crawlerGeneration || downloadMode != activeCrawlerMode) return;
                    if (forceStopInProgress) {
                        DiagnosticLog.log("DOWNLOAD_DONE_IGNORED reason=force_stop success=" + success + " failed=" + failed);
                        return;
                    }
                    downloading = false;
                    if (isResumeEnabled() && activeResumeTarget != null && (success > 0 || failed > 0)) {
                        writeResumeCheckpoint(activeResumeComplete, "download_complete");
                    }
                    syncBackgroundAnalysisService("download_done");
                    DiagnosticLog.log("DOWNLOAD_DONE folder=" + folderName
                            + " success=" + success + " failed=" + failed
                            + " savedSkip=" + skippedAlreadySaved
                            + " duplicateSkip=" + skippedDuplicate);
                    saveButton.setEnabled(countSelectedPendingSave() > 0);
                    applyButtonEnabledStyle(saveButton);
                    if (folderName.isEmpty()) {
                        status.setText("保存対象がありません");
                    } else {
                        File saveBase = SavePrefs.directory(MainActivity.this);
                        status.setText("保存完了  " + success + "件 / 失敗 " + failed + "件"
                                + (skippedAlreadySaved > 0 ? " / 保存済み除外 " + skippedAlreadySaved + "件" : "")
                                + "  " + new File(saveBase, folderName).getAbsolutePath());
                    }
                });
            }
        };
        // Downloading the currently displayed scan must use that scan's own provider.
        // CDN domains on media items are NOT allowed to select a different scan provider.
        if (downloadMode != activeCrawlerMode || modeProvider.mode() != downloadMode) {
            DiagnosticLog.log("MODE_DOWNLOAD_REFUSED expected=" + activeCrawlerMode + " actual=" + downloadMode);
            downloading = false;
            syncBackgroundAnalysisService("download_provider_mismatch");
            status.setText("保存元のモードが変わりました。再解析してください");
            return;
        }
        downloader = modeProvider.downloader(this,
                downloadMode == AnalysisModeRouter.Mode.X && (xGifAsGifToggle == null || xGifAsGifToggle.isChecked()),
                saveListener);
        DiagnosticLog.log("MODE_DOWNLOADER_CREATED mode=" + downloadMode);
        String downloadSourceUrl = activeAnalysisUrl == null || activeAnalysisUrl.trim().isEmpty()
                ? urlInput.getText().toString().trim() : activeAnalysisUrl.trim();
        String downloadCategory = downloadCategoryForUrl(downloadSourceUrl);
        SnsResumeStore.Target downloadTarget = SnsResumeStore.targetForUrl(downloadSourceUrl);
        // NORMAL owns a stable per-site folder; pass the SCANNED URL rather than
        // a media item's CDN hostname or an SNS account. Keep both SNS branches
        // identical to their pre-existing account/category selection.
        String downloadAccount = downloadMode == AnalysisModeRouter.Mode.NORMAL
                ? downloadSourceUrl
                : (downloadTarget == null ? "" : downloadTarget.accountName);
        downloader.download(downloadItems, pageTitle, downloadCategory, downloadAccount);
    }

    private String downloadCategoryForUrl(String url) {
        String host = hostFromUrl(url);
        if (host == null) return "";
        String h = host.toLowerCase(java.util.Locale.ROOT);
        if (h.equals("instagram.com") || h.endsWith(".instagram.com")) return "Instagram";
        if (h.equals("x.com") || h.endsWith(".x.com")
                || h.equals("twitter.com") || h.endsWith(".twitter.com")) return "X";
        return "";
    }

    private void cancelCurrent() {
        if (selectionMode) {
            exitSelectionMode(true, "cancel_button");
            return;
        }
        if (analyzing) {
            stopAnalysisByUser("cancel_button");
            return;
        }
        if (downloading && downloader != null) {
            downloader.cancel();
            DiagnosticLog.log("DOWNLOAD_CANCEL");
            downloading = false;
            syncBackgroundAnalysisService("download_cancel");
            status.setText("保存をキャンセル");
            saveButton.setEnabled(countSelectedPendingSave() > 0);
            applyButtonEnabledStyle(saveButton);
            return;
        }
        clearAnalysisCells();
    }

    private void handleSelectionButton() {
        if (!selectionMode) {
            enterSelectionMode();
            return;
        }
        if (areAllDownloadableSelected()) {
            exitSelectionMode(true, "select_all_toggle_clear");
            return;
        }
        selectAllDownloadable();
    }

    private void enterSelectionMode() {
        if (selectionMode) return;
        stopVideoPreview("selection_mode");
        selectionMode = true;
        selectionAnchorPosition = -1;
        DiagnosticLog.log("SELECTION_MODE_ENTER");
        updateSelectionControls();
        adapter.notifyDataSetChanged();
    }

    private void exitSelectionMode(boolean clearSelection, String reason) {
        stopVideoPreview("selection_exit_" + reason);
        if (clearSelection) {
            for (MediaItem i : items) {
                if (i.kind != MediaItem.Kind.STREAM) i.selected = false;
            }
        }
        boolean wasSelectionMode = selectionMode;
        selectionMode = false;
        selectionAnchorPosition = -1;
        if (wasSelectionMode) {
            DiagnosticLog.log("SELECTION_MODE_EXIT reason=" + reason + " clear=" + clearSelection);
        }
        updateSelectionControls();
        adapter.notifyDataSetChanged();
        updateSummary();
    }

    private void selectAllDownloadable() {
        int changed = 0;
        for (MediaItem i : items) {
            if (i.kind != MediaItem.Kind.STREAM && !isAlreadySavedForActiveSns(i) && !i.selected) {
                i.selected = true;
                changed++;
            }
        }
        DiagnosticLog.log("SELECT_ALL changed=" + changed + " count=" + countSelectedDownloadable());
        adapter.notifyDataSetChanged();
        updateSummary();
    }

    private void toggleSelectionAt(int position) {
        if (position < 0 || position >= items.size()) return;
        MediaItem item = items.get(position);
        if (item.kind == MediaItem.Kind.STREAM) return;
        if (isAlreadySavedForActiveSns(item)) {
            item.selected = false;
            DiagnosticLog.log("ITEM_SELECT_BLOCKED_SAVED position=" + position + " url=" + item.url);
            if (adapter != null) adapter.notifyDataSetChanged();
            updateSummary();
            return;
        }

        item.selected = !item.selected;
        if (item.selected) {
            selectionAnchorPosition = position;
        } else if (selectionAnchorPosition == position) {
            selectionAnchorPosition = -1;
        }
        DiagnosticLog.log("ITEM_SELECT position=" + position + " selected=" + item.selected
                + " kind=" + item.kind + " url=" + item.url);
        adapter.notifyDataSetChanged();
        updateSummary();

        if (selectionMode && countSelectedDownloadable() == 0) {
            exitSelectionMode(false, "all_deselected_by_tap");
        }
    }

    private void enterSelectionModeWithItem(int position) {
        if (position < 0 || position >= items.size()) return;
        MediaItem item = items.get(position);
        if (item.kind == MediaItem.Kind.STREAM) return;
        if (isAlreadySavedForActiveSns(item)) {
            item.selected = false;
            DiagnosticLog.log("ITEM_LONG_SELECT_BLOCKED_SAVED position=" + position + " url=" + item.url);
            if (adapter != null) adapter.notifyDataSetChanged();
            return;
        }
        if (!selectionMode) {
            stopVideoPreview("selection_long_press");
            selectionMode = true;
            DiagnosticLog.log("SELECTION_MODE_ENTER source=long_press position=" + position);
        }
        item.selected = true;
        selectionAnchorPosition = position;
        updateSelectionControls();
        adapter.notifyDataSetChanged();
        updateSummary();
    }

    private boolean selectRangeFromAnchor(int position) {
        if (!selectionMode || selectionAnchorPosition < 0 || position < 0 || position >= items.size()) {
            return false;
        }
        int anchor = selectionAnchorPosition;
        if (anchor == position || anchor >= items.size()) return false;
        MediaItem anchorItem = items.get(anchor);
        if (anchorItem.kind == MediaItem.Kind.STREAM || !anchorItem.selected) return false;

        int from = Math.min(anchor, position);
        int to = Math.max(anchor, position);
        for (int i = from + 1; i < to; i++) {
            MediaItem middle = items.get(i);
            if (middle.kind != MediaItem.Kind.STREAM && !isAlreadySavedForActiveSns(middle) && middle.selected) {
                DiagnosticLog.log("RANGE_SELECT_SKIP anchor=" + anchor + " target=" + position
                        + " reason=middle_selected position=" + i);
                return false;
            }
        }

        int selectedCount = 0;
        for (int i = from; i <= to; i++) {
            MediaItem candidate = items.get(i);
            if (candidate.kind != MediaItem.Kind.STREAM && !isAlreadySavedForActiveSns(candidate)) {
                candidate.selected = true;
                selectedCount++;
            }
        }
        selectionAnchorPosition = position;
        DiagnosticLog.log("RANGE_SELECT anchor=" + anchor + " target=" + position
                + " range=" + from + "-" + to + " selected=" + selectedCount);
        adapter.notifyDataSetChanged();
        updateSummary();
        return true;
    }

    private boolean areAllDownloadableSelected() {
        int selectable = 0;
        int selected = 0;
        for (MediaItem i : items) {
            if (i.kind == MediaItem.Kind.STREAM || isAlreadySavedForActiveSns(i)) continue;
            selectable++;
            if (i.selected) selected++;
        }
        return selectable > 0 && selected == selectable;
    }

    private void updateSelectionControls() {
        if (selectAllButton != null) {
            if (!selectionMode) {
                selectAllButton.setText("選択");
            } else {
                selectAllButton.setText(areAllDownloadableSelected() ? "全解除" : "全選択");
            }
        }
    }

    private void updateSummary() {
        int images = 0, videos = 0, streams = 0;
        int selectable = 0, selected = 0;
        for (MediaItem i : items) {
            if (i.kind == MediaItem.Kind.IMAGE) images++;
            else if (i.kind == MediaItem.Kind.VIDEO) videos++;
            else streams++;
            if (i.kind != MediaItem.Kind.STREAM && !isAlreadySavedForActiveSns(i)) {
                selectable++;
                if (i.selected) selected++;
            }
        }
        summary.setText("画像 " + images + "  動画 " + videos + "  ストリーム " + streams + "  選択 " + selected);
        updateSelectionControls();
        if (!downloading) {
            saveButton.setEnabled(countSelectedPendingSave() > 0);
            applyButtonEnabledStyle(saveButton);
        }
    }

    private int countSelectedDownloadable() {
        int n = 0;
        for (MediaItem i : items) {
            if (i.selected && i.kind != MediaItem.Kind.STREAM && !isAlreadySavedForActiveSns(i)) n++;
        }
        return n;
    }

    private boolean isAlreadySavedForActiveSns(MediaItem item) {
        if (item == null) return false;
        if (activeCrawlerMode == AnalysisModeRouter.Mode.NORMAL
                && AnalysisModeRouter.fromUrl(activeAnalysisUrl) == AnalysisModeRouter.Mode.NORMAL) {
            String target = NormalSavedLedgerStore.key(activeAnalysisUrl);
            if (target.isEmpty() || !target.equals(normalSavedTarget)) return false;
            String key = NormalSavedLedgerStore.mediaKey(item);
            return !key.isEmpty() && normalSavedMediaKeys.contains(key);
        }
        // The existing X/Instagram success path remains unchanged.
        if (activeResumeTarget == null) return false;
        String key = SnsResumeStore.savedMediaKey(item);
        return !key.isEmpty() && snsSessionSavedMediaKeys.contains(key);
    }

    private boolean isFailedForActiveSns(MediaItem item) {
        if (activeResumeTarget == null || item == null) return false;
        String key = SnsResumeStore.savedMediaKey(item);
        return !key.isEmpty() && !snsSessionSavedMediaKeys.contains(key)
                && snsSessionFailedMediaKeys.contains(key);
    }

    private int countSelectedPendingSave() {
        int n = 0;
        for (MediaItem item : items) {
            if (item == null || !item.selected || item.kind == MediaItem.Kind.STREAM) continue;
            if (!isAlreadySavedForActiveSns(item)) n++;
        }
        return n;
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (sharedText != null) {
                String url = firstHttpUrl(sharedText);
                if (!url.isEmpty()) {
                    urlInput.setText(url);
                    DiagnosticLog.log("SHARE_URL " + url);
                }
            }
        }
    }

    private static String firstHttpUrl(String value) {
        if (value == null) return "";
        for (String p : value.split("\\s+")) if (p.startsWith("http://") || p.startsWith("https://")) return p;
        return "";
    }

    private static String hostFromUrl(String value) {
        try {
            String x = value.trim();
            if (!x.matches("(?i)^https?://.*")) x = "https://" + x;
            String h = new URI(x).getHost();
            return h == null ? "WebMedia" : h;
        } catch (Exception e) {
            return "WebMedia";
        }
    }

    private void toggleSettingsPanel() {
        setSettingsExpanded(!settingsExpanded, true);
    }

    private void setSettingsExpanded(boolean expanded, boolean animate) {
        if (settingsPanel == null) return;
        if (settingsAnimator != null) {
            settingsAnimator.cancel();
            settingsAnimator = null;
        }
        settingsExpanded = expanded;

        if (!animate) {
            ViewGroup.LayoutParams lp = settingsPanel.getLayoutParams();
            lp.height = expanded ? ViewGroup.LayoutParams.WRAP_CONTENT : 0;
            settingsPanel.setLayoutParams(lp);
            settingsPanel.setAlpha(expanded ? 1f : 0f);
            settingsPanel.setTranslationY(0f);
            settingsPanel.setVisibility(expanded ? View.VISIBLE : View.GONE);
            return;
        }

        if (expanded) {
            settingsPanel.setVisibility(View.VISIBLE);
            settingsPanel.setAlpha(0f);
            settingsPanel.setTranslationY(-dp(18));
            int width = settingsPanel.getWidth();
            if (width <= 0 && settingsPanel.getParent() instanceof View) {
                width = ((View) settingsPanel.getParent()).getWidth();
            }
            int widthSpec = View.MeasureSpec.makeMeasureSpec(Math.max(1, width), View.MeasureSpec.EXACTLY);
            int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            ViewGroup.LayoutParams lp = settingsPanel.getLayoutParams();
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            settingsPanel.setLayoutParams(lp);
            settingsPanel.measure(widthSpec, heightSpec);
            final int targetHeight = settingsPanel.getMeasuredHeight();
            lp.height = 0;
            settingsPanel.setLayoutParams(lp);

            settingsAnimator = ValueAnimator.ofInt(0, targetHeight);
            settingsAnimator.setDuration(190L);
            settingsAnimator.addUpdateListener(a -> {
                float f = a.getAnimatedFraction();
                ViewGroup.LayoutParams p = settingsPanel.getLayoutParams();
                p.height = (Integer) a.getAnimatedValue();
                settingsPanel.setLayoutParams(p);
                settingsPanel.setAlpha(f);
                settingsPanel.setTranslationY(-dp(18) * (1f - f));
            });
            settingsAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    ViewGroup.LayoutParams p = settingsPanel.getLayoutParams();
                    p.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    settingsPanel.setLayoutParams(p);
                    settingsPanel.setAlpha(1f);
                    settingsPanel.setTranslationY(0f);
                    settingsAnimator = null;
                    DiagnosticLog.log("SETTINGS_EXPAND");
                }
            });
            settingsAnimator.start();
        } else {
            final int startHeight = settingsPanel.getHeight();
            if (startHeight <= 0) {
                settingsPanel.setVisibility(View.GONE);
                return;
            }
            settingsAnimator = ValueAnimator.ofInt(startHeight, 0);
            settingsAnimator.setDuration(170L);
            settingsAnimator.addUpdateListener(a -> {
                float f = a.getAnimatedFraction();
                ViewGroup.LayoutParams p = settingsPanel.getLayoutParams();
                p.height = (Integer) a.getAnimatedValue();
                settingsPanel.setLayoutParams(p);
                settingsPanel.setAlpha(1f - f);
                settingsPanel.setTranslationY(-dp(18) * f);
            });
            settingsAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    settingsPanel.setVisibility(View.GONE);
                    settingsPanel.setAlpha(0f);
                    settingsPanel.setTranslationY(0f);
                    ViewGroup.LayoutParams p = settingsPanel.getLayoutParams();
                    p.height = 0;
                    settingsPanel.setLayoutParams(p);
                    settingsAnimator = null;
                    DiagnosticLog.log("SETTINGS_COLLAPSE");
                }
            });
            settingsAnimator.start();
        }
    }

    private void showDiagnosticLog() {
        DiagnosticLog.log("DIAGNOSTIC_OPEN");

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView title = text("診断ログ", 21, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        panel.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setScrollbarFadingEnabled(true);
        TextView body = text(DiagnosticLog.report(this), 11, TEXT_WHITE);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setPadding(dp(10), dp(8), dp(10), dp(8));
        body.setBackground(rounded(DARK_GRAY, 10));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(8), 0, 0);

        TextView clearAction = makeDialogAction("ログ消去");
        TextView shareAction = makeDialogAction(".txtを共有");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        shareAction.setGravity(Gravity.CENTER);
        copyAction.setGravity(Gravity.CENTER);
        closeAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);

        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(shareAction, new LinearLayout.LayoutParams(dp(108), dp(48)));
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(78), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(78), dp(48)));

        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .create();

        clearAction.setOnClickListener(v -> {
            DiagnosticLog.clear();
            body.setText(DiagnosticLog.report(this));
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        shareAction.setOnClickListener(v -> {
            try {
                File reportFile = DiagnosticLog.exportReportFile(this);
                Uri uri = Uri.parse("content://" + getPackageName() + ".diagnostic/" + Uri.encode(reportFile.getName()));
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_STREAM, uri);
                share.putExtra(Intent.EXTRA_SUBJECT, reportFile.getName());
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                share.setClipData(ClipData.newRawUri("ImgStalker diagnostic", uri));
                DiagnosticLog.log("DIAGNOSTIC_SHARE file=" + reportFile.getName() + " bytes=" + reportFile.length());
                startActivity(Intent.createChooser(share, "診断ログを共有"));
            } catch (Exception e) {
                DiagnosticLog.logException("DIAGNOSTIC_SHARE_FAIL", e);
                Toast.makeText(this, "診断ログの共有に失敗しました", Toast.LENGTH_SHORT).show();
            }
        });
        copyAction.setOnClickListener(v -> {
            String report = DiagnosticLog.report(this);
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("ImgStalker diagnostic", report));
            Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
        });
        closeAction.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(rounded(GRAY, 20));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private TextView makeDialogAction(String value) {
        TextView t = text(value, 14, TEXT_WHITE);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(dp(8), 0, dp(8), 0);
        t.setBackground(new LinkCapsuleDrawable(t, LIGHT_BLUE));
        return t;
    }

    private final class LinkCapsuleDrawable extends Drawable {
        private final TextView host;
        private final int enabledColor;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        LinkCapsuleDrawable(TextView host, int enabledColor) {
            this.host = host;
            this.enabledColor = enabledColor;
            paint.setStyle(Paint.Style.FILL);
        }

        @Override public void draw(Canvas canvas) {
            if (host == null) return;
            paint.setColor(host.isEnabled() ? enabledColor : DARK_GRAY);
            CharSequence textValue = host.getText();
            float textWidth = host.getPaint().measureText(textValue == null ? "" : textValue.toString());
            float visualWidth = Math.max(dp(24), textWidth + dp(14));
            float visualHeight = dp(26);
            android.graphics.Rect bounds = getBounds();
            float textLeft;
            int absoluteGravity = Gravity.getAbsoluteGravity(host.getGravity(), host.getLayoutDirection());
            int horizontal = absoluteGravity & Gravity.HORIZONTAL_GRAVITY_MASK;
            float contentLeft = bounds.left + host.getPaddingLeft();
            float contentRight = bounds.right - host.getPaddingRight();
            if (horizontal == Gravity.RIGHT) {
                float textRight = contentRight;
                textLeft = textRight - textWidth;
            } else if (horizontal == Gravity.CENTER_HORIZONTAL) {
                textLeft = (contentLeft + contentRight - textWidth) / 2f;
            } else {
                textLeft = contentLeft;
            }
            float left = textLeft - dp(7);
            float right = textLeft + textWidth + dp(7);
            if (left < bounds.left) {
                right += bounds.left - left;
                left = bounds.left;
            }
            if (right > bounds.right) {
                left -= right - bounds.right;
                right = bounds.right;
            }
            if (right - left < visualWidth) {
                float cx = (left + right) / 2f;
                left = Math.max(bounds.left, cx - visualWidth / 2f);
                right = Math.min(bounds.right, cx + visualWidth / 2f);
            }
            float cy = bounds.exactCenterY();
            float top = cy - visualHeight / 2f;
            float bottom = cy + visualHeight / 2f;
            canvas.drawRoundRect(left, top, right, bottom, visualHeight / 2f, visualHeight / 2f, paint);
        }

        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private void showOriginalImage(MediaItem item) {
        if (item == null || item.kind != MediaItem.Kind.IMAGE) return;
        dismissKeyboardAndFocus();
        DiagnosticLog.log("ORIGINAL_OPEN url=" + item.url + " ref=" + item.referrer);

        Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        // Keep the bottom action row clear of gesture/navigation insets while retaining a full-screen dialog.
        root.setPadding(0, 0, 0, dp(16));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottomInset = insets.getSystemWindowInsetBottom();
            v.setPadding(0, 0, 0, Math.max(dp(16), bottomInset));
            return insets;
        });
        root.setBackgroundColor(Color.BLACK);

        FrameLayout viewerFrame = new FrameLayout(this);
        viewerFrame.setBackgroundColor(Color.BLACK);
        ZoomImageView viewer = new ZoomImageView(this);
        viewer.setBackgroundColor(Color.BLACK);
        viewerFrame.addView(viewer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView loading = text("読み込み中…", 14, N_WHITE);
        loading.setGravity(Gravity.CENTER);
        viewerFrame.addView(loading, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(viewerFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.setPadding(dp(12), dp(4), dp(12), dp(4));
        TextView closeAction = makeDialogAction("閉じる");
        closeAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.addView(new Space(this), new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(closeAction, new LinearLayout.LayoutParams(dp(78), dp(48)));
        root.addView(actions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        final ExecutorService originalLoader = Executors.newSingleThreadExecutor();
        final Bitmap[] loadedBitmap = new Bitmap[1];
        final boolean[] disposed = new boolean[]{false};

        closeAction.setOnClickListener(v -> dialog.dismiss());
        dialog.setOnDismissListener(d -> {
            disposed[0] = true;
            originalLoader.shutdownNow();
            viewer.setBitmap(null);
            if (loadedBitmap[0] != null && !loadedBitmap[0].isRecycled()) {
                loadedBitmap[0].recycle();
                loadedBitmap[0] = null;
            }
        });
        dialog.setContentView(root);
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.BLACK));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        final ModeProvider imageProvider = modeProvider;
        originalLoader.submit(() -> {
            try {
                Bitmap bitmap;
                bitmap = imageProvider.original(MainActivity.this, item);
                runOnUiThread(() -> {
                    if (disposed[0] || !dialog.isShowing()) {
                        if (!bitmap.isRecycled()) bitmap.recycle();
                        return;
                    }
                    loadedBitmap[0] = bitmap;
                    loading.setVisibility(View.GONE);
                    viewer.setBitmap(bitmap);
                    DiagnosticLog.log("ORIGINAL_LOADED url=" + item.url
                            + " size=" + bitmap.getWidth() + "x" + bitmap.getHeight());
                });
            } catch (Exception e) {
                DiagnosticLog.logException("ORIGINAL_ERROR url=" + item.url, e);
                runOnUiThread(() -> {
                    if (disposed[0] || !dialog.isShowing()) return;
                    loading.setText("画像を開けませんでした");
                    Toast.makeText(MainActivity.this, "元画像を開けませんでした", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void dismissKeyboardAndFocus() {
        View focused = getCurrentFocus();
        if (urlInput != null) urlInput.clearFocus();
        if (resolutionInput != null) resolutionInput.clearFocus();
        if (focused != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        }
        View content = findViewById(android.R.id.content);
        if (content != null) {
            content.setFocusableInTouchMode(true);
            content.requestFocus();
        }
    }

    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(TEXT_WHITE);
        b.setAllCaps(false);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setElevation(0f);
        b.setStateListAnimator(null);
        b.setBackground(rounded(color, 12));
        return b;
    }

    private void applyButtonEnabledStyle(Button b) {
        if (b.isEnabled()) {
            b.setTextColor(TEXT_WHITE);
            b.setBackground(rounded(BLUE, 12));
        } else {
            b.setTextColor(N_WHITE);
            b.setBackground(rounded(GRAY, 12));
        }
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int top, int left, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(left, top, 0, bottom);
        return p;
    }

    private LinearLayout.LayoutParams cloneParams(LinearLayout.LayoutParams src, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(src.width, src.height, src.weight);
        p.setMargins(left, top, right, bottom);
        return p;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mergeInstagramSessionProgress("state_save");
        if (analyzing || continuationCellVisible) writeResumeCheckpoint(false, "state_save");
        outState.putString(STATE_URL, urlInput == null ? "" : urlInput.getText().toString());
        outState.putString(STATE_RESOLUTION, resolutionInput == null ? "640" : resolutionInput.getText().toString());
        outState.putBoolean(STATE_PAGE_TOGGLE, pageToggle != null && pageToggle.isChecked());
        outState.putBoolean(STATE_DETAIL_TOGGLE, detailToggle != null && detailToggle.isChecked());
        outState.putBoolean(STATE_INTELLIGENT_TOGGLE, intelligentToggle == null || intelligentToggle.isChecked());
        outState.putBoolean(STATE_IMAGE_TOGGLE, imageToggle != null && imageToggle.isChecked());
        outState.putBoolean(STATE_VIDEO_TOGGLE, videoToggle != null && videoToggle.isChecked());
        outState.putBoolean(STATE_BACKGROUND_ANALYSIS_TOGGLE, backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked());
        outState.putBoolean(STATE_X_REPOST_TOGGLE, xRepostToggle != null && xRepostToggle.isChecked());
        outState.putBoolean(STATE_X_GIF_AS_GIF_TOGGLE, xGifAsGifToggle == null || xGifAsGifToggle.isChecked());
        outState.putBoolean(STATE_RESUME_TOGGLE, resumeToggle == null || resumeToggle.isChecked());
        outState.putString(STATE_SNS_SEARCH_SERVICE, snsSearchInstagramRadio != null && snsSearchInstagramRadio.isChecked() ? "instagram" : "x");
        outState.putString(STATE_SNS_SEARCH_QUERY, snsSearchInput == null ? "" : snsSearchInput.getText().toString());
        outState.putBoolean(STATE_SETTINGS_EXPANDED, settingsExpanded);
        outState.putString(STATE_PAGE_TITLE, pageTitle);
        outState.putBoolean(STATE_SELECTION_MODE, selectionMode);
        outState.putInt(STATE_SELECTION_ANCHOR, selectionAnchorPosition);
        outState.putBoolean(STATE_WAS_ANALYZING, analyzing);
        outState.putBoolean(STATE_CONTINUATION_VISIBLE, continuationCellVisible);
        outState.putString(STATE_CONTINUATION_REASON, continuationReason);
        outState.putStringArrayList(STATE_IG_SESSION_COMPLETED, new ArrayList<>(instagramSessionCompletedPosts));
        outState.putStringArrayList(STATE_IG_SESSION_DISCOVERED, new ArrayList<>(instagramSessionDiscoveredPosts));
        outState.putStringArrayList(STATE_SNS_SAVED_MEDIA_KEYS, new ArrayList<>(snsSessionSavedMediaKeys));
        outState.putString(STATE_NORMAL_SAVED_TARGET, normalSavedTarget);
        outState.putStringArrayList(STATE_NORMAL_SAVED_MEDIA_KEYS, new ArrayList<>(normalSavedMediaKeys));
        outState.putStringArrayList(STATE_SNS_FAILED_MEDIA_KEYS, new ArrayList<>(snsSessionFailedMediaKeys));
        outState.putBoolean(STATE_RESUME_SESSION_COMPLETE, activeResumeComplete);

        ArrayList<String> urls = new ArrayList<>();
        ArrayList<String> refs = new ArrayList<>();
        ArrayList<String> kinds = new ArrayList<>();
        ArrayList<String> dedupKeys = new ArrayList<>();
        boolean[] selected = new boolean[items.size()];
        int[] widths = new int[items.size()];
        int[] heights = new int[items.size()];
        long[] durations = new long[items.size()];
        long[] displayOrders = new long[items.size()];
        for (int i = 0; i < items.size(); i++) {
            MediaItem item = items.get(i);
            urls.add(item.url == null ? "" : item.url);
            refs.add(item.referrer == null ? "" : item.referrer);
            kinds.add(item.kind.name());
            dedupKeys.add(item.dedupKey == null ? "" : item.dedupKey);
            selected[i] = item.selected;
            widths[i] = item.width;
            heights[i] = item.height;
            durations[i] = item.durationMs;
            displayOrders[i] = item.displayOrder;
        }
        outState.putStringArrayList(STATE_ITEM_URLS, urls);
        outState.putStringArrayList(STATE_ITEM_REFS, refs);
        outState.putStringArrayList(STATE_ITEM_KINDS, kinds);
        outState.putStringArrayList(STATE_ITEM_DEDUP_KEYS, dedupKeys);
        outState.putBooleanArray(STATE_ITEM_SELECTED, selected);
        outState.putIntArray(STATE_ITEM_WIDTHS, widths);
        outState.putIntArray(STATE_ITEM_HEIGHTS, heights);
        outState.putLongArray(STATE_ITEM_DURATIONS, durations);
        outState.putLongArray(STATE_ITEM_DISPLAY_ORDERS, displayOrders);

        if (mediaGrid != null) {
            int first = mediaGrid.getFirstVisiblePosition();
            int top = 0;
            View firstChild = mediaGrid.getChildAt(0);
            if (firstChild != null) top = firstChild.getTop();
            outState.putInt(STATE_GRID_FIRST, first);
            outState.putInt(STATE_GRID_TOP, top);
        }
        DiagnosticLog.log("STATE_SAVE items=" + items.size() + " selected=" + countSelectedDownloadable()
                + " mode=" + selectionMode + " anchor=" + selectionAnchorPosition);
    }

    private void restoreInstanceState(Bundle state) {
        urlInput.setText(state.getString(STATE_URL, ""));
        String restoredResolution = state.getString(STATE_RESOLUTION, "640");
        applyingResolutionPreset = true;
        resolutionInput.setText(restoredResolution);
        applyingResolutionPreset = false;
        if ("640".equals(restoredResolution)) selectedResolutionPreset = resolutionSmall;
        else if ("1280".equals(restoredResolution)) selectedResolutionPreset = resolutionMedium;
        else if ("1920".equals(restoredResolution)) selectedResolutionPreset = resolutionLarge;
        else selectedResolutionPreset = null;
        updateResolutionPresetStyles();
        activeAnalysisUrl = urlInput.getText().toString().trim();
        showDetectedModeBadge(activeAnalysisUrl.isEmpty()
                ? null : AnalysisModeRouter.fromUrl(activeAnalysisUrl));
        try { activeAnalysisTargetPx = Integer.parseInt(restoredResolution); } catch (Exception ignored) { activeAnalysisTargetPx = 640; }
        activeSnsService = snsAccounts == null ? null : snsAccounts.serviceForUrl(activeAnalysisUrl);
        activeResumeTarget = SnsResumeStore.targetForUrl(activeAnalysisUrl);
        pageToggle.setChecked(state.getBoolean(STATE_PAGE_TOGGLE, pageToggle.isChecked()));
        detailToggle.setChecked(state.getBoolean(STATE_DETAIL_TOGGLE, detailToggle.isChecked()));
        if (intelligentToggle != null) intelligentToggle.setChecked(state.getBoolean(STATE_INTELLIGENT_TOGGLE, true));
        syncIntelligentTraversalUi();
        imageToggle.setChecked(state.getBoolean(STATE_IMAGE_TOGGLE, imageToggle.isChecked()));
        videoToggle.setChecked(state.getBoolean(STATE_VIDEO_TOGGLE, videoToggle.isChecked()));
        if (backgroundAnalysisToggle != null) {
            backgroundAnalysisToggle.setChecked(state.getBoolean(STATE_BACKGROUND_ANALYSIS_TOGGLE,
                    getSharedPreferences(PREFS_UI, MODE_PRIVATE).getBoolean(PREF_BACKGROUND_ENABLED, false)));
        }
        if (xRepostToggle != null) xRepostToggle.setChecked(state.getBoolean(STATE_X_REPOST_TOGGLE, xRepostToggle.isChecked()));
        if (xGifAsGifToggle != null) xGifAsGifToggle.setChecked(state.getBoolean(STATE_X_GIF_AS_GIF_TOGGLE, true));
        if (resumeToggle != null) resumeToggle.setChecked(state.getBoolean(STATE_RESUME_TOGGLE, resumeToggle.isChecked()));
        String snsSearchService = state.getString(STATE_SNS_SEARCH_SERVICE, "x");
        if (snsSearchInstagramRadio != null) snsSearchInstagramRadio.setChecked("instagram".equals(snsSearchService));
        if (snsSearchXRadio != null) snsSearchXRadio.setChecked(!"instagram".equals(snsSearchService));
        if (snsSearchInput != null) snsSearchInput.setText(state.getString(STATE_SNS_SEARCH_QUERY, ""));
        settingsExpanded = state.getBoolean(STATE_SETTINGS_EXPANDED, settingsExpanded);
        setSettingsExpanded(settingsExpanded, false);
        pageTitle = state.getString(STATE_PAGE_TITLE, "ImgStalker");

        ArrayList<String> urls = state.getStringArrayList(STATE_ITEM_URLS);
        ArrayList<String> refs = state.getStringArrayList(STATE_ITEM_REFS);
        ArrayList<String> kinds = state.getStringArrayList(STATE_ITEM_KINDS);
        ArrayList<String> dedupKeys = state.getStringArrayList(STATE_ITEM_DEDUP_KEYS);
        boolean[] selected = state.getBooleanArray(STATE_ITEM_SELECTED);
        int[] widths = state.getIntArray(STATE_ITEM_WIDTHS);
        int[] heights = state.getIntArray(STATE_ITEM_HEIGHTS);
        long[] durations = state.getLongArray(STATE_ITEM_DURATIONS);
        long[] displayOrders = state.getLongArray(STATE_ITEM_DISPLAY_ORDERS);
        items.clear();
        emittedItemKeys.clear();
        if (urls != null && kinds != null) {
            int count = Math.min(urls.size(), kinds.size());
            for (int i = 0; i < count; i++) {
                try {
                    MediaItem.Kind kind = MediaItem.Kind.valueOf(kinds.get(i));
                    String ref = refs != null && i < refs.size() ? refs.get(i) : "";
                    boolean isSelected = selected != null && i < selected.length && selected[i];
                    int width = widths != null && i < widths.length ? widths[i] : 0;
                    int height = heights != null && i < heights.length ? heights[i] : 0;
                    long duration = durations != null && i < durations.length ? durations[i] : 0L;
                    String dedupKey = dedupKeys != null && i < dedupKeys.size() ? dedupKeys.get(i) : "";
                    long displayOrder = displayOrders != null && i < displayOrders.length ? displayOrders[i] : Long.MAX_VALUE;
                    MediaItem item = new MediaItem(urls.get(i), ref, kind, isSelected, width, height, duration, dedupKey, displayOrder);
                    items.add(item);
                    String uiKey = dedupKey == null || dedupKey.isEmpty() ? kind.name() + "|" + urls.get(i) : dedupKey;
                    if (!uiKey.isEmpty()) emittedItemKeys.add(uiKey);
                    if (thumbnailLoader != null && kind == MediaItem.Kind.IMAGE && !isSnsThumbnailLazyMode()) thumbnailLoader.prefetch(item);
                } catch (Exception e) {
                    DiagnosticLog.logException("STATE_RESTORE_ITEM_FAIL index=" + i, e);
                }
            }
        }

        selectionMode = state.getBoolean(STATE_SELECTION_MODE, false);
        selectionAnchorPosition = state.getInt(STATE_SELECTION_ANCHOR, -1);
        continuationCellVisible = state.getBoolean(STATE_CONTINUATION_VISIBLE, false);
        continuationReason = state.getString(STATE_CONTINUATION_REASON, "restored");
        if (!isResumeEnabled() || (activeSnsService == null
                && activeCrawlerMode != AnalysisModeRouter.Mode.NORMAL)) continuationCellVisible = false;
        continuationReloading = false;
        instagramSessionCompletedPosts.clear();
        instagramSessionDiscoveredPosts.clear();
        snsSessionSavedMediaKeys.clear();
        snsSessionFailedMediaKeys.clear();
        normalSavedMediaKeys.clear();
        normalSavedTarget = NormalSavedLedgerStore.key(activeAnalysisUrl);
        // A Bundle is not proof a file still exists. Only validated URI ledger entries
        // may revive NORMAL green checks after activity recreation.
        normalSavedFileUris.clear();
        if (!normalSavedTarget.isEmpty()) {
            final String restoredNormalUrl = activeAnalysisUrl;
            final String restoredTarget = normalSavedTarget;
            resumeIoExecutor.execute(() -> {
                java.util.LinkedHashMap<String, String> committed =
                        NormalSavedLedgerStore.load(getApplicationContext(), restoredNormalUrl);
                runOnUiThread(() -> {
                    if (!restoredTarget.equals(normalSavedTarget)
                            || !NormalCheckpointStore.matches(restoredNormalUrl, activeAnalysisUrl)) return;
                    if (downloading) return; // Do not overwrite successful in-flight save callbacks.
                    normalSavedFileUris.clear();
                    normalSavedFileUris.putAll(committed);
                    normalSavedMediaKeys.clear();
                    normalSavedMediaKeys.addAll(committed.keySet());
                    if (adapter != null) adapter.notifyDataSetChanged();
                    updateSummary();
                });
            });
        }
        ArrayList<String> restoredSavedMediaKeys = state.getStringArrayList(STATE_SNS_SAVED_MEDIA_KEYS);
        if (restoredSavedMediaKeys != null) snsSessionSavedMediaKeys.addAll(restoredSavedMediaKeys);
        ArrayList<String> restoredFailedMediaKeys = state.getStringArrayList(STATE_SNS_FAILED_MEDIA_KEYS);
        if (restoredFailedMediaKeys != null) snsSessionFailedMediaKeys.addAll(restoredFailedMediaKeys);
        snsSessionFailedMediaKeys.removeAll(snsSessionSavedMediaKeys);
        for (MediaItem item : items) {
            if (isAlreadySavedForActiveSns(item)) item.selected = false;
        }
        activeResumeComplete = state.getBoolean(STATE_RESUME_SESSION_COMPLETE, false);
        ArrayList<String> restoredIgCompleted = state.getStringArrayList(STATE_IG_SESSION_COMPLETED);
        ArrayList<String> restoredIgDiscovered = state.getStringArrayList(STATE_IG_SESSION_DISCOVERED);
        if (restoredIgDiscovered != null) instagramSessionDiscoveredPosts.addAll(restoredIgDiscovered);
        if (restoredIgCompleted != null) {
            instagramSessionCompletedPosts.addAll(restoredIgCompleted);
            instagramSessionDiscoveredPosts.addAll(restoredIgCompleted);
        }
        if (selectionAnchorPosition < 0 || selectionAnchorPosition >= items.size()) selectionAnchorPosition = -1;
        if (selectionMode && countSelectedDownloadable() == 0) selectionMode = false;

        adapter.notifyDataSetChanged();
        updateSummary();
        updateSelectionControls();
        saveButton.setEnabled(countSelectedPendingSave() > 0);
        applyButtonEnabledStyle(saveButton);

        boolean wasAnalyzing = state.getBoolean(STATE_WAS_ANALYZING, false);
        analyzing = false;
        syncBackgroundAnalysisService("state_restore");
        setAnalysisRunningUi(false);
        if (wasAnalyzing) {
            status.setText("解析状態を復元中…");
            continuationNeededForRun = true;
            setContinuationCell(true, "activity_recreated");
            DiagnosticLog.log("ANALYSIS_INTERRUPTED activity_recreated=true restoredItems=" + items.size());
            // Activity recreation is not a signal that the scan is complete. Resume through
            // the normal start path, which reads the durable cursor and existing media.
            final int savedRestoreEpoch = cacheResetEpoch;
            mediaGrid.postDelayed(() -> {
                if (!isResumeEnabled() || analyzing || analysisPreparing || downloading
                        || cacheResetInProgress || cacheResetEpoch != savedRestoreEpoch
                        || isFinishing() || isDestroyed()) return;
                if (AnalysisKeepAliveService.hasOtherRetainedOwner(this)) {
                    connectRetainedWorkIfAny();
                    return;
                }
                DiagnosticLog.log("ANALYSIS_ACTIVITY_RECREATE_RESTART url=" + activeAnalysisUrl);
                startAnalysis();
            }, 650L);
        } else if (!items.isEmpty()) {
            status.setText("結果を復元");
        }

        final int first = state.getInt(STATE_GRID_FIRST, 0);
        final int top = state.getInt(STATE_GRID_TOP, 0);
        mediaGrid.post(() -> {
            if (mediaGrid != null && !items.isEmpty()) {
                int safeFirst = Math.max(0, Math.min(first, items.size() - 1));
                mediaGrid.setSelectionFromTop(safeFirst, top);
            }
        });
        DiagnosticLog.log("STATE_RESTORE items=" + items.size() + " selected=" + countSelectedDownloadable()
                + " mode=" + selectionMode + " anchor=" + selectionAnchorPosition
                + " igCompleted=" + instagramSessionCompletedPosts.size()
                + " igDiscovered=" + instagramSessionDiscoveredPosts.size()
                + " saved=" + snsSessionSavedMediaKeys.size()
                + " failed=" + snsSessionFailedMediaKeys.size());
    }

    @Override protected void onResume() {
        super.onResume();
        activityResumed = true;
        DiagnosticLog.log("ACTIVITY onResume analyzing=" + analyzing
                + " background=" + (backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked()));
        applyCrawlerForegroundPolicy("activity_resume");
        if (adapter != null) adapter.notifyDataSetChanged();
        refreshNormalSavedFiles("activity_resume");
        scheduleSnsThumbnailSweep("activity_resume");
        connectRetainedWorkIfAny();
        requestCacheAvailability();
    }

    @Override protected void onPause() {
        DiagnosticLog.log("ACTIVITY onPause analyzing=" + analyzing
                + " background=" + (backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked()));
        stopVideoPreview("activity_pause");
        super.onPause();
    }

    @Override protected void onStop() {
        activityResumed = false;
        if (analyzing) writeInternalCheckpoint(false, "activity_background");
        DiagnosticLog.log("ACTIVITY onStop analyzing=" + analyzing
                + " background=" + (backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked()));
        applyCrawlerForegroundPolicy("activity_stop");
        super.onStop();
    }

    @Override protected void onDestroy() {
        mirrorHandler.removeCallbacks(mirrorPoll);
        cacheProbeHandler.removeCallbacks(cacheProbeRunnable);
        boolean keepDetachedWork = hasActiveKeepAliveWork()
                && backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked()
                && AnalysisKeepAliveService.isRetaining(this)
                && !isChangingConfigurations();
        DiagnosticLog.log("ACTIVITY onDestroy keepDetachedWork=" + keepDetachedWork
                + " preparing=" + analysisPreparing + " analyzing=" + analyzing
                + " downloading=" + downloading + " finishing=" + isFinishing());

        stopVideoPreview("activity_destroy");
        resetSnsThumbnailSweep("activity_destroy");
        if (settingsAnimator != null) settingsAnimator.cancel();
        if (keepDetachedWork) {
            // Recents/task removal destroys the visible Activity.  The foreground service owns a
            // deliberate strong reference while work is active, so do not cancel/destroy the
            // crawler, downloader, WebView or resume executor here.  The worker completes and
            // releases itself at the next safe terminal state.
            taskRemovedKeepAlive = true;
            activityResumed = false;
            if (webView != null) {
                try {
                    webView.onResume();
                    webView.resumeTimers();
                    crawlerPausedByForegroundPolicy = false;
                } catch (Throwable t) {
                    DiagnosticLog.logException("BACKGROUND_ANALYSIS_DETACH_RESUME_FAIL", t);
                }
            }
            DiagnosticLog.log("BACKGROUND_ANALYSIS_DETACH_PRESERVE active=true");
            super.onDestroy();
            return;
        }

        analysisPreparing = false;
        analysisPrepareGeneration++;
        analysisWatchdogHandler.removeCallbacks(analysisWatchdog);
        if (crawler != null) crawler.cancel();
        if (downloader != null) downloader.cancel();
        if (thumbnailLoader != null) thumbnailLoader.shutdown();
        if (webView != null) webView.destroy();
        resumeCheckpointHandler.removeCallbacks(resumeCheckpointRunnable);
        try { resumeIoExecutor.shutdown(); } catch (Throwable ignored) { }
        try { cacheInspectExecutor.shutdownNow(); } catch (Throwable ignored) { }
        AnalysisKeepAliveService.releaseOwner(this);
        if (!AnalysisKeepAliveService.hasOtherRetainedOwner(this)) {
            stopService(new Intent(this, AnalysisKeepAliveService.class));
        }
        super.onDestroy();
    }

    @Override public boolean hasActiveKeepAliveWork() {
        return !forceStopInProgress && (analysisPreparing || analyzing || downloading || resumeWritesInFlight > 0);
    }

    @Override public String keepAliveProgressSnapshot() {
        return "phase=" + (analysisPreparing ? "preparing" : analyzing ? "analyzing"
                : downloading ? "downloading" : "checkpoint")
                + " media=" + items.size() + " cursor="
                + (crawler == null ? "none" : crawler.progressSnapshot());
    }

    @Override public void onKeepAliveHeartbeat() {
        if (analyzing && isResumeEnabled()) {
            writeInternalCheckpoint(false, "background_heartbeat");
        }
    }

    private void connectRetainedWorkIfAny() {
        AnalysisKeepAliveService.RetainedWorkOwner owner = AnalysisKeepAliveService.getActiveOwner();
        if (!(owner instanceof MainActivity) || owner == this || owner == mirroredWorkOwner) return;
        mirroredWorkOwner = (MainActivity) owner;
        DiagnosticLog.log("BACKGROUND_ANALYSIS_ATTACH existing_worker=true active="
                + mirroredWorkOwner.hasActiveKeepAliveWork());
        mirrorHandler.removeCallbacks(mirrorPoll);
        mirrorHandler.post(mirrorPoll);
    }

    /** A newly opened Activity observes the retained crawler rather than creating a second
     * one. The original Activity remains the sole engine owner until it completes. */
    private void syncMirroredWorkUi() {
        MainActivity worker = mirroredWorkOwner;
        if (worker == null) return;
        if (worker.activeAnalysisUrl != null && !worker.activeAnalysisUrl.isEmpty()) {
            activeAnalysisUrl = worker.activeAnalysisUrl;
            activeAnalysisTargetPx = worker.activeAnalysisTargetPx;
            if (urlInput != null && !worker.activeAnalysisUrl.contentEquals(urlInput.getText()))
                urlInput.setText(worker.activeAnalysisUrl);
            activeSnsService = worker.activeSnsService;
        }
        if (backgroundAnalysisToggle != null && worker.backgroundAnalysisToggle != null) {
            backgroundAnalysisToggle.setChecked(worker.backgroundAnalysisToggle.isChecked());
        }
        if (items.size() != worker.items.size()) {
            items.clear();
            emittedItemKeys.clear();
            for (MediaItem item : worker.items) {
                items.add(new MediaItem(item.url, item.referrer, item.kind, item.selected,
                        item.width, item.height, item.durationMs, item.dedupKey, item.displayOrder));
            }
            adapter.notifyDataSetChanged();
            updateSummary();
        }
        if (worker.hasActiveKeepAliveWork()) {
            showDetectedModeBadge(worker.activeCrawlerMode);
            updateForceStopButtonState();
            status.setText("バックグラウンド解析中（同期）  " + worker.items.size() + "件");
            analyzeButton.setText("停止");
        } else {
            status.setText("バックグラウンド処理が終了  " + items.size() + "件");
            mirroredWorkOwner = null;
            setAnalysisRunningUi(false);
            DiagnosticLog.log("BACKGROUND_ANALYSIS_ATTACH_DONE media=" + items.size());
            requestCacheAvailability();
        }
    }

    @Override public void onKeepAliveTaskRemoved() {
        runOnUiThread(() -> {
            if (!hasActiveKeepAliveWork()) return;
            boolean backgroundEnabled = backgroundAnalysisToggle != null && backgroundAnalysisToggle.isChecked();
            if (!backgroundEnabled) {
                DiagnosticLog.log("BACKGROUND_ANALYSIS_TASK_REMOVED_STOP reason=toggle_off");
                forceStopAll("task_removed_toggle_off");
                return;
            }
            taskRemovedKeepAlive = true;
            activityResumed = false;
            DiagnosticLog.log("BACKGROUND_ANALYSIS_TASK_REMOVED_CONTINUE preparing=" + analysisPreparing
                    + " analyzing=" + analyzing + " downloading=" + downloading);
            if (webView != null && analyzing) {
                try {
                    webView.onResume();
                    webView.resumeTimers();
                    crawlerPausedByForegroundPolicy = false;
                    DiagnosticLog.log("BACKGROUND_ANALYSIS_EXECUTION resume reason=task_removed_override");
                } catch (Throwable t) {
                    DiagnosticLog.logException("BACKGROUND_ANALYSIS_EXECUTION task_removed_resume_fail", t);
                }
            }
        });
    }

    @Override public void onKeepAliveTimeout() {
        runOnUiThread(() -> {
            DiagnosticLog.log("BACKGROUND_ANALYSIS_TIMEOUT_SAFE_STOP preparing=" + analysisPreparing
                    + " analyzing=" + analyzing + " downloading=" + downloading);
            if (analyzing) {
                stopAnalysisByUser("foreground_service_timeout");
            } else if (downloading && downloader != null) {
                downloader.cancel();
                downloading = false;
                syncBackgroundAnalysisService("foreground_service_timeout_download");
            } else if (analysisPreparing) {
                analysisPreparing = false;
                analysisPrepareGeneration++;
                setAnalysisPreparingUi(false);
                syncBackgroundAnalysisService("foreground_service_timeout_prepare");
            }
        });
    }

    private final class HeaderIconView extends View {
        private final HeaderIconKind kind;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        HeaderIconView(Context context, HeaderIconKind kind) {
            super(context);
            this.kind = kind;
            setClickable(true);
            setFocusable(true);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(DARK_GRAY);
            canvas.drawCircle(cx, cy, Math.min(getWidth(), getHeight()) / 2f, paint);

            paint.setColor(N_WHITE);
            paint.setStrokeWidth(dp(2.2f));
            paint.setStrokeCap(Paint.Cap.SQUARE);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStyle(Paint.Style.STROKE);

            if (kind == HeaderIconKind.SETTINGS) {
                // Solid 6-tooth gear. Keep the gear diameter, but make each tooth smaller
                // so the circular rim remains visibly exposed between the teeth.
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy, dp(7.2f), paint);
                for (int i = 0; i < 6; i++) {
                    canvas.save();
                    canvas.rotate(i * 60f, cx, cy);
                    RectF tooth = new RectF(cx - dp(1.7f), cy - dp(10.4f),
                            cx + dp(1.7f), cy - dp(7.0f));
                    canvas.drawRoundRect(tooth, dp(0.8f), dp(0.8f), paint);
                    canvas.restore();
                }
                paint.setColor(DARK_GRAY);
                canvas.drawCircle(cx, cy, dp(3.5f), paint);
                paint.setColor(N_WHITE);
                paint.setStyle(Paint.Style.STROKE);
            } else if (kind == HeaderIconKind.X) {
                // X mark traced as a filled vector path from the supplied reference image.
                // Coordinates use the canonical 24x24 X silhouette and are scaled/centered here.
                paint.setStyle(Paint.Style.FILL);
                path.reset();
                path.setFillType(Path.FillType.EVEN_ODD);
                float scale = dp(0.88f);
                float ox = cx - 12f * scale;
                float oy = cy - 12f * scale;
                path.moveTo(ox + 18.244f * scale, oy + 2.250f * scale);
                path.lineTo(ox + 21.552f * scale, oy + 2.250f * scale);
                path.lineTo(ox + 14.325f * scale, oy + 10.510f * scale);
                path.lineTo(ox + 22.827f * scale, oy + 21.750f * scale);
                path.lineTo(ox + 16.170f * scale, oy + 21.750f * scale);
                path.lineTo(ox + 10.956f * scale, oy + 14.933f * scale);
                path.lineTo(ox + 4.990f * scale, oy + 21.750f * scale);
                path.lineTo(ox + 1.680f * scale, oy + 21.750f * scale);
                path.lineTo(ox + 9.410f * scale, oy + 12.915f * scale);
                path.lineTo(ox + 1.254f * scale, oy + 2.250f * scale);
                path.lineTo(ox + 8.080f * scale, oy + 2.250f * scale);
                path.lineTo(ox + 12.793f * scale, oy + 8.481f * scale);
                path.close();
                path.moveTo(ox + 17.083f * scale, oy + 19.770f * scale);
                path.lineTo(ox + 18.916f * scale, oy + 19.770f * scale);
                path.lineTo(ox + 7.084f * scale, oy + 4.126f * scale);
                path.lineTo(ox + 5.117f * scale, oy + 4.126f * scale);
                path.close();
                canvas.drawPath(path, paint);
                paint.setStyle(Paint.Style.STROKE);
            } else if (kind == HeaderIconKind.INSTAGRAM) {
                RectF body = new RectF(cx - dp(9.5f), cy - dp(9.5f), cx + dp(9.5f), cy + dp(9.5f));
                canvas.drawRoundRect(body, dp(5), dp(5), paint);
                canvas.drawCircle(cx, cy, dp(4.2f), paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx + dp(5.8f), cy - dp(5.8f), dp(1.4f), paint);
                paint.setStyle(Paint.Style.STROKE);
            } else {
                // Solid document with knockout text lines, matching the supplied diagnostic reference.
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(N_WHITE);
                RectF doc = new RectF(cx - dp(8.2f), cy - dp(10.0f), cx + dp(8.2f), cy + dp(10.0f));
                canvas.drawRoundRect(doc, dp(2.3f), dp(2.3f), paint);
                paint.setColor(DARK_GRAY);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(dp(2.4f));
                paint.setStrokeCap(Paint.Cap.ROUND);
                canvas.drawLine(cx - dp(4.2f), cy - dp(4.5f), cx + dp(4.2f), cy - dp(4.5f), paint);
                canvas.drawLine(cx - dp(4.2f), cy, cx + dp(4.2f), cy, paint);
                canvas.drawLine(cx - dp(4.2f), cy + dp(4.5f), cx + dp(1.6f), cy + dp(4.5f), paint);
                paint.setColor(N_WHITE);
            }
        }
    }

    private final class MediaAdapter extends ArrayAdapter<MediaItem> {
        MediaAdapter(Context context, ArrayList<MediaItem> data) {
            super(context, 0, data);
        }

        @Override public int getCount() {
            return super.getCount() + (continuationCellVisible ? 1 : 0);
        }

        @Override public int getViewTypeCount() {
            return 2;
        }

        @Override public int getItemViewType(int position) {
            return continuationCellVisible && position == items.size() ? 1 : 0;
        }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            if (continuationCellVisible && position == items.size()) {
                return getContinuationCellView(convertView);
            }
            CellHolder h;
            if (convertView == null) {
                LinearLayout cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(dp(4), dp(4), dp(4), dp(5));
                cell.setBackgroundColor(BG);

                SquareFrameLayout thumbFrame = new SquareFrameLayout(MainActivity.this);
                thumbFrame.setBackground(rounded(DARK_GRAY, 7));
                thumbFrame.setClipToOutline(true);

                ImageView thumb = new ImageView(MainActivity.this);
                thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                thumb.setBackground(rounded(DARK_GRAY, 7));
                thumb.setClipToOutline(true);
                thumbFrame.addView(thumb, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                PlayIconView play = new PlayIconView(MainActivity.this);
                FrameLayout.LayoutParams playLp = new FrameLayout.LayoutParams(dp(43), dp(43), Gravity.CENTER);
                thumbFrame.addView(play, playLp);

                TextView duration = text("", 10, TEXT_WHITE);
                duration.setSingleLine(true);
                duration.setGravity(Gravity.CENTER);
                duration.setPadding(dp(4), dp(1), dp(4), dp(1));
                duration.setBackground(rounded(0xAA252020, 4));
                FrameLayout.LayoutParams durationLp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, dp(20), Gravity.BOTTOM | Gravity.START);
                durationLp.setMargins(dp(5), 0, 0, dp(5));
                thumbFrame.addView(duration, durationLp);

                EyeIconView eye = new EyeIconView(MainActivity.this);
                eye.setContentDescription("プレビュー");
                FrameLayout.LayoutParams eyeLp = new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP | Gravity.START);
                eyeLp.setMargins(dp(4), dp(4), 0, 0);
                thumbFrame.addView(eye, eyeLp);

                SaveStateCheckView saveState = new SaveStateCheckView(MainActivity.this);
                saveState.setContentDescription("保存状態");
                FrameLayout.LayoutParams saveStateLp = new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP | Gravity.END);
                saveStateLp.setMargins(0, dp(5), dp(5), 0);
                thumbFrame.addView(saveState, saveStateLp);

                cell.addView(thumbFrame, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                LinearLayout metaBox = new LinearLayout(MainActivity.this);
                metaBox.setOrientation(LinearLayout.VERTICAL);
                metaBox.setBackground(rounded(BG, 6));
                LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
                metaLp.setMargins(dp(2), dp(3), dp(2), 0);
                cell.addView(metaBox, metaLp);

                TextView fileName = text("", 11, N_WHITE);
                fileName.setGravity(Gravity.CENTER);
                fileName.setSingleLine(true);
                fileName.setEllipsize(TextUtils.TruncateAt.END);
                fileName.setPadding(dp(3), dp(2), dp(3), 0);
                fileName.setBackgroundColor(Color.TRANSPARENT);
                metaBox.addView(fileName, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));

                TextView resolution = text("", 10, LIGHT_GRAY);
                resolution.setGravity(Gravity.CENTER);
                resolution.setSingleLine(true);
                resolution.setPadding(dp(3), 0, dp(3), dp(2));
                resolution.setBackgroundColor(Color.TRANSPARENT);
                metaBox.addView(resolution, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(18)));

                h = new CellHolder(thumbFrame, thumb, play, eye, saveState, metaBox, fileName, resolution, duration);
                cell.setTag(h);
                convertView = cell;
            } else {
                h = (CellHolder) convertView.getTag();
            }

            MediaItem item = getItem(position);
            boolean savedState = isAlreadySavedForActiveSns(item);
            boolean failedState = isFailedForActiveSns(item);
            if (savedState && item.selected) item.selected = false;
            h.saveState.setState(savedState ? SaveStateCheckView.STATE_SAVED
                    : (failedState ? SaveStateCheckView.STATE_FAILED : SaveStateCheckView.STATE_NONE));
            if (h.thumbFrame == previewFrame && (previewItem != item || previewPosition != position)) {
                stopVideoPreview("cell_rebound");
            }
            LinearLayout cell = (LinearLayout) convertView;
            cell.setBackgroundColor(BG);
            h.fileName.setText(fileNameFromUrl(item.url));
            h.fileName.setTextColor(item.kind == MediaItem.Kind.STREAM ? LIGHT_GRAY : (item.selected ? TEXT_WHITE : N_WHITE));
            h.resolution.setText(formatResolution(item));
            h.resolution.setTextColor(item.selected ? TEXT_WHITE : LIGHT_GRAY);
            h.metaBox.setBackground(rounded(selectionMode && item.selected ? LIGHT_BLUE : BG, 6));
            h.duration.setText(item.kind == MediaItem.Kind.VIDEO ? formatDuration(item.durationMs) : "");
            h.duration.setVisibility(item.kind == MediaItem.Kind.VIDEO && item.durationMs > 0L ? View.VISIBLE : View.GONE);
            h.eye.setVisibility(selectionMode && (item.kind == MediaItem.Kind.IMAGE || item.kind == MediaItem.Kind.VIDEO)
                    ? View.VISIBLE : View.GONE);
            h.play.setVisibility(!selectionMode && item.kind == MediaItem.Kind.VIDEO
                    && !(previewItem == item && previewPosition == position) ? View.VISIBLE : View.GONE);
            thumbnailLoader.load(h.thumb, item);

            View.OnClickListener itemTap = v -> {
                if (selectionMode) {
                    toggleSelectionAt(position);
                    return;
                }
                if (item.kind == MediaItem.Kind.IMAGE) {
                    showOriginalImage(item);
                } else if (item.kind == MediaItem.Kind.VIDEO) {
                    toggleVideoPreview(item, position, h.thumbFrame);
                }
            };

            View.OnLongClickListener itemLongPress = v -> {
                if (item.kind == MediaItem.Kind.STREAM) return true;
                if (isAlreadySavedForActiveSns(item)) {
                    item.selected = false;
                    DiagnosticLog.log("ITEM_LONG_SELECT_BLOCKED_SAVED position=" + position + " url=" + item.url);
                    notifyDataSetChanged();
                    updateSummary();
                    return true;
                }
                if (!selectionMode) {
                    enterSelectionModeWithItem(position);
                    return true;
                }
                if (selectRangeFromAnchor(position)) return true;
                if (!item.selected) {
                    item.selected = true;
                    selectionAnchorPosition = position;
                    DiagnosticLog.log("ITEM_SELECT_LONG position=" + position + " url=" + item.url);
                    notifyDataSetChanged();
                    updateSummary();
                }
                return true;
            };

            h.thumbFrame.setOnClickListener(itemTap);
            h.thumbFrame.setOnLongClickListener(itemLongPress);
            h.metaBox.setOnClickListener(itemTap);
            h.metaBox.setOnLongClickListener(itemLongPress);
            h.fileName.setOnClickListener(v -> {
                if (selectionMode) {
                    toggleSelectionAt(position);
                } else if (item.kind == MediaItem.Kind.IMAGE) {
                    showOriginalImage(item);
                } else if (item.kind == MediaItem.Kind.VIDEO) {
                    toggleVideoPreview(item, position, h.thumbFrame);
                }
            });
            h.fileName.setOnLongClickListener(itemLongPress);
            h.resolution.setOnClickListener(itemTap);
            h.resolution.setOnLongClickListener(itemLongPress);
            h.eye.setOnClickListener(v -> {
                if (item.kind == MediaItem.Kind.IMAGE) {
                    DiagnosticLog.log("ITEM_PREVIEW_EYE position=" + position + " kind=image url=" + item.url);
                    showOriginalImage(item);
                } else if (item.kind == MediaItem.Kind.VIDEO) {
                    DiagnosticLog.log("ITEM_PREVIEW_EYE position=" + position + " kind=video url=" + item.url);
                    toggleVideoPreview(item, position, h.thumbFrame);
                }
            });
            h.eye.setOnLongClickListener(v -> true);
            return convertView;
        }

        private View getContinuationCellView(View convertView) {
            ReloadCellHolder h;
            if (convertView == null || !(convertView.getTag() instanceof ReloadCellHolder)) {
                LinearLayout cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(dp(4), dp(4), dp(4), dp(5));
                cell.setBackgroundColor(BG);

                SquareFrameLayout frame = new SquareFrameLayout(MainActivity.this);
                frame.setBackground(rounded(DARK_GRAY, 7));
                frame.setClipToOutline(true);
                ImageView reload = new ImageView(MainActivity.this);
                reload.setImageResource(com.cmyk.imgstalker.R.drawable.ic_reload_stalker);
                reload.setScaleType(ImageView.ScaleType.FIT_CENTER);
                reload.setPadding(dp(11), dp(11), dp(11), dp(11));
                frame.addView(reload, new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER));
                ProgressBar spinner = new ProgressBar(MainActivity.this);
                if (spinner.getIndeterminateDrawable() != null) spinner.getIndeterminateDrawable().setTint(N_WHITE);
                frame.addView(spinner, new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
                cell.addView(frame, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                TextView label = text("続きを再読込", 12, N_WHITE);
                label.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
                label.setPadding(dp(3), dp(5), dp(3), dp(3));
                LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(43));
                labelLp.setMargins(dp(2), dp(4), dp(2), 0);
                cell.addView(label, labelLp);
                h = new ReloadCellHolder(frame, reload, spinner, label);
                cell.setTag(h);
                convertView = cell;
            } else {
                h = (ReloadCellHolder) convertView.getTag();
            }
            h.reload.setVisibility(continuationReloading ? View.GONE : View.VISIBLE);
            h.spinner.setVisibility(continuationReloading ? View.VISIBLE : View.GONE);
            h.label.setText(continuationReloading ? "再読込中" : "続きを再読込");
            h.frame.setContentDescription(continuationReloading ? "続きを再読込中" : "続きを再読込");
            h.frame.setOnClickListener(v -> {
                if (!continuationReloading) startContinuationFromReloadCell();
            });
            h.label.setOnClickListener(v -> {
                if (!continuationReloading) startContinuationFromReloadCell();
            });
            convertView.setOnClickListener(v -> {
                if (!continuationReloading) startContinuationFromReloadCell();
            });
            return convertView;
        }
    }

    private void toggleVideoPreview(MediaItem item, int position, SquareFrameLayout frame) {
        if (item == null || item.kind != MediaItem.Kind.VIDEO || frame == null) return;
        if (previewItem == item && previewPosition == position && (previewPlayer != null || previewPreparing)) {
            stopVideoPreview("tap_stop");
            if (adapter != null) adapter.notifyDataSetChanged();
            return;
        }
        startVideoPreview(item, position, frame);
    }

    private Map<String, String> buildVideoPreviewHeaders(MediaItem item, String requestUrl,
                                                         boolean twitterBrowserFallback) {
        Map<String, String> headers = new HashMap<>();
        boolean twitterVideo = modeProvider.preview().isSpecialVideo(requestUrl)
                || (item != null && modeProvider.preview().isSpecialVideo(item.url));
        if (twitterVideo) {
            if (twitterBrowserFallback) {
                headers.put("Referer", "https://x.com/");
                headers.put("Origin", "https://x.com");
            } else if (item != null && item.referrer != null && !item.referrer.trim().isEmpty()) {
                headers.put("Referer", item.referrer.trim());
            }
        } else if (item != null && item.referrer != null && !item.referrer.trim().isEmpty()) {
            headers.put("Referer", item.referrer.trim());
        }
        try {
            String cookie = modeProvider.cookieFor(requestUrl);
            if (cookie != null && !cookie.trim().isEmpty()) headers.put("Cookie", cookie);
        } catch (Exception ignored) {}
        return headers;
    }

    private void startVideoPreview(MediaItem item, int position, SquareFrameLayout frame) {
        stopVideoPreview("switch");
        previewItem = item;
        previewPosition = position;
        previewFrame = frame;
        previewPreparing = true;

        PlayerView playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
        playerView.setBackgroundColor(Color.BLACK);
        playerView.setKeepContentOnPlayerReset(false);
        previewPlayerView = playerView;

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        frame.addView(playerView, Math.min(1, frame.getChildCount()), lp);

        DiagnosticLog.log("VIDEO_PREVIEW_START engine=media3 position=" + position
                + " muted=true loop=true url=" + item.url);

        try {
            final ModePreviewPolicy previewPolicy = modeProvider.preview();
            final boolean twitterVideo = previewPolicy.isSpecialVideo(item.url);
            if (twitterVideo && modeProvider.preview().isKnownFailed(item.url)) {
                DiagnosticLog.log("TW_VIDEO_FAIL_CACHE_HIT mode=preview url=" + item.url);
                stopVideoPreview("twitter_fail_cache");
                if (adapter != null) adapter.notifyDataSetChanged();
                Toast.makeText(this, "動画を再生できません", Toast.LENGTH_SHORT).show();
                return;
            }

            String baseUa;
            try {
                baseUa = WebSettings.getDefaultUserAgent(this);
            } catch (Exception e) {
                baseUa = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36";
            }
            final String browserUa = baseUa;
            String ua = twitterVideo ? browserUa : browserUa + " ImgStalker/0.1.110";

            Map<String, String> headers = buildVideoPreviewHeaders(
                    item, modeProvider.preview().resolvedUrl(item.url), false);

            DefaultHttpDataSource.Factory dataSourceFactory = new DefaultHttpDataSource.Factory()
                    .setUserAgent(ua)
                    .setAllowCrossProtocolRedirects(true)
                    .setDefaultRequestProperties(headers);
            DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(this)
                    .setDataSourceFactory(dataSourceFactory);
            ExoPlayer player = new ExoPlayer.Builder(this)
                    .setMediaSourceFactory(mediaSourceFactory)
                    .build();
            final String originalPreviewUrl = item.url;
            final String initialPreviewUrl = previewPolicy.resolvedUrl(originalPreviewUrl);
            final String[] activePreviewUrl = { initialPreviewUrl };
            if (!initialPreviewUrl.equals(originalPreviewUrl)) {
                DiagnosticLog.log("TW_VIDEO_URL_REUSE mode=preview url=" + initialPreviewUrl);
            }
            final int[] twitterRetryStage = { 0 };
            previewPlayer = player;
            playerView.setPlayer(player);
            player.setVolume(0f);
            player.setRepeatMode(Player.REPEAT_MODE_ONE);
            player.addListener(new Player.Listener() {
                @Override public void onPlaybackStateChanged(int playbackState) {
                    if (player != previewPlayer || item != previewItem || position != previewPosition) return;
                    if (playbackState == Player.STATE_READY) {
                        previewPreparing = false;
                        long duration = player.getDuration();
                        androidx.media3.common.VideoSize videoSize = player.getVideoSize();
                        if (duration > 0L) item.durationMs = duration;
                        if (videoSize != null && videoSize.width > 0 && videoSize.height > 0) {
                            item.width = videoSize.width;
                            item.height = videoSize.height;
                        }
                        DiagnosticLog.log("VIDEO_PREVIEW_PLAY engine=media3 position=" + position
                                + " size=" + item.width + "x" + item.height
                                + " durationMs=" + item.durationMs
                                + " url=" + activePreviewUrl[0]);
                        if (twitterVideo && !activePreviewUrl[0].equals(originalPreviewUrl)) {
                            previewPolicy.markRecovered(originalPreviewUrl, activePreviewUrl[0]);
                            DiagnosticLog.log("TW_VIDEO_URL_RECOVERED mode=preview url=" + activePreviewUrl[0]);
                        }
                        if (adapter != null) adapter.notifyDataSetChanged();
                    } else if (playbackState == Player.STATE_ENDED) {
                        DiagnosticLog.log("VIDEO_PREVIEW_ENDED position=" + position + " url=" + item.url);
                    }
                }

                @Override public void onPlayerError(PlaybackException error) {
                    if (player != previewPlayer) return;
                    if (twitterVideo && error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) {
                        if (twitterRetryStage[0] == 0) {
                            twitterRetryStage[0] = 1;
                            DiagnosticLog.log("TW_VIDEO_HEADER_RETRY mode=preview profile=x_origin url="
                                    + activePreviewUrl[0]);
                            try {
                                dataSourceFactory.setDefaultRequestProperties(
                                        buildVideoPreviewHeaders(item, activePreviewUrl[0], true));
                                player.stop();
                                player.clearMediaItems();
                                player.setMediaItem(androidx.media3.common.MediaItem.fromUri(activePreviewUrl[0]));
                                player.prepare();
                                player.play();
                                return;
                            } catch (Exception retryError) {
                                DiagnosticLog.logException("TW_VIDEO_HEADER_RETRY_FAIL mode=preview", retryError);
                            }
                        }
                        if (twitterRetryStage[0] <= 1) {
                            twitterRetryStage[0] = 2;
                            DiagnosticLog.log("TW_VIDEO_403_DETECTED mode=preview url=" + activePreviewUrl[0]);
                            try {
                                resumeIoExecutor.execute(() -> {
                                    String refreshed = previewPolicy.resolveFresh(
                                            originalPreviewUrl, item.referrer, browserUa);
                                    runOnUiThread(() -> {
                                        if (player != previewPlayer || item != previewItem
                                                || position != previewPosition) return;
                                        if (refreshed != null && !refreshed.isEmpty()) {
                                            activePreviewUrl[0] = refreshed;
                                            DiagnosticLog.log("TW_VIDEO_REFRESH_RETRY mode=preview url=" + refreshed);
                                            try {
                                                dataSourceFactory.setDefaultRequestProperties(
                                                        buildVideoPreviewHeaders(item, refreshed, false));
                                                player.stop();
                                                player.clearMediaItems();
                                                player.setMediaItem(androidx.media3.common.MediaItem.fromUri(refreshed));
                                                player.prepare();
                                                player.play();
                                                return;
                                            } catch (Exception retryError) {
                                                DiagnosticLog.logException("TW_VIDEO_REFRESH_RETRY_FAIL mode=preview url="
                                                        + refreshed, retryError);
                                            }
                                        }
                                        previewPolicy.markFailed(originalPreviewUrl);
                                        DiagnosticLog.log("TW_VIDEO_FAIL_CACHE_SET mode=preview url=" + originalPreviewUrl);
                                        DiagnosticLog.log("VIDEO_PREVIEW_ERROR engine=media3 code=" + error.errorCode
                                                + " name=" + error.getErrorCodeName()
                                                + " message=" + String.valueOf(error.getMessage())
                                                + " url=" + activePreviewUrl[0]);
                                        stopVideoPreview("media3_error");
                                        if (adapter != null) adapter.notifyDataSetChanged();
                                        Toast.makeText(MainActivity.this, "動画を再生できません", Toast.LENGTH_SHORT).show();
                                    });
                                });
                                return;
                            } catch (Throwable queueError) {
                                DiagnosticLog.logException("TW_VIDEO_REFRESH_QUEUE_FAIL mode=preview", queueError);
                            }
                        }
                    }
                    if (twitterVideo && error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) {
                        previewPolicy.markFailed(originalPreviewUrl);
                        DiagnosticLog.log("TW_VIDEO_FAIL_CACHE_SET mode=preview url=" + originalPreviewUrl);
                    }
                    DiagnosticLog.log("VIDEO_PREVIEW_ERROR engine=media3 code=" + error.errorCode
                            + " name=" + error.getErrorCodeName()
                            + " message=" + String.valueOf(error.getMessage())
                            + " url=" + activePreviewUrl[0]);
                    stopVideoPreview("media3_error");
                    if (adapter != null) adapter.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "動画を再生できません", Toast.LENGTH_SHORT).show();
                }
            });
            player.setMediaItem(androidx.media3.common.MediaItem.fromUri(initialPreviewUrl));
            player.prepare();
            player.play();
        } catch (Exception e) {
            DiagnosticLog.logException("VIDEO_PREVIEW_FAIL engine=media3 url=" + item.url, e);
            stopVideoPreview("prepare_exception");
            if (adapter != null) adapter.notifyDataSetChanged();
            Toast.makeText(this, "動画を再生できません", Toast.LENGTH_SHORT).show();
        }

        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void stopVideoPreview(String reason) {
        if (previewStopping) return;
        if (previewPlayer == null && previewPlayerView == null && previewItem == null && previewPosition < 0) return;
        previewStopping = true;
        String url = previewItem == null ? "" : previewItem.url;
        int position = previewPosition;

        ExoPlayer player = previewPlayer;
        previewPlayer = null;
        previewPreparing = false;

        PlayerView playerView = previewPlayerView;
        previewPlayerView = null;
        if (playerView != null) {
            try { playerView.setPlayer(null); } catch (Exception ignored) {}
            ViewParent parent = playerView.getParent();
            if (parent instanceof ViewGroup) {
                try { ((ViewGroup) parent).removeView(playerView); } catch (Exception ignored) {}
            }
        }
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
        }

        previewFrame = null;
        previewItem = null;
        previewPosition = -1;
        DiagnosticLog.log("VIDEO_PREVIEW_STOP reason=" + reason + " position=" + position + " url=" + url);
        previewStopping = false;
    }

    private static String fileNameFromUrl(String value) {
        try {
            Uri uri = Uri.parse(value == null ? "" : value);
            String last = uri.getLastPathSegment();
            if (last != null && !last.trim().isEmpty()) return Uri.decode(last.trim());
        } catch (Exception ignored) {}
        return value == null || value.trim().isEmpty() ? "(名称不明)" : value.trim();
    }

    private static String formatResolution(MediaItem item) {
        if (item == null || item.width <= 0 || item.height <= 0) return "";
        return item.width + " × " + item.height;
    }

    private static String formatDuration(long durationMs) {
        if (durationMs <= 0L) return "";
        long total = Math.max(0L, (durationMs + 500L) / 1000L);
        long h = total / 3600L;
        long m = (total % 3600L) / 60L;
        long sec = total % 60L;
        if (h > 0L) return String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(java.util.Locale.US, "%d:%02d", m, sec);
    }

    private final class FastScrollThumbView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private GridView grid;
        private FrameLayout host;
        private boolean dragging = false;
        private float dragOffsetY = 0f;
        private int lastFirst = 0;
        private int lastVisible = 0;
        private int lastTotal = 0;
        private int scrollState = AbsListView.OnScrollListener.SCROLL_STATE_IDLE;
        private final Runnable hideRunnable = () -> {
            if (dragging) return;
            animate().cancel();
            animate().alpha(0f).setDuration(180L).withEndAction(() -> {
                if (!dragging && getAlpha() == 0f) setVisibility(View.INVISIBLE);
            }).start();
        };

        FastScrollThumbView(Context context) {
            super(context);
            setClickable(true);
            setFocusable(false);
            setVisibility(View.INVISIBLE);
            setAlpha(0f);
            setContentDescription("スクロールカーソル");
        }

        void attach(GridView grid, FrameLayout host) {
            this.grid = grid;
            this.host = host;
        }

        void onGridScrollStateChanged(int state) {
            scrollState = state;
            if (state == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                scheduleHide();
            } else {
                showThumb();
            }
        }

        void updateFromGrid(int firstVisible, int visibleCount, int totalCount) {
            lastFirst = Math.max(0, firstVisible);
            lastVisible = Math.max(0, visibleCount);
            lastTotal = Math.max(0, totalCount);
            if (host == null || totalCount <= visibleCount || visibleCount <= 0) {
                if (!dragging) setVisibility(View.INVISIBLE);
                return;
            }
            if (!dragging) positionForFraction(scrollFraction(firstVisible, visibleCount, totalCount));
            showThumb();
            if (!dragging && scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) scheduleHide();
        }

        private float scrollFraction(int first, int visible, int total) {
            int maxFirst = Math.max(1, total - visible);
            return Math.max(0f, Math.min(1f, first / (float) maxFirst));
        }

        private void positionForFraction(float fraction) {
            if (host == null) return;
            int travel = Math.max(0, host.getHeight() - getHeight());
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) getLayoutParams();
            if (lp == null) return;
            int top = Math.round(Math.max(0f, Math.min(1f, fraction)) * travel);
            if (lp.topMargin != top) {
                lp.topMargin = top;
                setLayoutParams(lp);
            }
        }

        private void showThumb() {
            removeCallbacks(hideRunnable);
            animate().cancel();
            if (lastTotal <= lastVisible || lastVisible <= 0) return;
            if (getVisibility() != View.VISIBLE) setVisibility(View.VISIBLE);
            setAlpha(1f);
        }

        private void scheduleHide() {
            removeCallbacks(hideRunnable);
            if (!dragging) postDelayed(hideRunnable, 850L);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (grid == null || host == null || lastTotal <= lastVisible || lastVisible <= 0) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true;
                    dragOffsetY = event.getY();
                    showThumb();
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!dragging) return false;
                    int[] hostLocation = new int[2];
                    host.getLocationOnScreen(hostLocation);
                    float targetTop = event.getRawY() - hostLocation[1] - dragOffsetY;
                    int travel = Math.max(1, host.getHeight() - getHeight());
                    float fraction = Math.max(0f, Math.min(1f, targetTop / travel));
                    positionForFraction(fraction);
                    int maxFirst = Math.max(0, lastTotal - lastVisible);
                    int target = Math.round(fraction * maxFirst);
                    grid.setSelectionFromTop(target, 0);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    scheduleHide();
                    return true;
                default:
                    return true;
            }
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(N_WHITE);
            float width = dp(5);
            float left = (getWidth() - width) / 2f;
            float top = dp(4);
            float right = left + width;
            float bottom = Math.max(top + dp(12), getHeight() - dp(4));
            float radius = width / 2f;
            canvas.drawRoundRect(left, top, right, bottom, radius, radius, paint);
        }

        @Override protected void onDetachedFromWindow() {
            removeCallbacks(hideRunnable);
            animate().cancel();
            super.onDetachedFromWindow();
        }
    }

    private final class ReloadCellHolder {
        final SquareFrameLayout frame;
        final ImageView reload;
        final ProgressBar spinner;
        final TextView label;
        ReloadCellHolder(SquareFrameLayout frame, ImageView reload, ProgressBar spinner, TextView label) {
            this.frame = frame;
            this.reload = reload;
            this.spinner = spinner;
            this.label = label;
        }
    }

    private final class CellHolder {
        final SquareFrameLayout thumbFrame;
        final ImageView thumb;
        final PlayIconView play;
        final EyeIconView eye;
        final SaveStateCheckView saveState;
        final LinearLayout metaBox;
        final TextView fileName;
        final TextView resolution;
        final TextView duration;

        CellHolder(SquareFrameLayout thumbFrame, ImageView thumb, PlayIconView play, EyeIconView eye,
                   SaveStateCheckView saveState, LinearLayout metaBox, TextView fileName, TextView resolution, TextView duration) {
            this.thumbFrame = thumbFrame;
            this.thumb = thumb;
            this.play = play;
            this.eye = eye;
            this.saveState = saveState;
            this.metaBox = metaBox;
            this.fileName = fileName;
            this.resolution = resolution;
            this.duration = duration;
        }
    }

    private final class SaveStateCheckView extends View {
        static final int STATE_NONE = 0;
        static final int STATE_SAVED = 1;
        static final int STATE_FAILED = 2;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int state = STATE_NONE;

        SaveStateCheckView(Context context) {
            super(context);
            setWillNotDraw(false);
            setVisibility(View.GONE);
        }

        void setState(int state) {
            this.state = state;
            setVisibility(state == STATE_NONE ? View.GONE : View.VISIBLE);
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (state == STATE_NONE) return;
            float w = getWidth();
            float h = getHeight();
            float inset = dp(1.5f);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(state == STATE_SAVED ? GREEN : DARK_RED);
            canvas.drawCircle(w * 0.5f, h * 0.5f, Math.max(0f, Math.min(w, h) * 0.5f - inset), paint);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2.4f));
            paint.setStrokeCap(Paint.Cap.SQUARE);
            paint.setStrokeJoin(Paint.Join.MITER);
            paint.setColor(TEXT_WHITE);
            Path path = new Path();
            path.moveTo(w * 0.27f, h * 0.53f);
            path.lineTo(w * 0.44f, h * 0.69f);
            path.lineTo(w * 0.75f, h * 0.34f);
            canvas.drawPath(path, paint);
        }
    }

    private static final class SquareFrameLayout extends FrameLayout {
        SquareFrameLayout(Context context) {
            super(context);
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = View.MeasureSpec.getSize(widthMeasureSpec);
            if (width <= 0) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                width = getMeasuredWidth();
            }
            int square = View.MeasureSpec.makeMeasureSpec(Math.max(1, width), View.MeasureSpec.EXACTLY);
            super.onMeasure(square, square);
            setMeasuredDimension(Math.max(1, width), Math.max(1, width));
        }
    }

    private final class PlayIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        PlayIconView(Context context) {
            super(context);
            setClickable(false);
            setFocusable(false);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float r = Math.min(getWidth(), getHeight()) * 0.42f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xAA252020);
            canvas.drawCircle(cx, cy, r, paint);
            paint.setColor(N_WHITE);
            path.reset();
            float halfH = r * 0.55f;
            float left = cx - r * 0.25f;
            path.moveTo(left, cy - halfH);
            path.lineTo(left, cy + halfH);
            path.lineTo(cx + r * 0.52f, cy);
            path.close();
            canvas.drawPath(path, paint);
        }
    }

    private final class EyeIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval = new RectF();

        EyeIconView(Context context) {
            super(context);
            setClickable(true);
            setFocusable(true);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float radius = Math.min(getWidth(), getHeight()) / 2f;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(DARK_GRAY);
            canvas.drawCircle(cx, cy, radius, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1.8f));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(N_WHITE);
            oval.set(cx - dp(8), cy - dp(5), cx + dp(8), cy + dp(5));
            canvas.drawOval(oval, paint);

            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(cx, cy, dp(2.5f), paint);
        }
    }

}
