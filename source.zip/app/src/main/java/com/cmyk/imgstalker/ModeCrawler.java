package com.cmyk.imgstalker;

import java.util.List;

/** One-way UI contract. Implementations never call or construct another provider engine. */
interface ModeCrawler {
    void start(String url, boolean pages, boolean details, boolean intelligent, boolean images, boolean videos, int minPx);
    void cancel();
    void requestGracefulStop();
    boolean recoverFromStall();
    boolean hasPendingWork();
    String progressSnapshot();
    void seedExternalResumeMedia(List<MediaItem> items);
    void seedContinuationResults(List<MediaItem> items);
    boolean isIncompleteCompletion();
    String getIncompleteCompletionReason();
}
