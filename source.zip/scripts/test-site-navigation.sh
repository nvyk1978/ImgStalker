#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/net" "$TMP/src/android/content" "$TMP/src/org/json" "$TMP/src/com/cmyk/imgstalker" "$TMP/out"
cat > "$TMP/src/android/net/Uri.java" <<'JAVA'
package android.net;
public final class Uri {
 private final java.net.URI uri;
 private Uri(String s) {uri=java.net.URI.create(s);}
 public static Uri parse(String s) {return new Uri(s);}
 public String getHost() {return uri.getHost();}
 public String getScheme() {return uri.getScheme();}
 public String getPath() {return uri.getPath();}
}
JAVA
cat > "$TMP/src/android/content/SharedPreferences.java" <<'JAVA'
package android.content;
public interface SharedPreferences {
 String getString(String key,String fallback);
 Editor edit();
 interface Editor {Editor putString(String key,String value);void apply();}
}
JAVA
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content;
public class Context {
 public static final int MODE_PRIVATE=0;
 public SharedPreferences getSharedPreferences(String key,int mode) {throw new UnsupportedOperationException();}
}
JAVA
cat > "$TMP/src/org/json/JSONArray.java" <<'JAVA'
package org.json;
public class JSONArray {
 public JSONArray() {} public JSONArray(String s) {}
 public int length(){return 0;} public JSONObject optJSONObject(int n){return null;}
 public JSONArray put(JSONObject v){return this;}
 @Override public String toString(){return "[]";}
}
JAVA
cat > "$TMP/src/org/json/JSONObject.java" <<'JAVA'
package org.json;
public class JSONObject {
 public JSONObject() {}
 public String optString(String k,String d){return d;}
 public boolean optBoolean(String k,boolean d){return d;}
 public long optLong(String k,long d){return d;}
 public JSONObject put(String k,Object v){return this;}
}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" <<'JAVA'
package com.cmyk.imgstalker;
final class DiagnosticLog {static void logException(String code,Exception error){throw new AssertionError(code,error);}}
JAVA
javac -encoding UTF-8 -d "$TMP/out" \
 "$TMP/src/android/net/Uri.java" "$TMP/src/android/content/Context.java" \
 "$TMP/src/android/content/SharedPreferences.java" "$TMP/src/org/json/JSONArray.java" \
 "$TMP/src/org/json/JSONObject.java" "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" \
 app/src/main/java/com/cmyk/imgstalker/SiteVisitStore.java tests/SiteNavigationTitleTest.java tests/SiteNavigationHistoryTest.java
java -cp "$TMP/out" com.cmyk.imgstalker.SiteNavigationTitleTest
java -cp "$TMP/out" com.cmyk.imgstalker.SiteNavigationHistoryTest
python - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
m = Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
assert '"お気に入り"' not in m and '"お気に入り一覧"' not in m
assert 'historyNavigationFloatButton()' in m and 'R.drawable.ic_history_stalker' in m
assert 'confirmBookmarkRemoval(entry.url, entry.displayTitle(), change)' in m
assert 'if (bookmarksOnly && currentlyBookmarked)' in m
assert 'confirmBookmarkRemoval(url, SiteVisitStore.displayTitleForUrl' in m
assert 'showStableNavigationDialog(dialog, shell, width, height);' in m
assert 'showStableNavigationConfirmation("履歴を削除"' in m
assert 'showStableNavigationConfirmation("ブックマークを解除"' in m
assert 'SiteVisitStore.removeHistory(this, entry.url)' in m
assert 'row.setOnLongClickListener(historyLongPress)' in m
assert 'details.setOnLongClickListener(historyLongPress)' in m
assert 'window.setWindowAnimations(0)' in m
assert 'window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,' in m
assert m.index('window.setWindowAnimations(0)') < m.index('dialog.show();',m.index('private void showStableNavigationDialog'))
assert 'SOFT_INPUT_ADJUST_NOTHING' in m
assert 'URLを入力してください' in m
x=ET.parse('app/src/main/res/drawable/ic_history_stalker.xml')
assert x.getroot().tag.endswith('vector')
assert len(list(x.getroot()))==3
namespace='{http://schemas.android.com/apk/res/android}'
paths=list(x.getroot())
assert paths[0].get(namespace+'strokeWidth')==paths[2].get(namespace+'strokeWidth')
assert paths[0].get(namespace+'strokeColor')==paths[2].get(namespace+'strokeColor')=='#A9A999'
assert paths[1].get(namespace+'fillColor')=='#A9A999'
print('PASS: history long-press, stable all-navigation dialogs, bookmark confirmation, vector stroke matching')
PY
