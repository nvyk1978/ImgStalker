# ImgStalker v0.1.84 (85)

Android 16 / SDK 36 source package for ImgStalker.

## v0.1.84 — Instagram timeline-direct media resolution

Based on v0.1.83 Web Source Pipeline v3.

Observed v0.1.83 behavior:
- Profile identity and Web GraphQL timeline discovery succeed and can reach the 300-post cap.
- Per-post HTML / post GraphQL requests can still return HTTP 200 while yielding no usable post media, producing repeated `media_not_resolved` results.
- The timeline response itself already carries structured post/media objects for many posts.

v0.1.84 changes:
- Web GraphQL timeline discovery now extracts usable media directly from each discovered post object.
- Images, videos, and carousel children are emitted immediately from timeline data when available.
- A post with usable timeline media is marked resolved before any per-post HTTP resolver request is queued.
- Per-post HTML/Web-GraphQL resolver remains as fallback only for timeline objects that do not contain usable media.
- Resume-seeded posts can be upgraded to timeline-direct resolution; any already queued resolver task becomes a no-op after the post is marked complete.
- Invalid synthetic shortcodes such as `null`, `undefined`, and `none` are rejected before they can become `/p/null/` tasks.
- Added diagnostics: `SNS_IG_SOURCE_TIMELINE_RESOLVE`, `SNS_IG_SOURCE_TIMELINE_FALLBACK_QUEUE`, and `directResolved=` counts.

Retained:
- browser=false normal Instagram path.
- Profile source + Web GraphQL discovery and 300-post ceiling.
- Existing ordered UI/downloader path and carousel expansion rules.
- Video/Reel cover images are not treated as replacement media when the actual video URL is unavailable.
- Existing resume sidecar, saved-media ledger, foreground service, WakeLock, rate-limit gate, and anti-spam behavior.
- Fixed applicationId and signing keystore for overwrite installation.

Package: versionName 0.1.84 / versionCode 85.
