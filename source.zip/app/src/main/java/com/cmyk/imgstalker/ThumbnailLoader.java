package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ThumbnailLoader {
    private static final int MAX_THUMB_BYTES = 32 * 1024 * 1024;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final String userAgent;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final LruCache<String, Bitmap> cache;

    public ThumbnailLoader(Context context) {
        String baseUa;
        try {
            baseUa = WebSettings.getDefaultUserAgent(context);
        } catch (Exception e) {
            baseUa = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36";
        }
        userAgent = baseUa + " ImgStalker/0.1.5";
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024L);
        int cacheKb = Math.max(4096, Math.min(32768, maxKb / 12));
        cache = new LruCache<String, Bitmap>(cacheKb) {
            @Override protected int sizeOf(String key, Bitmap value) {
                return Math.max(1, value.getByteCount() / 1024);
            }
        };
    }

    public void load(ImageView view, MediaItem item) {
        if (view == null || item == null) return;
        if (item.kind != MediaItem.Kind.IMAGE) {
            clear(view);
            view.setVisibility(View.GONE);
            return;
        }
        view.setVisibility(View.VISIBLE);
        String key = item.url;
        view.setTag(key);
        view.setImageDrawable(null);
        view.setAlpha(0.55f);

        Bitmap hit = cache.get(key);
        if (hit != null && !hit.isRecycled()) {
            view.setImageBitmap(hit);
            view.setAlpha(1f);
            return;
        }

        pool.submit(() -> {
            Bitmap bitmap = null;
            try {
                bitmap = fetch(item);
                if (bitmap != null) cache.put(key, bitmap);
            } catch (Exception e) {
                DiagnosticLog.logException("THUMB_FAIL url=" + key, e);
            }
            Bitmap ready = bitmap;
            main.post(() -> {
                Object tag = view.getTag();
                if (!(tag instanceof String) || !key.equals(tag)) return;
                if (ready != null) {
                    view.setImageBitmap(ready);
                    view.setAlpha(1f);
                } else {
                    view.setImageDrawable(null);
                    view.setAlpha(0.55f);
                }
            });
        });
    }

    public void clear(ImageView view) {
        if (view == null) return;
        view.setTag(null);
        view.setImageDrawable(null);
        view.setAlpha(0.55f);
    }

    public void shutdown() {
        pool.shutdownNow();
        cache.evictAll();
    }

    private Bitmap fetch(MediaItem item) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(item.url).openConnection();
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(12000);
        con.setReadTimeout(16000);
        con.setRequestProperty("User-Agent", userAgent);
        con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
        con.setRequestProperty("Accept-Encoding", "identity");
        con.setRequestProperty("Sec-Fetch-Dest", "image");
        con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
        if (item.referrer != null && !item.referrer.isEmpty()) con.setRequestProperty("Referer", item.referrer);
        String cookie = CookieManager.getInstance().getCookie(item.url);
        if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
        con.connect();
        int code = con.getResponseCode();
        String contentType = con.getContentType();
        long contentLength = con.getContentLengthLong();
        DiagnosticLog.log("THUMB_HTTP code=" + code
                + " type=" + contentType
                + " length=" + contentLength
                + " finalUrl=" + con.getURL()
                + " ref=" + item.referrer
                + " cookie=" + (cookie == null ? 0 : cookie.length()));
        if (code < 200 || code >= 400) throw new IllegalStateException("HTTP " + code);
        if (contentType != null && !contentType.toLowerCase().startsWith("image/")) {
            throw new IllegalStateException("unexpected content-type " + contentType);
        }
        if (contentLength > MAX_THUMB_BYTES) {
            throw new IllegalStateException("thumbnail source too large: " + contentLength);
        }

        byte[] data;
        try (InputStream in = con.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[32 * 1024];
            int total = 0;
            int n;
            while ((n = in.read(buf)) >= 0) {
                total += n;
                if (total > MAX_THUMB_BYTES) throw new IllegalStateException("thumbnail source too large");
                out.write(buf, 0, n);
            }
            data = out.toByteArray();
        } finally {
            con.disconnect();
        }

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new IllegalStateException("decode bounds failed bytes=" + data.length);
        }
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        opts.inSampleSize = calculateSample(bounds.outWidth, bounds.outHeight, 320, 240);
        Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
        if (bitmap == null) throw new IllegalStateException("bitmap decode failed bytes=" + data.length);
        DiagnosticLog.log("THUMB_OK url=" + item.url + " source=" + bounds.outWidth + "x" + bounds.outHeight
                + " bytes=" + data.length + " sample=" + opts.inSampleSize);
        return bitmap;
    }

    private static int calculateSample(int width, int height, int reqWidth, int reqHeight) {
        int sample = 1;
        if (width <= 0 || height <= 0) return sample;
        while ((width / (sample * 2)) >= reqWidth && (height / (sample * 2)) >= reqHeight) sample *= 2;
        return Math.max(1, sample);
    }
}
