#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
root=Path('app/src/main/java/com/cmyk/imgstalker')
main=(root/'MainActivity.java').read_text()
start=main.index('Runnable metadataChanged = () -> {')
end=main.index('thumbnailLoader = provider.thumbnails(this, metadataChanged);',start)
callback=main[start:end]
assert 'desiredMode == AnalysisModeRouter.Mode.INSTAGRAM' in callback
assert 'desiredMode == AnalysisModeRouter.Mode.THREADS' in callback
assert 'refreshVisibleSnsThumbnailMetadata();' in callback
assert 'adapter.notifyDataSetChanged();' in callback.split('} else {')[1]
assert 'adapter.notifyDataSetChanged();' not in callback.split('} else {')[0]
start=main.index('private void refreshVisibleSnsThumbnailMetadata()')
end=main.index('private void prefetchSnsThumbnailWindow(',start)
refresh=main[start:end]
assert 'mediaGrid.getFirstVisiblePosition()' in refresh
assert 'key.equals(holder.thumb.getTag())' in refresh
assert 'holder.resolutionOverlay.setText(resolution);' in refresh
assert 'holder.duration.setText(' in refresh
assert 'notifyDataSetChanged()' not in refresh
assert 'thumbnailLoader.load(' not in refresh
for name in ('InstagramThumbnailLoader.java','ThreadsThumbnailLoader.java'):
 src=(root/name).read_text()
 assert 'if (!sameBinding) view.setImageDrawable(null);' in src
 assert 'else view.setAlpha(1f);' in src
 assert 'if (target.getDrawable() == null) target.setAlpha(0.55f);' in src
 assert 'if (metadataNowAvailable && metadataChanged != null) metadataChanged.run();' in src
assert 'versionCode 176' in Path('app/build.gradle').read_text()
assert "versionName '0.1.175'" in Path('app/build.gradle').read_text()
print('PASS: SNS thumbnail callbacks update visible metadata only; recycled cells and same-key images handled separately')
PY
