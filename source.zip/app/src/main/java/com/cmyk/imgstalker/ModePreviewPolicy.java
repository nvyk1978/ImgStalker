package com.cmyk.imgstalker;

/** Media preview URL state belongs to its owning source mode, not to a global X helper. */
interface ModePreviewPolicy {
    boolean isSpecialVideo(String url);
    boolean isKnownFailed(String url);
    String resolvedUrl(String url);
    String resolveFresh(String url, String referrer, String userAgent);
    void markRecovered(String sourceUrl, String resolvedUrl);
    void markFailed(String url);
    void reset();
}
