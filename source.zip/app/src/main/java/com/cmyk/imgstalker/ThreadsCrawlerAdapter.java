package com.cmyk.imgstalker;
import android.webkit.WebView;
import java.util.List;
/** Strict independent Threads scanner. Never touches the X/Instagram/NORMAL engines. */
final class ThreadsCrawlerAdapter implements ModeCrawler {
    private final ThreadsCrawlerEngine core;
    ThreadsCrawlerAdapter(WebView view, CrawlerEngine.Listener listener) { core = new ThreadsCrawlerEngine(view, listener); }
    @Override public void start(String url, boolean pages, boolean details, boolean intelligent, boolean images, boolean videos, int px) {
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.THREADS) { core.cancel(); throw new IllegalArgumentException("Threads host required"); }
        core.start(url, pages, images, videos, px);
    }
    @Override public void cancel() { core.cancel(); }
    @Override public void requestGracefulStop() { core.requestGracefulStop(); }
    @Override public boolean recoverFromStall() { return core.recoverFromStall(); }
    @Override public boolean hasPendingWork() { return core.hasPendingWork(); }
    @Override public String progressSnapshot() { return core.progressSnapshot(); }
    @Override public void seedExternalResumeMedia(List<MediaItem> items) { core.seedExternalResumeMedia(items); }
    @Override public void seedContinuationResults(List<MediaItem> items) { core.seedExternalResumeMedia(items); }
    @Override public boolean isIncompleteCompletion() { return core.isIncompleteCompletion(); }
    @Override public String getIncompleteCompletionReason() { return core.getIncompleteCompletionReason(); }
}
