package com.cmyk.imgstalker;

import android.content.Context;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Process-independent checkpoint for every analysis mode, including ordinary web pages,
 * streams and SNS. Stored in private storage; the existing SNS download-sidecar is unchanged.
 * A checkpoint is only written on an ordered single-thread executor by the owner Activity.
 */
final class AnalysisSessionStore {
    static final int SCHEMA = 1;
    static final class State {
        String sourceUrl = "";
        boolean complete;
        boolean pages, details, intelligent, images, videos, background, xReposts, xGifAsGif;
        int targetPx = 640;
        long updatedAt;
        JSONObject cursor;
        final ArrayList<MediaItem> mediaItems = new ArrayList<>();
    }
    private AnalysisSessionStore() {}
    // X retains its original on-disk location to keep 0.1.135 resume compatibility.
    // NORMAL and INSTAGRAM checkpoints can no longer overwrite X or each other.
    private static AtomicFile file(Context context, String url) {
        AnalysisModeRouter.Mode mode = AnalysisModeRouter.fromUrl(url);
        String name = mode == AnalysisModeRouter.Mode.X ? "imgstalker_analysis_checkpoint.json"
                : mode == AnalysisModeRouter.Mode.INSTAGRAM ? "imgstalker_ig_checkpoint.json"
                : "imgstalker_normal_checkpoint.json";
        if (mode == AnalysisModeRouter.Mode.NORMAL) {
            File path = NormalCheckpointStore.checkpoint(context, url);
            File parent = path.getParentFile();
            if (parent != null && !parent.isDirectory() && !parent.mkdirs() && !parent.isDirectory())
                throw new IllegalStateException("Unable to create NORMAL checkpoint folder");
            return new AtomicFile(path);
        }
        return new AtomicFile(new File(context.getFilesDir(), name));
    }
    static void write(Context context, State state) {
        if (context == null || state == null || state.sourceUrl.isEmpty()) return;
        FileOutputStream output = null;
        AtomicFile atomic = file(context, state.sourceUrl);
        try {
            JSONObject root = new JSONObject();
            root.put("schema", SCHEMA);
            root.put("url", state.sourceUrl);
            root.put("complete", state.complete);
            root.put("updatedAt", state.updatedAt);
            root.put("pages", state.pages);
            root.put("details", state.details);
            root.put("intelligent", state.intelligent);
            root.put("images", state.images);
            root.put("videos", state.videos);
            root.put("background", state.background);
            root.put("xReposts", state.xReposts);
            root.put("xGifAsGif", state.xGifAsGif);
            root.put("targetPx", state.targetPx);
            if (state.cursor != null) root.put("cursor", state.cursor);
            JSONArray media = new JSONArray();
            for (MediaItem item : state.mediaItems) {
                if (item == null || item.url == null || item.url.isEmpty()) continue;
                JSONObject m = new JSONObject();
                m.put("url", item.url);
                m.put("ref", item.referrer);
                m.put("kind", item.kind.name());
                m.put("width", item.width);
                m.put("height", item.height);
                m.put("duration", item.durationMs);
                m.put("dedup", item.dedupKey);
                m.put("order", item.displayOrder);
                media.put(m);
            }
            root.put("media", media);
            output = atomic.startWrite();
            byte[] encoded = root.toString().getBytes(StandardCharsets.UTF_8);
            output.write(encoded);
            atomic.finishWrite(output);
            if (AnalysisModeRouter.fromUrl(state.sourceUrl) == AnalysisModeRouter.Mode.NORMAL)
                NormalSafMirror.write(context, state.sourceUrl, encoded);
            DiagnosticLog.log("ANALYSIS_CHECKPOINT_WRITE complete=" + state.complete
                    + " media=" + state.mediaItems.size()
                    + " cursor=" + (state.cursor != null) + " url=" + state.sourceUrl);
        } catch (Throwable t) {
            if (output != null) atomic.failWrite(output);
            DiagnosticLog.logException("ANALYSIS_CHECKPOINT_WRITE_FAIL", t);
        }
    }
    static boolean existsForUrl(Context context, String url) {
        if (url == null || url.trim().isEmpty()) return false;
        State state = load(context, url);
        return state != null && (AnalysisModeRouter.fromUrl(url) == AnalysisModeRouter.Mode.NORMAL
                ? NormalCheckpointStore.matches(url, state.sourceUrl)
                : url.trim().equals(state.sourceUrl));
    }

    static boolean deleteForUrl(Context context, String url) {
        if (context == null || url == null || url.trim().isEmpty()) return false;
        if (!existsForUrl(context, url)) return false;
        file(context, url).delete();
        if (AnalysisModeRouter.fromUrl(url) == AnalysisModeRouter.Mode.NORMAL) {
            NormalSafMirror.delete(context, url);
            // Never delete a legacy NORMAL checkpoint belonging to a different target.
            File legacy = new File(context.getFilesDir(), "imgstalker_normal_checkpoint.json");
            State prior = readState(context, legacy, url);
            if (prior != null) legacy.delete();
        }
        DiagnosticLog.log("ANALYSIS_CHECKPOINT_DELETE url=" + url);
        return true;
    }

    static State load(Context context) {
        if (context == null) return null;
        State latest = null;
        for (String sample : new String[]{"https://x.com/", "https://instagram.com/"}) {
            State found = load(context, sample);
            if (found != null && (latest == null || found.updatedAt > latest.updatedAt)) latest = found;
        }
        File[] sites = NormalCheckpointStore.root(context).listFiles();
        if (sites != null) for (File site : sites) {
            File[] jsons = site.listFiles((dir, name) -> name.endsWith(".json"));
            if (jsons == null) continue;
            for (File json : jsons) {
                State found = readState(context, json, null);
                if (found != null && AnalysisModeRouter.fromUrl(found.sourceUrl) == AnalysisModeRouter.Mode.NORMAL
                        && (latest == null || found.updatedAt > latest.updatedAt)) latest = found;
            }
        }
        State legacy = readState(context, new File(context.getFilesDir(), "imgstalker_normal_checkpoint.json"), null);
        if (legacy != null && AnalysisModeRouter.fromUrl(legacy.sourceUrl) == AnalysisModeRouter.Mode.NORMAL
                && (latest == null || legacy.updatedAt > latest.updatedAt)) latest = legacy;
        return latest;
    }

    static State load(Context context, String url) {
        if (context == null || url == null || url.isEmpty()) return null;
        State current = readAtomic(file(context, url), url);
        if (current != null) return current;
        if (AnalysisModeRouter.fromUrl(url) == AnalysisModeRouter.Mode.NORMAL) {
            State legacy = readState(context, new File(context.getFilesDir(), "imgstalker_normal_checkpoint.json"), url);
            if (legacy != null) return legacy;
            byte[] remote = NormalSafMirror.read(context, url);
            if (remote != null) {
                try (ByteArrayInputStream input = new ByteArrayInputStream(remote)) {
                    return parseState(input, url);
                } catch (Throwable t) { DiagnosticLog.logException("NORMAL_SAF_CHECKPOINT_PARSE_FAIL", t); }
            }
        }
        return null;
    }

    private static State readAtomic(AtomicFile atomic, String expectedUrl) {
        try (FileInputStream in = atomic.openRead()) { return parseState(in, expectedUrl); }
        catch (java.io.FileNotFoundException ignored) { return null; }
        catch (Throwable t) { DiagnosticLog.logException("ANALYSIS_CHECKPOINT_LOAD_FAIL", t); return null; }
    }

    private static State readState(Context context, File source, String expectedUrl) {
        if (source == null) return null;
        try (FileInputStream in = new FileInputStream(source)) { return parseState(in, expectedUrl); }
        catch (java.io.FileNotFoundException ignored) { return null; }
        catch (Throwable t) { DiagnosticLog.logException("ANALYSIS_CHECKPOINT_LOAD_FAIL", t); return null; }
    }

    private static State parseState(InputStream in, String expectedUrl) throws Exception {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] bytes = new byte[8192];
            int n;
            while ((n = in.read(bytes)) >= 0) buffer.write(bytes, 0, n);
            JSONObject root = new JSONObject(buffer.toString(StandardCharsets.UTF_8.name()));
            if (root.optInt("schema", -1) != SCHEMA) return null;
            State state = new State();
            state.sourceUrl = root.optString("url", "");
            if (!(state.sourceUrl.startsWith("https://") || state.sourceUrl.startsWith("http://"))) return null;
            if (expectedUrl != null && (AnalysisModeRouter.fromUrl(state.sourceUrl) != AnalysisModeRouter.fromUrl(expectedUrl)
                    || (AnalysisModeRouter.fromUrl(expectedUrl) == AnalysisModeRouter.Mode.NORMAL
                        && !NormalCheckpointStore.matches(expectedUrl, state.sourceUrl)))) return null;
            state.complete = root.optBoolean("complete", false);
            state.updatedAt = root.optLong("updatedAt", 0L);
            state.pages = root.optBoolean("pages", true);
            state.details = root.optBoolean("details", true);
            state.intelligent = root.optBoolean("intelligent", true);
            state.images = root.optBoolean("images", true);
            state.videos = root.optBoolean("videos", true);
            state.background = root.optBoolean("background", false);
            state.xReposts = root.optBoolean("xReposts", false);
            state.xGifAsGif = root.optBoolean("xGifAsGif", true);
            state.targetPx = root.optInt("targetPx", 640);
            state.cursor = root.optJSONObject("cursor");
            JSONArray media = root.optJSONArray("media");
            if (media != null) for (int i = 0; i < media.length(); i++) {
                JSONObject m = media.optJSONObject(i);
                if (m == null) continue;
                String mediaUrl = m.optString("url", "");
                if (mediaUrl.isEmpty()) continue;
                try {
                    state.mediaItems.add(new MediaItem(mediaUrl, m.optString("ref", ""),
                            MediaItem.Kind.valueOf(m.optString("kind", "IMAGE")), false,
                            m.optInt("width", 0), m.optInt("height", 0),
                            m.optLong("duration", 0L), m.optString("dedup", ""),
                            m.optLong("order", Long.MAX_VALUE)));
                } catch (IllegalArgumentException ignored) { }
            }
            DiagnosticLog.log("ANALYSIS_CHECKPOINT_LOAD complete=" + state.complete
                    + " media=" + state.mediaItems.size() + " cursor=" + (state.cursor != null)
                    + " ageMs=" + (System.currentTimeMillis() - state.updatedAt));
            return state;
    }
}
