#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/stub/android/content" "$TMP/stub/android/util" "$TMP/stub/org/json" "$TMP/stub/com/cmyk/imgstalker" "$TMP/out"
cat > "$TMP/stub/android/content/Context.java" <<'JAVA'
package android.content;
public class Context {
 private final java.io.File root;
 public Context(java.io.File root) {this.root=root;}
 public java.io.File getFilesDir() {return root;}
}
JAVA
cat > "$TMP/stub/android/util/AtomicFile.java" <<'JAVA'
package android.util;
public class AtomicFile {
 private final java.io.File file;
 public AtomicFile(java.io.File f) {file=f;}
 public java.io.FileInputStream openRead() throws java.io.IOException {return new java.io.FileInputStream(file);}
 public java.io.FileOutputStream startWrite() throws java.io.IOException {return new java.io.FileOutputStream(file);}
 public void finishWrite(java.io.FileOutputStream out) {try {out.close();}catch(Exception e){throw new RuntimeException(e);}}
 public void failWrite(java.io.FileOutputStream out) {try {out.close();}catch(Exception ignored){}}
}
JAVA
# Minimal roundtripping JSON API stub: only the Java data model is tested here.
# Android's real org.json implementation is supplied by the runtime.
cat > "$TMP/stub/org/json/JSONObject.java" <<'JAVA'
package org.json;
public class JSONObject implements java.io.Serializable {
 final java.util.LinkedHashMap<String,Object> m;
 public JSONObject(){m=new java.util.LinkedHashMap<>();}
 @SuppressWarnings("unchecked") public JSONObject(String value) throws Exception {
   byte[] raw=java.util.Base64.getDecoder().decode(value);
   try(java.io.ObjectInputStream in=new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(raw))) {
    m=(java.util.LinkedHashMap<String,Object>)in.readObject();
   }
 }
 public JSONObject put(String key,Object value){m.put(key,value);return this;}
 public int optInt(String key,int fallback){Object o=m.get(key);return o instanceof Number?((Number)o).intValue():fallback;}
 public String optString(String key,String fallback){Object o=m.get(key);return o instanceof String?(String)o:fallback;}
 public JSONArray optJSONArray(String key){Object o=m.get(key);return o instanceof JSONArray?(JSONArray)o:null;}
 @Override public String toString(){
  try {java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();try(java.io.ObjectOutputStream out=new java.io.ObjectOutputStream(bytes)){out.writeObject(m);}return java.util.Base64.getEncoder().encodeToString(bytes.toByteArray());}
  catch(Exception e){throw new RuntimeException(e);}
 }
}
JAVA
cat > "$TMP/stub/org/json/JSONArray.java" <<'JAVA'
package org.json;
public class JSONArray implements java.io.Serializable {
 final java.util.ArrayList<Object> items=new java.util.ArrayList<>();
 public JSONArray put(Object item){items.add(item);return this;}
 public int length(){return items.size();}
 public JSONObject optJSONObject(int i){return i>=0&&i<items.size()&&items.get(i) instanceof JSONObject?(JSONObject)items.get(i):null;}
}
JAVA
cat > "$TMP/stub/com/cmyk/imgstalker/StoreStubs.java" <<'JAVA'
package com.cmyk.imgstalker;
import java.net.URI;
import java.util.Locale;
final class AnalysisModeRouter {
 enum Mode { NORMAL, X, INSTAGRAM }
 static Mode fromUrl(String url) {
  try {String h=new URI(url).getHost().toLowerCase(Locale.ROOT);if(h.endsWith("instagram.com"))return Mode.INSTAGRAM;if(h.endsWith("x.com"))return Mode.X;}
  catch(Exception ignored){}return Mode.NORMAL;
 }
}
final class NormalCheckpointStore {
 static String key(String url){return AnalysisModeRouter.fromUrl(url)==AnalysisModeRouter.Mode.NORMAL ? url.replaceAll("\\?page=\\d+$", "") : "";}
}
final class SnsResumeStore {
 static final class Target {
  final String categoryName,accountName;
  Target(String category,String account){categoryName=category;accountName=account;}
 }
 static Target targetForUrl(String url) {
  try {URI uri=new URI(url);String host=uri.getHost().toLowerCase(Locale.ROOT);String[] parts=uri.getPath().split("/");
   if(parts.length<2||parts[1].isEmpty())return null;
   if(host.endsWith("x.com"))return new Target("X",parts[1]);
   if(host.endsWith("instagram.com"))return new Target("Instagram",parts[1]);
  } catch(Exception ignored){} return null;
 }
 static String savedMediaKey(MediaItem item) {
  return item == null || item.kind==MediaItem.Kind.STREAM ? "" : item.dedupKey.isEmpty()?item.kind.name()+"|"+item.url:item.dedupKey;
 }
}
final class DiagnosticLog {
 static void log(String text){}
 static void logException(String k,Throwable e){throw new AssertionError(k,e);}
}
JAVA
cat > "$TMP/stub/com/cmyk/imgstalker/DiscoveredMediaLedgerTest.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.content.Context;
import java.io.File;
import java.util.*;
public class DiscoveredMediaLedgerTest {
 static void eq(int expected,int actual){if(expected!=actual)throw new AssertionError("want "+expected+" got "+actual);}
 static void yes(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
 static List<MediaItem> batch(int start,int end,MediaItem.Kind kind) {
  ArrayList<MediaItem> result=new ArrayList<>();
  for(int i=start;i<end;i++)result.add(new MediaItem("https://cdn.example/v/"+i,"",kind,false,0,0,0L,"media_"+i));
  return result;
 }
 public static void main(String[] args) throws Exception {
  Context context=new Context(new File(args[0]));
  String normal="https://example.com/photos?page=1";
  DiscoveredMediaLedger.Snapshot s=DiscoveredMediaLedger.merge(context,normal,batch(0,800,MediaItem.Kind.IMAGE));
  eq(800,s.imageCount());eq(0,s.videoCount());
  // A restarted process re-reads the same ledger; a partial reload must not shrink it.
  s=DiscoveredMediaLedger.merge(context,"https://example.com/photos?page=2",batch(400,900,MediaItem.Kind.IMAGE));
  eq(900,s.imageCount());
  s=DiscoveredMediaLedger.merge(context,normal,batch(0,1100,MediaItem.Kind.IMAGE));
  eq(1100,s.imageCount());
  s=DiscoveredMediaLedger.merge(context,normal,batch(0,500,MediaItem.Kind.IMAGE));
  eq(1100,s.imageCount());
  // Streams are not media counts; image and video are independent.
  s=DiscoveredMediaLedger.merge(context,normal,Arrays.asList(new MediaItem("stream","",MediaItem.Kind.STREAM,false),
    new MediaItem("https://cdn/video/1","",MediaItem.Kind.VIDEO,false,0,0,0L,"movie_1")));
  eq(1100,s.imageCount());eq(1,s.videoCount());
  String xA="https://x.com/UserA", xB="https://x.com/UserB", ig="https://instagram.com/UserA";
  DiscoveredMediaLedger.merge(context,xA,batch(0,12,MediaItem.Kind.IMAGE));
  eq(12,DiscoveredMediaLedger.merge(context,"https://x.com/usera",Collections.emptyList()).imageCount());
  eq(0,DiscoveredMediaLedger.merge(context,xB,Collections.emptyList()).imageCount());
  eq(0,DiscoveredMediaLedger.merge(context,ig,Collections.emptyList()).imageCount());
  // Cold read of historical NORMAL results from persisted JSON.
  DiscoveredMediaLedger.Snapshot loaded=DiscoveredMediaLedger.merge(context,normal,Collections.emptyList());
  eq(1100,loaded.imageCount());eq(1,loaded.videoCount());
  yes(loaded.mediaItems().size()==1101,"materialization for display");
  // Identities must be domain/page scoped for NORMAL and account scoped for SNS.
  yes(!DiscoveredMediaLedger.identity("https://a.com/").equals(DiscoveredMediaLedger.identity("https://b.com/")),"normal isolation");
  System.out.println("PASS: durable 800/800 -> 800/900 -> 800/1100; account isolation; types; restart");
 }
}
JAVA
javac -encoding UTF-8 -d "$TMP/out" \
 $(find "$TMP/stub" -type f -name '*.java') \
 app/src/main/java/com/cmyk/imgstalker/MediaItem.java \
 app/src/main/java/com/cmyk/imgstalker/DiscoveredMediaLedger.java
java -cp "$TMP/out" com.cmyk.imgstalker.DiscoveredMediaLedgerTest "$TMP/files"
