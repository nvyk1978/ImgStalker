package com.cmyk.imgstalker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.DocumentsContract;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** ImgStalker N Explorer: N palette, storage switch, hierarchy navigation, new folder and save confirmation. */
public final class FolderPickerActivity extends Activity {
    private static final int REQ_TREE_GRANT = 9101;
    private static final int BG = Color.rgb(48, 48, 48);
    private static final int DARK = Color.rgb(37, 32, 32);
    private static final int GRAY = Color.rgb(69, 64, 64);
    private static final int LGRAY = Color.rgb(101, 96, 96);
    private static final int BLUE = Color.rgb(34, 51, 85);
    private static final int N_WHITE = Color.rgb(169, 169, 153);
    private static final int TEXT = Color.WHITE;

    private final List<StorageTarget> storages = new ArrayList<>();
    private final ExecutorService listingExecutor = Executors.newSingleThreadExecutor();
    private final AtomicInteger listingGeneration = new AtomicInteger();
    private File currentDir;
    private File rootLimit;
    private TextView storageView;
    private TextView pathView;
    private LinearLayout folderList;
    private GripScrollHost scrollHost;
    private File pendingGrantDirectory;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DiagnosticLog.install(this);
        buildStorageTargets();
        File selected = SavePrefs.directory(this);
        File start = selected == null ? Environment.getExternalStorageDirectory() : selected;
        currentDir = start;
        rootLimit = matchingRoot(start);
        buildUi();
        refresh();
        DiagnosticLog.log("N_EXPLORER_OPEN current=" + currentDir.getAbsolutePath());
    }

    @Override protected void onDestroy() {
        listingGeneration.incrementAndGet();
        listingExecutor.shutdownNow();
        super.onDestroy();
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(14));
        root.setBackground(roundRect(BG, 14));

        TextView title = label("保存場所", 20, TEXT);
        title.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));

        storageView = label("", 16, TEXT);
        storageView.setGravity(Gravity.CENTER_VERTICAL);
        storageView.setPadding(dp(14), 0, dp(14), 0);
        storageView.setBackground(roundRect(GRAY, 10));
        storageView.setOnClickListener(v -> showStorageMenu());
        root.addView(storageView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        pathView = label("", 12, TEXT);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.START);
        pathView.setPadding(dp(4), dp(8), dp(4), dp(8));
        root.addView(pathView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        Button parent = button("親フォルダ", GRAY);
        Button create = button("新規フォルダ", GRAY);
        nav.addView(parent, new LinearLayout.LayoutParams(0, dp(44), 1f));
        LinearLayout.LayoutParams createLp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        createLp.leftMargin = dp(8);
        nav.addView(create, createLp);
        root.addView(nav);

        folderList = new LinearLayout(this);
        folderList.setOrientation(LinearLayout.VERTICAL);
        scrollHost = new GripScrollHost(this, folderList);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        scrollLp.topMargin = dp(10);
        scrollLp.bottomMargin = dp(10);
        root.addView(scrollHost, scrollLp);

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        Button reset = button("既定に戻す", GRAY);
        Button use = button("このフォルダを保存先にする", BLUE);
        footer.addView(reset, new LinearLayout.LayoutParams(0, dp(48), 0.85f));
        LinearLayout.LayoutParams useLp = new LinearLayout.LayoutParams(0, dp(48), 1.55f);
        useLp.leftMargin = dp(8);
        footer.addView(use, useLp);
        root.addView(footer);

        parent.setOnClickListener(v -> navigateParent());
        create.setOnClickListener(v -> showCreateFolder());
        reset.setOnClickListener(v -> {
            File target = SavePrefs.defaultDirectory();
            DiagnosticLog.log("N_EXPLORER_RESET_REQUEST path=" + target.getAbsolutePath());
            requestTreeGrant(target);
        });
        use.setOnClickListener(v -> {
            if (currentDir == null) return;
            DiagnosticLog.log("N_EXPLORER_CONFIRM_REQUEST path=" + currentDir.getAbsolutePath());
            requestTreeGrant(currentDir);
        });

        setContentView(root);
        root.post(() -> {
            Window window = getWindow();
            if (window == null) return;
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.width = Math.min(dp(560), Math.round(getResources().getDisplayMetrics().widthPixels * 0.94f));
            lp.height = Math.round(getResources().getDisplayMetrics().heightPixels * 0.78f);
            window.setAttributes(lp);
            window.setDimAmount(0.55f);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        });
    }


    private void requestTreeGrant(File requested) {
        if (requested == null) return;
        pendingGrantDirectory = requested;
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            Uri initial = documentUriForFile(requested);
            if (Build.VERSION.SDK_INT >= 26 && initial != null) {
                intent.putExtra("android.provider.extra.INITIAL_URI", initial);
            }
            DiagnosticLog.log("N_EXPLORER_SAF_REQUEST path=" + requested.getAbsolutePath()
                    + " initial=" + (initial == null ? "none" : initial));
            startActivityForResult(intent, REQ_TREE_GRANT);
        } catch (Throwable t) {
            DiagnosticLog.logException("N_EXPLORER_SAF_REQUEST_FAIL path=" + requested.getAbsolutePath(), t);
            Toast.makeText(this, "保存先の使用許可を開けませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private Uri documentUriForFile(File file) {
        if (file == null) return null;
        try {
            String path = file.getCanonicalPath();
            String primary = Environment.getExternalStorageDirectory().getCanonicalPath();
            String docId;
            if (path.equals(primary) || path.startsWith(primary + File.separator)) {
                String rel = path.equals(primary) ? "" : path.substring(primary.length() + 1);
                docId = "primary:" + rel.replace(File.separatorChar, '/');
            } else if (path.startsWith("/storage/")) {
                String rest = path.substring("/storage/".length());
                int slash = rest.indexOf('/');
                String volume = slash < 0 ? rest : rest.substring(0, slash);
                String rel = slash < 0 ? "" : rest.substring(slash + 1);
                docId = volume + ":" + rel.replace(File.separatorChar, '/');
            } else {
                return null;
            }
            return DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", docId);
        } catch (Throwable ignored) {
            return null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_TREE_GRANT) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try {
                    getContentResolver().takePersistableUriPermission(tree, flags);
                } catch (Throwable t) {
                    DiagnosticLog.logException("N_EXPLORER_SAF_PERSIST_FAIL uri=" + tree, t);
                }
                File picked = SavePrefs.fileFromTreeUri(tree);
                File finalDir = picked != null ? picked : pendingGrantDirectory;
                if (finalDir != null) {
                    SavePrefs.setDirectoryWithTree(this, finalDir, tree);
                    DiagnosticLog.log("N_EXPLORER_CONFIRM path=" + finalDir.getAbsolutePath() + " tree=" + tree);
                    Toast.makeText(this, "保存先を設定しました", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                    return;
                }
            }
            DiagnosticLog.log("N_EXPLORER_SAF_CANCEL path="
                    + (pendingGrantDirectory == null ? "none" : pendingGrantDirectory.getAbsolutePath()));
            Toast.makeText(this, "保存先は変更していません", Toast.LENGTH_SHORT).show();
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void navigateParent() {
        File parent = currentDir == null ? null : currentDir.getParentFile();
        if (parent == null) return;
        if (rootLimit != null && !isWithin(parent, rootLimit)) return;
        currentDir = parent;
        refresh();
    }

    private void refresh() {
        if (currentDir == null) return;
        final File requested = currentDir;
        final int generation = listingGeneration.incrementAndGet();
        pathView.setText(requested.getAbsolutePath());
        StorageTarget target = findStorage(requested);
        storageView.setText((target == null ? "ストレージ" : target.label) + "  ▾");
        folderList.removeAllViews();
        TextView loading = label("フォルダを読み込み中…", 14, N_WHITE);
        loading.setPadding(dp(12), dp(20), dp(12), dp(20));
        folderList.addView(loading);
        listingExecutor.execute(() -> {
            File[] dirs;
            try {
                dirs = requested.listFiles(file -> file != null && file.isDirectory() && !file.isHidden());
            } catch (Throwable error) {
                dirs = null;
            }
            if (dirs != null) Arrays.sort(dirs, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
            final File[] result = dirs;
            runOnUiThread(() -> {
                if (generation != listingGeneration.get() || !samePath(requested, currentDir)) return;
                folderList.removeAllViews();
                if (result == null) {
                    TextView empty = label("フォルダを読み込めません", 14, N_WHITE);
                    empty.setPadding(dp(12), dp(20), dp(12), dp(20));
                    folderList.addView(empty);
                    DiagnosticLog.log("N_EXPLORER_LIST_DENIED path=" + requested.getAbsolutePath());
                } else if (result.length == 0) {
                    TextView empty = label("フォルダはありません", 14, N_WHITE);
                    empty.setPadding(dp(12), dp(20), dp(12), dp(20));
                    folderList.addView(empty);
                } else {
                    for (File dir : result) addFolderRow(dir);
                }
                scrollHost.post(() -> {
                    scrollHost.scroll.scrollTo(0, 0);
                    scrollHost.updateThumb();
                });
                DiagnosticLog.log("N_EXPLORER_LIST path=" + requested.getAbsolutePath()
                        + " count=" + (result == null ? -1 : result.length));
            });
        });
    }

    private void addFolderRow(File dir) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), 0, dp(10), 0);
        row.setBackground(roundRect(DARK, 8));
        FolderGlyph icon = new FolderGlyph(this);
        row.addView(icon, new LinearLayout.LayoutParams(dp(38), dp(46)));
        TextView name = label(dir.getName(), 14, TEXT);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(46), 1f));
        row.setOnClickListener(v -> {
            currentDir = dir;
            refresh();
        });
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        rowLp.bottomMargin = dp(2);
        folderList.addView(row, rowLp);
    }

    private void showStorageMenu() {
        PopupMenu menu = new PopupMenu(this, storageView);
        for (int i = 0; i < storages.size(); i++) {
            menu.getMenu().add(0, i + 1, i, storages.get(i).label);
        }
        menu.setOnMenuItemClickListener(item -> {
            int index = item.getItemId() - 1;
            if (index < 0 || index >= storages.size()) return false;
            StorageTarget target = storages.get(index);
            currentDir = target.root;
            rootLimit = target.root;
            refresh();
            return true;
        });
        menu.show();
    }

    private void showCreateFolder() {
        EditText input = new EditText(this);
        input.setTextColor(TEXT);
        input.setHintTextColor(LGRAY);
        input.setHint("フォルダ名");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(18), dp(8), dp(18), 0);
        box.addView(input, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新規フォルダ")
                .setView(box)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("作成", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
            String name = input.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
            if (name.isEmpty()) {
                input.setError("フォルダ名を入力してください");
                return;
            }
            File out = new File(currentDir, name);
            if (out.exists()) {
                input.setError("同名フォルダがあります");
                return;
            }
            boolean ok = false;
            try { ok = out.mkdir(); } catch (Throwable ignored) { }
            if (!ok) {
                Toast.makeText(this, "この場所にはフォルダを作成できません", Toast.LENGTH_LONG).show();
                DiagnosticLog.log("N_EXPLORER_MKDIR_FAIL path=" + out.getAbsolutePath());
                return;
            }
            DiagnosticLog.log("N_EXPLORER_MKDIR path=" + out.getAbsolutePath());
            dialog.dismiss();
            refresh();
        }));
        dialog.show();
    }

    private void buildStorageTargets() {
        File primary = Environment.getExternalStorageDirectory();
        if (primary != null) storages.add(new StorageTarget("内部ストレージ", primary));
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                StorageManager manager = (StorageManager) getSystemService(STORAGE_SERVICE);
                if (manager != null) {
                    for (StorageVolume volume : manager.getStorageVolumes()) {
                        File dir = volume.getDirectory();
                        if (dir == null) continue;
                        boolean duplicate = false;
                        for (StorageTarget existing : storages) {
                            if (samePath(existing.root, dir)) {
                                duplicate = true;
                                break;
                            }
                        }
                        if (duplicate) continue;
                        String label = volume.getDescription(this);
                        if (label == null || label.trim().isEmpty()) {
                            label = volume.isRemovable() ? "外部ストレージ" : "ストレージ";
                        }
                        storages.add(new StorageTarget(label, dir));
                    }
                }
            } catch (Throwable error) {
                DiagnosticLog.logException("N_EXPLORER_STORAGE_LIST_FAIL", error);
            }
        }
    }

    private StorageTarget findStorage(File file) {
        if (file == null) return null;
        StorageTarget best = null;
        int bestLength = -1;
        for (StorageTarget target : storages) {
            if (isWithin(file, target.root)) {
                int length = target.root.getAbsolutePath().length();
                if (length > bestLength) {
                    best = target;
                    bestLength = length;
                }
            }
        }
        return best;
    }

    private File matchingRoot(File file) {
        StorageTarget target = findStorage(file);
        return target == null ? Environment.getExternalStorageDirectory() : target.root;
    }

    private static File nearestExistingDirectory(File file) {
        File current = file;
        while (current != null && (!current.exists() || !current.isDirectory())) current = current.getParentFile();
        return current;
    }

    private static boolean isWithin(File child, File root) {
        if (child == null || root == null) return false;
        try {
            String c = child.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Throwable error) {
            return false;
        }
    }

    private static boolean samePath(File a, File b) {
        if (a == null || b == null) return false;
        try { return a.getCanonicalFile().equals(b.getCanonicalFile()); }
        catch (Throwable error) { return a.equals(b); }
    }

    private TextView label(String text, float sizeSp, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private Button button(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(TEXT);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setBackground(roundRect(color, 10));
        button.setStateListAnimator(null);
        return button;
    }

    private GradientDrawable roundRect(int color, float radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private static final class StorageTarget {
        final String label;
        final File root;
        StorageTarget(String label, File root) {
            this.label = label;
            this.root = root;
        }
    }

    private final class FolderGlyph extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        FolderGlyph(Context context) { super(context); paint.setColor(N_WHITE); paint.setStyle(android.graphics.Paint.Style.FILL); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            android.graphics.RectF body = new android.graphics.RectF(cx - dp(10), cy - dp(6), cx + dp(10), cy + dp(8));
            canvas.drawRoundRect(body, dp(2.5f), dp(2.5f), paint);
            android.graphics.RectF tab = new android.graphics.RectF(cx - dp(8), cy - dp(10), cx + dp(1), cy - dp(4));
            canvas.drawRoundRect(tab, dp(2), dp(2), paint);
        }
    }

    /** N Explorer directly grabbable scrollbar: narrow visible thumb, wide touch target. */
    private final class GripScrollHost extends FrameLayout {
        final TrackingScrollView scroll;
        final View thumb;
        final View hit;
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable fade;
        int thumbHeight;
        boolean dragging;

        GripScrollHost(Context context, View child) {
            super(context);
            scroll = new TrackingScrollView(context);
            scroll.setVerticalScrollBarEnabled(false);
            scroll.addView(child, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            thumb = new View(context);
            thumb.setBackground(roundRect(N_WHITE, 2));
            fade = () -> thumb.animate().alpha(0f).setDuration(260).start();
            FrameLayout.LayoutParams thumbLp = new FrameLayout.LayoutParams(dp(4), dp(40), Gravity.END | Gravity.TOP);
            thumbLp.rightMargin = dp(2);
            addView(thumb, thumbLp);

            hit = new View(context);
            addView(hit, new FrameLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END));
            hit.setOnTouchListener((v, event) -> handleGrip(event));
            post(this::updateThumb);
        }

        void showThumb() {
            handler.removeCallbacks(fade);
            thumb.animate().cancel();
            thumb.setAlpha(1f);
            if (!dragging) handler.postDelayed(fade, 900);
        }

        void updateThumb() {
            if (scroll.getChildCount() == 0 || getHeight() <= 0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content - viewport);
            if (range <= 0) {
                thumb.setVisibility(View.GONE);
                return;
            }
            thumb.setVisibility(View.VISIBLE);
            thumbHeight = Math.max(dp(36), Math.round(viewport * (viewport / (float) Math.max(viewport, content))));
            thumbHeight = Math.min(viewport, thumbHeight);
            int track = Math.max(1, viewport - thumbHeight);
            float ratio = scroll.getScrollY() / (float) Math.max(1, range);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) thumb.getLayoutParams();
            lp.height = thumbHeight;
            lp.topMargin = Math.round(track * ratio);
            lp.gravity = Gravity.END | Gravity.TOP;
            lp.rightMargin = dp(2);
            thumb.setLayoutParams(lp);
        }

        boolean handleGrip(MotionEvent event) {
            if (thumb.getVisibility() != View.VISIBLE) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true;
                    showThumb();
                    moveTo(event.getY());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    moveTo(event.getY());
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    showThumb();
                    return true;
                default:
                    return false;
            }
        }

        void moveTo(float y) {
            if (scroll.getChildCount() == 0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content - viewport);
            int track = Math.max(1, viewport - thumbHeight);
            float ratio = Math.max(0f, Math.min(1f, (y - thumbHeight / 2f) / track));
            scroll.scrollTo(0, Math.round(range * ratio));
            updateThumb();
        }

        final class TrackingScrollView extends ScrollView {
            TrackingScrollView(Context context) { super(context); }
            @Override protected void onScrollChanged(int l, int t, int oldl, int oldt) {
                super.onScrollChanged(l, t, oldl, oldt);
                updateThumb();
                showThumb();
            }
            @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
                super.onSizeChanged(w, h, oldw, oldh);
                post(GripScrollHost.this::updateThumb);
            }
        }
    }
}
