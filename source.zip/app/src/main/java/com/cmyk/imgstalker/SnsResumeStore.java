package com.cmyk.imgstalker;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/**
 * External SNS resume state stored beside the user's downloaded media.
 * The file is intentionally outside app-private storage so it survives reinstall/copy.
 */
public final class SnsResumeStore {
    private static final int SCHEMA_VERSION = 1;

    private SnsResumeStore() { }

    public static final class Target {
        public final SnsAccountManager.Service service;
        public final String accountName;
        public final String categoryName;
        public final String fileName;
        public final String tempFileName;

        Target(SnsAccountManager.Service service, String accountName) {
            this.service = service;
            this.accountName = sanitizeSegment(accountName);
            this.categoryName = service == SnsAccountManager.Service.INSTAGRAM ? "Instagram" : "X";
            String prefix = service == SnsAccountManager.Service.INSTAGRAM ? "is_instagram_" : "is_x_";
            this.fileName = prefix + this.accountName + ".json";
            this.tempFileName = this.fileName + ".tmp";
        }

        public String relativeFolder() {
            return categoryName + "/" + accountName;
        }
    }

    public static final class State {
        public String sourceUrl = "";
        public boolean complete = false;
        public final LinkedHashSet<String> completedInstagramPosts = new LinkedHashSet<>();
        public final LinkedHashSet<String> discoveredInstagramPosts = new LinkedHashSet<>();
        public final ArrayList<MediaItem> mediaItems = new ArrayList<>();
    }

    public static Target targetForUrl(String rawUrl) {
        if (rawUrl == null || rawUrl.trim().isEmpty()) return null;
        try {
            URI uri = new URI(rawUrl.trim());
            String host = uri.getHost();
            if (host == null) return null;
            host = host.toLowerCase(Locale.ROOT);
            String path = uri.getPath() == null ? "" : uri.getPath();
            String[] parts = path.split("/");
            String first = "";
            for (String p : parts) {
                if (p != null && !p.trim().isEmpty()) { first = p.trim(); break; }
            }
            if (first.isEmpty()) return null;
            if (host.equals("instagram.com") || host.endsWith(".instagram.com")) {
                String low = first.toLowerCase(Locale.ROOT);
                if (low.equals("p") || low.equals("reel") || low.equals("reels")
                        || low.equals("explore") || low.equals("accounts") || low.equals("stories")) return null;
                return new Target(SnsAccountManager.Service.INSTAGRAM, first);
            }
            if (host.equals("x.com") || host.endsWith(".x.com")
                    || host.equals("twitter.com") || host.endsWith(".twitter.com")) {
                String low = first.toLowerCase(Locale.ROOT);
                if (low.equals("home") || low.equals("search") || low.equals("explore")
                        || low.equals("notifications") || low.equals("messages") || low.equals("i")
                        || low.equals("settings") || low.equals("compose")) return null;
                return new Target(SnsAccountManager.Service.X, first);
            }
        } catch (Throwable ignored) { }
        return null;
    }

    public static State load(Context context, Target target) {
        if (context == null || target == null) return null;
        SaveTarget save = resolveSaveTarget(context);
        String rel = appendPath(save.relativeBase, target.relativeFolder()) + "/";
        Uri collection = MediaStore.Files.getContentUri(save.volumeName);
        Uri uri = findEntry(context.getContentResolver(), collection, rel, target.fileName);
        boolean recoveredTemp = false;
        if (uri == null) {
            uri = findEntry(context.getContentResolver(), collection, rel, target.tempFileName);
            recoveredTemp = uri != null;
        }
        if (uri == null) {
            State direct = loadDirect(context, target);
            if (direct != null) return direct;
            DiagnosticLog.log("SNS_RESUME_LOAD miss service=" + target.categoryName
                    + " account=" + target.accountName + " path=" + rel + target.fileName);
            return null;
        }
        if (recoveredTemp) DiagnosticLog.log("SNS_RESUME_LOAD temp_recovery file=" + target.tempFileName);
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[8192];
            int n;
            while ((n = reader.read(buf)) >= 0) sb.append(buf, 0, n);
            JSONObject obj = new JSONObject(sb.toString());
            if (obj.optInt("schema", 0) != SCHEMA_VERSION) {
                DiagnosticLog.log("SNS_RESUME_LOAD schema_mismatch file=" + target.fileName
                        + " schema=" + obj.optInt("schema", 0));
                return null;
            }
            String service = obj.optString("service", "");
            String account = sanitizeSegment(obj.optString("account", ""));
            if (!target.categoryName.equalsIgnoreCase(service) || !target.accountName.equals(account)) {
                DiagnosticLog.log("SNS_RESUME_LOAD identity_mismatch file=" + target.fileName
                        + " service=" + service + " account=" + account);
                return null;
            }
            State state = new State();
            state.sourceUrl = obj.optString("source_url", "");
            state.complete = obj.optBoolean("complete", false);
            addStrings(obj.optJSONArray("instagram_completed"), state.completedInstagramPosts);
            addStrings(obj.optJSONArray("instagram_discovered"), state.discoveredInstagramPosts);
            JSONArray media = obj.optJSONArray("media");
            if (media != null) {
                for (int i = 0; i < media.length(); i++) {
                    JSONObject m = media.optJSONObject(i);
                    if (m == null) continue;
                    String url = m.optString("url", "");
                    String ref = m.optString("referrer", "");
                    String kindName = m.optString("kind", "");
                    if (url.isEmpty() || kindName.isEmpty()) continue;
                    try {
                        MediaItem.Kind kind = MediaItem.Kind.valueOf(kindName);
                        MediaItem item = new MediaItem(url, ref, kind, false,
                                Math.max(0, m.optInt("width", 0)),
                                Math.max(0, m.optInt("height", 0)),
                                Math.max(0L, m.optLong("duration_ms", 0L)),
                                m.optString("dedup_key", ""),
                                m.has("display_order") ? m.optLong("display_order", Long.MAX_VALUE) : Long.MAX_VALUE);
                        state.mediaItems.add(item);
                    } catch (Throwable ignored) { }
                }
            }
            DiagnosticLog.log("SNS_RESUME_LOAD ok service=" + target.categoryName
                    + " account=" + target.accountName
                    + " complete=" + state.complete
                    + " media=" + state.mediaItems.size()
                    + " igCompleted=" + state.completedInstagramPosts.size()
                    + " igDiscovered=" + state.discoveredInstagramPosts.size()
                    + " uri=" + uri);
            return state;
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_LOAD_FAIL file=" + target.fileName, t);
            return null;
        }
    }

    public static boolean write(Context context, Target target, State state) {
        if (context == null || target == null || state == null) return false;
        SaveTarget save = resolveSaveTarget(context);
        String rel = appendPath(save.relativeBase, target.relativeFolder()) + "/";
        Uri collection = MediaStore.Files.getContentUri(save.volumeName);
        ContentResolver resolver = context.getContentResolver();
        Uri tempUri = null;
        try {
            JSONObject obj = stateToJson(target, state);
            byte[] bytes = obj.toString(2).getBytes(StandardCharsets.UTF_8);

            Uri oldTemp = findEntry(resolver, collection, rel, target.tempFileName);
            if (oldTemp != null) resolver.delete(oldTemp, null, null);

            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, target.tempFileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            tempUri = resolver.insert(collection, values);
            if (tempUri == null) throw new IllegalStateException("resume temp insert failed");
            try (OutputStream out = resolver.openOutputStream(tempUri, "w")) {
                if (out == null) throw new IllegalStateException("resume temp output null");
                out.write(bytes);
                out.flush();
            }
            ContentValues publishTemp = new ContentValues();
            publishTemp.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(tempUri, publishTemp, null, null);

            Uri oldFinal = findEntry(resolver, collection, rel, target.fileName);
            if (oldFinal != null) resolver.delete(oldFinal, null, null);
            ContentValues rename = new ContentValues();
            rename.put(MediaStore.MediaColumns.DISPLAY_NAME, target.fileName);
            int rows = resolver.update(tempUri, rename, null, null);
            if (rows <= 0) throw new IllegalStateException("resume rename failed");
            DiagnosticLog.log("SNS_RESUME_WRITE ok service=" + target.categoryName
                    + " account=" + target.accountName
                    + " complete=" + state.complete
                    + " media=" + state.mediaItems.size()
                    + " igCompleted=" + state.completedInstagramPosts.size()
                    + " igDiscovered=" + state.discoveredInstagramPosts.size()
                    + " bytes=" + bytes.length + " path=" + rel + target.fileName);
            return true;
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_WRITE_FAIL file=" + target.fileName, t);
            if (tempUri != null) {
                try { resolver.delete(tempUri, null, null); } catch (Throwable ignored) { }
            }
            return writeDirect(context, target, state);
        }
    }

    public static boolean delete(Context context, Target target) {
        if (context == null || target == null) return false;
        SaveTarget save = resolveSaveTarget(context);
        String rel = appendPath(save.relativeBase, target.relativeFolder()) + "/";
        Uri collection = MediaStore.Files.getContentUri(save.volumeName);
        ContentResolver resolver = context.getContentResolver();
        boolean any = false;
        for (String name : new String[]{target.fileName, target.tempFileName}) {
            Uri uri = findEntry(resolver, collection, rel, name);
            if (uri != null) {
                try { any |= resolver.delete(uri, null, null) > 0; } catch (Throwable ignored) { }
            }
        }
        try {
            File dir = new File(SavePrefs.directory(context), target.relativeFolder());
            any |= new File(dir, target.fileName).delete();
            any |= new File(dir, target.tempFileName).delete();
        } catch (Throwable ignored) { }
        return any;
    }

    private static State loadDirect(Context context, Target target) {
        File dir = new File(SavePrefs.directory(context), target.relativeFolder());
        File file = new File(dir, target.fileName);
        if (!file.isFile()) {
            File temp = new File(dir, target.tempFileName);
            if (temp.isFile()) file = temp;
            else return null;
        }
        try (InputStream in = new FileInputStream(file)) {
            byte[] bytes = new byte[(int) Math.min(Integer.MAX_VALUE, Math.max(0L, file.length()))];
            int offset = 0;
            while (offset < bytes.length) {
                int n = in.read(bytes, offset, bytes.length - offset);
                if (n < 0) break;
                offset += n;
            }
            String json = new String(bytes, 0, offset, StandardCharsets.UTF_8);
            State state = parseStateJson(target, new JSONObject(json));
            if (state != null) DiagnosticLog.log("SNS_RESUME_LOAD direct_ok file=" + file.getAbsolutePath());
            return state;
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_LOAD_DIRECT_FAIL file=" + file.getAbsolutePath(), t);
            return null;
        }
    }

    private static boolean writeDirect(Context context, Target target, State state) {
        File dir = new File(SavePrefs.directory(context), target.relativeFolder());
        File finalFile = new File(dir, target.fileName);
        File tempFile = new File(dir, target.tempFileName);
        try {
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("mkdirs failed " + dir);
            byte[] bytes = stateToJson(target, state).toString(2).getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = new FileOutputStream(tempFile, false)) {
                out.write(bytes);
                out.flush();
            }
            if (finalFile.exists() && !finalFile.delete()) throw new IllegalStateException("delete final failed");
            if (!tempFile.renameTo(finalFile)) throw new IllegalStateException("rename temp failed");
            DiagnosticLog.log("SNS_RESUME_WRITE direct_ok file=" + finalFile.getAbsolutePath()
                    + " bytes=" + bytes.length);
            return true;
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_WRITE_DIRECT_FAIL file=" + finalFile.getAbsolutePath(), t);
            return false;
        }
    }

    private static JSONObject stateToJson(Target target, State state) throws Exception {
        JSONObject obj = new JSONObject();
        obj.put("schema", SCHEMA_VERSION);
        obj.put("service", target.categoryName);
        obj.put("account", target.accountName);
        obj.put("source_url", state.sourceUrl == null ? "" : state.sourceUrl);
        obj.put("complete", state.complete);
        obj.put("updated_at", System.currentTimeMillis());
        obj.put("instagram_completed", toJsonArray(state.completedInstagramPosts));
        obj.put("instagram_discovered", toJsonArray(state.discoveredInstagramPosts));
        JSONArray media = new JSONArray();
        for (MediaItem item : state.mediaItems) {
            if (item == null || item.url == null || item.url.trim().isEmpty()) continue;
            JSONObject m = new JSONObject();
            m.put("url", item.url);
            m.put("referrer", item.referrer == null ? "" : item.referrer);
            m.put("kind", item.kind.name());
            m.put("width", item.width);
            m.put("height", item.height);
            m.put("duration_ms", item.durationMs);
            m.put("dedup_key", item.dedupKey == null ? "" : item.dedupKey);
            m.put("display_order", item.displayOrder);
            media.put(m);
        }
        obj.put("media", media);
        return obj;
    }

    private static State parseStateJson(Target target, JSONObject obj) {
        if (obj == null || obj.optInt("schema", 0) != SCHEMA_VERSION) return null;
        String service = obj.optString("service", "");
        String account = sanitizeSegment(obj.optString("account", ""));
        if (!target.categoryName.equalsIgnoreCase(service) || !target.accountName.equals(account)) return null;
        State state = new State();
        state.sourceUrl = obj.optString("source_url", "");
        state.complete = obj.optBoolean("complete", false);
        addStrings(obj.optJSONArray("instagram_completed"), state.completedInstagramPosts);
        addStrings(obj.optJSONArray("instagram_discovered"), state.discoveredInstagramPosts);
        JSONArray media = obj.optJSONArray("media");
        if (media != null) {
            for (int i = 0; i < media.length(); i++) {
                JSONObject m = media.optJSONObject(i);
                if (m == null) continue;
                String url = m.optString("url", "");
                String ref = m.optString("referrer", "");
                String kindName = m.optString("kind", "");
                if (url.isEmpty() || kindName.isEmpty()) continue;
                try {
                    MediaItem.Kind kind = MediaItem.Kind.valueOf(kindName);
                    state.mediaItems.add(new MediaItem(url, ref, kind, false,
                            Math.max(0, m.optInt("width", 0)),
                            Math.max(0, m.optInt("height", 0)),
                            Math.max(0L, m.optLong("duration_ms", 0L)),
                            m.optString("dedup_key", ""),
                            m.has("display_order") ? m.optLong("display_order", Long.MAX_VALUE) : Long.MAX_VALUE));
                } catch (Throwable ignored) { }
            }
        }
        return state;
    }

    private static void addStrings(JSONArray array, Collection<String> out) {
        if (array == null || out == null) return;
        for (int i = 0; i < array.length(); i++) {
            String value = array.optString(i, "").trim();
            if (!value.isEmpty()) out.add(value);
        }
    }

    private static JSONArray toJsonArray(Collection<String> values) {
        JSONArray array = new JSONArray();
        if (values != null) for (String value : values) if (value != null && !value.trim().isEmpty()) array.put(value);
        return array;
    }

    private static Uri findEntry(ContentResolver resolver, Uri collection, String relativePath, String displayName) {
        if (resolver == null || collection == null) return null;
        String[] projection = new String[]{MediaStore.MediaColumns._ID};
        String selection = MediaStore.MediaColumns.RELATIVE_PATH + "=? AND "
                + MediaStore.MediaColumns.DISPLAY_NAME + "=?";
        String[] args = new String[]{relativePath, displayName};
        try (Cursor c = resolver.query(collection, projection, selection, args,
                MediaStore.MediaColumns.DATE_MODIFIED + " DESC")) {
            if (c != null && c.moveToFirst()) {
                long id = c.getLong(0);
                return Uri.withAppendedPath(collection, String.valueOf(id));
            }
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_RESUME_QUERY_FAIL name=" + displayName + " path=" + relativePath, t);
        }
        return null;
    }

    private static String sanitizeSegment(String raw) {
        String value = raw == null ? "" : raw.trim();
        value = value.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
        value = value.replaceAll("\\s+", "_");
        while (value.startsWith(".")) value = value.substring(1);
        while (value.endsWith(".")) value = value.substring(0, value.length() - 1);
        if (value.length() > 80) value = value.substring(0, 80);
        return value.isEmpty() ? "account" : value;
    }

    private static SaveTarget resolveSaveTarget(Context context) {
        File requested = SavePrefs.directory(context);
        File primary = Environment.getExternalStorageDirectory();
        if (isWithin(requested, primary)) {
            return new SaveTarget(MediaStore.VOLUME_EXTERNAL_PRIMARY, relativePath(primary, requested));
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                StorageManager manager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
                if (manager != null) {
                    for (StorageVolume volume : manager.getStorageVolumes()) {
                        File root = volume.getDirectory();
                        if (root == null || !isWithin(requested, root)) continue;
                        String mediaVolume = volume.getMediaStoreVolumeName();
                        if (mediaVolume == null || mediaVolume.trim().isEmpty()) continue;
                        return new SaveTarget(mediaVolume, relativePath(root, requested));
                    }
                }
            } catch (Throwable error) {
                DiagnosticLog.logException("SNS_RESUME_SAVE_TARGET_VOLUME_FAIL requested=" + requested, error);
            }
        }
        File fallback = SavePrefs.defaultDirectory();
        return new SaveTarget(MediaStore.VOLUME_EXTERNAL_PRIMARY, relativePath(primary, fallback));
    }

    private static boolean isWithin(File child, File root) {
        if (child == null || root == null) return false;
        try {
            String c = child.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Throwable error) {
            return false;
        }
    }

    private static String relativePath(File root, File target) {
        try {
            String r = root.getCanonicalPath();
            String t = target.getCanonicalPath();
            if (t.equals(r)) return "ImgStalker";
            if (t.startsWith(r + File.separator)) {
                String relative = t.substring(r.length() + 1).replace(File.separatorChar, '/');
                return relative.isEmpty() ? "ImgStalker" : relative;
            }
        } catch (Throwable ignored) { }
        return Environment.DIRECTORY_PICTURES + "/ImgStalker";
    }

    private static String appendPath(String base, String child) {
        String left = base == null ? "" : base.replace('\\', '/');
        while (left.endsWith("/")) left = left.substring(0, left.length() - 1);
        String right = child == null ? "" : child.replace('\\', '/');
        while (right.startsWith("/")) right = right.substring(1);
        return left.isEmpty() ? right : left + "/" + right;
    }

    private static final class SaveTarget {
        final String volumeName;
        final String relativeBase;
        SaveTarget(String volumeName, String relativeBase) {
            this.volumeName = volumeName;
            this.relativeBase = relativeBase;
        }
    }
}
