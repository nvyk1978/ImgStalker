#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
r=Path('app/src/main/java/com/cmyk/imgstalker')
ui=(r/'MainActivity.java').read_text()
assert 'SNS_THUMB_BACKGROUND_BATCH = 2' in ui
assert 'SNS_THUMB_BACKGROUND_MAX_PENDING = 3' in ui
assert 'scanCount = Math.min(size, 160)' in ui
assert 'SNS_THUMB_AUTO_PREFETCH index=' in ui
assert 'snsThumbnailSweepPolicy.recordAttempt(key, now);' in ui
assert 'snsThumbnailSweepIdleScanned < size' in ui
assert 'scheduleSnsThumbnailSweep("media_item")' in ui
assert 'scheduleSnsThumbnailSweep("resume_restore")' in ui
assert 'scheduleSnsThumbnailSweep("continue_reload")' in ui
assert 'scheduleSnsThumbnailSweep("activity_resume")' in ui
assert 'prefetchSnsThumbnailWindow(firstVisibleItem, visibleItemCount)' in ui
assert 'resetSnsThumbnailSweep("cache_clear")' in ui
assert 'isSnsThumbnailLazyMode()' in ui
iface=(r/'ModeThumbnailLoader.java').read_text()
assert 'default boolean isReady(MediaItem item)' in iface
for service in ('Instagram','Threads'):
    loader=(r/(service+'ThumbnailLoader.java')).read_text()
    adapter=(r/(service+'ThumbnailAdapter.java')).read_text()
    assert 'new SnsThumbnailDiskCache(context, "'+service.lower()+'")' in loader
    assert 'bitmap = diskCache.read(key);' in loader
    assert 'diskCache.write(key, bitmap)' in loader
    assert 'diskCache.clear();' in loader
    assert 'metadataChanged.run()' in loader
    assert 'core.isReady(item)' in adapter
cache=(r/'SnsThumbnailDiskCache.java').read_text()
assert '96L * 1024 * 1024' in cache
assert 'Thread(() ->' in cache
assert 'directory.getName() + "_clearing_"' in cache
assert 'SHA-256' in cache
assert 'BitmapFactory.decodeFile' in cache
assert 'MAX_BYTES' in cache
assert 'versionCode 173' in Path('app/build.gradle').read_text()
assert "versionName '0.1.172'" in Path('app/build.gradle').read_text()
assert 'new SnsThumbnailDiskCache' not in (r/'ThumbnailLoader.java').read_text()
print('PASS: all-discovered SNS sweep, bounded scheduler, service-isolated disk cache, UI update, modes protected')
PY
# Pure JDK state-policy behavioral checks.
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/com/cmyk/imgstalker"
cat > "$tmp/com/cmyk/imgstalker/SweepPolicyTest.java" <<'JAVA'
package com.cmyk.imgstalker;
final class SweepPolicyTest {
    static void yes(boolean value) { if (!value) throw new AssertionError(); }
    public static void main(String[] args) {
        SnsThumbnailSweepPolicy policy = new SnsThumbnailSweepPolicy();
        long t=100000L;
        String a="IMAGE|https://example.org/a";
        String b="IMAGE|https://example.org/b";
        yes(policy.canAttempt(a,t) && policy.canAttempt(b,t));
        policy.recordAttempt(a,t);
        yes(!policy.canAttempt(a,t+3499));
        yes(policy.canAttempt(a,t+3500));
        policy.recordAttempt(a,t+3500);
        yes(!policy.canAttempt(a,t+17500-1));
        yes(policy.canAttempt(a,t+17500));
        policy.recordAttempt(a,t+17500);
        yes(!policy.canAttempt(a,t+77500-1));
        yes(policy.canAttempt(a,t+77500));
        policy.recordAttempt(a,t+77500);
        yes(policy.exhausted(a));
        yes(!policy.canAttempt(a,t+999999));
        yes(policy.canAttempt(b,t));
        policy.finish(b);
        yes(policy.isFinished(b) && !policy.canAttempt(b,t));
        policy.reset();
        yes(policy.canAttempt(a,t) && policy.canAttempt(b,t));
        System.out.println("PASS: isolated stable media keys, bounded exponential retry, reset");
    }
}
JAVA
javac -d "$tmp" app/src/main/java/com/cmyk/imgstalker/SnsThumbnailSweepPolicy.java "$tmp/com/cmyk/imgstalker/SweepPolicyTest.java"
java -cp "$tmp" com.cmyk.imgstalker.SweepPolicyTest
