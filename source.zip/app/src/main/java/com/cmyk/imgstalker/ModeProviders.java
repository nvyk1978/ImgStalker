package com.cmyk.imgstalker;

/** The ONLY legal cross-provider construction site. URL parsing is host-only. */
final class ModeProviders {
    private ModeProviders() { }
    static ModeProvider forUrl(String url) { return forMode(AnalysisModeRouter.fromUrl(url)); }
    static ModeProvider forMode(AnalysisModeRouter.Mode mode) {
        if (mode == null) throw new IllegalArgumentException("Missing scan mode");
        switch (mode) {
            case NORMAL: return new NormalModeProvider();
            case X: return new XModeProvider();
            case INSTAGRAM: return new InstagramModeProvider();
            default: throw new IllegalArgumentException("Unsupported mode " + mode);
        }
    }
}
