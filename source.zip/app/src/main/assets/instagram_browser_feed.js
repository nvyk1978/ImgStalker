/* ImgStalker Instagram-only observer. Executed at document start on instagram.com.
   Observe responses the user's WebView actually receives; never synthesize credentials,
   bypass a challenge, or read/alter requests sent by other app modes. */
(function () {
  'use strict';
  if (!/(^|\.)instagram\.com$/.test(location.hostname)) return;
  if (window.__imgStalkerFeedV1) return;
  const state = { responses: [], blocked: '', requests: 0, dropped: 0, lastStatus: 0 };
  window.__imgStalkerFeedV1 = state;
  const interesting = function (url) {
    try {
      if (typeof url !== 'string') return false;
      const u = new URL(url, location.href);
      return u.protocol === 'https:' && u.hostname === 'www.instagram.com' &&
        /^\/(api\/graphql|graphql\/query)/.test(u.pathname);
    } catch (_) { return false; }
  };
  const observe = function (url, status, body) {
    try {
      if (!interesting(url) || typeof body !== 'string') return;
      state.requests++;
      state.lastStatus = status;
      if (status === 429) state.blocked = 'rate_limited';
      if ((status === 400 || status === 401 || status === 403 || status === 429) &&
        (/"spam"\s*:\s*true/.test(body) || /"feedback_required"/.test(body) ||
         /"require_login"\s*:\s*true/.test(body))) {
        state.blocked = /"spam"\s*:\s*true/.test(body) ? 'spam' :
          /"require_login"\s*:\s*true/.test(body) ? 'login' : 'feedback';
      }
      if (status !== 200 || body.length > 1800000 ||
          !/(shortcode|image_versions2|video_versions|edge_owner_to_timeline_media|PolarisProfilePostsTabContentQuery)/.test(body)) return;
      if (state.responses.length >= 10) { state.dropped++; return; }
      state.responses.push(body);
    } catch (_) { }
  };
  try {
    const originalFetch = window.fetch;
    if (typeof originalFetch === 'function') {
      window.fetch = function () {
        const input = arguments[0];
        const url = (typeof input === 'string') ? input : input && input.url;
        const promise = originalFetch.apply(this, arguments);
        if (!interesting(url)) return promise;
        return promise.then(function (response) {
          try { response.clone().text().then(function (text) {
            observe(url, response.status, text);
          }).catch(function () {}); } catch (_) { }
          return response;
        });
      };
    }
  } catch (_) { }
  try {
    const originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url) {
      try { this.__imgStalkerFeedUrl = interesting(url) ? new URL(url, location.href).href : ''; }
      catch (_) { this.__imgStalkerFeedUrl = ''; }
      return originalOpen.apply(this, arguments);
    };
    const originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
      if (this.__imgStalkerFeedUrl) {
        this.addEventListener('loadend', function () {
          try { if (typeof this.responseText === 'string')
            observe(this.__imgStalkerFeedUrl, this.status, this.responseText); } catch (_) { }
        });
      }
      return originalSend.apply(this, arguments);
    };
  } catch (_) { }
  window.__imgStalkerFeedSnapshot = function () {
    const links = [];
    const seen = Object.create(null);
    try {
      document.querySelectorAll('a[href*="/p/"],a[href*="/reel/"]').forEach(function (a) {
        const url = new URL(a.getAttribute('href'), location.href);
        if (!/(^|\.)instagram\.com$/.test(url.hostname)) return;
        const m = /^\/(p|reel)\/([A-Za-z0-9_-]{5,30})(?:\/|$)/.exec(url.pathname);
        if (!m) return;
        const key = m[1] + '/' + m[2];
        if (!seen[key] && links.length < 300) { seen[key] = true; links.push('https://www.instagram.com/' + key + '/'); }
      });
    } catch (_) { }
    const responses = state.responses.splice(0);
    const doc = document.scrollingElement || document.documentElement;
    return JSON.stringify({
      host: location.hostname, path: location.pathname, links: links,
      responses: responses, blocked: state.blocked, requests: state.requests,
      dropped: state.dropped, lastStatus: state.lastStatus,
      scrollY: doc ? doc.scrollTop : 0,
      scrollHeight: doc ? doc.scrollHeight : 0,
      viewport: doc ? doc.clientHeight : 0
    });
  };
})();
