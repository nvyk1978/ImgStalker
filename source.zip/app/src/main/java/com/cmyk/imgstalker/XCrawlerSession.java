package com.cmyk.imgstalker;

import org.json.JSONObject;

/** X-only search, repost and persisted queue API. */
interface XCrawlerSession {
    JSONObject checkpointCursor();
    void seedQueueCursor(JSONObject cursor);
    void setIncludeXReposts(boolean enabled);
    void setXSearchExecutionAllowed(boolean enabled, String reason);
}
