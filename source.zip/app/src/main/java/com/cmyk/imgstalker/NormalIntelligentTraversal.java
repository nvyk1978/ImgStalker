package com.cmyk.imgstalker;

import java.net.URI;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** NORMAL-only, read-only techniques inspired by general DOM/media discovery. Does not access SNS engines. */
final class NormalIntelligentTraversal {
    private NormalIntelligentTraversal() { }
    private static final Pattern ALBUM_PATH = Pattern.compile(
            "^(/(?:[a-z]{2}/)?album/[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})(?:/([1-9][0-9]{0,2}))?/?$");
    static boolean isCosersAlbum(String url) {
        try {
            URI uri = new URI(url);
            String h = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            return ("coserslove.com".equals(h) || "www.coserslove.com".equals(h))
                    && ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))
                    && ALBUM_PATH.matcher(uri.getPath() == null ? "" : uri.getPath()).matches();
        } catch (Exception ignored) { return false; }
    }
    static boolean sameAlbum(String root, String page) {
        if (!isCosersAlbum(root) || !isCosersAlbum(page)) return false;
        try {
            URI r = new URI(root), p = new URI(page);
            Matcher a = ALBUM_PATH.matcher(r.getPath()), b = ALBUM_PATH.matcher(p.getPath());
            return a.matches() && b.matches() && r.getScheme().equalsIgnoreCase(p.getScheme())
                    && r.getHost().equalsIgnoreCase(p.getHost()) && r.getPort() == p.getPort()
                    && a.group(1).equalsIgnoreCase(b.group(1));
        } catch (Exception ignored) { return false; }
    }
    static int albumPageNumber(String url) {
        if (!isCosersAlbum(url)) return -1;
        Matcher m = ALBUM_PATH.matcher(URI.create(url).getPath());
        if (!m.matches()) return -1;
        return m.group(2) == null ? 1 : Integer.parseInt(m.group(2));
    }
    static String nextAlbumPage(String root, String page) {
        if (!sameAlbum(root, page)) return "";
        int n = albumPageNumber(page);
        if (n < 1 || n >= 100) return "";
        URI u = URI.create(root);
        Matcher m = ALBUM_PATH.matcher(u.getPath());
        if (!m.matches()) return "";
        try { return new URI(u.getScheme(), u.getRawAuthority(), m.group(1) + "/" + (n + 1), null, null).toString(); }
        catch (Exception ignored) { return ""; }
    }
    static boolean isAlbumAsset(String url) {
        try {
            URI u = new URI(url);
            String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            return (host.equals("img.coserslove.com") || host.endsWith(".img.coserslove.com"))
                    && u.getPath() != null && u.getPath().matches("(?i).*\\.(?:jpg|jpeg|png|gif|webp|avif|bmp|heic|heif)$");
        } catch (Exception ignored) { return false; }
    }
    /** Called *inside* NORMAL's existing DOM collector; only returns observed page data. */
    static String supplementalJavascript() {
        return 
                "// NORMAL intelligent discovery is an in-page, read-only augmentation: no SNS API/cookies/navigation.\n" +
                "const intelligentStats={x:0,instagram:0,threads:0};\n" +
                "const intelligentImagePattern=/\\.(?:jpg|jpeg|png|gif|webp|avif|bmp|heic|heif)(?:[?#]|$)/i;\n" +
                "const intelligentVideoPattern=/\\.(?:mp4|webm|m4v|mov|m3u8|mpd)(?:[?#]|$)/i;\n" +
                "const intelligentPush=(raw,lane)=>{if(typeof raw!=='string'||raw.length>4096)return;const u=abs(raw.trim());if(!u||!/^https?:\\/\\//i.test(u))return;let accepted=false;if(intelligentImagePattern.test(u)){images.push(u);accepted=true;}else if(intelligentVideoPattern.test(u)){if(/\\.(?:m3u8|mpd)(?:[?#]|$)/i.test(u))streams.push(u);else videos.push(u);accepted=true;}if(accepted&&lane&&intelligentStats[lane]!==undefined)intelligentStats[lane]++;};\n" +
                "// Instagram-style responsive/lazy picture candidates (never invoke the IG crawler).\n" +
                "try{let count=0;document.querySelectorAll('img,picture source,[data-src],[data-original],[data-full],[data-image],[data-background]').forEach(e=>{if(count++>2500)return;['currentSrc','src'].forEach(k=>{try{intelligentPush(e[k],'instagram')}catch(_) {}});['data-src','data-original','data-lazy-src','data-full','data-image','data-background','data-zoom-image','data-highres','data-hires','poster'].forEach(k=>intelligentPush(e.getAttribute(k),'instagram'));['srcset','data-srcset'].forEach(k=>{let value=e.getAttribute(k)||'';value.split(',').slice(0,25).forEach(s=>intelligentPush(s.trim().split(/\\s+/)[0],'instagram'));});});}catch(_){}\n" +
                "// X-style CSS/lazy backgrounds and loaded resource discovery; document context only.\n" +
                "try{let count=0;document.querySelectorAll('[style],[data-bg],[data-background-image]').forEach(e=>{if(count++>750)return;['data-bg','data-background-image'].forEach(k=>intelligentPush(e.getAttribute(k),'x'));let bg='';try{bg=getComputedStyle(e).backgroundImage||''}catch(_){};let re=/url\\(\\s*['\\\"]?([^'\\\")]+)['\\\"]?\\s*\\)/gi,m;while((m=re.exec(bg))!==null){intelligentPush(m[1],'x');}});if(typeof performance!=='undefined'&&performance.getEntriesByType){performance.getEntriesByType('resource').slice(-1800).forEach(e=>{if(/^(img|css|image)$/i.test(e.initiatorType||''))intelligentPush(e.name,'x')});}}catch(_){}\n" +
                "// Threads-style JSON/carousel metadata. Strict limits avoid a busy or recursive page.\n" +
                "try{let visited=0;const allowedKey=/^(?:image|images|image_url|imageurl|media|media_url|mediaurl|photo|photos|picture|pictures|thumbnail|thumbnailurl|thumbnail_url|url|src|srcset|contenturl|displayurl|fullurl|original|originalurl|carousel|slides|items|edges|nodes|resources|variants|data)$/i;const walk=(v,depth)=>{if(++visited>7500||depth>10||v==null)return;if(Array.isArray(v)){v.slice(0,1200).forEach(x=>walk(x,depth+1));return;}if(typeof v==='string'){intelligentPush(v,'threads');return;}if(typeof v!=='object')return;Object.keys(v).slice(0,200).forEach(k=>{if(allowedKey.test(k))walk(v[k],depth+1);});};document.querySelectorAll('script[type=\"application/ld+json\"],script#__NEXT_DATA__,script#__NUXT_DATA__,script[type=\"application/json\"]').forEach(s=>{let raw=s.textContent||'';if(raw.length<2||raw.length>1400000)return;try{walk(JSON.parse(raw),0)}catch(_){}});document.querySelectorAll('[role=\"group\"] img,[data-testid*=\"carousel\"] img,[class*=\"carousel\"] img').forEach(e=>{intelligentPush(e.currentSrc||e.src,'threads')});}catch(_){}\n";
    }
}
