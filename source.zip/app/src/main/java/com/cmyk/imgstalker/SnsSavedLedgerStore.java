package com.cmyk.imgstalker;

import android.content.Context;
import android.util.AtomicFile;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Collection;
import java.util.LinkedHashSet;

/**
 * Saved-media success ledger. It is NOT analysis cache and must never be deleted by
 * "キャッシュ削除". Kept independently of all crawler/continuation checkpoints.
 *
 * The local AtomicFile is a durable fallback. The extra SAF JSON beside the media
 * allows saved marks to survive an app-data loss when the save directory is retained.
 */
final class SnsSavedLedgerStore {
    private static final int SCHEMA = 1;
    private SnsSavedLedgerStore() { }

    private static AtomicFile file(Context context, SnsResumeStore.Target target) throws Exception {
        String saveDirectory = SavePrefs.directory(context).getCanonicalPath();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(saveDirectory.getBytes(StandardCharsets.UTF_8));
        StringBuilder suffix = new StringBuilder();
        for (int i = 0; i < 12; i++) suffix.append(String.format(java.util.Locale.ROOT, "%02x", hash[i] & 0xff));
        File root = new File(context.getFilesDir(), "sns_saved_ledgers");
        if (!root.isDirectory() && !root.mkdirs() && !root.isDirectory())
            throw new java.io.IOException("Cannot create saved ledger directory");
        return new AtomicFile(new File(root, target.fileName + "." + suffix + ".saved.json"));
    }

    private static LinkedHashSet<String> readInternal(Context context, SnsResumeStore.Target target) {
        LinkedHashSet<String> result = new LinkedHashSet<>();
        try (FileInputStream input = file(context, target).openRead()) {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] bytes = new byte[8192];
            int n;
            while ((n = input.read(bytes)) != -1) buf.write(bytes, 0, n);
            JSONObject json = new JSONObject(buf.toString(StandardCharsets.UTF_8.name()));
            if (json.optInt("schema", 0) != SCHEMA
                    || !target.categoryName.equals(json.optString("service", ""))
                    || !target.accountName.equals(json.optString("account", ""))) return result;
            JSONArray keys = json.optJSONArray("saved_media_keys");
            if (keys != null) for (int i = 0; i < keys.length(); i++) {
                String key = keys.optString(i, "").trim();
                if (!key.isEmpty()) result.add(key);
            }
        } catch (java.io.FileNotFoundException ignored) {
            // First run after migration / a fresh install.
        } catch (Throwable e) {
            DiagnosticLog.logException("SNS_SAVED_LEDGER_READ_FAIL", e);
        }
        return result;
    }

    static LinkedHashSet<String> load(Context context, SnsResumeStore.Target target) {
        LinkedHashSet<String> keys = new LinkedHashSet<>();
        if (context == null || target == null) return keys;
        keys.addAll(readInternal(context, target));
        keys.addAll(SnsResumeStore.loadSavedLedger(context, target));
        DiagnosticLog.log("SNS_SAVED_LEDGER_LOAD service=" + target.categoryName
                + " account=" + target.accountName + " saved=" + keys.size());
        return keys;
    }

    /** Monotonic: a delayed save must never overwrite newer successfully saved keys. */
    static boolean save(Context context, SnsResumeStore.Target target, Collection<String> newKeys) {
        if (context == null || target == null) return false;
        LinkedHashSet<String> keys = load(context, target);
        if (newKeys != null) for (String key : newKeys) {
            if (key != null && !key.trim().isEmpty()) keys.add(key.trim());
        }
        AtomicFile atomic = null;
        FileOutputStream out = null;
        try {
            atomic = file(context, target);
            JSONObject json = new JSONObject();
            json.put("schema", SCHEMA);
            json.put("service", target.categoryName);
            json.put("account", target.accountName);
            json.put("updated_at", System.currentTimeMillis());
            JSONArray array = new JSONArray();
            for (String key : keys) array.put(key);
            json.put("saved_media_keys", array);
            out = atomic.startWrite();
            out.write(json.toString().getBytes(StandardCharsets.UTF_8));
            atomic.finishWrite(out);
            out = null;
        } catch (Throwable e) {
            if (out != null && atomic != null) {
                try { atomic.failWrite(out); } catch (Throwable ignored) { }
            }
            DiagnosticLog.logException("SNS_SAVED_LEDGER_WRITE_FAIL", e);
            return false;
        }
        boolean externalOk = !SavePrefs.hasTreeAccess(context)
                || SnsResumeStore.writeSavedLedger(context, target, keys);
        DiagnosticLog.log("SNS_SAVED_LEDGER_SAVE service=" + target.categoryName
                + " account=" + target.accountName + " saved=" + keys.size()
                + " externalOk=" + externalOk);
        return externalOk;
    }
}
