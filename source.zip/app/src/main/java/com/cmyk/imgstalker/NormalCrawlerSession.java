package com.cmyk.imgstalker;
import org.json.JSONObject;
/** NORMAL-only continuation contract; not exposed on ModeCrawler or SNS providers. */
interface NormalCrawlerSession {
    JSONObject checkpointCursor();
    void seedQueueCursor(JSONObject cursor);
}
