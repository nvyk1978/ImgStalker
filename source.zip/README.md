# ImgStalker v0.1.44 (45)

## v0.1.44
- Instagram detail pages now start media discovery from an early DOM/network probe shortly after `onPageStarted`; they no longer wait for the entire post page to finish loading before beginning queue collection.
- Instagram still images discovered in post detail pages are added to the result/download queue immediately. Unknown-size images no longer block traversal on the separate image-size probe; thumbnail loading remains lazy/visible-window based and fills metadata later.
- Reel pages no longer enter carousel-next traversal once the real video request/URL has been found. They wait briefly for a video URL, queue it, and move to the next post.
- Carousel navigation now clicks only explicit safe Next/次へ controls. Geometry/hit-test fallbacks that could mistake audio/mute/back controls for Next are removed.
- Slide-change polling is short (6 x 180 ms) and failures retry the post page instead of repeatedly clicking the same control. Instagram detail failures get up to two in-run page retries before being marked incomplete.
- Instagram detail phase budget is extended from 90 s to 180 s, while the final network-quiet wait is reduced from 7 s to 1.5 s. This keeps the crawler persistent before offering Continue/reload without spending long idle waits inside each post.
- Analysis-stall indication is relaxed from 45 s to 75 s so Continue/reload is not surfaced prematurely during recoverable Instagram stalls.
- v0.1.43 stable Instagram image deduplication and the smaller gear teeth / exposed circular rim are retained.
- versionCode 45 / versionName 0.1.44. applicationId and fixed signing are unchanged.

## v0.1.43
- Instagram still-image duplicate suppression now uses a stable image identity: `ig_cache_key` first, then the CDN filename as fallback, instead of volatile signed query parameters.
- Continue analysis seeds use the same stable Instagram image key, preventing already collected thumbnails from being re-added when `_nc_gid`, `oh`, and related CDN parameters rotate.
- Settings gear keeps its existing overall diameter and center hole, but each tooth is narrower/shallower at the root so the circular rim is visibly exposed between the teeth.
- Existing Instagram carousel/video handling, SNS thumbnail windowing, filename/resolution labels, diagnostic icon, X repost setting, SNS login/profile support and fixed signing are retained.
- versionCode 44 / versionName 0.1.43. applicationId and fixed signing are unchanged.

## v0.1.42
- SNS grids (X / Instagram) no longer eagerly prefetch every still-image thumbnail. Visible cells load normally and only a six-item margin before/after the visible range is prefetched.
- SNS thumbnail cache is trimmed to the active visible/prefetch window so distant decoded bitmaps do not accumulate. Normal website thumbnail prefetch behavior is unchanged.
- Diagnostic Log header icon is now a solid document glyph with three knockout text lines.
- Settings header icon is now a solid simplified six-tooth gear with a punched center.
- Original-image fullscreen viewer and all image-area letterbox margins use pure black (#000000).
- Existing filename/resolution labels, video frame thumbnails, duration overlay, manual-stop Continue cell, Instagram carousel/video handling, X repost setting, SNS login/profile support and fixed signing are retained.
- versionCode 43 / versionName 0.1.42. applicationId and fixed signing are unchanged.

## v0.1.41
- Media grid cells now show a single-line filename and a second-line resolution under the thumbnail.
- Video cells render a real video frame thumbnail when available, keep the centered play button, and show duration at the lower-left of the thumbnail.
- Image dimensions are carried from crawler probes; video dimensions/duration are filled from video metadata or Media3 playback metadata.
- Settings and Diagnostic Log header icons were redrawn as vector graphics based on the supplied gear/document references.
- Manual Analyze/Stop now leaves the Continue cell so the same analysis can be resumed with existing results preserved.
- Instagram video duplicate suppression now keys same-post video requests by Instagram asset id when available.
- Instagram audio-only tracks are excluded and explicit ad-tagged video encodes are skipped.
- Existing Instagram carousel traversal, X repost setting, X status detail collection, SNS login/profile support, and fixed signing are retained.
- versionCode 42 / versionName 0.1.41. applicationId and fixed signing are unchanged.
