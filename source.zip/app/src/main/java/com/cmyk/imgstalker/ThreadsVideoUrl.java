package com.cmyk.imgstalker;
/** Threads media URLs are kept as-is; never use X or NORMAL URL caches. */
final class ThreadsVideoUrl {
    private ThreadsVideoUrl() {}
    static String resolvedOrOriginal(String url) { return url; }
    static String stripTag(String url) { return url; }
    static void markRecovered(String oldUrl, String newUrl) { }
}
