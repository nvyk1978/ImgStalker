package com.cmyk.imgstalker;
import android.content.Context;
import java.util.List;
/** Threads-only saver. */
final class ThreadsDownloaderAdapter implements ModeDownloader {
    private final ThreadsMediaDownloader core;
    ThreadsDownloaderAdapter(Context c, boolean ignored, MediaDownloader.Listener listener) { core = new ThreadsMediaDownloader(c, listener); }
    @Override public void download(List<MediaItem> items, String title, String category, String account) { core.download(items, title, category, account); }
    @Override public void cancel() { core.cancel(); }
}
