# ImgStalker v0.1.146 — mode execution firewall

## Chosen invariant
An analysis session chooses exactly one `ModeProvider` from the source URL's parsed hostname. The provider owns a crawler, thumbnail loader, downloader, original-image loader, preview URL policy and CookieManager scope. The UI may not instantiate those concrete transports directly.

| Mode | Backend classes | Mode-only crawler continuation |
|---|---|---|
| NORMAL | `Normal*` | none |
| X | frozen v0.1.135 transport + `X*` adapters | `XCrawlerSession` (X repost/search/JSON queue) |
| INSTAGRAM | successful v0.1.145 Instagram HTML-first pipeline + `Instagram*` adapters | `InstagramCrawlerSession` (Instagram post IDs) |

`ModeCrawler` now exposes only common crawler operations. It has **no** Instagram or X state methods. Each provider's adapter rejects foreign source URLs before `core.start()`. Switching profiles or source modes recreates the WebView and crawler and increments an epoch, invalidating late analysis callbacks. Download callbacks are also tied to the originating mode and epoch.

The media-preview cookie header and preview URL/retry cache now come from the active provider. Previously preview processing used `SessionCookies` / `TwitterVideoUrl` directly even for Instagram and normal pages. A URL on a media CDN does not alter the session's source mode.

## Build-time regression protection

* `mode-locks.sha256` continues to freeze known-good X processing, SNS infrastructure and the stable signing keystore.
* `provider-mode-locks.sha256` additionally freezes the **unchanged** NORMAL and INSTAGRAM crawlers, HTTP extraction, media download, thumbnail, originals and session cookie classes. Deliberate modifications require updating these hash manifests explicitly.
* `verifyModeIsolation` runs before Android `preBuild`; it rejects unexpected changes to locked files and executes `scripts/verify-provider-boundaries.py`. This script fails on cross-mode provider wiring, reintroduced mixed shared APIs or bypasses in `MainActivity`.
* `scripts/test-mode-provider-compile.sh` runs a Java interface compilation and dynamic dispatch test with Android interface stubs. Tests check the 3 provider selections, cookie scopes and preview URL policies and all 6 cross-mode start rejections.
* `scripts/test-instagram-v084-parity.sh` and `scripts/test-instagram-v084-source-compile.sh` protect the previously successful Instagram extraction route.

## Preserved scope and limits

The old, protected X crawler source and old normal crawler source still contain historical Instagram-specific methods that are now *unreachable as a scan entry* through their adapters. They were deliberately **not** removed because that would alter the previously working engine source and could break X/normal behavior. Thus this version provides hard mode-owned **entry and transport dispatch** and source-level API fences, but **not** complete removal of every historical foreign-mode implementation from every old engine file.

UI, `MediaItem`, process, some SNS database/store code and the `CrawlerEngine.Listener` callback type are still shared. WebView cookies live in the existing Android WebView/profile infrastructure; independent OS processes are not claimed. Actual device scans for each mode and GitBuild release compilation still require verification on-device/in CI.
