package com.cmyk.imgstalker;

public final class ModeUrlIsolationTest {
    private static void equals(String expected, String actual) {
        if (!expected.equals(actual)) throw new AssertionError("Expected=" + expected + ", actual=" + actual);
    }
    public static void main(String[] args) {
        String cdn = "https://video.twimg.com/ext_tw_video/123/pu/vid/640x360/test.mp4?tag=12&foo=bar#part";
        String wanted = "https://video.twimg.com/ext_tw_video/123/pu/vid/640x360/test.mp4?foo=bar#part";
        equals(wanted, NormalVideoUrl.stripTag(cdn));
        equals(wanted, InstagramVideoUrl.stripTag(cdn));
        equals("https://video.twimg.com/test.mp4", NormalVideoUrl.stripTag("https://video.twimg.com/test.mp4?tag=12"));
        equals("https://video.twimg.com/test.mp4?foo=bar", NormalVideoUrl.stripTag("https://video.twimg.com/test.mp4?foo=bar&tag=12"));
        String igSigned = "https://scontent.cdninstagram.com/test.mp4?tag=should-stay&oh=signature";
        equals(igSigned, InstagramVideoUrl.stripTag(igSigned));
        equals(igSigned, NormalVideoUrl.stripTag(igSigned));
        String evilHost = "https://video.twimg.com.evil.com/test.mp4?tag=preserved";
        equals(evilHost, NormalVideoUrl.stripTag(evilHost));
        String url = "https://video.twimg.com/vid.mp4?tag=1";
        NormalVideoUrl.markRecovered(url, "https://example.org/normal.mp4");
        equals("https://example.org/normal.mp4", NormalVideoUrl.resolvedOrOriginal(url));
        equals(url, InstagramVideoUrl.resolvedOrOriginal(url));
        InstagramVideoUrl.markRecovered(url, "https://example.org/instagram.mp4");
        equals("https://example.org/instagram.mp4", InstagramVideoUrl.resolvedOrOriginal(url));
        equals("https://example.org/normal.mp4", NormalVideoUrl.resolvedOrOriginal(url));
        System.out.println("ModeUrlIsolationTest: PASS");
    }
}
