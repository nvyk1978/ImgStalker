# ImgStalker v0.1.45 (46)

## v0.1.45
- Instagram video duplicate suppression is now based on the post media slot instead of CDN URL / `xpv_asset_id`: Reel/TV uses one video slot per post, while carousel posts use one slot per slide. DOM and network discovery share the same slot key, so the same clip cannot create adjacent or separated duplicate cells.
- The Instagram carousel collector now reads video URLs only from the currently visible video element/source. Hidden or preloaded neighboring slide videos are not emitted as the current slide.
- A final UI-level media dedup guard uses the crawler-provided dedup key, so asynchronous DOM/network callbacks cannot add a second cell even if they race. Dedup keys are preserved across state save/restore and Continue seeding.
- SNS thumbnail scrolling no longer calls position-based `trimCacheToWindow()`. Once loaded, thumbnails remain in the normal LRU cache and are evicted only by memory pressure, preventing already-loaded cells from going blank when scrolling away and back.
- Instagram detail pages keep the early DOM/network queue collection, Reel fast exit after video capture, safe explicit Next-only carousel navigation, short per-slide polling, in-run detail retries, 180 s detail budget and 1.5 s final quiet wait introduced in the previous build.
- The smaller settings-gear teeth / exposed circular rim are retained.
- versionCode 46 / versionName 0.1.45. applicationId and fixed signing are unchanged.

## v0.1.43
- Instagram still-image duplicate suppression now uses a stable image identity: `ig_cache_key` first, then the CDN filename as fallback, instead of volatile signed query parameters.
- Continue analysis seeds use the same stable Instagram image key, preventing already collected thumbnails from being re-added when `_nc_gid`, `oh`, and related CDN parameters rotate.
- Settings gear keeps its existing overall diameter and center hole, but each tooth is narrower/shallower at the root so the circular rim is visibly exposed between the teeth.
- Existing Instagram carousel/video handling, SNS thumbnail windowing, filename/resolution labels, diagnostic icon, X repost setting, SNS login/profile support and fixed signing are retained.
- versionCode 44 / versionName 0.1.43. applicationId and fixed signing are unchanged.

## v0.1.42
- SNS grids (X / Instagram) no longer eagerly prefetch every still-image thumbnail. Visible cells load normally and only a six-item margin before/after the visible range is prefetched.
- SNS thumbnail cache is trimmed to the active visible/prefetch window so distant decoded bitmaps do not accumulate. Normal website thumbnail prefetch behavior is unchanged.
- Diagnostic Log header icon is now a solid document glyph with three knockout text lines.
- Settings header icon is now a solid simplified six-tooth gear with a punched center.
- Original-image fullscreen viewer and all image-area letterbox margins use pure black (#000000).
- Existing filename/resolution labels, video frame thumbnails, duration overlay, manual-stop Continue cell, Instagram carousel/video handling, X repost setting, SNS login/profile support and fixed signing are retained.
- versionCode 43 / versionName 0.1.42. applicationId and fixed signing are unchanged.

## v0.1.41
- Media grid cells now show a single-line filename and a second-line resolution under the thumbnail.
- Video cells render a real video frame thumbnail when available, keep the centered play button, and show duration at the lower-left of the thumbnail.
- Image dimensions are carried from crawler probes; video dimensions/duration are filled from video metadata or Media3 playback metadata.
- Settings and Diagnostic Log header icons were redrawn as vector graphics based on the supplied gear/document references.
- Manual Analyze/Stop now leaves the Continue cell so the same analysis can be resumed with existing results preserved.
- Instagram video duplicate suppression now keys same-post video requests by Instagram asset id when available.
- Instagram audio-only tracks are excluded and explicit ad-tagged video encodes are skipped.
- Existing Instagram carousel traversal, X repost setting, X status detail collection, SNS login/profile support, and fixed signing are retained.
- versionCode 42 / versionName 0.1.41. applicationId and fixed signing are unchanged.
