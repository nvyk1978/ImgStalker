# ImgStalker v0.1.65 (66)

## Base
- Functional base: v0.1.63.
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.

## Instagram streaming traversal
- Instagram no longer collects the whole profile post list before opening details.
- The profile stays at the current scroll position and scans only the currently visible post cells.
- The next unprocessed cell is chosen in visual order: top to bottom, then left to right.
- That cell is opened by its actual DOM anchor first, with the Android-side native touch path retained as a fallback.
- The opened post is processed immediately, including all carousel slides and Reel/video extraction.
- Each discovered image/video/stream is emitted immediately through the existing `onItem()` path, so result cells are populated progressively instead of waiting for the full profile scan.
- When a post completes, the SPA post view is closed and traversal resumes from the same profile position; history.go(-n) fallback is no longer used.
- Only after all currently visible cells are handled does the profile scroll farther down.
- Already handled post URLs are skipped with the existing dedup/continuation state.

## Carousel / video behavior retained
- Carousel next-slide traversal now accepts only an explicit Next/次へ control; geometry/hit-test guessing is disabled at the terminal slide.
- Existing image URL normalization, duplicate suppression and target-size filtering are retained.
- Existing Reel/network video capture is retained.
- Video cover frames remain excluded as standalone IMAGE items.

## Recovery
- A failed post returns to the profile and retries from slide 1.
- Retry count remains bounded.
- A permanently skipped post no longer causes the crawler to fall back to the old whole-list deferred queue at completion.
- HTTP 429 handling remains unchanged.

## Visible diagnostics
- The Instagram WebView remains visible while streaming traversal runs, but a transparent touch shield blocks all user interaction without blocking crawler-originated direct WebView events.
- Result cells stay visible below the diagnostic WebView and are appended immediately as media is emitted.
- The background-analysis toggle starts/stops the foreground service and WakeLock immediately during an active run; lifecycle and heartbeat markers make background execution observable.
- New log stages include `SNS_IG_STREAM_START`, `SNS_IG_STREAM_PICK`, `SNS_IG_STREAM_OPEN`, `SNS_IG_STREAM_RESUME`, `SNS_IG_STREAM_SCROLL`, `SNS_IG_STREAM_RETRY`, and `SNS_IG_STREAM_DONE`.

## Package
- versionCode: 66
- versionName: 0.1.65
