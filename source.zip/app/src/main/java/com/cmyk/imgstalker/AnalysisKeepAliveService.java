package com.cmyk.imgstalker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.IBinder;
import android.os.PowerManager;

public class AnalysisKeepAliveService extends Service {
    private static final String CHANNEL_ID = "imgstalker_analysis";
    private static final int NOTIFICATION_ID = 1052;
    private static final long WAKE_LOCK_TIMEOUT_MS = 6L * 60L * 60L * 1000L;

    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        DiagnosticLog.install(this);
        createNotificationChannel();
        acquireWakeLock();
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE onCreate");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification = buildNotification();
        startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE foreground startId=" + startId);
        return START_NOT_STICKY;
    }

    private void createNotificationChannel() {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "バックグラウンド解析",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("ImgStalkerの解析をバックグラウンドで継続します");
        channel.setSound(null, null);
        channel.enableVibration(false);
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Intent launchIntent = new Intent(this, MainActivity.class);
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                this,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("ImgStalker")
                .setContentText("バックグラウンドで解析中")
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ImgStalker:BackgroundAnalysis");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(WAKE_LOCK_TIMEOUT_MS);
            DiagnosticLog.log("BACKGROUND_ANALYSIS_WAKELOCK acquire");
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_ANALYSIS_WAKELOCK acquire_fail", t);
        }
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            DiagnosticLog.log("BACKGROUND_ANALYSIS_WAKELOCK release");
        } catch (Throwable t) {
            DiagnosticLog.logException("BACKGROUND_ANALYSIS_WAKELOCK release_fail", t);
        }
        wakeLock = null;
    }

    @Override public void onTimeout(int startId, int fgsType) {
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE timeout startId=" + startId + " type=" + fgsType);
        stopSelf(startId);
    }

    @Override public void onDestroy() {
        releaseWakeLock();
        stopForeground(STOP_FOREGROUND_REMOVE);
        DiagnosticLog.log("BACKGROUND_ANALYSIS_SERVICE onDestroy");
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }
}
