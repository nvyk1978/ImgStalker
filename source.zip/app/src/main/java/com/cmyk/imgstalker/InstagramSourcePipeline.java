package com.cmyk.imgstalker;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Instagram source-first crawler.
 *
 * This pipeline intentionally does not navigate, scroll or click an Instagram WebView.
 * Discovery and post resolution run as two independent producer/consumer stages:
 *
 *   profile feed -> ordered post queue -> media-info resolver -> MediaSet
 *
 * Browser state is used only as an authentication source (CookieManager is sampled by the
 * caller before start).  A 429 never triggers an immediate retry storm: all workers share one
 * request gate and honor Retry-After when supplied.  Posts that still fail after one deferred
 * retry are reported as skipped so a later ImgStalker resume can retry only those posts.
 */
final class InstagramSourcePipeline {
    interface Listener {
        void onProfileMeta(String username, int expectedPosts);
        void onPostDiscovered(int index, String postUrl);
        void onPostResolved(String postUrl, List<ResolvedMedia> media);
        void onPostRetry(String postUrl, int attempt, String reason, long delayMs);
        void onPostSkipped(String postUrl, String reason);
        void onRateLimited(String scope, int statusCode, long waitMs);
        void onComplete(int discovered, int resolved, int skipped, int expectedPosts, boolean countMatched);
        void onFatal(String message);
    }

    static final class ResolvedMedia {
        final MediaItem.Kind kind;
        final String url;
        final int width;
        final int height;

        ResolvedMedia(MediaItem.Kind kind, String url, int width, int height) {
            this.kind = kind;
            this.url = url == null ? "" : url;
            this.width = Math.max(0, width);
            this.height = Math.max(0, height);
        }
    }

    private static final class PostTask {
        static final PostTask END = new PostTask("", true);
        final String url;
        final boolean end;

        PostTask(String url) { this(url, false); }
        private PostTask(String url, boolean end) {
            this.url = url == null ? "" : url;
            this.end = end;
        }
    }

    private static final class HttpResult {
        final int code;
        final String body;
        final long retryAfterMs;

        HttpResult(int code, String body, long retryAfterMs) {
            this.code = code;
            this.body = body == null ? "" : body;
            this.retryAfterMs = Math.max(0L, retryAfterMs);
        }
    }

    private static final class ProfileIdentity {
        final String userId;
        final int expectedPosts;
        final String source;

        ProfileIdentity(String userId, int expectedPosts, String source) {
            this.userId = userId == null ? "" : userId;
            this.expectedPosts = Math.max(0, expectedPosts);
            this.source = source == null ? "" : source;
        }

        boolean valid() { return !userId.isEmpty(); }
    }

    private static final class ResolveResult {
        final boolean ok;
        final boolean rateLimited;
        final int statusCode;
        final long retryAfterMs;
        final String reason;
        final List<ResolvedMedia> media;

        private ResolveResult(boolean ok, boolean rateLimited, int statusCode, long retryAfterMs,
                              String reason, List<ResolvedMedia> media) {
            this.ok = ok;
            this.rateLimited = rateLimited;
            this.statusCode = statusCode;
            this.retryAfterMs = retryAfterMs;
            this.reason = reason == null ? "" : reason;
            this.media = media == null ? Collections.emptyList() : media;
        }

        static ResolveResult ok(List<ResolvedMedia> media) {
            return new ResolveResult(true, false, 200, 0L, "", media);
        }

        static ResolveResult fail(String reason, int statusCode) {
            return new ResolveResult(false, false, statusCode, 0L, reason, Collections.emptyList());
        }

        static ResolveResult limited(int statusCode, long retryAfterMs, String reason) {
            return new ResolveResult(false, true, statusCode, retryAfterMs, reason, Collections.emptyList());
        }
    }

    private static final String IG_APP_ID = "936619743392459";
    private static final String IG_ASBD_ID = "129477";
    private static final String PUBLIC_GRAPHQL_URL = "https://www.instagram.com/graphql/query/";
    private static final String PUBLIC_GRAPHQL_WEB_URL = "https://www.instagram.com/api/graphql";
    private static final String PROFILE_SEARCH_DOC_ID = "26347858941511777";
    private static final String PROFILE_INFO_DOC_ID = "28036671149327607";
    private static final String MEDIA_INFO_DOC_ID = "27128499623469141";
    // Web profile timeline query. The source parser attempts to discover a fresher doc_id first;
    // this value is only a last-resort web-query candidate and is never followed by a private/mobile API fallback.
    private static final String PROFILE_TIMELINE_WEB_DOC_ID_FALLBACK = "34579740524958711";
    private static final String GRAPHQL_APP_UA = "Instagram 273.0.0.16.70 (iPhone15,2; iOS 17_5_1; en_US; en-US; scale=3.00; 1290x2796; 470085518)";
    private static final int PAGE_SIZE = 12;
    private static final long PAGE_PACE_MS = 1200L;
    private static final long POST_PACE_MS = 550L;
    private static final long FALLBACK_PACE_MS = 300L;
    private static final long DEFAULT_429_WAIT_MS = 45000L;
    private static final long MAX_429_WAIT_MS = 120000L;
    private static final int POST_RETRY_LIMIT = 1; // first pass + one deferred retry

    private final Listener listener;
    private final String cookie;
    private final String userAgent;
    private final String csrf;
    private volatile String runtimeCsrf;
    private volatile String profileSourceBody = "";
    private volatile String profileLsd = "";
    private volatile String profileFbDtsg = "";
    private volatile String profileTimelineDocId = "";
    private final ExecutorService discoveryExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService resolverExecutor = Executors.newSingleThreadExecutor();
    private final LinkedBlockingQueue<PostTask> postQueue = new LinkedBlockingQueue<>();
    private final LinkedHashSet<String> discoveredUrls = new LinkedHashSet<>();
    private final Set<String> completedSeed = Collections.synchronizedSet(new HashSet<>());
    private final List<String> retryQueue = Collections.synchronizedList(new ArrayList<>());
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private final AtomicBoolean active = new AtomicBoolean(false);
    private final AtomicBoolean discoveryDone = new AtomicBoolean(false);
    private final AtomicBoolean fatal = new AtomicBoolean(false);
    private final AtomicLong requestGateUntil = new AtomicLong(0L);

    private volatile int expectedPosts = 0;
    private volatile int resolvedPosts = 0;
    private volatile int skippedPosts = 0;
    private volatile int targetLimit = 300;
    private volatile boolean followPagination = true;
    private volatile boolean resolveDetails = true;
    private volatile String username = "";

    InstagramSourcePipeline(String cookie, String userAgent, Listener listener) {
        this.cookie = cookie == null ? "" : cookie;
        this.userAgent = (userAgent == null || userAgent.trim().isEmpty())
                ? "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/151.0 Mobile Safari/537.36"
                : userAgent.trim();
        this.csrf = cookieValue(this.cookie, "csrftoken");
        this.runtimeCsrf = this.csrf;
        this.listener = listener;
    }

    void start(String inputUrl, int targetLimit, boolean followPagination, boolean resolveDetails,
               Collection<String> completed, Collection<String> discoveredSeed) {
        if (!active.compareAndSet(false, true)) return;
        this.targetLimit = Math.max(1, Math.min(300, targetLimit));
        this.followPagination = followPagination;
        this.resolveDetails = resolveDetails;
        if (completed != null) {
            for (String raw : completed) {
                String canonical = canonicalPostUrl(raw);
                if (!canonical.isEmpty()) completedSeed.add(canonical);
            }
        }

        String onePost = canonicalPostUrl(inputUrl);
        if (!onePost.isEmpty()) {
            username = "";
            expectedPosts = 1;
            listener.onProfileMeta("", 1);
            rememberAndQueue(onePost);
            discoveryDone.set(true);
            postQueue.offer(PostTask.END);
            resolverExecutor.execute(this::resolverLoop);
            return;
        }

        username = usernameFromProfile(inputUrl);
        if (username.isEmpty()) {
            active.set(false);
            listener.onFatal("InstagramプロフィールURLを確認してください");
            return;
        }

        resolverExecutor.execute(this::resolverLoop);
        discoveryExecutor.execute(() -> discoveryLoop(discoveredSeed));
    }

    void cancel() {
        cancelled.set(true);
        active.set(false);
        postQueue.clear();
        postQueue.offer(PostTask.END);
        discoveryExecutor.shutdownNow();
        resolverExecutor.shutdownNow();
    }

    boolean isActive() { return active.get() && !cancelled.get(); }
    boolean isDiscoveryDone() { return discoveryDone.get(); }
    int getDiscoveredCount() { synchronized (discoveredUrls) { return discoveredUrls.size(); } }
    int getResolvedCount() { return resolvedPosts; }
    int getSkippedCount() { return skippedPosts; }
    int getExpectedPosts() { return expectedPosts; }

    String snapshot() {
        return "sourceActive=" + isActive()
                + ",discoveryDone=" + discoveryDone.get()
                + ",discovered=" + getDiscoveredCount()
                + ",resolved=" + resolvedPosts
                + ",skipped=" + skippedPosts
                + ",expected=" + expectedPosts
                + ",queue=" + postQueue.size()
                + ",retry=" + retryQueue.size();
    }

    private void discoveryLoop(Collection<String> discoveredSeed) {
        try {
            if (discoveredSeed != null) {
                for (String raw : discoveredSeed) {
                    if (cancelled.get()) break;
                    String canonical = canonicalPostUrl(raw);
                    if (!canonical.isEmpty() && !completedSeed.contains(canonical)) rememberAndQueue(canonical);
                }
            }
            discoverProfileFeed();
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_IG_SOURCE_DISCOVERY_FATAL", t);
            String msg = t.getMessage() == null ? "" : t.getMessage();
            if (msg.startsWith("instagram_spam_gate")) {
                abortFatal("Instagram側が投稿一覧取得を一時拒否しました (spam gate)。時間を空けて再開してください");
            } else {
                abortFatal("Instagram投稿URL取得に失敗: " + t.getClass().getSimpleName());
            }
        } finally {
            discoveryDone.set(true);
            postQueue.offer(PostTask.END);
            DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_DONE discovered=" + getDiscoveredCount()
                    + " expected=" + expectedPosts + " cancelled=" + cancelled.get());
        }
    }

    private void discoverProfileFeed() throws Exception {
        ProfileIdentity identity = resolveProfileIdentity();
        if (!identity.valid()) {
            throw new IllegalStateException("Instagram user id not resolved for " + username);
        }
        if (identity.expectedPosts > 0) {
            expectedPosts = identity.expectedPosts;
            listener.onProfileMeta(username, expectedPosts);
        } else {
            listener.onProfileMeta(username, 0);
        }
        DiagnosticLog.log("SNS_IG_SOURCE_IDENTITY username=" + username
                + " userId=" + identity.userId + " expected=" + expectedPosts
                + " source=" + identity.source);

        int sourceAdded = discoverProfileSourcePosts(profileSourceBody);
        int target = expectedPosts > 0 ? Math.min(expectedPosts, targetLimit) : targetLimit;
        DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_SOURCE_DISCOVERY added=" + sourceAdded
                + " discovered=" + getDiscoveredCount() + " target=" + target
                + " lsd=" + (!profileLsd.isEmpty()) + " csrf=" + (!runtimeCsrf.isEmpty())
                + " docId=" + (!profileTimelineDocId.isEmpty()));

        if (!cancelled.get() && getDiscoveredCount() < target && followPagination) {
            discoverWebGraphqlTimeline(identity.userId);
        }

        int discovered = getDiscoveredCount();
        int expectedTarget = expectedPosts > 0 ? Math.min(expectedPosts, targetLimit) : 0;
        if (expectedTarget > 0 && discovered < expectedTarget) {
            DiagnosticLog.log("SNS_IG_SOURCE_COUNT_MISMATCH expectedTarget=" + expectedTarget
                    + " discovered=" + discovered);
        } else if (expectedTarget > 0) {
            DiagnosticLog.log("SNS_IG_SOURCE_COUNT_MATCH expectedTarget=" + expectedTarget
                    + " discovered=" + discovered);
        }
        if (discovered == 0) {
            throw new IllegalStateException("Instagram posts not discovered");
        }
    }

    private ProfileIdentity resolveProfileIdentity() throws Exception {
        String userId = "";
        int count = 0;
        String source = "";
        String profileUrl = "https://www.instagram.com/" + username + "/";

        // Source first: this is the same web document the user would normally open, but there is no WebView,
        // scrolling or DOM interaction.  It also gives us fresh web tokens and sometimes the first post page.
        HttpResult html = getHtml(profileUrl, "https://www.instagram.com/", "profile_source");
        if (isSpamGate(html.body)) throw new IllegalStateException("instagram_spam_gate:profile_source");
        if (html.code == 429) {
            registerRateLimit("profile_source", html);
            throw new IllegalStateException("Instagram rate limited during profile source lookup");
        }
        if (html.code == 200 && !html.body.isEmpty()) {
            profileSourceBody = html.body;
            profileLsd = extractToken(html.body, "\\[\\\"LSD\\\",\\[\\],\\{\\\"token\\\":\\\"([^\\\"]+)\\\"");
            profileFbDtsg = extractToken(html.body, "\\[\\\"DTSG(?:Init|Initial)Data\\\",\\[\\],\\{\\\"token\\\":\\\"([^\\\"]+)\\\"");
            profileTimelineDocId = extractProfileTimelineDocId(html.body);
            userId = profileIdFromSource(html.body, username);
            count = mediaCountFromSource(html.body);
            if (!userId.isEmpty() || count > 0) source = "profile_source";
        }

        if (userId.isEmpty()) {
            JSONObject searchVars = new JSONObject();
            searchVars.put("hasQuery", true);
            searchVars.put("query", username);
            HttpResult search = postDocIdGraphql(PUBLIC_GRAPHQL_URL, PROFILE_SEARCH_DOC_ID, searchVars,
                    "https://www.instagram.com/", "profile_search", GRAPHQL_APP_UA, profileLsd, profileFbDtsg);
            if (isSpamGate(search.body)) throw new IllegalStateException("instagram_spam_gate:profile_search");
            if (search.code == 429) {
                registerRateLimit("profile_search", search);
                throw new IllegalStateException("Instagram rate limited during profile search");
            }
            if (search.code == 200 && !search.body.isEmpty()) {
                try {
                    JSONObject root = new JSONObject(search.body);
                    JSONObject data = root.optJSONObject("data");
                    JSONObject serp = data == null ? null : data.optJSONObject("xdt_api__v1__fbsearch__non_profiled_serp");
                    JSONArray users = serp == null ? null : serp.optJSONArray("users");
                    if (users != null) {
                        for (int i = 0; i < users.length(); i++) {
                            JSONObject wrapper = users.optJSONObject(i);
                            JSONObject u = wrapper == null ? null : wrapper.optJSONObject("user");
                            if (u == null) u = wrapper;
                            if (u == null || !username.equalsIgnoreCase(u.optString("username", ""))) continue;
                            userId = firstNonEmpty(u.optString("pk", ""), u.optString("id", ""));
                            count = Math.max(count, deepMediaCount(u, 0));
                            source = source.isEmpty() ? "fbsearch_doc_id" : source + "+fbsearch_doc_id";
                            break;
                        }
                    }
                } catch (Throwable t) {
                    DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_SEARCH_PARSE_FAIL reason=" + t.getClass().getSimpleName());
                }
            }
        }

        if (userId.isEmpty()) {
            String endpoint = "https://www.instagram.com/api/v1/users/web_profile_info/?username="
                    + URLEncoder.encode(username, "UTF-8");
            HttpResult info = getJson(endpoint, profileUrl, "profile_info_v1");
            if (isSpamGate(info.body)) throw new IllegalStateException("instagram_spam_gate:profile_info");
            if (info.code == 429) {
                registerRateLimit("profile_info_v1", info);
                throw new IllegalStateException("Instagram rate limited during profile lookup");
            }
            if (info.code == 200 && !info.body.isEmpty()) {
                try {
                    JSONObject root = new JSONObject(info.body);
                    JSONObject data = root.optJSONObject("data");
                    JSONObject u = data == null ? null : data.optJSONObject("user");
                    if (u != null) {
                        userId = firstNonEmpty(u.optString("id", ""), u.optString("pk", ""));
                        count = Math.max(count, deepMediaCount(u, 0));
                        source = source.isEmpty() ? "web_profile_info" : source + "+web_profile_info";
                    }
                } catch (Throwable t) {
                    DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_INFO_PARSE_FAIL reason=" + t.getClass().getSimpleName());
                }
            }
        }

        if (userId.isEmpty()) {
            String endpoint = "https://www.instagram.com/web/search/topsearch/?context=blended&query="
                    + URLEncoder.encode(username, "UTF-8")
                    + "&rank_token=0.7763938004511706&include_reel=true";
            HttpResult top = getJson(endpoint, "https://www.instagram.com/", "profile_topsearch");
            if (isSpamGate(top.body)) throw new IllegalStateException("instagram_spam_gate:profile_topsearch");
            if (top.code == 429) {
                registerRateLimit("profile_topsearch", top);
                throw new IllegalStateException("Instagram rate limited during profile search fallback");
            }
            if (top.code == 200 && !top.body.isEmpty()) {
                try {
                    JSONObject root = new JSONObject(top.body);
                    JSONArray users = root.optJSONArray("users");
                    if (users != null) {
                        for (int i = 0; i < users.length(); i++) {
                            JSONObject wrapper = users.optJSONObject(i);
                            JSONObject u = wrapper == null ? null : wrapper.optJSONObject("user");
                            if (u == null || !username.equalsIgnoreCase(u.optString("username", ""))) continue;
                            userId = firstNonEmpty(u.optString("pk", ""), u.optString("id", ""));
                            count = Math.max(count, deepMediaCount(u, 0));
                            source = source.isEmpty() ? "topsearch" : source + "+topsearch";
                            break;
                        }
                    }
                } catch (Throwable t) {
                    DiagnosticLog.log("SNS_IG_SOURCE_TOPSEARCH_PARSE_FAIL reason=" + t.getClass().getSimpleName());
                }
            }
        }

        if (!userId.isEmpty() && count <= 0) {
            int gqlCount = fetchExpectedCountViaProfileDocId(userId);
            if (gqlCount > 0) {
                count = gqlCount;
                source = source.isEmpty() ? "profile_doc_id" : source + "+profile_doc_id";
            }
        }
        return new ProfileIdentity(userId, count, source);
    }

    private int fetchExpectedCountViaProfileDocId(String userId) {
        try {
            JSONObject vars = new JSONObject();
            vars.put("enable_integrity_filters", true);
            vars.put("id", userId);
            vars.put("render_surface", "PROFILE");
            vars.put("__relay_internal__pv__PolarisCannesGuardianExperienceEnabledrelayprovider", true);
            vars.put("__relay_internal__pv__PolarisCASB976ProfileEnabledrelayprovider", false);
            vars.put("__relay_internal__pv__PolarisWebSchoolsEnabledrelayprovider", false);
            vars.put("__relay_internal__pv__PolarisRepostsConsumptionEnabledrelayprovider", false);
            vars.put("__relay_internal__pv__PolarisShortDramaEnabledrelayprovider", false);
            HttpResult http = postDocIdGraphql(PUBLIC_GRAPHQL_URL, PROFILE_INFO_DOC_ID, vars,
                    "https://www.instagram.com/" + username + "/", "profile_doc_id",
                    userAgent, profileLsd, profileFbDtsg);
            if (isSpamGate(http.body)) throw new IllegalStateException("instagram_spam_gate:profile_doc_id");
            if (http.code != 200 || http.body.isEmpty()) return 0;
            JSONObject root = new JSONObject(http.body);
            JSONObject data = root.optJSONObject("data");
            JSONObject user = data == null ? null : data.optJSONObject("user");
            return deepMediaCount(user, 0);
        } catch (Throwable t) {
            if (t.getMessage() != null && t.getMessage().startsWith("instagram_spam_gate")) throw new RuntimeException(t);
            DiagnosticLog.log("SNS_IG_SOURCE_PROFILE_DOC_SKIP reason=" + t.getClass().getSimpleName());
            return 0;
        }
    }

    private static final class SourcePostCandidate {
        final int position;
        final String url;
        SourcePostCandidate(int position, String url) { this.position = position; this.url = url; }
    }

    private int discoverProfileSourcePosts(String body) {
        if (body == null || body.isEmpty()) return 0;
        String decoded = decodeInstagramSource(body);
        ArrayList<SourcePostCandidate> candidates = new ArrayList<>();
        Pattern path = Pattern.compile("/(p|reel)/([A-Za-z0-9_-]{5,30})/", Pattern.CASE_INSENSITIVE);
        Matcher pm = path.matcher(decoded);
        while (pm.find()) {
            candidates.add(new SourcePostCandidate(pm.start(), "https://www.instagram.com/"
                    + pm.group(1).toLowerCase(Locale.ROOT) + "/" + pm.group(2) + "/"));
        }
        Pattern shortcode = Pattern.compile("\\\"shortcode\\\"\\s*:\\s*\\\"([A-Za-z0-9_-]{5,30})\\\"");
        Matcher sm = shortcode.matcher(decoded);
        while (sm.find()) {
            candidates.add(new SourcePostCandidate(sm.start(), "https://www.instagram.com/p/" + sm.group(1) + "/"));
        }
        candidates.sort((a, b) -> Integer.compare(a.position, b.position));
        int before = getDiscoveredCount();
        for (SourcePostCandidate c : candidates) {
            if (getDiscoveredCount() >= targetLimit) break;
            rememberAndQueue(c.url);
        }
        return getDiscoveredCount() - before;
    }

    private void discoverWebGraphqlTimeline(String userId) throws Exception {
        String docId = profileTimelineDocId;
        if (docId.isEmpty()) docId = PROFILE_TIMELINE_WEB_DOC_ID_FALLBACK;
        String cursor = getDiscoveredCount() > 0 ? extractInitialCursor(profileSourceBody) : "";
        int page = 0;
        boolean first = true;
        while (!cancelled.get() && getDiscoveredCount() < targetLimit) {
            if (!first && !followPagination) break;
            JSONObject vars = buildWebTimelineVariables(userId, cursor, Math.min(PAGE_SIZE,
                    Math.max(1, targetLimit - getDiscoveredCount())));
            HttpResult http = postDocIdGraphql(PUBLIC_GRAPHQL_URL, docId, vars,
                    "https://www.instagram.com/" + username + "/", "timeline_web_graphql",
                    userAgent, profileLsd, profileFbDtsg);
            if (isSpamGate(http.body)) {
                DiagnosticLog.log("SNS_IG_SOURCE_SPAM_GATE scope=timeline_web_graphql page=" + page
                        + " discovered=" + getDiscoveredCount());
                throw new IllegalStateException("instagram_spam_gate:timeline_web_graphql");
            }
            if (http.code == 429) {
                long wait = registerRateLimit("timeline_web_graphql", http);
                if (!sleepInterruptibly(wait)) break;
                http = postDocIdGraphql(PUBLIC_GRAPHQL_URL, docId, vars,
                        "https://www.instagram.com/" + username + "/", "timeline_web_graphql_retry",
                        userAgent, profileLsd, profileFbDtsg);
                if (isSpamGate(http.body)) throw new IllegalStateException("instagram_spam_gate:timeline_web_graphql_retry");
            }
            if (http.code == 401 || http.code == 403 || containsAuthGate(http.body)) {
                throw new IllegalStateException("Instagram認証が必要です (HTTP " + http.code + ")");
            }
            if (http.code != 200 || http.body.isEmpty()) {
                DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_STOP route=web_graphql reason=http_" + http.code
                        + " page=" + page + " docId=" + docId);
                break;
            }
            JSONObject root;
            try { root = new JSONObject(http.body); }
            catch (Throwable t) {
                DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_STOP route=web_graphql reason=json_"
                        + t.getClass().getSimpleName() + " page=" + page);
                break;
            }
            int before = getDiscoveredCount();
            collectPostCodes(root, 0);
            int added = getDiscoveredCount() - before;
            String next = findCursorRecursive(root, 0);
            boolean more = findHasMoreRecursive(root, 0, !next.isEmpty());
            page++;
            DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERY_PAGE route=web_graphql page=" + page
                    + " added=" + added + " discovered=" + getDiscoveredCount()
                    + " expected=" + expectedPosts + " more=" + more
                    + " cursor=" + (!next.isEmpty()) + " docId=" + docId);
            if (!more || next.isEmpty() || next.equals(cursor) || (added == 0 && page > 1)) break;
            cursor = next;
            first = false;
            if (!sleepInterruptibly(PAGE_PACE_MS)) break;
        }
    }

    private JSONObject buildWebTimelineVariables(String userId, String cursor, int count) throws Exception {
        JSONObject vars = new JSONObject();
        JSONObject data = new JSONObject();
        data.put("count", Math.max(1, Math.min(12, count)));
        data.put("include_relationship_info", true);
        data.put("latest_besties_reel_media", true);
        data.put("latest_reel_media", true);
        vars.put("data", data);
        vars.put("username", username);
        vars.put("__relay_internal__pv__PolarisFeedShareMenurelayprovider", false);
        if (cursor != null && !cursor.isEmpty()) vars.put("after", cursor);
        return vars;
    }

    private void collectPostCodes(Object value, int depth) {
        if (value == null || depth > 12 || getDiscoveredCount() >= targetLimit) return;
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            String code = firstNonEmpty(obj.optString("shortcode", ""), obj.optString("code", ""));
            if (!code.isEmpty() && looksLikePostObject(obj)) {
                String product = obj.optString("product_type", "").toLowerCase(Locale.ROOT);
                String typename = obj.optString("__typename", "").toLowerCase(Locale.ROOT);
                String path = (product.equals("clips") || product.equals("reels") || typename.contains("reel")) ? "reel" : "p";
                rememberAndQueue("https://www.instagram.com/" + path + "/" + code + "/");
            }
            JSONArray names = obj.names();
            if (names != null) {
                for (int i = 0; i < names.length() && getDiscoveredCount() < targetLimit; i++) {
                    collectPostCodes(obj.opt(names.optString(i)), depth + 1);
                }
            }
        } else if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i = 0; i < a.length() && getDiscoveredCount() < targetLimit; i++) {
                collectPostCodes(a.opt(i), depth + 1);
            }
        }
    }

    private static boolean looksLikePostObject(JSONObject obj) {
        return obj.has("media_type") || obj.has("product_type") || obj.has("display_url")
                || obj.has("image_versions2") || obj.has("video_versions") || obj.has("carousel_media")
                || obj.has("edge_media_to_caption") || obj.has("edge_sidecar_to_children")
                || obj.has("taken_at") || obj.has("taken_at_timestamp") || obj.has("is_video");
    }

    private static String findCursorRecursive(Object value, int depth) {
        if (value == null || depth > 12) return "";
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            String[] keys = {"end_cursor", "next_max_id", "profile_grid_items_cursor", "cursor"};
            for (String key : keys) {
                String v = obj.optString(key, "");
                if (!v.isEmpty() && v.length() > 4) return v;
            }
            JSONArray names = obj.names();
            if (names != null) for (int i = 0; i < names.length(); i++) {
                String found = findCursorRecursive(obj.opt(names.optString(i)), depth + 1);
                if (!found.isEmpty()) return found;
            }
        } else if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i = 0; i < a.length(); i++) {
                String found = findCursorRecursive(a.opt(i), depth + 1);
                if (!found.isEmpty()) return found;
            }
        }
        return "";
    }

    private static boolean findHasMoreRecursive(Object value, int depth, boolean defaultValue) {
        if (value == null || depth > 10) return defaultValue;
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            if (obj.has("has_next_page")) return obj.optBoolean("has_next_page", defaultValue);
            if (obj.has("more_available")) return obj.optBoolean("more_available", defaultValue);
            JSONArray names = obj.names();
            if (names != null) for (int i = 0; i < names.length(); i++) {
                Object child = obj.opt(names.optString(i));
                if (child instanceof JSONObject || child instanceof JSONArray) {
                    boolean childDefault = findCursorRecursive(child, depth + 1).isEmpty() ? defaultValue : true;
                    boolean found = findHasMoreRecursive(child, depth + 1, childDefault);
                    if (found != defaultValue || childDefault) return found;
                }
            }
        } else if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i = 0; i < a.length(); i++) {
                Object child = a.opt(i);
                if (child instanceof JSONObject || child instanceof JSONArray) {
                    boolean found = findHasMoreRecursive(child, depth + 1, defaultValue);
                    if (found != defaultValue) return found;
                }
            }
        }
        return defaultValue;
    }

    private static String extractInitialCursor(String body) {
        String decoded = decodeInstagramSource(body);
        String[] patterns = {
                "\\\"end_cursor\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"",
                "\\\"next_max_id\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"",
                "\\\"profile_grid_items_cursor\\\"\\s*:\\s*\\\"([^\\\"]+)\\\""
        };
        for (String regex : patterns) {
            try {
                Matcher m = Pattern.compile(regex).matcher(decoded);
                if (m.find()) return m.group(1);
            } catch (Throwable ignored) {}
        }
        return "";
    }

    private static String extractProfileTimelineDocId(String body) {
        if (body == null || body.isEmpty()) return "";
        String decoded = decodeInstagramSource(body);
        String[] keywords = {"PolarisProfilePostsTabContentQuery", "ProfilePostsTabContentQuery",
                "IGProfileTimelineQuery", "ProfileTimelineQuery"};
        Pattern idPattern = Pattern.compile("(?:doc_id|id)\\\"?\\s*[:=]\\s*\\\"(\\d{14,})\\\"");
        for (String keyword : keywords) {
            int from = 0;
            while (true) {
                int pos = decoded.indexOf(keyword, from);
                if (pos < 0) break;
                int start = Math.max(0, pos - 2500);
                int end = Math.min(decoded.length(), pos + 2500);
                Matcher m = idPattern.matcher(decoded.substring(start, end));
                String last = "";
                while (m.find()) last = m.group(1);
                if (!last.isEmpty()) return last;
                from = pos + keyword.length();
            }
        }
        return "";
    }

    private static String decodeInstagramSource(String body) {
        return (body == null ? "" : body).replace("\\u0026", "&").replace("\\u003d", "=")
                .replace("\\u002f", "/").replace("\\u002F", "/")
                .replace("\\/", "/").replace("\\\"", "\"").replace("&amp;", "&");
    }

    private boolean rememberAndQueue(String raw) {
        String canonical = canonicalPostUrl(raw);
        if (canonical.isEmpty()) return false;
        final int index;
        synchronized (discoveredUrls) {
            if (!discoveredUrls.add(canonical)) return false;
            index = discoveredUrls.size() - 1;
        }
        listener.onPostDiscovered(index, canonical);
        DiagnosticLog.log("SNS_IG_SOURCE_DISCOVERED index=" + index + " url=" + canonical);
        if (!completedSeed.contains(canonical) && resolveDetails) postQueue.offer(new PostTask(canonical));
        return true;
    }

    private void resolverLoop() {
        try {
            while (!cancelled.get()) {
                PostTask task = postQueue.poll(1200L, TimeUnit.MILLISECONDS);
                if (task == null) {
                    if (discoveryDone.get()) break;
                    continue;
                }
                if (task.end) break;
                resolveOne(task.url, false);
                if (!sleepInterruptibly(POST_PACE_MS)) break;
            }

            if (!cancelled.get() && resolveDetails) {
                List<String> retrySnapshot;
                synchronized (retryQueue) { retrySnapshot = new ArrayList<>(retryQueue); }
                retryQueue.clear();
                for (String url : retrySnapshot) {
                    if (cancelled.get()) break;
                    listener.onPostRetry(url, 1, "deferred", 1200L);
                    DiagnosticLog.log("SNS_IG_SOURCE_RETRY url=" + url + " attempt=1 delayMs=1200");
                    if (!sleepInterruptibly(1200L)) break;
                    resolveOne(url, true);
                    if (!sleepInterruptibly(POST_PACE_MS)) break;
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Throwable t) {
            DiagnosticLog.logException("SNS_IG_SOURCE_RESOLVER_FATAL", t);
            abortFatal("Instagram投稿解析に失敗: " + t.getClass().getSimpleName());
        } finally {
            active.set(false);
            if (!cancelled.get() && !fatal.get()) {
                int discovered = getDiscoveredCount();
                int target = expectedPosts > 0 ? Math.min(expectedPosts, targetLimit) : 0;
                boolean matched = target <= 0 || discovered >= target;
                listener.onComplete(discovered, resolvedPosts, skippedPosts, expectedPosts, matched);
                DiagnosticLog.log("SNS_IG_SOURCE_PIPELINE_DONE discovered=" + discovered
                        + " resolved=" + resolvedPosts + " skipped=" + skippedPosts
                        + " expected=" + expectedPosts + " countMatched=" + matched);
            }
        }
    }

    private void resolveOne(String postUrl, boolean retryPass) {
        if (cancelled.get() || completedSeed.contains(postUrl)) return;
        String code = shortcodeFromPostUrl(postUrl);
        if (code.isEmpty()) {
            skip(postUrl, "shortcode_missing");
            return;
        }

        DiagnosticLog.log("SNS_IG_SOURCE_RESOLVE_START retry=" + retryPass + " url=" + postUrl);
        ResolveResult result = resolvePost(code, postUrl);
        if (result.rateLimited) {
            long wait = Math.max(DEFAULT_429_WAIT_MS, result.retryAfterMs);
            wait = Math.min(MAX_429_WAIT_MS, wait);
            requestGateUntil.accumulateAndGet(System.currentTimeMillis() + wait, Math::max);
            listener.onRateLimited("post", result.statusCode, wait);
            DiagnosticLog.log("SNS_IG_SOURCE_RATE_LIMIT scope=post http=" + result.statusCode
                    + " waitMs=" + wait + " url=" + postUrl);
            if (!retryPass) {
                if (!retryQueue.contains(postUrl)) retryQueue.add(postUrl);
            } else {
                skip(postUrl, "rate_limited");
            }
            return;
        }
        if (!result.ok || result.media.isEmpty()) {
            String reason = result.reason.isEmpty() ? "media_empty" : result.reason;
            if (reason.startsWith("spam_gate")) {
                abortFatal("Instagram側が投稿取得を一時拒否しました (spam gate)。時間を空けて再開してください");
                return;
            }
            if (reason.startsWith("auth_gate_")) {
                abortFatal("Instagram認証が必要です (" + reason + ")");
                return;
            }
            if (!retryPass) {
                if (!retryQueue.contains(postUrl)) retryQueue.add(postUrl);
                listener.onPostRetry(postUrl, 0, reason, 0L);
                DiagnosticLog.log("SNS_IG_SOURCE_RETRY_DEFER reason=" + reason + " url=" + postUrl);
            } else {
                skip(postUrl, reason);
            }
            return;
        }

        completedSeed.add(postUrl);
        resolvedPosts++;
        listener.onPostResolved(postUrl, result.media);
        DiagnosticLog.log("SNS_IG_SOURCE_RESOLVE_DONE media=" + result.media.size()
                + " resolved=" + resolvedPosts + " url=" + postUrl);
    }

    private void skip(String postUrl, String reason) {
        skippedPosts++;
        listener.onPostSkipped(postUrl, reason);
        DiagnosticLog.log("SNS_IG_SOURCE_SKIP reason=" + reason + " skipped=" + skippedPosts + " url=" + postUrl);
    }

    private ResolveResult resolvePost(String shortcode, String postUrl) {
        try {
            ResolveResult graphql = resolvePostGraphql(shortcode, postUrl);
            if (graphql.rateLimited) return graphql;
            if (graphql.ok && !graphql.media.isEmpty()) return graphql;
            if (graphql.reason.startsWith("auth_gate_") || graphql.reason.startsWith("spam_gate")) return graphql;

            // Final source fallback.  No private/mobile media-info request and no WebView navigation.
            HttpResult html = getHtml(postUrl, "https://www.instagram.com/", "post_source_html");
            if (isSpamGate(html.body)) return ResolveResult.fail("spam_gate_post_source", html.code);
            if (html.code == 429) return ResolveResult.limited(429, html.retryAfterMs, "post_source_429");
            if (html.code == 401 || html.code == 403 || containsAuthGate(html.body)) {
                return ResolveResult.fail("auth_gate_" + html.code, html.code);
            }
            if (html.code == 200 && !html.body.isEmpty()) {
                try {
                    JSONObject root = new JSONObject(html.body);
                    JSONObject item = firstMediaItem(root, shortcode);
                    if (item != null) {
                        List<ResolvedMedia> media = parseMediaItem(item);
                        if (!media.isEmpty()) return ResolveResult.ok(media);
                    }
                } catch (Throwable ignored) {}
                List<ResolvedMedia> raw = parseRawSourceMedia(html.body);
                if (!raw.isEmpty()) return ResolveResult.ok(raw);
            }
            return ResolveResult.fail("media_not_resolved", html.code);
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_IG_SOURCE_RESOLVE_FAIL error=" + t.getClass().getSimpleName() + " url=" + postUrl);
            return ResolveResult.fail(t.getClass().getSimpleName(), 0);
        }
    }

    private List<ResolvedMedia> parseMediaItem(JSONObject item) {
        if (item == null) return Collections.emptyList();
        JSONArray carousel = item.optJSONArray("carousel_media");
        if (carousel != null && carousel.length() > 0) {
            ArrayList<ResolvedMedia> out = new ArrayList<>();
            for (int i = 0; i < carousel.length(); i++) {
                JSONObject child = carousel.optJSONObject(i);
                ResolvedMedia one = parseSingleMedia(child);
                if (one != null) out.add(one);
            }
            return out;
        }

        // GraphQL source fallback.
        JSONObject sidecar = item.optJSONObject("edge_sidecar_to_children");
        JSONArray edges = sidecar == null ? null : sidecar.optJSONArray("edges");
        if (edges != null && edges.length() > 0) {
            ArrayList<ResolvedMedia> out = new ArrayList<>();
            for (int i = 0; i < edges.length(); i++) {
                JSONObject edge = edges.optJSONObject(i);
                JSONObject node = edge == null ? null : edge.optJSONObject("node");
                ResolvedMedia one = parseGraphMedia(node);
                if (one != null) out.add(one);
            }
            return out;
        }

        ResolvedMedia one = parseSingleMedia(item);
        if (one == null) one = parseGraphMedia(item);
        return one == null ? Collections.emptyList() : Collections.singletonList(one);
    }

    private ResolvedMedia parseSingleMedia(JSONObject item) {
        if (item == null) return null;
        int mediaType = item.optInt("media_type", 0);
        JSONArray videos = item.optJSONArray("video_versions");
        if (mediaType == 2 || (videos != null && videos.length() > 0)) {
            JSONObject best = bestCandidate(videos);
            if (best != null) {
                String url = best.optString("url", "");
                if (!url.isEmpty()) return new ResolvedMedia(MediaItem.Kind.VIDEO, url,
                        best.optInt("width", 0), best.optInt("height", 0));
            }
            String direct = item.optString("video_url", "");
            if (!direct.isEmpty()) return new ResolvedMedia(MediaItem.Kind.VIDEO, direct,
                    item.optInt("original_width", 0), item.optInt("original_height", 0));
            return null;
        }

        JSONObject imageVersions = item.optJSONObject("image_versions2");
        JSONObject best = bestCandidate(imageVersions == null ? null : imageVersions.optJSONArray("candidates"));
        if (best != null) {
            String url = best.optString("url", "");
            if (!url.isEmpty()) return new ResolvedMedia(MediaItem.Kind.IMAGE, url,
                    best.optInt("width", 0), best.optInt("height", 0));
        }
        String direct = firstNonEmpty(item.optString("display_url", ""), item.optString("image_url", ""));
        if (!direct.isEmpty()) return new ResolvedMedia(MediaItem.Kind.IMAGE, direct,
                item.optInt("original_width", 0), item.optInt("original_height", 0));
        return null;
    }

    private ResolvedMedia parseGraphMedia(JSONObject node) {
        if (node == null) return null;
        boolean video = node.optBoolean("is_video", false)
                || node.optString("__typename", "").toLowerCase(Locale.ROOT).contains("video");
        if (video) {
            String url = node.optString("video_url", "");
            if (!url.isEmpty()) {
                JSONObject dimensions = node.optJSONObject("dimensions");
                return new ResolvedMedia(MediaItem.Kind.VIDEO, url,
                        dimensions == null ? 0 : dimensions.optInt("width", 0),
                        dimensions == null ? 0 : dimensions.optInt("height", 0));
            }
            return parseSingleMedia(node);
        }
        String url = firstNonEmpty(node.optString("display_url", ""), node.optString("display_src", ""));
        if (!url.isEmpty()) {
            JSONObject dimensions = node.optJSONObject("dimensions");
            return new ResolvedMedia(MediaItem.Kind.IMAGE, url,
                    dimensions == null ? 0 : dimensions.optInt("width", 0),
                    dimensions == null ? 0 : dimensions.optInt("height", 0));
        }
        return parseSingleMedia(node);
    }

    private static JSONObject bestCandidate(JSONArray candidates) {
        if (candidates == null || candidates.length() == 0) return null;
        JSONObject best = null;
        long bestArea = -1L;
        for (int i = 0; i < candidates.length(); i++) {
            JSONObject c = candidates.optJSONObject(i);
            if (c == null || c.optString("url", "").isEmpty()) continue;
            long w = Math.max(0, c.optLong("width", 0L));
            long h = Math.max(0, c.optLong("height", 0L));
            long area = w * h;
            if (best == null || area > bestArea) {
                best = c;
                bestArea = area;
            }
        }
        return best;
    }

    private JSONObject firstMediaItem(JSONObject root, String shortcode) {
        if (root == null) return null;
        JSONArray items = root.optJSONArray("items");
        if (items != null && items.length() > 0) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                String code = firstNonEmpty(item.optString("code", ""), item.optString("shortcode", ""));
                if (code.isEmpty() || shortcode.equals(code)) return item;
            }
            JSONObject first = items.optJSONObject(0);
            if (first != null) return first;
        }

        JSONObject data = root.optJSONObject("data");
        if (data != null) {
            JSONObject web = data.optJSONObject("xdt_api__v1__media__shortcode__web_info");
            JSONObject found = firstMediaItem(web, shortcode);
            if (found != null) return found;
            JSONObject xdt = data.optJSONObject("xdt_shortcode_media");
            if (xdt != null) return xdt;
            JSONObject gql = data.optJSONObject("shortcode_media");
            if (gql != null) return gql;
        }
        JSONObject graphql = root.optJSONObject("graphql");
        if (graphql != null) {
            JSONObject media = graphql.optJSONObject("shortcode_media");
            if (media != null) return media;
        }
        return findMediaObjectRecursive(root, shortcode, 0);
    }

    private JSONObject findMediaObjectRecursive(Object value, String shortcode, int depth) {
        if (value == null || depth > 8) return null;
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            String code = firstNonEmpty(obj.optString("code", ""), obj.optString("shortcode", ""));
            if ((!code.isEmpty() && code.equals(shortcode))
                    && (obj.has("carousel_media") || obj.has("image_versions2") || obj.has("video_versions")
                    || obj.has("display_url") || obj.has("edge_sidecar_to_children"))) return obj;
            JSONArray names = obj.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    Object child = obj.opt(names.optString(i));
                    JSONObject found = findMediaObjectRecursive(child, shortcode, depth + 1);
                    if (found != null) return found;
                }
            }
        } else if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i = 0; i < a.length(); i++) {
                JSONObject found = findMediaObjectRecursive(a.opt(i), shortcode, depth + 1);
                if (found != null) return found;
            }
        }
        return null;
    }

    private List<ResolvedMedia> parseRawSourceMedia(String body) {
        if (body == null || body.isEmpty()) return Collections.emptyList();
        String decoded = body.replace("\\u0026", "&").replace("\\u003d", "=")
                .replace("\\u002f", "/").replace("\\/", "/").replace("&amp;", "&");
        Pattern p = Pattern.compile("https?://[^\\s\\\"'<>\\\\]+", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(decoded);
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        ArrayList<ResolvedMedia> out = new ArrayList<>();
        while (m.find() && out.size() < 24) {
            String url = m.group();
            if (!(url.contains("cdninstagram.com") || url.contains("fbcdn.net"))) continue;
            int start = Math.max(0, m.start() - 220);
            int end = Math.min(decoded.length(), m.end() + 220);
            String context = decoded.substring(start, end).toLowerCase(Locale.ROOT);
            MediaItem.Kind kind;
            if (url.matches("(?i).*\\.mp4(?:\\?.*)?$")
                    && (context.contains("video_versions") || context.contains("video_url") || context.contains("carousel_media"))) {
                kind = MediaItem.Kind.VIDEO;
            } else if (url.matches("(?i).*\\.(?:jpg|jpeg|png|webp)(?:\\?.*)?$")
                    && (context.contains("image_versions2") || context.contains("display_url") || context.contains("carousel_media"))) {
                kind = MediaItem.Kind.IMAGE;
            } else continue;
            String key = kind.name() + "|" + stripQuery(url);
            if (seen.add(key)) out.add(new ResolvedMedia(kind, url, 0, 0));
        }
        return out;
    }

    private void abortFatal(String message) {
        if (!fatal.compareAndSet(false, true)) return;
        cancelled.set(true);
        postQueue.clear();
        postQueue.offer(PostTask.END);
        DiagnosticLog.log("SNS_IG_SOURCE_ABORT_FATAL message=" + (message == null ? "" : message));
        listener.onFatal(message == null ? "Instagramソース解析に失敗" : message);
    }

    private ResolveResult resolvePostGraphql(String shortcode, String postUrl) {
        try {
            HttpResult source = getHtml(postUrl, "https://www.instagram.com/", "post_graphql_tokens");
            if (isSpamGate(source.body)) return ResolveResult.fail("spam_gate_post_html", source.code);
            if (source.code == 429) return ResolveResult.limited(429, source.retryAfterMs, "post_html_429");
            if (source.code == 401 || source.code == 403 || containsAuthGate(source.body)) {
                return ResolveResult.fail("auth_gate_" + source.code, source.code);
            }
            if (source.code == 200 && !source.body.isEmpty()) {
                List<ResolvedMedia> raw = parseRawSourceMedia(source.body);
                if (!raw.isEmpty()) return ResolveResult.ok(raw);
            }
            String lsd = source.code == 200 ? extractToken(source.body,
                    "\\[\\\"LSD\\\",\\[\\],\\{\\\"token\\\":\\\"([^\\\"]+)\\\"") : profileLsd;
            String fbDtsg = source.code == 200 ? extractToken(source.body,
                    "\\[\\\"DTSG(?:Init|Initial)Data\\\",\\[\\],\\{\\\"token\\\":\\\"([^\\\"]+)\\\"") : profileFbDtsg;
            if (lsd.isEmpty()) lsd = profileLsd;
            if (fbDtsg.isEmpty()) fbDtsg = profileFbDtsg;

            JSONObject docVars = new JSONObject();
            docVars.put("shortcode", shortcode);
            docVars.put("__relay_internal__pv__PolarisShortDramaEnabledrelayprovider", false);
            docVars.put("__relay_internal__pv__PolarisMultiCaptionCarouselEnabledrelayprovider", true);
            HttpResult doc = postDocIdGraphql(PUBLIC_GRAPHQL_WEB_URL, MEDIA_INFO_DOC_ID, docVars,
                    postUrl, "post_graphql_doc", userAgent, lsd, fbDtsg);
            if (isSpamGate(doc.body)) return ResolveResult.fail("spam_gate_post_graphql", doc.code);
            if (doc.code == 429) return ResolveResult.limited(429, doc.retryAfterMs, "post_graphql_doc_429");
            if (doc.code == 200 && !doc.body.isEmpty()) {
                try {
                    JSONObject root = new JSONObject(doc.body);
                    JSONObject item = firstMediaItem(root, shortcode);
                    if (item != null) {
                        List<ResolvedMedia> media = parseMediaItem(item);
                        if (!media.isEmpty()) return ResolveResult.ok(media);
                    }
                } catch (Throwable ignored) {}
                List<ResolvedMedia> raw = parseRawSourceMedia(doc.body);
                if (!raw.isEmpty()) return ResolveResult.ok(raw);
            }
            if (doc.code == 401 || doc.code == 403 || containsAuthGate(doc.body)) {
                return ResolveResult.fail("auth_gate_" + doc.code, doc.code);
            }
            return ResolveResult.fail("graphql_media_not_resolved", doc.code);
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_IG_SOURCE_POST_GRAPHQL_FAIL error=" + t.getClass().getSimpleName()
                    + " url=" + postUrl);
            return ResolveResult.fail("graphql_" + t.getClass().getSimpleName(), 0);
        }
    }

    private HttpResult postDocIdGraphql(String endpoint, String docId, JSONObject variables,
                                        String referrer, String scope, String ua,
                                        String lsd, String fbDtsg) throws Exception {
        StringBuilder body = new StringBuilder();
        appendForm(body, "variables", variables == null ? "{}" : variables.toString());
        appendForm(body, "doc_id", docId);
        appendForm(body, "server_timestamps", "true");
        if (lsd != null && !lsd.isEmpty()) appendForm(body, "lsd", lsd);
        if (fbDtsg != null && !fbDtsg.isEmpty()) appendForm(body, "fb_dtsg", fbDtsg);
        awaitRequestGate();
        if (cancelled.get()) return new HttpResult(499, "", 0L);
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(endpoint).openConnection();
            con.setInstanceFollowRedirects(true);
            con.setConnectTimeout(12000);
            con.setReadTimeout(18000);
            con.setRequestMethod("POST");
            con.setDoOutput(true);
            con.setRequestProperty("User-Agent", (ua == null || ua.isEmpty()) ? userAgent : ua);
            con.setRequestProperty("Accept", "*/*");
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            con.setRequestProperty("Origin", "https://www.instagram.com");
            con.setRequestProperty("X-IG-App-ID", IG_APP_ID);
            con.setRequestProperty("X-ASBD-ID", IG_ASBD_ID);
            if (!runtimeCsrf.isEmpty()) con.setRequestProperty("X-CSRFToken", runtimeCsrf);
            if (lsd != null && !lsd.isEmpty()) con.setRequestProperty("X-FB-LSD", lsd);
            String requestCookie = requestCookieHeader();
            if (!requestCookie.isEmpty()) con.setRequestProperty("Cookie", requestCookie);
            if (referrer != null && !referrer.isEmpty()) con.setRequestProperty("Referer", referrer);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            con.setFixedLengthStreamingMode(bytes.length);
            try (java.io.OutputStream out = con.getOutputStream()) { out.write(bytes); }
            int code = con.getResponseCode();
            updateRuntimeCsrf(con);
            long retryAfterMs = parseRetryAfterMs(con.getHeaderField("Retry-After"));
            InputStream stream = code >= 200 && code < 400 ? con.getInputStream() : con.getErrorStream();
            String response = readAll(stream, 8 * 1024 * 1024);
            logHttp(scope, code, response, retryAfterMs);
            return new HttpResult(code, response, retryAfterMs);
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private HttpResult getHtml(String endpoint, String referrer, String scope) throws Exception {
        awaitRequestGate();
        if (cancelled.get()) return new HttpResult(499, "", 0L);
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(endpoint).openConnection();
            con.setInstanceFollowRedirects(true);
            con.setConnectTimeout(12000);
            con.setReadTimeout(18000);
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", userAgent);
            con.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            con.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en-US;q=0.7,en;q=0.6");
            String requestCookie = requestCookieHeader();
            if (!requestCookie.isEmpty()) con.setRequestProperty("Cookie", requestCookie);
            if (referrer != null && !referrer.isEmpty()) con.setRequestProperty("Referer", referrer);
            int code = con.getResponseCode();
            updateRuntimeCsrf(con);
            long retryAfterMs = parseRetryAfterMs(con.getHeaderField("Retry-After"));
            InputStream stream = code >= 200 && code < 400 ? con.getInputStream() : con.getErrorStream();
            String body = readAll(stream, 8 * 1024 * 1024);
            logHttp(scope, code, body, retryAfterMs);
            return new HttpResult(code, body, retryAfterMs);
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private void updateRuntimeCsrf(HttpURLConnection con) {
        if (con == null) return;
        try {
            Map<String, List<String>> headers = con.getHeaderFields();
            if (headers == null) return;
            for (Map.Entry<String, List<String>> e : headers.entrySet()) {
                String key = e.getKey();
                if (key == null || !key.equalsIgnoreCase("Set-Cookie") || e.getValue() == null) continue;
                for (String raw : e.getValue()) {
                    if (raw == null) continue;
                    Matcher m = Pattern.compile("(?:^|[;,]\\s*)csrftoken=([^; ,]+)", Pattern.CASE_INSENSITIVE).matcher(raw);
                    if (m.find() && !m.group(1).isEmpty()) {
                        runtimeCsrf = m.group(1);
                        return;
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void appendForm(StringBuilder out, String key, String value) throws Exception {
        if (out.length() > 0) out.append('&');
        out.append(URLEncoder.encode(key, "UTF-8"));
        out.append('=');
        out.append(URLEncoder.encode(value == null ? "" : value, "UTF-8"));
    }

    private static String extractToken(String body, String regex) {
        if (body == null || body.isEmpty()) return "";
        try {
            Matcher m = Pattern.compile(regex).matcher(body);
            return m.find() ? m.group(1) : "";
        } catch (Throwable ignored) { return ""; }
    }

    private static int deepMediaCount(Object value, int depth) {
        if (value == null || depth > 9) return 0;
        if (value instanceof JSONObject) {
            JSONObject obj = (JSONObject) value;
            int direct = obj.optInt("media_count", 0);
            if (direct > 0) return direct;
            JSONObject timeline = obj.optJSONObject("edge_owner_to_timeline_media");
            if (timeline != null && timeline.optInt("count", 0) > 0) return timeline.optInt("count", 0);
            JSONArray names = obj.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    int found = deepMediaCount(obj.opt(names.optString(i)), depth + 1);
                    if (found > 0) return found;
                }
            }
        } else if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i = 0; i < a.length(); i++) {
                int found = deepMediaCount(a.opt(i), depth + 1);
                if (found > 0) return found;
            }
        }
        return 0;
    }

    private static String profileIdFromSource(String body, String username) {
        if (body == null || body.isEmpty()) return "";
        String decoded = body.replace("\\u0026", "&").replace("\\\"", "\"");
        String user = Pattern.quote(username == null ? "" : username);
        String[] patterns = {
                "\\\"profile_id\\\"\\s*:\\s*\\\"(\\d+)\\\"",
                "\\\"username\\\"\\s*:\\s*\\\"" + user + "\\\".{0,700}?\\\"(?:id|pk)\\\"\\s*:\\s*\\\"?(\\d+)\\\"?",
                "\\\"(?:id|pk)\\\"\\s*:\\s*\\\"?(\\d+)\\\"?.{0,700}?\\\"username\\\"\\s*:\\s*\\\"" + user + "\\\""
        };
        for (String regex : patterns) {
            try {
                Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(decoded);
                if (m.find()) return m.group(1);
            } catch (Throwable ignored) {}
        }
        return "";
    }

    private static int mediaCountFromSource(String body) {
        if (body == null || body.isEmpty()) return 0;
        String decoded = body.replace("\\u0026", "&").replace("\\\"", "\"");
        String[] patterns = {
                "\\\"media_count\\\"\\s*:\\s*(\\d+)",
                "\\\"edge_owner_to_timeline_media\\\"\\s*:\\s*\\{[^}]{0,900}\\\"count\\\"\\s*:\\s*(\\d+)",
                "\\\"profile_post_count\\\"\\s*:\\s*(\\d+)"
        };
        for (String regex : patterns) {
            try {
                Matcher m = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(decoded);
                if (m.find()) {
                    int count = Integer.parseInt(m.group(1));
                    if (count > 0) return count;
                }
            } catch (Throwable ignored) {}
        }
        return 0;
    }

    private static String diagnosticBody(String body) {
        if (body == null || body.isEmpty()) return "";
        String compact = body.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').trim();
        compact = compact.replaceAll("(?i)sessionid[^,;\\\" ]*", "sessionid=<redacted>");
        compact = compact.replaceAll("(?i)csrftoken[^,;\\\" ]*", "csrftoken=<redacted>");
        if (compact.length() > 600) compact = compact.substring(0, 600) + "…";
        return compact;
    }

    private static void logHttp(String scope, int code, String body, long retryAfterMs) {
        DiagnosticLog.log("SNS_IG_SOURCE_HTTP scope=" + scope + " http=" + code
                + " bytes=" + (body == null ? 0 : body.length()) + " retryAfterMs=" + retryAfterMs);
        if (code < 200 || code >= 300) {
            DiagnosticLog.log("SNS_IG_SOURCE_HTTP_BODY scope=" + scope + " http=" + code
                    + " body=" + diagnosticBody(body));
        }
    }

    private HttpResult getJson(String endpoint, String referrer, String scope) throws Exception {
        awaitRequestGate();
        if (cancelled.get()) return new HttpResult(499, "", 0L);
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(endpoint).openConnection();
            con.setInstanceFollowRedirects(true);
            con.setConnectTimeout(12000);
            con.setReadTimeout(18000);
            con.setRequestMethod("GET");
            con.setRequestProperty("User-Agent", userAgent);
            con.setRequestProperty("Accept", "*/*");
            con.setRequestProperty("Accept-Language", "ja-JP,ja;q=0.9,en-US;q=0.7,en;q=0.6");
            con.setRequestProperty("X-IG-App-ID", IG_APP_ID);
            con.setRequestProperty("X-ASBD-ID", IG_ASBD_ID);
            if (!runtimeCsrf.isEmpty()) con.setRequestProperty("X-CSRFToken", runtimeCsrf);
            String requestCookie = requestCookieHeader();
            if (!requestCookie.isEmpty()) con.setRequestProperty("Cookie", requestCookie);
            if (referrer != null && !referrer.isEmpty()) con.setRequestProperty("Referer", referrer);
            con.setRequestProperty("X-Requested-With", "XMLHttpRequest");
            int code = con.getResponseCode();
            updateRuntimeCsrf(con);
            long retryAfterMs = parseRetryAfterMs(con.getHeaderField("Retry-After"));
            InputStream stream = code >= 200 && code < 400 ? con.getInputStream() : con.getErrorStream();
            String body = readAll(stream, 8 * 1024 * 1024);
            logHttp(scope, code, body, retryAfterMs);
            return new HttpResult(code, body, retryAfterMs);
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private long registerRateLimit(String scope, HttpResult http) {
        long wait = http.retryAfterMs > 0L ? http.retryAfterMs : DEFAULT_429_WAIT_MS;
        wait = Math.min(MAX_429_WAIT_MS, Math.max(5000L, wait));
        long until = System.currentTimeMillis() + wait;
        requestGateUntil.accumulateAndGet(until, Math::max);
        listener.onRateLimited(scope, http.code, wait);
        DiagnosticLog.log("SNS_IG_SOURCE_RATE_LIMIT scope=" + scope + " http=" + http.code + " waitMs=" + wait);
        return wait;
    }

    private void awaitRequestGate() throws InterruptedException {
        while (!cancelled.get()) {
            long remaining = requestGateUntil.get() - System.currentTimeMillis();
            if (remaining <= 0L) return;
            Thread.sleep(Math.min(remaining, 1000L));
        }
    }

    private boolean sleepInterruptibly(long ms) {
        long end = System.currentTimeMillis() + Math.max(0L, ms);
        while (!cancelled.get()) {
            long remaining = end - System.currentTimeMillis();
            if (remaining <= 0L) return true;
            try {
                Thread.sleep(Math.min(remaining, 500L));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return false;
    }

    private static String readAll(InputStream in, int maxBytes) throws Exception {
        if (in == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buf = new char[8192];
            int n;
            int chars = 0;
            while ((n = br.read(buf)) >= 0) {
                if (n == 0) continue;
                if (chars + n > maxBytes) n = Math.max(0, maxBytes - chars);
                if (n <= 0) break;
                out.append(buf, 0, n);
                chars += n;
                if (chars >= maxBytes) break;
            }
        }
        return out.toString();
    }

    private static int findMediaCount(JSONObject root) {
        if (root == null) return 0;
        try {
            JSONObject data = root.optJSONObject("data");
            JSONObject user = data == null ? null : data.optJSONObject("user");
            if (user != null) {
                int direct = user.optInt("media_count", 0);
                if (direct > 0) return direct;
                JSONObject timeline = user.optJSONObject("edge_owner_to_timeline_media");
                if (timeline != null && timeline.optInt("count", 0) > 0) return timeline.optInt("count", 0);
            }
            JSONArray items = root.optJSONArray("items");
            if (items != null && items.length() > 0) {
                JSONObject first = items.optJSONObject(0);
                JSONObject itemUser = first == null ? null : first.optJSONObject("user");
                if (itemUser != null && itemUser.optInt("media_count", 0) > 0) return itemUser.optInt("media_count", 0);
            }
        } catch (Throwable ignored) {}
        return 0;
    }

    private static String usernameFromProfile(String raw) {
        if (raw == null) return "";
        try {
            URI uri = new URI(raw.trim());
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!(host.equals("instagram.com") || host.endsWith(".instagram.com"))) return "";
            String path = uri.getPath() == null ? "" : uri.getPath();
            String[] parts = path.split("/");
            for (String p : parts) {
                if (p == null || p.trim().isEmpty()) continue;
                String value = p.trim();
                String lower = value.toLowerCase(Locale.ROOT);
                if (lower.equals("p") || lower.equals("reel") || lower.equals("tv") || lower.equals("explore")
                        || lower.equals("accounts") || lower.equals("stories")) return "";
                return value;
            }
        } catch (Throwable ignored) {}
        return "";
    }

    static String canonicalPostUrl(String raw) {
        if (raw == null) return "";
        try {
            URI uri = new URI(raw.trim());
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!(host.equals("instagram.com") || host.endsWith(".instagram.com"))) return "";
            String path = uri.getPath() == null ? "" : uri.getPath();
            Matcher m = Pattern.compile("/(p|reel|tv)/([^/?#]+)", Pattern.CASE_INSENSITIVE).matcher(path);
            if (!m.find()) return "";
            return "https://www.instagram.com/" + m.group(1).toLowerCase(Locale.ROOT) + "/" + m.group(2) + "/";
        } catch (Throwable ignored) {
            return "";
        }
    }

    private static String shortcodeFromPostUrl(String raw) {
        String canonical = canonicalPostUrl(raw);
        if (canonical.isEmpty()) return "";
        Matcher m = Pattern.compile("/(?:p|reel|tv)/([^/?#]+)", Pattern.CASE_INSENSITIVE).matcher(canonical);
        return m.find() ? m.group(1) : "";
    }

    private static String mediaIdFromShortcode(String code) {
        try {
            if (code == null || code.isEmpty() || code.length() > 11) return "";
            StringBuilder padded = new StringBuilder(code);
            while (padded.length() < 12) padded.insert(0, 'A');
            byte[] decoded = Base64.decode(padded.toString(), Base64.URL_SAFE | Base64.NO_WRAP);
            return new BigInteger(1, decoded).toString();
        } catch (Throwable ignored) {
            return "";
        }
    }

    private String requestCookieHeader() {
        if (runtimeCsrf == null || runtimeCsrf.isEmpty() || !cookieValue(cookie, "csrftoken").isEmpty()) return cookie;
        if (cookie == null || cookie.trim().isEmpty()) return "csrftoken=" + runtimeCsrf;
        return cookie + "; csrftoken=" + runtimeCsrf;
    }

    private static String cookieValue(String cookie, String key) {
        if (cookie == null || key == null) return "";
        for (String part : cookie.split(";")) {
            int eq = part.indexOf('=');
            if (eq <= 0) continue;
            if (part.substring(0, eq).trim().equals(key)) return part.substring(eq + 1).trim();
        }
        return "";
    }

    private static boolean isSpamGate(String body) {
        if (body == null || body.isEmpty()) return false;
        String lower = body.toLowerCase(Locale.ROOT).replace(" ", "");
        return lower.contains("\"spam\":true")
                || lower.contains("spam:true")
                || lower.contains("sentry_block")
                || lower.contains("rate_limit_error");
    }

    private static boolean containsAuthGate(String body) {
        if (body == null || body.isEmpty()) return false;
        String lower = body.toLowerCase(Locale.ROOT);
        return lower.contains("login_required") || lower.contains("challenge_required")
                || lower.contains("checkpoint_required") || lower.contains("feedback_required");
    }

    private static long parseRetryAfterMs(String raw) {
        if (raw == null || raw.trim().isEmpty()) return 0L;
        try {
            long seconds = Long.parseLong(raw.trim());
            return Math.max(0L, seconds * 1000L);
        } catch (Throwable ignored) {
            return 0L;
        }
    }

    private static String firstNonEmpty(String a, String b) {
        if (a != null && !a.trim().isEmpty()) return a.trim();
        return b == null ? "" : b.trim();
    }

    private static String stripQuery(String url) {
        if (url == null) return "";
        int q = url.indexOf('?');
        return q >= 0 ? url.substring(0, q) : url;
    }
}
