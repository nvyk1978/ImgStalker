#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/net" "$TMP/src/android/content" "$TMP/src/org/json" "$TMP/src/com/cmyk/imgstalker" "$TMP/out"
cat > "$TMP/src/android/net/Uri.java" <<'JAVA'
package android.net;
public class Uri {
 private final java.net.URI uri;
 private Uri(String u) {uri = java.net.URI.create(u);}
 public static Uri parse(String s){return new Uri(s);}
 public String getScheme(){return uri.getScheme();} public String getHost(){return uri.getHost();}
 public String getPath(){return uri.getPath();}
}
JAVA
cat > "$TMP/src/android/content/SharedPreferences.java" <<'JAVA'
package android.content;
public interface SharedPreferences {
 String getString(String key,String fallback);
 Editor edit();
 interface Editor{Editor putString(String key,String value);void apply();}
}
JAVA
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content;
public class Context {
 public static final int MODE_PRIVATE=0;
 private final java.util.Map<String,String> data = new java.util.HashMap<>();
 private final SharedPreferences prefs = new SharedPreferences() {
  public String getString(String key,String fallback) {return data.getOrDefault(key,fallback);}
  public Editor edit() {return new Editor(){private final java.util.Map<String,String> pending=new java.util.HashMap<>();
   public Editor putString(String k,String v){pending.put(k,v);return this;}
   public void apply(){data.putAll(pending);}
  };}
 };
 public SharedPreferences getSharedPreferences(String name,int mode){return prefs;}
}
JAVA
cat > "$TMP/src/org/json/JSONObject.java" <<'JAVA'
package org.json;
public class JSONObject {
 private final java.util.Map<String,Object> fields=new java.util.HashMap<>();
 public String optString(String k,String fallback){Object o=fields.get(k);return o==null?fallback:o.toString();}
 public boolean optBoolean(String k,boolean d){Object o=fields.get(k);return o instanceof Boolean?(Boolean)o:d;}
 public long optLong(String k,long d){Object o=fields.get(k);return o instanceof Number?((Number)o).longValue():d;}
 public JSONObject put(String k,Object v){fields.put(k,v);return this;}
}
JAVA
cat > "$TMP/src/org/json/JSONArray.java" <<'JAVA'
package org.json;
public class JSONArray {
 private static final java.util.Map<String,java.util.List<Object>> registry = new java.util.HashMap<>();
 private static int next=0;
 private final java.util.List<Object> entries;
 public JSONArray(){entries=new java.util.ArrayList<>();}
 public JSONArray(String raw){entries=new java.util.ArrayList<>(registry.getOrDefault(raw,java.util.Collections.emptyList()));}
 public int length(){return entries.size();}
 public JSONObject optJSONObject(int i){return i>=0&&i<entries.size()&&entries.get(i) instanceof JSONObject?(JSONObject)entries.get(i):null;}
 public String optString(int i,String d){return i>=0&&i<entries.size()&&entries.get(i) instanceof String?(String)entries.get(i):d;}
 public JSONArray put(JSONObject o){entries.add(o);return this;}
 public JSONArray put(String s){entries.add(s);return this;}
 @Override public String toString(){String id="array-"+(++next);registry.put(id,new java.util.ArrayList<>(entries));return id;}
}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" <<'JAVA'
package com.cmyk.imgstalker;
final class DiagnosticLog{static void logException(String s,Exception e){throw new RuntimeException(s,e);}}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/BookmarkOrderTest.java" <<'JAVA'
package com.cmyk.imgstalker;
import java.util.*;
import android.content.Context;
public class BookmarkOrderTest {
 private static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 private static void order(Context ctx,String... expected){
  List<SiteVisitStore.Entry> list=SiteVisitStore.entries(ctx,true);
  check(list.size()==expected.length,"size: "+list.size());
  for(int i=0;i<expected.length;i++)check(list.get(i).url.equals(expected[i]),"index "+i+" expected "+expected[i]+" actual "+list.get(i).url);
 }
 public static void main(String[] args){
  Context prefs=new Context();
  String a="https://a.example/a", b="https://b.example/b", c="https://c.example/c", d="https://d.example/d";
  SiteVisitStore.toggleFavorite(prefs,a);
  SiteVisitStore.toggleFavorite(prefs,b);
  SiteVisitStore.toggleFavorite(prefs,c);
  order(prefs,c,b,a);
  SiteVisitStore.setBookmarkOrder(prefs,Arrays.asList(a,c,b));
  order(prefs,a,c,b);
  SiteVisitStore.recordVisit(prefs,b);
  order(prefs,a,c,b); // Visiting must not move the bookmark.
  SiteVisitStore.removeHistory(prefs,b);
  order(prefs,a,c,b);
  SiteVisitStore.toggleFavorite(prefs,c);
  order(prefs,a,b);
  SiteVisitStore.toggleFavorite(prefs,d);
  order(prefs,d,a,b);
  System.out.println("PASS: persisted bookmark order, visit/history independence, removal and new prepend");
 }
}
JAVA
javac -encoding UTF-8 -d "$TMP/out" "$TMP"/src/android/net/*.java "$TMP"/src/android/content/*.java "$TMP"/src/org/json/*.java "$TMP"/src/com/cmyk/imgstalker/*.java app/src/main/java/com/cmyk/imgstalker/SiteVisitStore.java
java -cp "$TMP/out" com.cmyk.imgstalker.BookmarkOrderTest
