#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/com/cmyk/imgstalker')
main=(s/'MainActivity.java').read_text()
accounts=(s/'SnsAccountManager.java').read_text()
resume=(s/'SnsResumeStore.java').read_text()
nav=(s/'NavigationIconLoader.java').read_text()
parser=Path('app/src/main/assets/threads_feed.js').read_text()
assert 'THREADS' in (s/'AnalysisModeRouter.java').read_text()
assert 'case THREADS: return new ThreadsModeProvider();' in (s/'ModeProviders.java').read_text()
assert 'new ThreadsCrawlerAdapter' in (s/'ThreadsModeProvider.java').read_text()
assert 'new ThreadsDownloaderAdapter' in (s/'ThreadsModeProvider.java').read_text()
assert 'new ThreadsThumbnailAdapter' in (s/'ThreadsModeProvider.java').read_text()
assert 'ThreadsSessionCookies' in (s/'ThreadsModeProvider.java').read_text()
assert 'THREADS("th", "Threads"' in accounts
assert 'is_threads_' in resume and 'return new Target(SnsAccountManager.Service.THREADS' in resume
assert 'threadsIcon, snsLp3' in main
assert main.index('titleRow.addView(instagramIcon, snsLp2);') < main.index('titleRow.addView(threadsIcon, snsLp3);')
assert 'SnsAccountManager.Service.THREADS' in main
assert 'HeaderIconKind.THREADS' in main
assert 'Threadsのみ表示' in main
assert 'Threadsモード' in main
assert 'if (social) return null;' in nav
assert 'return social ? null : favicon;' in nav
assert 'THREADS_LOGIN_PROFILE_RETAINED_UNVERIFIED' in (s/'SnsUiController.java').read_text()
assert 'state=unverified_profile' in main
checkpoints=(s/'AnalysisSessionStore.java').read_text()
assert 'imgstalker_threads_checkpoint.json' in checkpoints
assert '"https://threads.com/"' in checkpoints
assert 'AnalysisModeRouter.Mode.THREADS' in checkpoints
assert 'R.drawable.ic_nav_normal' in nav and 'R.drawable.ic_nav_threads' in main
assert 'canvas.drawOval(oval, paint);' not in main
assert 'THREADS_APP_LINK_BLOCK' in (s/'ThreadsCrawlerEngine.java').read_text()
assert 'threads_no_media_or_access_blocked' in (s/'ThreadsCrawlerEngine.java').read_text()
assert 'video source' in parser and 'img,video' in parser
assert Path('app/src/main/res/drawable-nodpi/ic_nav_threads.png').is_file()
print('PASS: Threads route, login UI, asset, profile icons, separate media/ledger/resume and failed-zero guard')
PY
