package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Navigation artwork only. No crawler WebView, login cookies or provider session access. */
final class NavigationIconLoader {
    private static final int MAX_BYTES = 450_000;
    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> memory = new LruCache<>(64);
    private final Set<String> inProgress = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Map<String, Long> failed = new ConcurrentHashMap<>();
    private final Map<String, ArrayList<ImageView>> listeners = new ConcurrentHashMap<>();
    private static final Pattern TAG = Pattern.compile("<(?:link|meta)\\b[^>]*>", Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR = Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");

    NavigationIconLoader(Context ctx) { context = ctx.getApplicationContext(); }

    static String iconIdentity(String url) {
        String normalized = SiteVisitStore.normalize(url);
        if (normalized.isEmpty()) return "";
        try {
            URI uri = URI.create(normalized);
            String host = uri.getHost();
            if (host == null) return "";
            String social = SiteVisitStore.socialHandleForUrl(normalized);
            if (!social.isEmpty()) {
                String canonical = AnalysisModeRouter.fromUrl(normalized) == AnalysisModeRouter.Mode.INSTAGRAM
                        ? "instagram" : "x";
                return canonical + ":" + social.toLowerCase(java.util.Locale.ROOT);
            }
            return uri.getScheme().toLowerCase(java.util.Locale.ROOT) + "://" + host.toLowerCase(java.util.Locale.ROOT);
        } catch (RuntimeException e) { return ""; }
    }

    void bind(ImageView view, String url) {
        String key = iconIdentity(url);
        view.setTag(key);
        int mode = AnalysisModeRouter.fromUrl(url).ordinal();
        if (mode == AnalysisModeRouter.Mode.X.ordinal()) view.setImageResource(R.drawable.ic_nav_x);
        else if (mode == AnalysisModeRouter.Mode.INSTAGRAM.ordinal()) view.setImageResource(R.drawable.ic_nav_instagram);
        else view.setImageResource(android.R.drawable.ic_menu_view);
        if (key.isEmpty()) return;
        Bitmap cached = memory.get(key);
        if (cached != null) { view.setImageBitmap(cached); return; }
        File file = cacheFile(key);
        if (file.isFile()) {
            Bitmap disk = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (disk != null) { memory.put(key, disk); view.setImageBitmap(disk); return; }
            file.delete();
        }
        long now = System.currentTimeMillis();
        Long retryAt = failed.get(key);
        if (retryAt != null && now < retryAt) return;
        synchronized (listeners) {
            ArrayList<ImageView> views = listeners.get(key);
            if (views == null) { views = new ArrayList<>(); listeners.put(key, views); }
            views.add(view);
        }
        if (!inProgress.add(key)) return;
        try {
            io.execute(() -> {
                Bitmap found = null;
                try { found = loadRemote(url); }
                catch (Throwable e) { DiagnosticLog.logException("NAVIGATION_ICON_FETCH_FAIL", e); }
                if (found != null) {
                    memory.put(key, found);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        found.compress(Bitmap.CompressFormat.PNG, 95, out);
                    } catch (Exception ignored) { }
                } else failed.put(key, System.currentTimeMillis() + 60L * 60_000L);
                final Bitmap result = found;
                main.post(() -> {
                    ArrayList<ImageView> waiters;
                    synchronized (listeners) { waiters = listeners.remove(key); }
                    inProgress.remove(key);
                    if (waiters != null && result != null) for (ImageView image : waiters) {
                        if (key.equals(image.getTag())) image.setImageBitmap(result);
                    }
                });
            });
        } catch (RuntimeException rejected) {
            inProgress.remove(key);
            synchronized (listeners) { listeners.remove(key); }
        }
    }

    private Bitmap loadRemote(String url) throws Exception {
        URI original = URI.create(url);
        String host = original.getHost();
        if (host == null) return null;
        boolean social = !SiteVisitStore.socialHandleForUrl(url).isEmpty();
        String origin = original.getScheme() + "://" + host;
        String page = social ? origin + "/" + SiteVisitStore.socialHandleForUrl(url).substring(1) + "/" : origin + "/";
        String html = downloadText(page);
        if (html != null) {
            String meta = findMetaImage(html, social);
            if (meta != null) {
                Bitmap bitmap = downloadBitmap(resolve(page, meta));
                if (bitmap != null) return bitmap;
            }
        }
        for (String candidate : new String[]{origin + "/apple-touch-icon.png", origin + "/favicon.png", origin + "/favicon.ico"}) {
            Bitmap bitmap = downloadBitmap(candidate);
            if (bitmap != null) return bitmap;
        }
        return null;
    }

    static String findMetaImage(String html, boolean social) {
        if (html == null) return null;
        Matcher tags = TAG.matcher(html);
        String favicon = null;
        while (tags.find()) {
            String tag = tags.group();
            java.util.HashMap<String, String> a = new java.util.HashMap<>();
            Matcher attrs = ATTR.matcher(tag);
            while (attrs.find()) {
                String value = attrs.group(2) != null ? attrs.group(2) : attrs.group(3) != null ? attrs.group(3) : attrs.group(4);
                a.put(attrs.group(1).toLowerCase(java.util.Locale.ROOT), value);
            }
            String rel = a.get("rel");
            String property = a.containsKey("property") ? a.get("property") : a.get("name");
            if (social && property != null && (property.equalsIgnoreCase("og:image") || property.equalsIgnoreCase("twitter:image"))) {
                String content = a.get("content");
                if (content != null && !content.isEmpty()) return unescape(content);
            }
            if (rel != null && rel.toLowerCase(java.util.Locale.ROOT).contains("icon") && favicon == null)
                favicon = unescape(a.get("href"));
        }
        return favicon;
    }

    private static String unescape(String s) { return s == null ? null : s.replace("&amp;", "&").replace("&#38;", "&"); }
    private static String resolve(String base, String value) {
        try {
            URI u = URI.create(base).resolve(value);
            if (!"https".equalsIgnoreCase(u.getScheme()) && !"http".equalsIgnoreCase(u.getScheme())) return null;
            return u.toString();
        } catch (Exception ignored) { return null; }
    }

    private String downloadText(String url) {
        try {
            byte[] data = get(url, 160_000, "text/html");
            return data == null ? null : new String(data, StandardCharsets.UTF_8);
        } catch (Exception ignored) { return null; }
    }
    private Bitmap downloadBitmap(String url) {
        try {
            byte[] data = get(url, MAX_BYTES, "image/*");
            if (data == null) return null;
            Bitmap source = BitmapFactory.decodeByteArray(data, 0, data.length);
            if (source == null) return null; // e.g. unsupported Windows ICO; try alternate URL.
            if (source.getWidth() <= 96 && source.getHeight() <= 96) return source;
            Bitmap scaled = Bitmap.createScaledBitmap(source, 96, 96, true);
            if (scaled != source) source.recycle();
            return scaled;
        } catch (Exception ignored) { return null; }
    }
    private static byte[] get(String source, int cap, String accept) throws Exception {
        if (source == null) return null;
        URL url = new URL(source);
        if (!"https".equalsIgnoreCase(url.getProtocol()) && !"http".equalsIgnoreCase(url.getProtocol())) return null;
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(4000);
        connection.setReadTimeout(4500);
        connection.setRequestProperty("Accept", accept);
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) ImgStalker/Navigation");
        connection.setInstanceFollowRedirects(true);
        try {
            if (connection.getResponseCode() != 200 || connection.getContentLengthLong() > cap) return null;
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int n;
                while ((n = input.read(buffer)) != -1) {
                    if (out.size() + n > cap) return null;
                    out.write(buffer, 0, n);
                }
                return out.toByteArray();
            }
        } finally { connection.disconnect(); }
    }

    private File cacheFile(String key) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(key.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : hash) out.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
            File root = new File(context.getCacheDir(), "navigation_icons");
            if (!root.exists()) root.mkdirs();
            return new File(root, out + ".png");
        } catch (Exception e) { return new File(context.getCacheDir(), "nav_icon_failure.png"); }
    }

    void shutdown() { io.shutdownNow(); }
}
