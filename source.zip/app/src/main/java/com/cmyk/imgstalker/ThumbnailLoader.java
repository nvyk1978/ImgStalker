package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.webkit.WebSettings;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class ThumbnailLoader {
    private static final int MAX_THUMB_BYTES = 32 * 1024 * 1024;
    private static final int THUMB_MAX_EDGE = 320;

    private static final class Pending {
        final int generation;
        final ArrayList<WeakReference<ImageView>> waiters = new ArrayList<>();
        Future<?> future;

        Pending(int generation) {
            this.generation = generation;
        }
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final String userAgent;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final LruCache<String, Bitmap> cache;
    private final Object pendingLock = new Object();
    private final Map<String, Pending> pendingByUrl = new HashMap<>();
    private final Runnable metadataChanged;
    private volatile int generation = 1;

    public ThumbnailLoader(Context context) {
        this(context, null);
    }

    public ThumbnailLoader(Context context, Runnable metadataChanged) {
        this.metadataChanged = metadataChanged;
        String baseUa;
        try {
            baseUa = WebSettings.getDefaultUserAgent(context);
        } catch (Exception e) {
            baseUa = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36";
        }
        userAgent = baseUa + " ImgStalker/0.1.69";
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024L);
        int cacheKb = Math.max(8192, Math.min(49152, maxKb / 8));
        cache = new LruCache<String, Bitmap>(cacheKb) {
            @Override protected int sizeOf(String key, Bitmap value) {
                return Math.max(1, value.getByteCount() / 1024);
            }
        };
        DiagnosticLog.log("THUMB_CACHE_INIT kb=" + cacheKb + " workers=3 edge=" + THUMB_MAX_EDGE);
    }

    /** Prefetch only still images. Video frame extraction is intentionally visible-cell-only. */
    public void prefetch(MediaItem item) {
        if (item == null || item.kind != MediaItem.Kind.IMAGE || item.url == null || item.url.isEmpty()) return;
        String key = cacheKey(item);
        Bitmap hit = cache.get(key);
        if (hit != null && !hit.isRecycled()) return;

        final int requestGeneration = generation;
        final Pending request;
        synchronized (pendingLock) {
            Pending existing = pendingByUrl.get(key);
            if (existing != null && existing.generation == requestGeneration) return;
            request = new Pending(requestGeneration);
            pendingByUrl.put(key, request);
            request.future = pool.submit(() -> runRequest(key, item, request));
        }
        DiagnosticLog.log("THUMB_PREFETCH url=" + item.url + " generation=" + requestGeneration);
    }

    public void load(ImageView view, MediaItem item) {
        if (view == null || item == null) return;
        if (item.kind == MediaItem.Kind.STREAM) {
            clear(view);
            view.setVisibility(View.VISIBLE);
            return;
        }

        view.setVisibility(View.VISIBLE);
        String key = cacheKey(item);
        Object previousTag = view.getTag();
        boolean sameBinding = key.equals(previousTag);
        view.setTag(key);

        Bitmap hit = cache.get(key);
        if (hit != null && !hit.isRecycled()) {
            view.setImageBitmap(hit);
            view.setAlpha(1f);
            return;
        }

        if (!sameBinding) view.setImageDrawable(null);
        view.setAlpha(0.55f);

        final Pending request;
        final int requestGeneration = generation;
        synchronized (pendingLock) {
            Pending existing = pendingByUrl.get(key);
            if (existing != null && existing.generation == requestGeneration) {
                if (addWaiter(existing, view)) {
                    DiagnosticLog.log("THUMB_JOIN url=" + item.url + " waiters=" + existing.waiters.size());
                }
                return;
            }

            request = new Pending(requestGeneration);
            addWaiter(request, view);
            pendingByUrl.put(key, request);
            request.future = pool.submit(() -> runRequest(key, item, request));
        }
    }

    private static String cacheKey(MediaItem item) {
        return item.kind.name() + "|" + item.url;
    }

    private void runRequest(String key, MediaItem item, Pending request) {
        Bitmap bitmap = null;
        boolean metadataWasMissing = item.width <= 0 || item.height <= 0 || (item.kind == MediaItem.Kind.VIDEO && item.durationMs <= 0L);
        try {
            if (Thread.currentThread().isInterrupted()) return;
            bitmap = item.kind == MediaItem.Kind.VIDEO ? fetchVideoFrame(item) : fetchImage(item);
            if (bitmap != null) cache.put(key, bitmap);
        } catch (Exception e) {
            if (request.generation == generation && !Thread.currentThread().isInterrupted()) {
                DiagnosticLog.logException("THUMB_FAIL url=" + item.url, e);
            } else {
                DiagnosticLog.log("THUMB_ABORT url=" + item.url + " generation=" + request.generation);
            }
        } finally {
            synchronized (pendingLock) {
                if (pendingByUrl.get(key) == request) pendingByUrl.remove(key);
            }
        }

        final Bitmap ready = bitmap;
        final boolean metadataNowAvailable = metadataWasMissing && (item.width > 0 || item.height > 0 || item.durationMs > 0L);
        if (request.generation != generation) return;
        main.post(() -> {
            if (request.generation != generation) return;
            for (WeakReference<ImageView> ref : request.waiters) {
                ImageView target = ref.get();
                if (target == null) continue;
                Object tag = target.getTag();
                if (!(tag instanceof String) || !key.equals(tag)) continue;
                if (ready != null && !ready.isRecycled()) {
                    target.setImageBitmap(ready);
                    target.setAlpha(1f);
                } else {
                    target.setImageDrawable(null);
                    target.setAlpha(0.55f);
                }
            }
            if (metadataNowAvailable && metadataChanged != null) metadataChanged.run();
        });
    }

    private static boolean addWaiter(Pending pending, ImageView view) {
        for (WeakReference<ImageView> ref : pending.waiters) {
            if (ref.get() == view) return false;
        }
        pending.waiters.add(new WeakReference<>(view));
        return true;
    }

    public void clear(ImageView view) {
        if (view == null) return;
        view.setTag(null);
        view.setImageDrawable(null);
        view.setAlpha(0.55f);
    }

    /** Keep only thumbnails near the visible SNS grid window. Normal-site callers never use this. */
    public void trimCacheToWindow(ArrayList<MediaItem> items, int start, int end) {
        if (items == null || items.isEmpty()) return;
        int safeStart = Math.max(0, start);
        int safeEnd = Math.min(items.size() - 1, end);
        Set<String> keep = new HashSet<>();
        for (int i = safeStart; i <= safeEnd; i++) {
            MediaItem item = items.get(i);
            if (item != null && item.kind != MediaItem.Kind.STREAM) keep.add(cacheKey(item));
        }
        int removed = 0;
        for (String key : new ArrayList<>(cache.snapshot().keySet())) {
            if (!keep.contains(key)) {
                cache.remove(key);
                removed++;
            }
        }
        if (removed > 0) DiagnosticLog.log("SNS_THUMB_CACHE_TRIM removed=" + removed
                + " keep=" + keep.size() + " window=" + safeStart + "-" + safeEnd);
    }

    public void cancelPending() {
        ArrayList<Future<?>> futures = new ArrayList<>();
        int newGeneration = generation + 1;
        generation = newGeneration;
        synchronized (pendingLock) {
            for (Pending p : pendingByUrl.values()) {
                if (p.future != null) futures.add(p.future);
            }
            pendingByUrl.clear();
        }
        for (Future<?> future : futures) future.cancel(true);
        DiagnosticLog.log("THUMB_CANCEL_PENDING count=" + futures.size() + " generation=" + newGeneration);
    }

    public void shutdown() {
        cancelPending();
        pool.shutdownNow();
        cache.evictAll();
    }

    private Bitmap fetchImage(MediaItem item) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(item.url).openConnection();
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(12000);
        con.setReadTimeout(16000);
        con.setRequestProperty("User-Agent", userAgent);
        con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
        con.setRequestProperty("Accept-Encoding", "identity");
        con.setRequestProperty("Sec-Fetch-Dest", "image");
        con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
        if (item.referrer != null && !item.referrer.isEmpty()) con.setRequestProperty("Referer", item.referrer);
        String cookie = SessionCookies.getCookie(item.url);
        if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
        con.connect();
        int code = con.getResponseCode();
        String contentType = con.getContentType();
        long contentLength = con.getContentLengthLong();
        DiagnosticLog.log("THUMB_HTTP code=" + code
                + " type=" + contentType
                + " length=" + contentLength
                + " finalUrl=" + con.getURL()
                + " ref=" + item.referrer
                + " cookie=" + (cookie == null ? 0 : cookie.length()));
        if (code < 200 || code >= 400) throw new IllegalStateException("HTTP " + code);
        if (contentType != null && !contentType.toLowerCase().startsWith("image/")) {
            throw new IllegalStateException("unexpected content-type " + contentType);
        }
        if (contentLength > MAX_THUMB_BYTES) throw new IllegalStateException("thumbnail source too large: " + contentLength);

        byte[] data;
        try (InputStream in = con.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[32 * 1024];
            int total = 0;
            int n;
            while ((n = in.read(buf)) >= 0) {
                if (Thread.currentThread().isInterrupted()) throw new InterruptedException("thumbnail cancelled");
                total += n;
                if (total > MAX_THUMB_BYTES) throw new IllegalStateException("thumbnail source too large");
                out.write(buf, 0, n);
            }
            data = out.toByteArray();
        } finally {
            con.disconnect();
        }

        if (Thread.currentThread().isInterrupted()) throw new InterruptedException("thumbnail cancelled");

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new IllegalStateException("decode bounds failed bytes=" + data.length);
        }
        if (item.width <= 0 || item.height <= 0) {
            item.width = bounds.outWidth;
            item.height = bounds.outHeight;
        }

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        opts.inSampleSize = calculateSample(bounds.outWidth, bounds.outHeight, THUMB_MAX_EDGE, THUMB_MAX_EDGE);
        Bitmap decoded = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
        if (decoded == null) throw new IllegalStateException("bitmap decode failed bytes=" + data.length);
        Bitmap bitmap = scaleToMaxEdge(decoded, THUMB_MAX_EDGE);
        DiagnosticLog.log("THUMB_OK url=" + item.url + " source=" + bounds.outWidth + "x" + bounds.outHeight
                + " decoded=" + bitmap.getWidth() + "x" + bitmap.getHeight()
                + " bytes=" + data.length + " sample=" + opts.inSampleSize);
        return bitmap;
    }

    private Bitmap fetchVideoFrame(MediaItem item) throws Exception {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            HashMap<String, String> headers = new HashMap<>();
            headers.put("User-Agent", userAgent);
            headers.put("Accept", "video/*,*/*;q=0.8");
            if (item.referrer != null && !item.referrer.isEmpty()) headers.put("Referer", item.referrer);
            String cookie = SessionCookies.getCookie(item.url);
            if (cookie != null && !cookie.isEmpty()) headers.put("Cookie", cookie);
            retriever.setDataSource(item.url, headers);

            long duration = parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            int width = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int height = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            int rotation = parseInt(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION));
            if (rotation == 90 || rotation == 270) {
                int t = width; width = height; height = t;
            }
            if (duration > 0L) item.durationMs = duration;
            if (width > 0 && height > 0) {
                item.width = width;
                item.height = height;
            }

            long frameUs = duration > 1500L ? 1_000_000L : 0L;
            Bitmap frame = retriever.getFrameAtTime(frameUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (frame == null) frame = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (frame == null) throw new IllegalStateException("video frame unavailable");
            Bitmap scaled = scaleToMaxEdge(frame, THUMB_MAX_EDGE);
            DiagnosticLog.log("VIDEO_THUMB_OK size=" + item.width + "x" + item.height
                    + " durationMs=" + item.durationMs + " url=" + item.url);
            return scaled;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    private static int parseInt(String value) {
        try { return value == null ? 0 : Integer.parseInt(value); } catch (Exception e) { return 0; }
    }

    private static long parseLong(String value) {
        try { return value == null ? 0L : Long.parseLong(value); } catch (Exception e) { return 0L; }
    }

    private static Bitmap scaleToMaxEdge(Bitmap source, int maxEdge) {
        int w = source.getWidth();
        int h = source.getHeight();
        int edge = Math.max(w, h);
        if (edge <= maxEdge) return source;
        float scale = maxEdge / (float) edge;
        int nw = Math.max(1, Math.round(w * scale));
        int nh = Math.max(1, Math.round(h * scale));
        Bitmap scaled = Bitmap.createScaledBitmap(source, nw, nh, true);
        if (scaled != source) source.recycle();
        return scaled;
    }

    private static int calculateSample(int width, int height, int reqWidth, int reqHeight) {
        int sample = 1;
        if (width <= 0 || height <= 0) return sample;
        while ((width / (sample * 2)) >= reqWidth && (height / (sample * 2)) >= reqHeight) sample *= 2;
        return Math.max(1, sample);
    }
}
