# ImgStalker v0.1.74 (75)

## Base
- Functional base: v0.1.72 (73).
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.


## v0.1.74 Instagram recovery changes
- Carousel `Next` click success followed by slide-change timeout is no longer treated as the last slide. The current post state is reloaded/reopened and retried from slide 1.
- A visible `Next` button that remains unclickable after retries is also treated as a post failure/reload path, never as successful carousel completion.
- One reload/reopen retry is performed for the affected post; if it still fails, only that post is marked failed and profile discovery continues.
- Continuation reload restores `discovered - completed` as an explicit pending set and processes those posts before ordinary new-post discovery.
- When Instagram exposes a profile post count and discovered posts are still below `min(profileCount, 300)`, `bottom_stall`/pass-limit no longer end analysis. The profile is reloaded and discovery resumes.
- New diagnostics: `SNS_IG_CONTINUE_PENDING_START/PICK/DONE`, `SNS_IG_POST_RELOAD`, and `SNS_IG_DISCOVERY_RELOAD`.

## Instagram CDN URL-hash fix
- Resolver candidates from Instagram post HTML are no longer accepted merely because they look like valid fbcdn/cdninstagram media URLs.
- IMAGE/VIDEO candidates on Meta CDN must include the expiring `oh` and `oe` hash parameters before the resolver may complete the post.
- A candidate missing either hash is treated as incomplete and immediately enters the existing browser/WebView fallback for that same post.
- The browser fallback continues to read post media from the live DOM/current WebView session, where Instagram supplies the complete signed CDN URL actually used by the page.
- This targets the v0.1.72 failure where direct thumbnail/video requests returned HTTP 403 with a 12-byte text response while the visible Instagram page itself could display the media.

## Ordered inline fallback
- The profile is still processed in order, one post at a time.
- An invalid/partial resolver URL does not get queued as finished media and discovery does not advance past that post.
- Browser fallback is completed for the current post before the next profile post is selected.
- Existing inline retry behavior remains: one browser retry after profile restoration, then skip and continue if the same post still cannot be resolved.

## Preserved behavior
- Reel completion still requires playable video/stream media.
- Regular `/p/` posts are not rejected solely because `videoHint` is present.
- Carousel-hinted resolver results with fewer than two candidates still use browser fallback.
- Reel/video cover JPEGs remain excluded as standalone IMAGE results.
- Video thumbnails still use bounded local MP4 download followed by local frame extraction.
- Completed/discovered post URLs and profile-order display ordering remain unchanged.

## Diagnostics
- `SNS_IG_RESOLVER_SIGNATURE_FALLBACK`: resolver returned an IMAGE/VIDEO CDN URL missing Meta `oh`/`oe` hash parameters, so the post is handed to browser fallback instead of emitting the broken URL.
- Existing `SNS_IG_RESOLVER_INLINE_FALLBACK`, `SNS_IG_STREAM_RETRY_INLINE`, `THUMB_HTTP`, and `VIDEO_THUMB_HTTP` diagnostics remain.

## Package
- versionCode: 75
- versionName: 0.1.74

## v0.1.75

- Analyze button now transitions `停止 -> クリア -> 解析` after a manual stop; Clear removes media/reload cells before returning to Analyze.
- Selected media metadata uses one continuous N-light-blue rounded square around filename + resolution.
- Header gear artwork reduced one step; X and Instagram glyph visual sizes normalized.
- Status text suppresses raw URLs. Instagram `投稿を取得中（done/total）` is shown on the right side of the image/video/stream/selection summary row.
- Added `保存場所を変更` directly below the resolution floor setting. It opens the N Explorer dialog with storage switching, parent navigation, new-folder creation, direct-grab scrollbar and folder confirmation.
- Downloads now use the persisted save destination; default remains `Downloads/ImgStalker`.
