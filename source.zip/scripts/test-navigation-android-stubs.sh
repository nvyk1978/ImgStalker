#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)";trap 'rm -rf "$TMP"' EXIT
ROOT="$TMP/src"
mkdir -p "$ROOT"/{android/content,android/content/res,android/util,android/graphics,android/net,android/os,android/view,android/widget,com/cmyk/imgstalker}
cat > "$ROOT/android/content/Context.java" <<'JAVA'
package android.content; public class Context {
 public android.content.Context getApplicationContext(){return this;}
 public java.io.File getCacheDir(){return new java.io.File("/tmp");}
 public android.content.res.Resources getResources(){return new android.content.res.Resources();}
}
JAVA
cat > "$ROOT/android/content/res/Resources.java" <<'JAVA'
package android.content.res;public class Resources{public android.util.DisplayMetrics getDisplayMetrics(){return new android.util.DisplayMetrics();}}
JAVA
cat > "$ROOT/android/util/DisplayMetrics.java" <<'JAVA'
package android.util; public class DisplayMetrics{public float density=1;}
JAVA
cat > "$ROOT/android/util/LruCache.java" <<'JAVA'
package android.util;public class LruCache<K,V>{public LruCache(int n){}public V get(K k){return null;}public V put(K k,V v){return v;}}
JAVA
cat > "$ROOT/android/graphics/Bitmap.java" <<'JAVA'
package android.graphics;public class Bitmap{
 public enum CompressFormat{PNG}
 public enum Config{ARGB_8888}
 public static Bitmap createBitmap(int w,int h,Config c){return new Bitmap();}
 public boolean compress(CompressFormat f,int i,java.io.OutputStream o){return true;}
 public int getWidth(){return 16;}public int getHeight(){return 16;}public void recycle(){}
 public static Bitmap createScaledBitmap(Bitmap b,int w,int h,boolean filter){return b;}
}
JAVA
cat > "$ROOT/android/graphics/BitmapFactory.java" <<'JAVA'
package android.graphics;public class BitmapFactory{public static Bitmap decodeFile(String s){return null;}public static Bitmap decodeByteArray(byte[] b,int start,int length){return null;}
 public static Bitmap decodeByteArray(byte[] b,int start,int length,Options o){return null;}
 public static class Options{public boolean inJustDecodeBounds;public int outWidth=0,outHeight=0,inSampleSize=1;}}
JAVA
cat > "$ROOT/android/graphics/Canvas.java" <<'JAVA'
package android.graphics;public class Canvas{
 public Canvas(Bitmap b){} public boolean clipPath(Path p){return true;}
 public void drawBitmap(Bitmap b,Rect r,RectF f,Paint p){}
}
JAVA
cat > "$ROOT/android/graphics/Paint.java" <<'JAVA'
package android.graphics;public class Paint{public static final int ANTI_ALIAS_FLAG=1,FILTER_BITMAP_FLAG=2;public Paint(int f){}}
JAVA
cat > "$ROOT/android/graphics/Path.java" <<'JAVA'
package android.graphics;public class Path{public enum Direction{CW} public void addCircle(float cx,float cy,float radius,Direction dir){}}
JAVA
cat > "$ROOT/android/graphics/Rect.java" <<'JAVA'
package android.graphics;public class Rect{public Rect(int a,int b,int c,int d){}}
JAVA
cat > "$ROOT/android/graphics/RectF.java" <<'JAVA'
package android.graphics;public class RectF{public RectF(float a,float b,float c,float d){}}
JAVA
cat > "$ROOT/android/R.java" <<'JAVA' 
package android;public final class R{public static final class drawable{public static final int ic_menu_view=0;}}
JAVA
cat > "$ROOT/android/net/Uri.java" <<'JAVA'
package android.net;public class Uri{}
JAVA
cat > "$ROOT/android/os/Looper.java" <<'JAVA'
package android.os;public class Looper{public static Looper getMainLooper(){return new Looper();}}
JAVA
cat > "$ROOT/android/os/Handler.java" <<'JAVA'
package android.os;public class Handler{public Handler(Looper l){}public boolean post(Runnable r){return true;}public boolean postDelayed(Runnable r,long delay){return true;}public void removeCallbacks(Runnable r){}}
JAVA
cat > "$ROOT/android/view/HapticFeedbackConstants.java" <<'JAVA'
package android.view;public class HapticFeedbackConstants{public static final int LONG_PRESS=0,FLAG_IGNORE_VIEW_SETTING=1;}
JAVA
cat > "$ROOT/android/view/MotionEvent.java" <<'JAVA'
package android.view;public class MotionEvent{public static final int ACTION_DOWN=0,ACTION_MOVE=2,ACTION_UP=1,ACTION_CANCEL=3;public int getActionMasked(){return 0;}public float getRawY(){return 0;}}
JAVA
cat > "$ROOT/android/view/View.java" <<'JAVA'
package android.view;
public class View{
 public static final int VISIBLE=0; public int getVisibility(){return 0;}
 public interface OnTouchListener{boolean onTouch(View v,MotionEvent e);}
 public interface OnLongClickListener{boolean onLongClick(View v);}
 public void setHapticFeedbackEnabled(boolean enabled){}
 public void setOnTouchListener(OnTouchListener l){}
 public void setOnLongClickListener(OnLongClickListener l){}
 public Object getParent(){return null;}
 public float getElevation(){return 0;}
 public void setElevation(float z){}
 public boolean performHapticFeedback(int c,int flags){return true;}
 public int getTop(){return 0;} public int getBottom(){return 0;}
 public int getHeight(){return 0;}public float getTranslationY(){return 0;}
 public void setTranslationY(float t){}
 public Object getTag(){return null;}public void setTag(Object t){}
 public ViewPropertyAnimator animate(){return new ViewPropertyAnimator();}
 public static class ViewPropertyAnimator{public ViewPropertyAnimator translationY(float y){return this;}public ViewPropertyAnimator setDuration(long d){return this;}public ViewPropertyAnimator withEndAction(Runnable r){return this;}public void start(){}public void cancel(){}}
}
JAVA
cat > "$ROOT/android/view/ViewGroup.java" <<'JAVA'
package android.view;public class ViewGroup extends View{public void removeViewAt(int idx){}public void addView(View v,int idx){}public int getChildCount(){return 0;}public View getChildAt(int i){return null;}public int indexOfChild(View v){return 0;}public void requestDisallowInterceptTouchEvent(boolean d){}}
JAVA
cat > "$ROOT/android/widget/ImageView.java" <<'JAVA'
package android.widget;public class ImageView extends android.view.View{public void setImageResource(int i){}public void setImageBitmap(android.graphics.Bitmap b){}}
JAVA
cat > "$ROOT/android/widget/LinearLayout.java" <<'JAVA'
package android.widget;public class LinearLayout extends android.view.ViewGroup{}
JAVA
cat > "$ROOT/android/widget/ScrollView.java" <<'JAVA'
package android.widget;public class ScrollView extends android.view.ViewGroup{public int getScrollY(){return 0;}public void getLocationOnScreen(int[] xy){}public void scrollBy(int x,int y){}}
JAVA
cat > "$ROOT/com/cmyk/imgstalker/Stubs.java" <<'JAVA'
package com.cmyk.imgstalker;
final class R{static final class drawable{static final int ic_nav_x=0,ic_nav_instagram=0,ic_nav_normal=0;}}
final class SiteVisitStore{
 static String normalize(String s){return s;} static String socialHandleForUrl(String s){return "";}
 static void setBookmarkOrder(android.content.Context c,java.util.List<String> l){}
 static final class Entry{String url="";} 
 static java.util.List<Entry> entries(android.content.Context c, boolean favorites){return java.util.Collections.emptyList();}
}
final class AnalysisModeRouter{enum Mode{NORMAL,X,INSTAGRAM}static Mode fromUrl(String s){return Mode.NORMAL;}}
final class DiagnosticLog{static void logException(String s,Throwable e) {}}
JAVA
javac -encoding UTF-8 -d "$TMP/out" $(find "$ROOT" -name '*.java') \
 app/src/main/java/com/cmyk/imgstalker/NavigationIconLoader.java \
 app/src/main/java/com/cmyk/imgstalker/BookmarkReorderTouch.java \
 app/src/main/java/com/cmyk/imgstalker/NavigationBookmarkOrder.java \
 app/src/main/java/com/cmyk/imgstalker/NavigationModeFilter.java
printf '%s\n' 'PASS: v0.1.159 navigation icon, circular crop, drag and filter javac with API stubs'
