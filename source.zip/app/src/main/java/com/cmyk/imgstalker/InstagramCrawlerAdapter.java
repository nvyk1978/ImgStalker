package com.cmyk.imgstalker;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import android.webkit.WebView;
import org.json.JSONObject;

/** Original v0.1.92 provider engine, confined to one host class and one WebView. */
final class InstagramCrawlerAdapter implements ModeCrawler {
    private final InstagramCrawlerEngine core;
    InstagramCrawlerAdapter(WebView view, CrawlerEngine.Listener listener) { core = new InstagramCrawlerEngine(view, listener); }
    @Override public void start(String url, boolean pages, boolean details, boolean intelligent, boolean images, boolean videos, int px) {
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.INSTAGRAM) { core.cancel(); throw new IllegalArgumentException("INSTAGRAM crawler refused foreign host"); }
        // v0.1.92 did not have the v0.1.135 intelligent flag; retain its original traversal semantics.
        core.start(url, pages, details, images, videos, px);
    }
    @Override public void cancel(){core.cancel();}
    @Override public void requestGracefulStop(){core.requestGracefulStop();}
    @Override public boolean recoverFromStall(){return core.recoverFromStall();}
    @Override public boolean hasPendingWork(){return core.hasPendingWork();}
    @Override public String progressSnapshot(){return core.progressSnapshot();}
    @Override public void seedExternalResumeMedia(List<MediaItem> items){core.seedExternalResumeMedia(items);}
    @Override public void seedContinuationResults(List<MediaItem> items){core.seedContinuationResults(items);}
    @Override public void seedInstagramContinuationState(Collection<String> done, Collection<String> discovered){core.seedInstagramContinuationState(done, discovered);}
    @Override public List<String> getCompletedInstagramPostUrls(){return core.getCompletedInstagramPostUrls();}
    @Override public List<String> getDiscoveredInstagramPostUrls(){return core.getDiscoveredInstagramPostUrls();}
    @Override public int getInstagramFailedPostCount(){return core.getInstagramFailedPostCount();}
    @Override public boolean isIncompleteCompletion(){return core.isIncompleteCompletion();}
    @Override public String getIncompleteCompletionReason(){return core.getIncompleteCompletionReason();}
    // The legacy crawler was built before the generic resumable queue cursor. Do not route
    // legacy checkpoints through the X crawler, or invent a compatible queue format.
    @Override public JSONObject checkpointCursor(){return null;}
    @Override public void seedQueueCursor(JSONObject cursor){}
    @Override public void setIncludeXReposts(boolean enabled){}
    @Override public void setXSearchExecutionAllowed(boolean enabled, String reason){}
}
