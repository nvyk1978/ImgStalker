#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TEMP=$(mktemp -d); trap 'rm -rf "$TEMP"' EXIT
src="$TEMP/stub"
mkdir -p "$src/android/os" "$src/android/content/res" "$src/android/content" "$src/android/webkit" "$src/org/json" "$src/com/cmyk/imgstalker"
cat > "$src/android/os/Looper.java" <<'JAVA'
package android.os;public class Looper {public static Looper getMainLooper(){return new Looper();}}
JAVA
cat > "$src/android/os/Handler.java" <<'JAVA'
package android.os;public class Handler {public Handler(Looper l){}public boolean postDelayed(Runnable r,long t){return true;}public boolean post(Runnable r){return true;}}
JAVA
cat > "$src/android/content/res/AssetManager.java" <<'JAVA'
package android.content.res;public class AssetManager {public java.io.InputStream open(String s) throws java.io.IOException{return null;}}
JAVA
cat > "$src/android/content/Context.java" <<'JAVA'
package android.content; public class Context {public android.content.res.AssetManager getAssets(){return null;}}
JAVA
cat > "$src/android/webkit/WebSettings.java" <<'JAVA'
package android.webkit;public class WebSettings {public String getUserAgentString(){return "";}public void setUserAgentString(String u){}public void setJavaScriptEnabled(boolean on){}public void setDomStorageEnabled(boolean on){}}
JAVA
cat > "$src/android/webkit/WebResourceRequest.java" <<'JAVA'
package android.webkit;public interface WebResourceRequest {android.net.Uri getUrl(); boolean isForMainFrame();}
JAVA
mkdir -p "$src/android/net"
cat > "$src/android/net/Uri.java" <<'JAVA'
package android.net;public class Uri {public String toString(){return "";}}
JAVA
cat > "$src/android/webkit/WebResourceError.java" <<'JAVA'
package android.webkit;public class WebResourceError {public int getErrorCode(){return 0;}}
JAVA
cat > "$src/android/webkit/WebViewClient.java" <<'JAVA'
package android.webkit;public class WebViewClient {public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return false;}public boolean shouldOverrideUrlLoading(WebView v,String s){return false;}public void onPageFinished(WebView v,String u){}public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){}}
JAVA
cat > "$src/android/webkit/WebView.java" <<'JAVA'
package android.webkit;public class WebView {public WebSettings getSettings(){return new WebSettings();}public android.content.Context getContext(){return new android.content.Context();}public void setWebViewClient(WebViewClient c){}public void loadUrl(String u){}public String getUrl(){return "";}public void evaluateJavascript(String s,java.util.function.Consumer<String> cb){}}
JAVA
cat > "$src/org/json/JSONTokener.java" <<'JAVA'
package org.json;public class JSONTokener {public JSONTokener(String s){} public Object nextValue(){return "";}}
JAVA
cat > "$src/org/json/JSONArray.java" <<'JAVA'
package org.json;public class JSONArray {public int length(){return 0;}public String optString(int i,String d){return d;}public JSONObject optJSONObject(int i){return null;}}
JAVA
cat > "$src/org/json/JSONObject.java" <<'JAVA'
package org.json;public class JSONObject {public JSONObject(String s){}public String optString(String k,String d){return d;}public JSONArray optJSONArray(String k){return null;}public int optInt(String k){return 0;}public boolean optBoolean(String k,boolean d){return d;}public long optLong(String k,long d){return d;}}
JAVA
cat > "$src/com/cmyk/imgstalker/Stubs.java" <<'JAVA'
package com.cmyk.imgstalker;
class DiagnosticLog {static void log(String m){}static void logException(String m,Throwable t){}}
class CrawlerEngine {interface Listener {void onStatus(String t);void onProgressPulse(String t);void onItem(MediaItem i);void onDone(String t,int p,int im,int v,int st);void onError(String m);}}
JAVA
javac -encoding UTF-8 -d "$TEMP/classes" $(find "$src" -name '*.java') \
 app/src/main/java/com/cmyk/imgstalker/MediaItem.java \
 app/src/main/java/com/cmyk/imgstalker/AnalysisModeRouter.java \
 app/src/main/java/com/cmyk/imgstalker/ThreadsMediaIdentity.java \
 app/src/main/java/com/cmyk/imgstalker/ThreadsCrawlerEngine.java
node --check app/src/main/assets/threads_feed.js
printf '%s\n' 'PASS: Threads crawler engine Java compilation + DOM JS syntax'
