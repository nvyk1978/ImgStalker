package com.cmyk.imgstalker;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.WebSettings;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class MediaDownloader {
    public interface Listener {
        void onProgress(int done, int total, String message);
        // Called only after the media has been durably written/published. This is the commit point for JSON save history.
        void onSaved(MediaItem item, long bytes);
        // Called for an actual save failure; user cancellation is not recorded as a failed media key.
        void onFailed(MediaItem item, String reason);
        void onFinished(String folderName, int success, int failed);
    }

    private final Context context;
    private final Listener listener;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private final String userAgent;
    private final String browserUserAgent;
    private final boolean saveXGifAsGif;

    public MediaDownloader(Context context, boolean saveXGifAsGif, Listener listener) {
        this.context = context.getApplicationContext();
        this.saveXGifAsGif = saveXGifAsGif;
        this.listener = listener;
        String baseUa;
        try {
            baseUa = WebSettings.getDefaultUserAgent(this.context);
        } catch (Exception e) {
            baseUa = "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36";
        }
        browserUserAgent = baseUa;
        userAgent = baseUa + " ImgStalker/0.1.110";
    }

    public void cancel() {
        DiagnosticLog.log("DOWNLOADER_CANCEL");
        cancelled.set(true);
        pool.shutdownNow();
    }

    public void download(List<MediaItem> source, String pageTitle, String category, String accountName) {
        ArrayList<MediaItem> items = new ArrayList<>();
        for (MediaItem i : source) if (i.selected && i.kind != MediaItem.Kind.STREAM) items.add(i);
        final int total = items.size();
        DiagnosticLog.log("DOWNLOADER_BEGIN total=" + total + " title=" + pageTitle);
        if (total == 0) {
            listener.onFinished("", 0, 0);
            return;
        }
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.JAPAN).format(new Date());
        String base = sanitize(pageTitle);
        if (base.isEmpty()) base = "WebMedia";
        final String folder = base + "_" + stamp;
        final String categoryFolder = sanitizeCategory(category);
        final String accountFolder = sanitize(accountName);
        final String destinationFolder;
        if (!categoryFolder.isEmpty() && !accountFolder.isEmpty()) {
            destinationFolder = appendPath(categoryFolder, accountFolder);
        } else {
            destinationFolder = categoryFolder.isEmpty() ? folder : appendPath(categoryFolder, folder);
        }
        AtomicInteger done = new AtomicInteger();
        AtomicInteger ok = new AtomicInteger();
        AtomicInteger ng = new AtomicInteger();

        for (int idx = 0; idx < items.size(); idx++) {
            final int index = idx + 1;
            final MediaItem item = items.get(idx);
            pool.submit(() -> {
                if (!cancelled.get()) {
                    try {
                        long bytes = downloadOne(item, destinationFolder, index);
                        ok.incrementAndGet();
                        DiagnosticLog.log("DOWNLOAD_OK kind=" + item.kind + " bytes=" + bytes + " url=" + item.url);
                        try {
                            listener.onSaved(item, bytes);
                        } catch (Throwable callbackError) {
                            // The media is already published; a UI/history callback must not turn a
                            // successful file write into a false download failure.
                            DiagnosticLog.logException("DOWNLOAD_SAVED_CALLBACK_FAIL key="
                                    + SnsResumeStore.savedMediaKey(item), callbackError);
                        }
                    } catch (Exception e) {
                        ng.incrementAndGet();
                        DiagnosticLog.logException("DOWNLOAD_FAIL kind=" + item.kind + " url=" + item.url, e);
                        try {
                            listener.onFailed(item, e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()));
                        } catch (Throwable callbackError) {
                            DiagnosticLog.logException("DOWNLOAD_FAILED_CALLBACK_FAIL key="
                                    + SnsResumeStore.savedMediaKey(item), callbackError);
                        }
                    }
                } else {
                    ng.incrementAndGet();
                }
                int d = done.incrementAndGet();
                if (cancelled.get()) return;
                listener.onProgress(d, total, item.url);
                if (d == total) {
                    pool.shutdown();
                    listener.onFinished(destinationFolder, ok.get(), ng.get());
                }
            });
        }
    }

    private long downloadOne(MediaItem item, String folder, int index) throws Exception {
        if (shouldConvertXGif(item)) return downloadXGifAsGif(item, folder, index);
        String accept = item.kind == MediaItem.Kind.IMAGE
                ? "image/avif,image/webp,image/apng,image/*,*/*;q=0.8"
                : "video/mp4,video/webm,video/*,*/*;q=0.8";
        HttpURLConnection con = item.kind == MediaItem.Kind.IMAGE
                ? openImageLikeThumbnail(item, 0)
                : openVideoFollowingRedirectsWithTwitterFallback(item.url, item.referrer, accept, "download");
        Uri uri = null;
        boolean success = false;
        long written = 0L;
        try {
            int code = con.getResponseCode();
            String finalUrl = con.getURL().toString();
            String contentType = normalizeMime(con.getContentType());
            long contentLength = con.getContentLengthLong();
            DiagnosticLog.log("DOWNLOAD_HTTP_RESPONSE code=" + code
                    + " type=" + contentType
                    + " length=" + contentLength
                    + " finalUrl=" + finalUrl);
            if (item.kind == MediaItem.Kind.IMAGE && code == 403) {
                con.disconnect();
                DiagnosticLog.log("DOWNLOAD_RETRY reason=HTTP403 url=" + item.url);
                try { Thread.sleep(250L); } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw interrupted;
                }
                con = openImageLikeThumbnail(item, 1);
                code = con.getResponseCode();
                finalUrl = con.getURL().toString();
                contentType = normalizeMime(con.getContentType());
                contentLength = con.getContentLengthLong();
                DiagnosticLog.log("DOWNLOAD_HTTP_RESPONSE retry=1 code=" + code
                        + " type=" + contentType
                        + " length=" + contentLength
                        + " finalUrl=" + finalUrl);
            }
            if (code < 200 || code >= 300) throw new FileNotFoundException("HTTP " + code);
            if (contentType != null && (contentType.startsWith("text/html") || contentType.startsWith("application/json"))) {
                throw new IOException("media response is " + contentType);
            }
            if (item.kind == MediaItem.Kind.VIDEO) {
                String lowerType = contentType == null ? "" : contentType.toLowerCase(Locale.ROOT);
                String lowerUrl = finalUrl == null ? "" : finalUrl.toLowerCase(Locale.ROOT);
                if (lowerType.contains("mpegurl") || lowerType.contains("dash+xml")
                        || lowerUrl.matches(".*\\.(m3u8|mpd)(\\?.*)?$")) {
                    throw new IOException("stream manifest cannot be saved as video file");
                }
                if (TwitterVideoUrl.isTwitterVideoMp4(finalUrl)
                        && contentType != null && !contentType.isEmpty()
                        && !lowerType.startsWith("video/")
                        && !lowerType.equals("application/octet-stream")) {
                    throw new IOException("unexpected X video response type " + contentType);
                }
            }

            String original = filenameFromUrl(finalUrl);
            String ext = extension(original);
            if (ext.isEmpty()) ext = extensionForMime(contentType, item.kind);
            if (original.isEmpty() || extension(original).isEmpty()) {
                original = (item.kind == MediaItem.Kind.IMAGE ? "image" : "video")
                        + "_" + String.format(Locale.US, "%03d", index) + ext;
            }
            original = sanitizeFilename(original);
            String displayName = String.format(Locale.US, "%03d_", index) + original;
            String saveMime = contentType != null ? contentType : fallbackMime(item.kind, ext);
            ContentResolver resolver = context.getContentResolver();
            boolean safVideo = false;
            String relPath = "";
            SaveTarget saveTarget = resolveSaveTarget();

            // Android scoped storage rejects videos inserted under a Pictures-only RELATIVE_PATH.
            // When the N Explorer has a persisted SAF grant, write the video to the selected tree
            // directly so Pictures/ImgStalker/.../videos remains a real user-selected destination.
            if (item.kind == MediaItem.Kind.VIDEO && SavePrefs.hasTreeAccess(context)) {
                uri = createSafMediaDocument(folder, "videos", saveMime, displayName);
                if (uri != null) {
                    safVideo = true;
                    relPath = appendPath(appendPath(saveTarget.relativeBase, folder), "videos") + "/";
                    DiagnosticLog.log("DOWNLOAD_SAVE_URI backend=saf uri=" + uri
                            + " path=" + relPath + " selected=" + saveTarget.selectedPath
                            + " name=" + displayName);
                }
            }

            if (uri == null) {
                if (item.kind == MediaItem.Kind.VIDEO) saveTarget = videoCompatibleTarget(saveTarget);
                relPath = appendPath(saveTarget.relativeBase, folder) + "/";
                if (item.kind == MediaItem.Kind.VIDEO) relPath += "videos/";

                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
                v.put(MediaStore.MediaColumns.MIME_TYPE, saveMime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, relPath);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = collectionForSaveTarget(saveTarget, item.kind);
                uri = resolver.insert(collection, v);
                if (uri == null) throw new FileNotFoundException("MediaStore insert failed");
                DiagnosticLog.log("DOWNLOAD_SAVE_URI backend=mediastore uri=" + uri + " volume=" + saveTarget.volumeName
                        + " path=" + relPath + " selected=" + saveTarget.selectedPath + " name=" + displayName);
            }

            try (BufferedInputStream in = new BufferedInputStream(con.getInputStream());
                 OutputStream raw = resolver.openOutputStream(uri, "w")) {
                if (raw == null) throw new FileNotFoundException("openOutputStream returned null");
                try (BufferedOutputStream out = new BufferedOutputStream(raw)) {
                    DiagnosticLog.log("DOWNLOAD_WRITE_BEGIN backend=" + (safVideo ? "saf" : "mediastore") + " uri=" + uri);
                    byte[] buf = new byte[128 * 1024];
                    int n;
                    while (!cancelled.get() && (n = in.read(buf)) >= 0) {
                        if (n == 0) continue;
                        out.write(buf, 0, n);
                        written += n;
                    }
                    out.flush();
                }
            }
            if (cancelled.get()) throw new InterruptedException("cancelled");
            if (written <= 0L) throw new IOException("empty response body");
            DiagnosticLog.log("DOWNLOAD_WRITE_DONE backend=" + (safVideo ? "saf" : "mediastore")
                    + " uri=" + uri + " bytes=" + written);

            if (item.kind == MediaItem.Kind.VIDEO) {
                validateSavedVideo(uri, finalUrl, contentType, written);
            }

            if (!safVideo) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                int updated = resolver.update(uri, done, null, null);
                DiagnosticLog.log("DOWNLOAD_PUBLISH uri=" + uri + " rows=" + updated + " bytes=" + written);
            } else {
                DiagnosticLog.log("DOWNLOAD_PUBLISH backend=saf uri=" + uri + " bytes=" + written);
            }
            success = true;
            return written;
        } finally {
            con.disconnect();
            if (!success && uri != null) {
                try {
                    context.getContentResolver().delete(uri, null, null);
                    DiagnosticLog.log("DOWNLOAD_PARTIAL_DELETE uri=" + uri);
                } catch (Exception e) {
                    DiagnosticLog.logException("DOWNLOAD_PARTIAL_DELETE_FAIL uri=" + uri, e);
                }
            }
        }
    }

    private boolean shouldConvertXGif(MediaItem item) {
        if (!saveXGifAsGif || item == null || item.kind != MediaItem.Kind.VIDEO) return false;
        try {
            URL url = new URL(item.url);
            String host = url.getHost() == null ? "" : url.getHost().toLowerCase(Locale.ROOT);
            String path = url.getPath() == null ? "" : url.getPath().toLowerCase(Locale.ROOT);
            return (host.equals("video.twimg.com") || host.endsWith(".video.twimg.com"))
                    && (path.startsWith("/tweet_video/")
                    || path.contains("animated_gif") || path.contains("animatedgif"));
        } catch (Throwable ignored) {
            return false;
        }
    }

    private long downloadXGifAsGif(MediaItem item, String folder, int index) throws Exception {
        File temp = File.createTempFile("imgstalker_xgif_", ".mp4", context.getCacheDir());
        Uri uri = null;
        boolean success = false;
        HttpURLConnection con = null;
        try {
            DiagnosticLog.log("SNS_X_GIF_SAVE_BEGIN url=" + item.url + " ref=" + item.referrer);
            con = openVideoFollowingRedirectsWithTwitterFallback(item.url, item.referrer,
                    "video/mp4,video/*,*/*;q=0.8", "xgif_source");
            int code = con.getResponseCode();
            if (code < 200 || code >= 300) throw new FileNotFoundException("HTTP " + code);
            String contentType = normalizeMime(con.getContentType());
            if (contentType != null && (contentType.startsWith("text/html") || contentType.startsWith("application/json"))) {
                throw new IOException("GIF source response is " + contentType);
            }
            long sourceBytes = 0L;
            try (BufferedInputStream in = new BufferedInputStream(con.getInputStream());
                 BufferedOutputStream out = new BufferedOutputStream(new java.io.FileOutputStream(temp), 128 * 1024)) {
                byte[] buf = new byte[128 * 1024];
                int n;
                while (!cancelled.get() && (n = in.read(buf)) >= 0) {
                    if (n == 0) continue;
                    out.write(buf, 0, n);
                    sourceBytes += n;
                }
                out.flush();
            }
            if (cancelled.get()) throw new InterruptedException("cancelled");
            if (sourceBytes <= 0L) throw new IOException("empty GIF source body");
            DiagnosticLog.log("SNS_X_GIF_SOURCE_READY bytes=" + sourceBytes + " temp=" + temp.length());

            String baseName = filenameFromUrl(con.getURL().toString());
            if (baseName.isEmpty()) baseName = "twitter_gif_" + String.format(Locale.US, "%03d", index) + ".gif";
            int dot = baseName.lastIndexOf('.');
            if (dot > 0) baseName = baseName.substring(0, dot);
            String displayName = String.format(Locale.US, "%03d_", index) + sanitizeFilename(baseName) + ".gif";
            String saveMime = "image/gif";
            SaveTarget saveTarget = resolveSaveTarget();
            String relPath = appendPath(saveTarget.relativeBase, folder) + "/";

            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
            v.put(MediaStore.MediaColumns.MIME_TYPE, saveMime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, relPath);
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            ContentResolver resolver = context.getContentResolver();
            uri = resolver.insert(collectionForSaveTarget(saveTarget, MediaItem.Kind.IMAGE), v);
            if (uri == null) throw new FileNotFoundException("GIF MediaStore insert failed");
            DiagnosticLog.log("SNS_X_GIF_SAVE_URI uri=" + uri + " path=" + relPath + " name=" + displayName);

            long written;
            try (OutputStream raw = resolver.openOutputStream(uri, "w")) {
                if (raw == null) throw new FileNotFoundException("GIF openOutputStream returned null");
                written = XGifTranscoder.transcode(context, temp, raw, cancelled::get);
            }
            if (cancelled.get()) throw new InterruptedException("cancelled");
            if (written <= 0L) throw new IOException("empty GIF output");

            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            int updated = resolver.update(uri, done, null, null);
            DiagnosticLog.log("SNS_X_GIF_PUBLISH uri=" + uri + " rows=" + updated
                    + " sourceBytes=" + sourceBytes + " gifBytes=" + written);
            success = true;
            return written;
        } finally {
            if (con != null) con.disconnect();
            if (!success && uri != null) {
                try { context.getContentResolver().delete(uri, null, null); }
                catch (Throwable error) { DiagnosticLog.logException("SNS_X_GIF_PARTIAL_DELETE_FAIL uri=" + uri, error); }
            }
            if (!temp.delete() && temp.exists()) temp.deleteOnExit();
        }
    }

    private HttpURLConnection openImageLikeThumbnail(MediaItem item, int attempt) throws Exception {
        if (cancelled.get()) throw new InterruptedException("cancelled");
        URL url = new URL(item.url);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(12000);
        con.setReadTimeout(16000);
        con.setRequestProperty("User-Agent", userAgent);
        con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
        con.setRequestProperty("Accept-Encoding", "identity");
        con.setRequestProperty("Sec-Fetch-Dest", "image");
        con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
        if (item.referrer != null && !item.referrer.isEmpty()) {
            con.setRequestProperty("Referer", item.referrer);
        }
        String cookie = SessionCookies.getCookie(item.url);
        if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
        DiagnosticLog.log("DOWNLOAD_HTTP_BEGIN mode=thumbnail_like attempt=" + attempt
                + " url=" + item.url
                + " ref=" + item.referrer
                + " cookie=" + (cookie == null ? 0 : cookie.length()));
        con.connect();
        return con;
    }

    private HttpURLConnection openVideoFollowingRedirectsWithTwitterFallback(
            String startUrl, String referrer, String accept, String mode) throws Exception {
        if (!TwitterVideoUrl.isTwitterVideoMp4(startUrl)) {
            return openFollowingRedirects(startUrl, referrer, accept, userAgent, null);
        }
        if (TwitterVideoUrl.isKnownFailed(startUrl, mode)) {
            DiagnosticLog.log("TW_VIDEO_FAIL_CACHE_HIT mode=" + mode + " url=" + startUrl);
            throw new FileNotFoundException("HTTP 403 cached");
        }

        String effectiveStartUrl = TwitterVideoUrl.resolvedOrOriginal(startUrl);
        if (!effectiveStartUrl.equals(startUrl)) {
            DiagnosticLog.log("TW_VIDEO_URL_REUSE mode=" + mode + " url=" + effectiveStartUrl);
        }

        // Primary transport: use the real status URL as Referer and do not invent an Origin.
        HttpURLConnection con = openFollowingRedirects(
                effectiveStartUrl, referrer, accept, browserUserAgent, null);
        int code = con.getResponseCode();
        if (code >= 200 && code < 300) return con;
        if (code != 403) return con;

        DiagnosticLog.log("TW_VIDEO_403_DETECTED mode=" + mode + " profile=status_ref url=" + effectiveStartUrl);
        con.disconnect();

        // Compatibility fallback for CDN variants that only accept browser-like X root headers.
        con = openFollowingRedirects(
                effectiveStartUrl, "https://x.com/", accept, browserUserAgent, "https://x.com");
        int browserCode = con.getResponseCode();
        DiagnosticLog.log("TW_VIDEO_BROWSER_RETRY mode=" + mode
                + " code=" + browserCode + " url=" + con.getURL());
        if (browserCode >= 200 && browserCode < 300) {
            DiagnosticLog.log("TW_VIDEO_BROWSER_RECOVERED mode=" + mode + " url=" + con.getURL());
            return con;
        }
        if (browserCode != 403) return con;
        con.disconnect();

        // Re-resolve a current MP4 from the original status page, then repeat the same order:
        // real status Referer first, X-root Origin only as a compatibility fallback.
        String refreshed = TwitterVideoUrl.resolveFresh(startUrl, referrer, browserUserAgent);
        if (!refreshed.isEmpty()) {
            DiagnosticLog.log("TW_VIDEO_REFRESH_RETRY mode=" + mode + " profile=status_ref url=" + refreshed);
            con = openFollowingRedirects(
                    refreshed, referrer, accept, browserUserAgent, null);
            int refreshedCode = con.getResponseCode();
            if (refreshedCode >= 200 && refreshedCode < 300) {
                TwitterVideoUrl.markRecovered(startUrl, refreshed);
                DiagnosticLog.log("TW_VIDEO_URL_RECOVERED mode=" + mode
                        + " profile=status_ref code=" + refreshedCode + " url=" + con.getURL());
                return con;
            }
            if (refreshedCode != 403) return con;
            con.disconnect();

            DiagnosticLog.log("TW_VIDEO_REFRESH_RETRY mode=" + mode + " profile=x_origin url=" + refreshed);
            con = openFollowingRedirects(
                    refreshed, "https://x.com/", accept, browserUserAgent, "https://x.com");
            int refreshedBrowserCode = con.getResponseCode();
            if (refreshedBrowserCode >= 200 && refreshedBrowserCode < 300) {
                TwitterVideoUrl.markRecovered(startUrl, refreshed);
                DiagnosticLog.log("TW_VIDEO_URL_RECOVERED mode=" + mode
                        + " profile=x_origin code=" + refreshedBrowserCode + " url=" + con.getURL());
                return con;
            }
            if (refreshedBrowserCode != 403) return con;
            con.disconnect();
        }

        TwitterVideoUrl.markFailed(startUrl, mode);
        DiagnosticLog.log("TW_VIDEO_FAIL_CACHE_SET mode=" + mode + " url=" + startUrl);
        throw new FileNotFoundException("HTTP 403");
    }

    private HttpURLConnection openFollowingRedirects(String startUrl, String referrer, String accept,
                                                      String requestUserAgent, String origin) throws Exception {
        URL current = new URL(startUrl);
        for (int hop = 0; hop <= 6; hop++) {
            if (cancelled.get()) throw new InterruptedException("cancelled");
            HttpURLConnection con = (HttpURLConnection) current.openConnection();
            con.setInstanceFollowRedirects(false);
            con.setConnectTimeout(15000);
            con.setReadTimeout(45000);
            con.setRequestProperty("User-Agent", requestUserAgent == null || requestUserAgent.isEmpty()
                    ? userAgent : requestUserAgent);
            con.setRequestProperty("Accept", accept);
            con.setRequestProperty("Accept-Language", Locale.getDefault().toLanguageTag() + ",ja;q=0.9,en;q=0.7");
            con.setRequestProperty("Accept-Encoding", "identity");
            con.setRequestProperty("Cache-Control", "no-cache");
            con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
            con.setRequestProperty("Sec-Fetch-Dest", accept.startsWith("image/") ? "image" : "video");
            if (referrer != null && !referrer.isEmpty()) con.setRequestProperty("Referer", referrer);
            if (origin != null && !origin.isEmpty()) con.setRequestProperty("Origin", origin);
            String cookie = SessionCookies.getCookie(current.toString());
            if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
            DiagnosticLog.log("DOWNLOAD_HTTP_BEGIN hop=" + hop + " url=" + current + " ref=" + referrer
                    + " origin=" + String.valueOf(origin)
                    + " cookie=" + (cookie == null ? 0 : cookie.length()));
            con.connect();
            int code = con.getResponseCode();
            if (isRedirect(code)) {
                String location = con.getHeaderField("Location");
                if (location == null || location.trim().isEmpty()) return con;
                URL next = new URL(current, location);
                DiagnosticLog.log("DOWNLOAD_REDIRECT code=" + code + " from=" + current + " to=" + next);
                con.disconnect();
                current = next;
                continue;
            }
            return con;
        }
        throw new IOException("too many redirects");
    }

    private void validateSavedVideo(Uri uri, String sourceUrl, String contentType, long bytes) throws IOException {
        if (uri == null) throw new IOException("video validation uri missing");
        if (bytes < 1024L) throw new IOException("video response too small: " + bytes);
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(context, uri);
            String hasVideo = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO);
            String width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
            String height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
            String duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            boolean videoTrack = "yes".equalsIgnoreCase(hasVideo)
                    || positiveInt(width) > 0 || positiveInt(height) > 0;
            DiagnosticLog.log("DOWNLOAD_VIDEO_VALIDATE ok=" + videoTrack
                    + " bytes=" + bytes
                    + " type=" + String.valueOf(contentType)
                    + " size=" + String.valueOf(width) + "x" + String.valueOf(height)
                    + " durationMs=" + String.valueOf(duration)
                    + " source=" + sourceUrl);
            if (!videoTrack) throw new IOException("saved file has no decodable video track");
        } catch (IOException e) {
            throw e;
        } catch (Throwable t) {
            DiagnosticLog.logException("DOWNLOAD_VIDEO_VALIDATE_FAIL uri=" + uri + " source=" + sourceUrl, t);
            throw new IOException("saved video validation failed: " + t.getClass().getSimpleName(), t);
        } finally {
            try { retriever.release(); } catch (Throwable ignored) {}
        }
    }

    private static int positiveInt(String value) {
        if (value == null || value.trim().isEmpty()) return 0;
        try { return Math.max(0, Integer.parseInt(value.trim())); }
        catch (Exception ignored) { return 0; }
    }

    private Uri createSafMediaDocument(String folder, String childFolder, String mimeType,
                                       String displayName) {
        Uri tree = SavePrefs.treeUri(context);
        if (tree == null || !SavePrefs.hasTreeAccess(context)) return null;
        try {
            ContentResolver resolver = context.getContentResolver();
            String treeId = DocumentsContract.getTreeDocumentId(tree);
            Uri current = DocumentsContract.buildDocumentUriUsingTree(tree, treeId);
            File treeFile = SavePrefs.fileFromTreeUri(tree);
            File saveBase = SavePrefs.directory(context);
            if (treeFile != null && saveBase != null) {
                String treePath = treeFile.getCanonicalPath();
                String savePath = saveBase.getCanonicalPath();
                if (!savePath.equals(treePath)) {
                    if (!savePath.startsWith(treePath + File.separator)) {
                        DiagnosticLog.log("DOWNLOAD_SAF_TREE_MISMATCH tree=" + treePath + " save=" + savePath);
                        return null;
                    }
                    String relative = savePath.substring(treePath.length() + 1);
                    current = ensureSafDirectoryPath(resolver, tree, current, relative);
                    if (current == null) return null;
                }
            }
            current = ensureSafDirectoryPath(resolver, tree, current, folder);
            if (current == null) return null;
            current = ensureSafDirectoryPath(resolver, tree, current, childFolder);
            if (current == null) return null;
            Uri created = DocumentsContract.createDocument(resolver, current,
                    mimeType == null || mimeType.trim().isEmpty() ? "video/mp4" : mimeType,
                    displayName);
            if (created == null) DiagnosticLog.log("DOWNLOAD_SAF_CREATE_FAIL name=" + displayName);
            return created;
        } catch (Throwable error) {
            DiagnosticLog.logException("DOWNLOAD_SAF_CREATE_EXCEPTION name=" + displayName, error);
            return null;
        }
    }

    private static Uri ensureSafDirectoryPath(ContentResolver resolver, Uri tree, Uri start, String path)
            throws Exception {
        Uri current = start;
        if (path == null || path.trim().isEmpty()) return current;
        for (String segment : path.replace(File.separatorChar, '/').split("/")) {
            if (segment == null || segment.trim().isEmpty()) continue;
            Uri next = findSafChild(resolver, tree, current, segment, true);
            if (next == null) {
                next = DocumentsContract.createDocument(resolver, current,
                        DocumentsContract.Document.MIME_TYPE_DIR, segment);
            }
            if (next == null) return null;
            current = next;
        }
        return current;
    }

    private static Uri findSafChild(ContentResolver resolver, Uri tree, Uri parent,
                                    String displayName, boolean directoryOnly) {
        try {
            String parentId = DocumentsContract.getDocumentId(parent);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
            String[] projection = new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
            };
            try (Cursor c = resolver.query(children, projection, null, null, null)) {
                if (c == null) return null;
                int idCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                while (c.moveToNext()) {
                    String name = nameCol >= 0 ? c.getString(nameCol) : null;
                    if (!displayName.equals(name)) continue;
                    String mime = mimeCol >= 0 ? c.getString(mimeCol) : null;
                    if (directoryOnly && !DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) continue;
                    String id = idCol >= 0 ? c.getString(idCol) : null;
                    if (id != null) return DocumentsContract.buildDocumentUriUsingTree(tree, id);
                }
            }
        } catch (Throwable error) {
            DiagnosticLog.logException("DOWNLOAD_SAF_FIND_FAIL name=" + displayName, error);
        }
        return null;
    }

    private SaveTarget videoCompatibleTarget(SaveTarget requested) {
        String rel = requested.relativeBase == null ? "" : requested.relativeBase.toLowerCase(Locale.ROOT);
        if (rel.equals("download") || rel.startsWith("download/")
                || rel.equals("movies") || rel.startsWith("movies/")
                || rel.equals("dcim") || rel.startsWith("dcim/")) {
            return requested;
        }
        File primary = Environment.getExternalStorageDirectory();
        File fallback = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "ImgStalker");
        DiagnosticLog.log("DOWNLOAD_VIDEO_TARGET_FALLBACK requested=" + requested.selectedPath
                + " requestedRelative=" + requested.relativeBase
                + " fallback=" + fallback.getAbsolutePath());
        return new SaveTarget(MediaStore.VOLUME_EXTERNAL_PRIMARY,
                relativePath(primary, fallback), fallback.getAbsolutePath());
    }

    private SaveTarget resolveSaveTarget() {
        File requested = SavePrefs.directory(context);
        File primary = Environment.getExternalStorageDirectory();
        if (isWithin(requested, primary)) {
            return new SaveTarget(MediaStore.VOLUME_EXTERNAL_PRIMARY, relativePath(primary, requested), requested.getAbsolutePath());
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                StorageManager manager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
                if (manager != null) {
                    for (StorageVolume volume : manager.getStorageVolumes()) {
                        File root = volume.getDirectory();
                        if (root == null || !isWithin(requested, root)) continue;
                        String mediaVolume = volume.getMediaStoreVolumeName();
                        if (mediaVolume == null || mediaVolume.trim().isEmpty()) continue;
                        return new SaveTarget(mediaVolume, relativePath(root, requested), requested.getAbsolutePath());
                    }
                }
            } catch (Throwable error) {
                DiagnosticLog.logException("DOWNLOAD_SAVE_TARGET_VOLUME_FAIL requested=" + requested, error);
            }
        }
        File fallback = SavePrefs.defaultDirectory();
        DiagnosticLog.log("DOWNLOAD_SAVE_TARGET_FALLBACK requested=" + requested.getAbsolutePath()
                + " fallback=" + fallback.getAbsolutePath());
        return new SaveTarget(MediaStore.VOLUME_EXTERNAL_PRIMARY, relativePath(primary, fallback), fallback.getAbsolutePath());
    }

    private static boolean isWithin(File child, File root) {
        if (child == null || root == null) return false;
        try {
            String c = child.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Throwable error) {
            return false;
        }
    }

    private static String relativePath(File root, File target) {
        try {
            String r = root.getCanonicalPath();
            String t = target.getCanonicalPath();
            if (t.equals(r)) return "ImgStalker";
            if (t.startsWith(r + File.separator)) {
                String relative = t.substring(r.length() + 1).replace(File.separatorChar, '/');
                return relative.isEmpty() ? "ImgStalker" : relative;
            }
        } catch (Throwable ignored) { }
        return Environment.DIRECTORY_PICTURES + "/ImgStalker";
    }

    private static Uri collectionForSaveTarget(SaveTarget target, MediaItem.Kind kind) {
        String rel = target.relativeBase == null ? "" : target.relativeBase.toLowerCase(Locale.ROOT);
        if (rel.equals("download") || rel.startsWith("download/")) {
            return MediaStore.Downloads.getContentUri(target.volumeName);
        }
        if (kind == MediaItem.Kind.IMAGE
                && (rel.equals("pictures") || rel.startsWith("pictures/")
                || rel.equals("dcim") || rel.startsWith("dcim/"))) {
            return MediaStore.Images.Media.getContentUri(target.volumeName);
        }
        if (kind == MediaItem.Kind.VIDEO
                && (rel.equals("movies") || rel.startsWith("movies/")
                || rel.equals("dcim") || rel.startsWith("dcim/"))) {
            return MediaStore.Video.Media.getContentUri(target.volumeName);
        }
        return MediaStore.Files.getContentUri(target.volumeName);
    }

    private static String appendPath(String base, String child) {
        String left = base == null ? "" : base.replace('\\', '/');
        while (left.endsWith("/")) left = left.substring(0, left.length() - 1);
        String right = child == null ? "" : child.replace('\\', '/');
        while (right.startsWith("/")) right = right.substring(1);
        return left.isEmpty() ? right : left + "/" + right;
    }

    private static final class SaveTarget {
        final String volumeName;
        final String relativeBase;
        final String selectedPath;

        SaveTarget(String volumeName, String relativeBase, String selectedPath) {
            this.volumeName = volumeName;
            this.relativeBase = relativeBase;
            this.selectedPath = selectedPath;
        }
    }

    private static boolean isRedirect(int code) {
        return code == HttpURLConnection.HTTP_MOVED_PERM
                || code == HttpURLConnection.HTTP_MOVED_TEMP
                || code == HttpURLConnection.HTTP_SEE_OTHER
                || code == 307 || code == 308;
    }

    private static String normalizeMime(String mime) {
        if (mime == null) return null;
        int semi = mime.indexOf(';');
        if (semi >= 0) mime = mime.substring(0, semi);
        mime = mime.trim().toLowerCase(Locale.ROOT);
        return mime.isEmpty() ? null : mime;
    }

    private static String filenameFromUrl(String s) {
        try {
            String p = new URL(s).getPath();
            int slash = p.lastIndexOf('/');
            String f = slash >= 0 ? p.substring(slash + 1) : p;
            return URLDecoder.decode(f, StandardCharsets.UTF_8.name());
        } catch (Exception e) { return ""; }
    }

    private static String extension(String f) {
        if (f == null) return "";
        int dot = f.lastIndexOf('.');
        if (dot < 0 || dot < f.length() - 8) return "";
        String e = f.substring(dot).toLowerCase(Locale.ROOT);
        return e.matches("\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif|mp4|webm|mov|m4v|3gp)") ? e : "";
    }

    private static String extensionForMime(String mime, MediaItem.Kind kind) {
        if (mime == null) return kind == MediaItem.Kind.IMAGE ? ".jpg" : ".mp4";
        switch (mime.toLowerCase(Locale.ROOT)) {
            case "image/jpeg": return ".jpg";
            case "image/png": return ".png";
            case "image/gif": return ".gif";
            case "image/webp": return ".webp";
            case "image/avif": return ".avif";
            case "image/heic": return ".heic";
            case "image/heif": return ".heif";
            case "video/webm": return ".webm";
            case "video/quicktime": return ".mov";
            case "video/3gpp": return ".3gp";
            default: return kind == MediaItem.Kind.IMAGE ? ".jpg" : ".mp4";
        }
    }

    private static String fallbackMime(MediaItem.Kind kind, String ext) {
        if (kind == MediaItem.Kind.IMAGE) {
            if (".png".equals(ext)) return "image/png";
            if (".gif".equals(ext)) return "image/gif";
            if (".webp".equals(ext)) return "image/webp";
            if (".avif".equals(ext)) return "image/avif";
            if (".heic".equals(ext)) return "image/heic";
            if (".heif".equals(ext)) return "image/heif";
            return "image/jpeg";
        }
        if (".webm".equals(ext)) return "video/webm";
        if (".mov".equals(ext)) return "video/quicktime";
        if (".3gp".equals(ext)) return "video/3gpp";
        return "video/mp4";
    }

    private static String sanitizeCategory(String value) {
        if (value == null) return "";
        String v = value.trim();
        if ("Instagram".equalsIgnoreCase(v)) return "Instagram";
        if ("X".equalsIgnoreCase(v)) return "X";
        return "";
    }

    private static String sanitize(String s) {
        if (s == null) return "";
        s = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (s.length() > 60) s = s.substring(0, 60).trim();
        return s;
    }

    private static String sanitizeFilename(String s) {
        String x = sanitize(s);
        return x.isEmpty() ? "media" : x;
    }
}
