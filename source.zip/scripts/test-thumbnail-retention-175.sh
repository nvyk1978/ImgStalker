#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/content" "$TMP/src/android/graphics" "$TMP/src/android/media" "$TMP/src/android/os" "$TMP/src/android/util" "$TMP/src/android/view" "$TMP/src/android/webkit" "$TMP/src/android/widget" "$TMP/src/com/cmyk/imgstalker"
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content; import java.io.*; public class Context {
 public Context getApplicationContext(){return this;}
 public File getCacheDir(){return new File("/tmp");}
}
JAVA
cat > "$TMP/src/android/graphics/Bitmap.java" <<'JAVA'
package android.graphics; import java.io.*; public class Bitmap {
 public static enum Config { RGB_565 }
 public static enum CompressFormat { JPEG }
 public boolean compress(CompressFormat f,int q,OutputStream o){return true;}
 public int getByteCount(){return 10;} public int getWidth(){return 10;} public int getHeight(){return 10;}
 public boolean isRecycled(){return false;} public void recycle(){}
 public static Bitmap createScaledBitmap(Bitmap b,int w,int h,boolean f){return b;}
}
JAVA
cat > "$TMP/src/android/graphics/BitmapFactory.java" <<'JAVA'
package android.graphics; public class BitmapFactory {
 public static class Options {public int outWidth=10,outHeight=10,inSampleSize=1; public boolean inJustDecodeBounds; public Bitmap.Config inPreferredConfig;}
 public static Bitmap decodeByteArray(byte[] a,int off,int len,Options o){return new Bitmap();}
 public static Bitmap decodeFile(String path){return new Bitmap();}
}
JAVA
cat > "$TMP/src/android/media/MediaMetadataRetriever.java" <<'JAVA'
package android.media; import android.graphics.Bitmap; public class MediaMetadataRetriever {
 public static final int METADATA_KEY_DURATION=9,METADATA_KEY_VIDEO_WIDTH=18,METADATA_KEY_VIDEO_HEIGHT=19,METADATA_KEY_VIDEO_ROTATION=24,OPTION_CLOSEST_SYNC=2;
 public void setDataSource(String s){} public String extractMetadata(int i){return "0";}
 public Bitmap getFrameAtTime(long t,int o){return new Bitmap();} public void release(){}
}
JAVA
cat > "$TMP/src/android/os/Looper.java" <<'JAVA'
package android.os; public class Looper {public static Looper getMainLooper(){return new Looper();}}
JAVA
cat > "$TMP/src/android/os/Handler.java" <<'JAVA'
package android.os; public class Handler {public Handler(Looper l){} public boolean post(Runnable r){r.run();return true;}}
JAVA
cat > "$TMP/src/android/util/LruCache.java" <<'JAVA'
package android.util; import java.util.*; public class LruCache<K,V>{Map<K,V> map=new HashMap<>(); public LruCache(int m){} protected int sizeOf(K k,V v){return 1;} public V get(K k){return map.get(k);} public V put(K k,V v){return map.put(k,v);} public V remove(K k){return map.remove(k);} public Map<K,V> snapshot(){return new HashMap<>(map);} public void evictAll(){map.clear();}}
JAVA
cat > "$TMP/src/android/view/View.java" <<'JAVA'
package android.view; public class View {public static int VISIBLE=0; private Object tag; public void setVisibility(int v){} public Object getTag(){return tag;} public void setTag(Object tag){this.tag=tag;} private float alpha=1f; public void setAlpha(float a){alpha=a;} public float getAlpha(){return alpha;}}
JAVA
cat > "$TMP/src/android/widget/ImageView.java" <<'JAVA'
package android.widget; import android.view.View; import android.graphics.Bitmap; public class ImageView extends View {private Object drawable; public void setImageBitmap(Bitmap b){drawable=b;} public void setImageDrawable(Object x){drawable=x;} public Object getDrawable(){return drawable;}}
JAVA
cat > "$TMP/src/android/webkit/WebSettings.java" <<'JAVA'
package android.webkit; import android.content.Context; public class WebSettings {public static String getDefaultUserAgent(Context c){return "Mozilla";}}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/Stubs.java" <<'JAVA'
package com.cmyk.imgstalker;
class MediaItem {
 enum Kind {IMAGE,VIDEO,STREAM} Kind kind=Kind.IMAGE;
 String url="https://example.org/x",referrer=""; MediaItem() {} MediaItem(String url){this.url=url;} int width,height; long durationMs;
}
class DiagnosticLog {static void log(String s){} static void logException(String s,Throwable t){} }
class InstagramSessionCookies {static String getCookie(String s){return "";}}
class ThreadsSessionCookies {static String getCookie(String s){return "";}}
class InstagramVideoUrl {static String resolvedOrOriginal(String s){return s;} static String stripTag(String s){return s;} static void markRecovered(String u,String s){}}
class ThreadsVideoUrl {static String resolvedOrOriginal(String s){return s;} static String stripTag(String s){return s;} static void markRecovered(String u,String s){}}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/ThumbnailRetentionTest.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.content.Context;
import android.graphics.Bitmap;
import android.widget.ImageView;

public class ThumbnailRetentionTest {
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static void waitForFailure(BooleanSupplier done) throws InterruptedException {
  for(int t=0;t<400 && !done.isDone();t++) Thread.sleep(5);
  check(done.isDone(),"network-failure request did not finish");
  Thread.sleep(50);
 }
 interface BooleanSupplier {boolean isDone();}
 static void exerciseInstagram() throws InterruptedException {
  InstagramThumbnailLoader l=new InstagramThumbnailLoader(new Context(),null);
  try {
   MediaItem item=new MediaItem("file:///imgstalker-175-instagram-absent.jpg");
   ImageView view=new ImageView(); Bitmap visible=new Bitmap();
   view.setTag("IMAGE|"+item.url); view.setImageBitmap(visible);
   l.load(view,item);
   check(view.getDrawable()==visible,"Instagram: same-item bitmap vanished on cache miss");
   check(view.getAlpha()==1f,"Instagram: same-item bitmap dimmed on cache miss");
   waitForFailure(()->l.pendingCount()==0);
   check(view.getDrawable()==visible,"Instagram: bitmap vanished on network failure");
   // Rebind a recycled cell for a different item: do not display the old media.
   MediaItem replacement=new MediaItem("file:///imgstalker-175-instagram-other.jpg");
   l.load(view,replacement);
   check(view.getDrawable()==null,"Instagram: different-item old bitmap leaked");
   waitForFailure(()->l.pendingCount()==0);
   check(view.getDrawable()==null,"Instagram: failed new item should remain empty");
  } finally { l.shutdown(); }
 }
 static void exerciseThreads() throws InterruptedException {
  ThreadsThumbnailLoader l=new ThreadsThumbnailLoader(new Context(),null);
  try {
   MediaItem item=new MediaItem("file:///imgstalker-175-threads-absent.jpg");
   ImageView view=new ImageView(); Bitmap visible=new Bitmap();
   view.setTag("IMAGE|"+item.url);view.setImageBitmap(visible);
   l.load(view,item);
   check(view.getDrawable()==visible,"Threads: same-item bitmap vanished on cache miss");
   check(view.getAlpha()==1f,"Threads: same-item bitmap dimmed on cache miss");
   waitForFailure(()->l.pendingCount()==0);
   check(view.getDrawable()==visible,"Threads: bitmap vanished on network failure");
   MediaItem replacement=new MediaItem("file:///imgstalker-175-threads-other.jpg");
   l.load(view,replacement);
   check(view.getDrawable()==null,"Threads: different-item old bitmap leaked");
   waitForFailure(()->l.pendingCount()==0);
   check(view.getDrawable()==null,"Threads: failed new item should remain empty");
  } finally {l.shutdown();}
 }
 public static void main(String[] args) throws Exception {
  exerciseInstagram(); exerciseThreads();
  System.out.println("PASS: Instagram/Threads retain same-key bitmaps on retries/failure and clear recycled different-key cells");
 }
}
JAVA
SRC=app/src/main/java/com/cmyk/imgstalker
javac -encoding UTF-8 -d "$TMP/classes" \
 $(find "$TMP/src" -name '*.java') \
 "$SRC/SnsThumbnailDiskCache.java" "$SRC/InstagramThumbnailLoader.java" "$SRC/ThreadsThumbnailLoader.java"
java -cp "$TMP/classes" com.cmyk.imgstalker.ThumbnailRetentionTest
