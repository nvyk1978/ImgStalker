package com.cmyk.imgstalker;
public final class NavigationModeFilterTest {
    private static void check(boolean ok, String msg) { if (!ok) throw new AssertionError(msg); }
    public static void main(String[] args) {
        AnalysisModeRouter.Mode n=AnalysisModeRouter.Mode.NORMAL;
        AnalysisModeRouter.Mode x=AnalysisModeRouter.Mode.X;
        AnalysisModeRouter.Mode ig=AnalysisModeRouter.Mode.INSTAGRAM;
        AnalysisModeRouter.Mode active=null;
        check(NavigationModeFilter.matchesUrl(active, "https://example.org/"), "all normal");
        check(NavigationModeFilter.matchesUrl(active, "https://x.com/person"), "all x");
        check(NavigationModeFilter.matchesUrl(active, "https://instagram.com/person"), "all ig");
        active=NavigationModeFilter.next(active,n);
        check(active==n && NavigationModeFilter.matchesUrl(active, "https://example.org"), "normal selection");
        check(!NavigationModeFilter.matchesUrl(active, "https://x.com/person"), "exclude x");
        active=NavigationModeFilter.next(active,x);
        check(active==x && NavigationModeFilter.matchesUrl(active, "https://twitter.com/person"), "switch to x twitter");
        check(!NavigationModeFilter.matchesUrl(active, "https://x.com.attacker.org/"), "avoid host spoof");
        active=NavigationModeFilter.next(active,x);
        check(active==null, "toggle selected resets to all");
        active=NavigationModeFilter.next(active,ig);
        check(active==ig && NavigationModeFilter.matchesUrl(active, "https://www.instagram.com/person/"), "ig");
        check(!NavigationModeFilter.matchesUrl(active, "https://www.instagram.com.evil.com"), "ig lookalike excluded");
        active=NavigationModeFilter.next(active,ig);
        check(active==null, "ig off");
        System.out.println("PASS: navigation mode filter / toggle / spoof-resistant routing");
    }
}
