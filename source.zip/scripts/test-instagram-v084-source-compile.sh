#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
mkdir -p "$T/android/util" "$T/org/json" "$T/com/cmyk/imgstalker" "$T/classes"
cat > "$T/android/util/Base64.java" <<'JAVA'
package android.util;
public class Base64 { public static final int URL_SAFE=8, NO_WRAP=2; public static byte[] decode(String s,int flags){return java.util.Base64.getUrlDecoder().decode(s);} }
JAVA
cat > "$T/org/json/JSONObject.java" <<'JAVA'
package org.json;
public class JSONObject {
 public JSONObject(){} public JSONObject(String s){}
 public JSONObject put(String k,Object o){return this;}
 public JSONObject optJSONObject(String k){return null;} public JSONArray optJSONArray(String k){return null;}
 public String optString(String k){return "";} public String optString(String k,String d){return d;}
 public int optInt(String k){return 0;} public int optInt(String k,int d){return d;}
 public long optLong(String k){return 0L;} public long optLong(String k,long d){return d;}
 public boolean optBoolean(String k){return false;} public boolean optBoolean(String k,boolean d){return d;}
 public Object opt(String k){return null;} public boolean has(String k){return false;}
 public JSONArray names(){return null;} @Override public String toString(){return "{}";}
}
JAVA
cat > "$T/org/json/JSONArray.java" <<'JAVA'
package org.json;
public class JSONArray {
 public JSONArray(){} public JSONArray(String s){}
 public int length(){return 0;} public Object opt(int i){return null;}
 public JSONObject optJSONObject(int i){return null;} public JSONArray optJSONArray(int i){return null;}
 public String optString(int i){return "";} public String optString(int i,String d){return d;}
 public int optInt(int i){return 0;} public int optInt(int i,int d){return d;}
 public JSONArray put(Object o){return this;}
}
JAVA
cat > "$T/com/cmyk/imgstalker/DiagnosticLog.java" <<'JAVA'
package com.cmyk.imgstalker;
public class DiagnosticLog {public static void log(String s){} public static void logException(String s, Throwable t) {}}
JAVA
javac -encoding UTF-8 -d "$T/classes" \
  "$T/android/util/Base64.java" "$T/org/json/JSONObject.java" "$T/org/json/JSONArray.java" \
  "$T/com/cmyk/imgstalker/DiagnosticLog.java" \
  app/src/main/java/com/cmyk/imgstalker/MediaItem.java \
  app/src/main/java/com/cmyk/imgstalker/InstagramInstagramSourcePipeline.java
printf 'PASS: v0.1.84 Instagram GraphQL source pipeline javac smoke\n'
