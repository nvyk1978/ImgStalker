#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
DIR="$(mktemp -d)"
trap 'rm -rf "$DIR"' EXIT
javac -d "$DIR" app/src/main/java/com/cmyk/imgstalker/NormalVideoUrl.java app/src/main/java/com/cmyk/imgstalker/InstagramVideoUrl.java tests/ModeUrlIsolationTest.java
java -cp "$DIR" com.cmyk.imgstalker.ModeUrlIsolationTest
