package com.cmyk.imgstalker;

import android.content.Context;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/** Navigation statistics. Discovery history is a separate durable append-only JSON; no crawler or checkpoint is changed here. */
final class NavigationMediaCounts {
    static final class Result {
        final String images;
        final String videos;
        Result(String images, String videos) { this.images = images; this.videos = videos; }
    }
    private NavigationMediaCounts() { }

    /** Resolve the same cached statistics identity as the existing per-mode JSON stores. */
    static String identity(String url) {
        return DiscoveredMediaLedger.identity(url);
    }

    /** JSON counts are shown as soon as available; filesystem inventory can be slower
     * or inaccessible on Android 16 and must not delay showing cumulative history. */
    static Result forUrl(Context context, String url) {
        Result history = forUrlHistory(context, url);
        return withFiles(context, url, history);
    }

    static Result withFiles(Context context, String url, Result history) {
        if (context == null || SiteVisitStore.normalize(url).isEmpty()) return history;
        return useFiles(history, NavigationSavedFileInventory.forUrl(context, url));
    }

    static boolean hasUnknown(Result result) {
        return result == null || result.images.contains("—") || result.videos.contains("—");
    }

    static Result forUrlHistory(Context context, String url) {
        if (context == null || SiteVisitStore.normalize(url).isEmpty()) return new Result("画像 —/—", "動画 —/—");
        try {
            SnsResumeStore.Target target = SnsResumeStore.targetForUrl(url);
            if (target != null) {
                SnsResumeStore.State external = SnsResumeStore.load(context, target);
                AnalysisSessionStore.State internal = AnalysisSessionStore.load(context, url);
                // Migrate BOTH legacy sources before counting. The global SNS internal
                // checkpoint must never leak another account's links into this ledger.
                ArrayList<MediaItem> discovered = new ArrayList<>();
                if (external != null) discovered.addAll(external.mediaItems);
                boolean sameInternalAccount = internal != null
                        && sameAccount(target, SnsResumeStore.targetForUrl(internal.sourceUrl));
                if (sameInternalAccount) discovered.addAll(internal.mediaItems);
                DiscoveredMediaLedger.Snapshot cumulative = DiscoveredMediaLedger.merge(context, url, discovered);
                LinkedHashSet<String> saved = SnsSavedLedgerStore.load(context, target);
                if (external != null) saved.addAll(external.savedMediaKeys);
                List<MediaItem> totals;
                if (cumulative.readable && (cumulative.existed || !discovered.isEmpty()))
                    totals = cumulative.mediaItems();
                else totals = external != null || sameInternalAccount ? discovered : null;
                return calculate(totals, saved);
            }
            if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.NORMAL)
                return new Result("画像 —/—", "動画 —/—");
            AnalysisSessionStore.State state = AnalysisSessionStore.load(context, url);
            DiscoveredMediaLedger.Snapshot cumulative = DiscoveredMediaLedger.merge(context, url,
                    state == null ? null : state.mediaItems);
            Map<String, String> savedLocations = NormalSavedLedgerStore.load(context, url);
            List<MediaItem> totals = cumulative.readable && (cumulative.existed || state != null)
                    ? cumulative.mediaItems() : state == null ? null : state.mediaItems;
            return calculate(totals, savedLocations.keySet());
        } catch (Throwable t) {
            DiagnosticLog.logException("NAVIGATION_MEDIA_COUNTS_FAIL", t);
            return new Result("画像 —/—", "動画 —/—");
        }
    }

    /** The inventory is authoritative for the numerator; checkpoint JSON supplies the denominator. */
    static Result useFiles(Result fallback, NavigationSavedFileInventory.Counts files) {
        if (files == null) return fallback;
        return new Result(withFileCount(fallback.images, "画像", files.images),
                withFileCount(fallback.videos, "動画", files.videos));
    }

    private static String withFileCount(String old, String kind, Integer files) {
        if (files == null) return old; // Permission/volume not accessible: preserve JSON result.
        int slash = old.indexOf('/');
        return kind + " " + files + "/" + (slash >= 0 ? old.substring(slash + 1) : "—");
    }

    private static boolean sameAccount(SnsResumeStore.Target a, SnsResumeStore.Target b) {
        return a != null && b != null && a.service == b.service
                && a.accountName.equalsIgnoreCase(b.accountName);
    }

    /** Pure counting logic: media keys are deduped, stream links do not count as image/video. */
    static Result calculate(List<MediaItem> discovered, Collection<String> savedKeys) {
        LinkedHashMap<String, MediaItem.Kind> media = new LinkedHashMap<>();
        if (discovered != null) for (MediaItem item : discovered) {
            if (item == null || item.kind == MediaItem.Kind.STREAM) continue;
            String key = SnsResumeStore.savedMediaKey(item);
            if (!key.isEmpty() && !media.containsKey(key)) media.put(key, item.kind);
        }
        int imageTotal = 0, videoTotal = 0, imageSaved = 0, videoSaved = 0;
        HashSet<String> accountedSaved = new HashSet<>();
        for (Map.Entry<String, MediaItem.Kind> item : media.entrySet()) {
            if (item.getValue() == MediaItem.Kind.IMAGE) imageTotal++;
            else videoTotal++;
            if (savedKeys != null && savedKeys.contains(item.getKey())) {
                if (item.getValue() == MediaItem.Kind.IMAGE) imageSaved++;
                else videoSaved++;
                accountedSaved.add(item.getKey());
            }
        }
        // Old saved keys might outlive the crawl JSON. A typed URL fallback is safe;
        // an opaque Instagram/X dedup key without a matching media entry is NOT classifiable.
        boolean unknownSavedKind = false;
        if (savedKeys != null) for (String key : savedKeys) {
            if (key == null || key.isEmpty() || accountedSaved.contains(key)) continue;
            if (media.containsKey(key)) continue;
            if (key.startsWith("IMAGE|")) imageSaved++;
            else if (key.startsWith("VIDEO|")) videoSaved++;
            else unknownSavedKind = true;
        }
        boolean haveDiscovery = discovered != null && (!discovered.isEmpty() || savedKeys == null || savedKeys.isEmpty());
        String imageDenominator = haveDiscovery ? Integer.toString(imageTotal) : "—";
        String videoDenominator = haveDiscovery ? Integer.toString(videoTotal) : "—";
        String imageNumerator = unknownSavedKind ? "—" : Integer.toString(imageSaved);
        String videoNumerator = unknownSavedKind ? "—" : Integer.toString(videoSaved);
        return new Result("画像 " + imageNumerator + "/" + imageDenominator,
                "動画 " + videoNumerator + "/" + videoDenominator);
    }
}
