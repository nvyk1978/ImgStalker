# ImgStalker v0.1.162 (versionCode 163) — repair saved checks after SNS CDN URL changes

- **Sole source:** the user-provided `ImgStalker_0.1.161_source.zip`, SHA-256 `66be711fab8ee90aacf2ff2ca49a6df26a6499352ddb8a4c98172ef3b6a1efab`. Application ID, fixed keystore, existing saved/resume JSON schemas, and all 29 protected crawler/downloader/provider files are byte-for-byte unchanged.
- **Diagnosis:** SNS saved-state UI only checked the exact current `dedupKey`, or a legacy full CDN URL when no key existed. Different historical key formats could cause a published file to appear unsaved; navigation file counts already found files even when corresponding saved-ledger entries were missing.
- **Repair:** add SNS-only compatibility aliases for Instagram CDN cache media ID (survives signed URL/encode changes), filename fallback and legacy full URL; X CDN rendition URLs match by immutable `/media/` path. Images/videos remain distinct; NORMAL's URI-verified saved flow is untouched.
- **Existing files:** while preparing an SNS analysis, read only that account's physical `X|Instagram/<account>/` saved filenames (including SAF/MediaStore and Movies video fallback). Restore saved marks only on exact, sufficiently distinctive CDN basename matches, including historical discovered entries. Import successes into the independent monotonic saved ledger without redownloading, and batch writes. File counts alone never mark an individual image as saved. Refresh on activity resume.
- **Boundaries:** Never clear or rebuild old saved ledgers destructively; never mix one account/service with another; do not change the crawler, rate-limit/browsing logic, save file naming, background crawling, signed keys, or protected mode files. If a filename and old key have both changed with no retained stable identifier, a lost mark cannot be reliably inferred and must remain unchecked.
- **Validation:** `scripts/test-sns-saved-media-identity.sh` (signed URL, Instagram encode, legacy URL, X rendition, image/video isolation and false positives), existing offline tests, SHA-256 manifests; **Android APK compile and real-device saved-mark restoration require GitBuild/device testing.**

# ImgStalker v0.1.160 (versionCode 161) — media grid publication-date labels

- **Sole base:** v0.1.159 (versionCode 160). Application ID `com.cmyk.imgstalker`, fixed signing keystore and all 29 protected NORMAL/X/Instagram engine, downloader and JSON/resume files remain byte-for-byte unchanged.
- Every media grid cell keeps the existing filename line unchanged. Move its `width × height` resolution from the former metadata line into a translucent bottom-right overlay **inside the thumbnail**; move video duration above the overlay when both labels are present so narrow cells do not overlap.
- The previous resolution line, directly under the unchanged filename, now shows the publication date/time formatted as `yyyy/MM/dd HH:mm` in Asia/Tokyo when independently verifiable. It remains blank when unknown; download, filesystem and cache timestamps are never substituted. Grid cell geometry and selection/preview tap and long press behaviors stay intact.
- X: derive post publication time from the linked tweet/status ID's Twitter Snowflake time bits, validating the date. Instagram: observe `taken_at`/`taken_at_timestamp` fields from the **same first-party GraphQL responses already captured by the browser** and store by post shortcode in a display-only private preference. This does not issue any new network requests, touch browser authentication or modify the response passed to the crawler. Previously fetched Instagram posts with no stored timestamp require observation in a later analysis; publication time cannot be invented from old checkpoints. NORMAL pages without a reliable timestamp remain blank.
- Changed `MainActivity.java` (grid presentation only), `InstagramBrowserFeed.java` (optional read-only timestamp observer), added `PostPublicationDates.java`, updated the isolated compile test, added dedicated publication-date tests, and bumped `app/build.gradle`.
- Offline tests pass; **Android release APK compile / device verification remain unperformed** in this environment.

# ImgStalker v0.1.158 (versionCode 159) — circular icons + navigation mode filters

- **Only source:** v0.1.157 (versionCode 158), kept `com.cmyk.imgstalker`, stable keystore and all 29 mode-protected NORMAL/X/Instagram files intact.
- Bookmark and History dialogs: add three round, right-aligned mode selectors (NORMAL, X, Instagram), with the **same X/Instagram vector drawing as the main screen header**. The new NORMAL globe is an Android VectorDrawable based on the supplied reference. Tap once to filter, tap the same again for all, or tap another to switch directly. Selected selectors invert N White / N Dark Gray, while dialog geometry remains fixed.
- Filter identity derives exclusively from `AnalysisModeRouter.fromUrl`, not page text, favorites, active crawler, or `@` handles. This is view-only: no changes to data/JSON/crawlers. Empty filtered lists show a hint and can be switched back without reopening.
- Favicon and account images use an **aspect-preserving central crop followed by a circular transparent mask**, for both bookmark/history rows and the URL field. Network image bytes are decoded downsampled. The circular artwork cache uses a new versioned folder, avoiding reuse of distorted old 96×96 square PNGs; social provider artwork remains the fallback.
- Filtered bookmark drag preserves the positions of other modes in the saved full order; drag remains long-press with one vibration and PriceRec.-style insertion. Deletion of a history/bookmark entry keeps active filters and pending icon/JSON queues consistent. Existing stable dialogs and all saved media and green checks are untouched.
- Offline regression: `scripts/test-navigation-mode-filter.sh`, `scripts/test-navigation-bookmark-filter-order.sh`, every existing `scripts/test-*.sh`, `verify-provider-boundaries.py`, protected SHA manifests, and syntax parsing of changed Java classes. **Android APK compilation and real-device icon/drag testing require GitBuild/Android 16.**

# ImgStalker v0.1.157 (versionCode 158) — saved counts from files actually on disk

- **Only base:** ImgStalker_0.1.156_source.zip (versionCode 157). Stable application ID, keystore, all 29 mode-protected files and existing settings/JSON schema retained.
- Navigation counts now prefer a *read-only live file inventory* for the numerator: JPEG/PNG/etc. under `<save-root>/Normal/<host>/` or `<save-root>/X|Instagram/<account>/`; MP4/etc. under their `videos/` subfolders. Query app-owned MediaStore images/videos by target `RELATIVE_PATH`, and use the existing persisted SAF tree for documents not indexed by MediaStore.
- Account for Android's **separate primary `Movies/ImgStalker/<mode>/<target>/videos/` fallback** used when videos could not be saved under Pictures without SAF. The same file seen via SAF and MediaStore is counted only once (location+filename identity); incomplete, zero-byte, JSON, and unrelated files are omitted. Actual deletion/renaming is reflected on next list opening.
- The denominator remains deduplicated media links in the per-URL NORMAL or per-account SNS analysis JSON. A missing or incomplete analysis JSON still shows `—`; no fresh crawl, API request or media download is initiated for navigation statistics.
- **Scope:** numerator represents *files in that site/account folder*, not a per-page count where multiple NORMAL URLs share a host. Older saves in obsolete timestamp folders or an unrelated/previously chosen storage root cannot always be recovered. Converted X GIFs count by their stored file format (image). If filesystem access is unavailable, retain the previous saved-JSON estimate instead of treating a failed query as zero.
- Changed only `NavigationMediaCounts`, new read-only `NavigationSavedFileInventory`, version/README and navigation statistics tests. Crawlers, session/saved JSON, provider mode detection, dialogs, bookmarks and downloader/save logic are byte-for-byte unchanged.
- Offline tests: `scripts/test-navigation-file-inventory.sh` (MediaStore+SAF+Movies fallback, de-duplication, deletion), `scripts/test-navigation-counts.sh` and all existing regression/isolation tests. Android APK build and real-device document-provider queries require GitBuild/device validation.

# ImgStalker v0.1.156 (versionCode 157) — navigation sorting, icons and media counts

- **Only base:** ImgStalker_0.1.155_source.zip (versionCode 156). applicationId and original stable keystore unchanged; all protected NORMAL/X/INSTAGRAM provider and downloader files untouched.
- Bookmark list: long-press a row to enter drag mode (one haptic pulse), follow pointer, animate surrounding rows into the insertion slot, and persist URL order separately from the original history/bookmark JSON. No visible reorder grip. Star taps remain independent.
- History and bookmark entries and the URL field display a favicon beside the star. For X/Instagram account URLs, a public OG/Twitter profile image is preferred; unavailable/restricted profile images fall back to the social network's vector icon. UI-only background HTTP work uses no saved login cookies or crawler WebViews, disk/memory caching, and visible-row lazy loading.
- Right edge of the history/bookmark rows: `画像 saved/discovered` and `動画 saved/discovered` centered vertically with fixed row geometry. Statistics read existing per-target NORMAL or per-account SNS resume/checkpoint and saved-success ledgers asynchronously without starting a new crawl. Media links are deduplicated by the same stable keys used for green checks. Unrecoverable historical media kinds/totals show `—`, rather than a fabricated count. Images/streams are never confused with videos.
- The original v0.1.155 navigation confirmation dialogs, favorite protections, history long-press delete, NORMAL saved-file verification and Instagram browser-first recovery remain in place. No modifications to crawler or download pipelines.
- Offline scripts: `scripts/test-bookmark-order.sh`, `scripts/test-navigation-counts.sh`, `scripts/test-navigation-ui-156.sh` plus all previous tests. Android APK compilation and actual UI/Instagram profile-photo rendering require GitBuild / real-device validation.

# ImgStalker v0.1.155 (versionCode 156) — history deletion & stable dialogs

- Base: **only** `ImgStalker_0.1.154_source.zip` (SHA-256 `b6ba7df60eb78ea7637d1c3a624357f35e448900aa105265770ca0bf7572af4a`). The successful Instagram v0.1.153 browser feed path remains byte-for-byte protected; NORMAL/X and all other crawler, resolver, downloader and resume implementation files unchanged.
- **Long press a history list item** to open an N-themed confirmation (`履歴を削除`). `キャンセル` leaves it unchanged; `削除` removes that one URL from history. Bookmarking is unaffected: if starred, that entry stays in Bookmarks with its original title and sort order; media, checkpoints, cached downloads and green checks are untouched. History list-star taps continue to switch bookmark state immediately without confirmation.
- **Stable dialogs:** History list, Bookmarks list, Bookmark removal and History removal all share a pre-sized, center-positioned panel inside a fixed full-window transparent dialog overlay. No post-show window resizing; animations disabled; keyboard dismissed and `SOFT_INPUT_ADJUST_NOTHING`. The list shell stays fixed even when an item is deleted, while the list itself scrolls. N dark-gray and N white palette retained, left/right 15dp window margins.
- **History VectorDrawable:** round counterclockwise arc / arrowhead geometry adjusted so the arrow and ring contours do not visually merge; outer arc stroke and central clock hands now both `4.5` viewport units, N White `#A9A999`. Floating button size and N Dark Gray background preserved.
- Stable package `com.cmyk.imgstalker`, fixed signing keystore, existing data format (`imgstalker_site_navigation_v1`) and versionCode monotonicity preserved.
- Offline tests: `scripts/test-site-navigation.sh` covers history deletion semantics, bookmark preservation, pre-display dialog geometry, icon stroke parity; existing provider/isolation and Instagram browser tests unchanged. Full APK build and on-device visual behavior still require GitBuild/device verification.

# ImgStalker v0.1.154 (versionCode 155) — history/bookmarks UI only

- Base: v0.1.153 (154), the Instagram-browser acquisition version reported successful on-device. This build deliberately leaves all NORMAL/X/Instagram engines, resolvers, cookie/profile managers, resume JSON, downloader implementations, `AnalysisKeepAliveService`, and signing keystore unchanged.
- User-visible 「お気に入り」 labels are now 「ブックマーク」; existing persisted `SiteVisitStore` favorites are kept intact (the internal preference key/schema and storage are unchanged).
- History button: `res/drawable/ic_history_stalker.xml` Android VectorDrawable, counter-clockwise circular arrow with a clock, monochrome N White (#A9A999); N Dark Gray floating button background is preserved.
- Both navigation list dialogs now use a fixed-size preconfigured `Dialog` window before display, with scrolling only inside the content. Removes the previous `AlertDialog.setOnShowListener` width/height adjustment that caused a visible resize/jump.
- Tapping a filled star in the bookmarks list or URL input requires confirmation to remove. Tapping a filled star in *history* immediately toggles it off and retains the history record. New bookmarks are added directly. No history data is deleted by a bookmark removal.
- X and Instagram account pages display a verified profile display name when the source page title includes `Name (@handle)`; otherwise `@handle` is derived from the *target URL* (not the logged-in account). Generic/nonprofile pages use their prior site/page title behavior. Persistent history/URL identity is separate from the visible title and is not renamed.
- The previously fixed URL-input crash workaround is retained unmodified. All pre-existing other-mode isolation and Instagram/browser-recovery tests, plus the new navigation test, pass offline.
- APK full Gradle build and actual dialog animation / Instagram device verification have **not** been run; Android SDK/Gradle are not available in this container.

# ImgStalker v0.1.152 (versionCode 153) — site history, favorites & safe URL typing

- UI-only navigation storage `SiteVisitStore.java`: visited HTTP(S) URLs and favorites are saved independently of NORMAL, X and Instagram crawler/resume/saved-media state. History entries show the detected page title (or domain fallback), subtitle URL, and an inline favorite star; favorites can be added or removed without modifying session data.
- Two dark-gray round floating controls above the selection/cancel/bulk-save bar open History (left) and Favorites (right) dialogs. Tapping an entry accesses it through the regular analyzer when no analysis/download is active. Favorite status appears as a gray/yellow star at the left edge of the URL field.
- URL editing no longer starts an immediate checkpoint/cache scan on every keystroke. Cache inspection is debounced 350 ms, incomplete URLs are not passed to checkpoint parsers, and exceptions are caught inside the worker runnable, avoiding an unhandled background thread failure.
- Cache delete text is split into two centered lines: `キャッシュ` / `削除`.
- Base: v0.1.151 (152). Only `MainActivity.java`, `app/build.gradle`, this README and the new UI-only store change. All protected engine/provider files and stable signing key remain byte-for-byte unchanged.
- Existing mode routing, NORMAL ledger/checkpoint/folder, Instagram and provider-firewall tests passed offline. Actual Android APK build and device crash reproduction still require GitBuild/device testing.

# ImgStalker v0.1.151 (versionCode 152) — NORMAL saved-file verification

- NORMAL green checks are now based on successful saved-file content URIs verified on scan/resume; deleting the actual saved media removes the check and permits re-download.
- The new NORMAL-only v2 saved-ledger JSON records both media identity and URI, with a dedicated `.saved.json` sidecar in `<selected>/Normal/<host>/` when the SAF tree grant is available. Deleting this sidecar explicitly clears its marks on the next resume/reload; clearing the disposable analysis checkpoint retains it.
- Old v1 records lack file URI and cannot reliably prove media existence, so they are treated as unverified rather than falsely blocking downloads. They are not deleted; subsequent successful saves use v2.
- The `NORMAL` downloader alone sends `onNormalSavedAtUri`, while X and Instagram keep the existing `onSaved` callback and code unchanged. Normal scan URL site-folder mapping, keystore, applicationId and SNS JSON remain unchanged.
- Static tests: `scripts/test-normal-saved-ledger.sh`, `scripts/test-normal-site-folder.sh`, `scripts/verify-provider-boundaries.py`. Android / GitHub build and device test require GitBuild.

# ImgStalker v0.1.150 (versionCode 151) — NORMAL fixed per-site media folders

- Based exclusively on `ImgStalker_0.1.149_source.zip`.
- NORMAL saves new images to `<selected save directory>/Normal/<source website hostname>/` and videos to its `videos/` subfolder when the selected SAF tree supports it. Android MediaStore may require video output under `Movies/ImgStalker/Normal/<hostname>/videos/` if the selected base is Pictures without SAF permission.
- Repeated scans of the same hostname, all query/page variants and different boards within that hostname reuse the same folder. `www.` is normalized away; other subdomains remain separate.
- The folder owner is the scanned page URL, never the media CDN's URL. Invalid NORMAL origins reject the save request; X/Instagram URLs cannot enter the NORMAL folder resolver.
- Existing timestamp-based folders are not moved or deleted; future successful NORMAL saves go to the stable folder. Prior per-target NORMAL saved-ledger JSON is unchanged.
- X and Instagram downloaders, analysis pipelines and storage remain byte-for-byte unchanged. Stable signing key preserved; provider lock manifest explicitly updated for the reviewed NORMAL downloader edit.
- Run `scripts/test-normal-site-folder.sh` to validate stable folder mapping and foreign-mode refusal.

# ImgStalker v0.1.147 (148) — NORMAL per-site checkpoint + resume

- Base ONLY v0.1.146 (147) source ZIP. Package ID and fixed signing unchanged.
- NORMAL checkpoint isolated by normalized target URL under app-private `files/Normal/<host>/<target_hash>.json`; paging `page=` links share one session, other query args/sites remain separate.
- If the configured Pictures/ImgStalker SAF folder is writable, mirror JSON under `<selected folder>/Normal/<host>/<target_hash>.json`; normal sessions never touch `X/` or `Instagram/`.
- Checkpoint includes pending/current page, visited URLs, deferred details, accepted/provisional images, settings and media; preserve cursor *before* safe stop discards execution state.
- NORMAL watchdog retries a stalled page twice; the existing continuation/reload cell is now enabled for interrupted NORMAL sessions.
- Existing X and Instagram crawler/downloader/thumbnail/source engine bytes remain unchanged. Provider firewall and signing locks remain enforced.
- Android build/live background behavior still requires real GitBuild and Android 16 validation.

# ImgStalker v0.1.142 (versionCode 143) — Instagram HTTP 429 / source-first recovery

- Only base: `ImgStalker_0.1.141_source.zip` (versionCode 142); fixed package ID and signed keystore preserved.
- An HTTP 200 Instagram profile HTML is scanned for post URLs **before** additional profile-ID requests. If posts exist but profile identity is missing, they are resolved in source-only mode; pagination remains **incomplete/resumable**, never falsely marked as fully collected.
- Profile discovery 429: respect Retry-After and the request gate; perform at most one timed retry. If the server asks for longer than 120 seconds, stop and defer without retrying early. A second 429 also stops with an explicit status; other Instagram endpoints are not hammered as an immediate fallback.
- Restore the v0.1.84 legacy unverified-account candidate as the last Instagram-only fallback. Existing X account selection and all X/Normal processing sources remain unchanged.
- Verification: Java pipeline smoke, offline 429/retry source tests, routing tests, X/Normal SHA-256 locks and fixed keystore match. GitBuild Android compilation and live Instagram/server behavior not verified offline.

# ImgStalker v0.1.141 (versionCode 142) — Instagram v0.1.84 extraction restored

- Current package base: v0.1.140 (141) source ZIP. No downgrade of installed package, applicationId or fixed signing.
- `InstagramCrawlerEngine.java`: recreated from v0.1.84 `CrawlerEngine.java` with only provider class / interface / cookie / resolver / pipeline name adaptation. Its original source-first `browser=false`, timeline GraphQL direct-media logic and 300-post limit are preserved.
- `InstagramInstagramSourcePipeline.java`: recreated from v0.1.84 `InstagramSourcePipeline.java` with only provider class rename. Source HTTP follow-redirects behavior is restored (the later special redirect-failure policy was removed only for the Instagram provider).
- `InstagramInstagramMediaResolver.java`: recreated from v0.1.84 `InstagramMediaResolver.java` with only provider class rename.
- The current mode URL router / isolated WebView / dedicated Instagram downloader and thumbnail pipeline remain in place; X and Normal engines and their protected files are unchanged.
- The current saved-file ledger, cache reset, fixed signature, SNS login/profile manager and UI remain unchanged. Historical source pipeline implements no generic queue cursor; Instagram still uses SNS per-account continuation.
- Static source parity and isolation tests are provided. This does not establish live Instagram compatibility or successful APK compilation; validate with GitBuild and real Instagram accounts.

# ImgStalker 0.1.139 — Instagram recovery build

Three exclusive crawler instances selected from the entered URL's parsed host:

- NORMAL: exact preserved 0.1.92 CrawlerEngine logic (`NormalCrawlerEngine`), separate instance/WebView.
- INSTAGRAM: source-first v0.1.84 crawler logic (`InstagramCrawlerEngine`), separate instance/WebView.
- X: exact preserved 0.1.135 `CrawlerEngine` logic behind `XCrawlerAdapter`; X engine file unchanged.

`ModeCrawler` is the boundary between display and extraction. The router rejects lookalike hosts and does not examine query strings. Switching providers destroys and recreates the crawler and WebView. Each adapter rejects a foreign host before start.

Important limitation: analysis, media downloading, thumbnail extraction, original-image loading, cookie references and checkpoints are separated, but the screen Activity, media-item data model, account-management UI, background keep-alive service and Android process remain shared. The v0.1.92 crawler has no newer generic queue cursor; its original SNS continuation is kept, while generic queue checkpoint/restore applies only to X. The legacy InstagramSourcePipeline is identical in both versions, so an HTTP redirect loop can remain a runtime/network issue.

# ImgStalker v0.1.135 (versionCode 136)

## Cache reset without losing saved marks (2026-10-08)
- Base: ONLY the 0.1.134 (135) source ZIP. applicationId and stable signing keystore unchanged.
- キャッシュ削除 is a **fresh scan** operation: stop workers, drain their queued resume writes, remove the current SNS account's **analysis/resume sidecar** and matching internal checkpoint, clear temporary caches and in-memory crawler state.
- Saved media success keys are now a **separate independent JSON ledger**. A private AtomicFile mirror and a SAF JSON alongside downloaded media preserve green checkmarks and prevent duplicate saves after the reset.
- Before deleting any legacy sidecar, merge its `saved_media_keys` with in-memory success keys and the separate ledger. Persist and verify the independent ledger first. If the old sidecar cannot be read or the saved ledger cannot be committed, **abort deleting it** rather than destroy successful-save history.
- Saving a file commits its success key to the independent ledger even if resumable analysis is switched OFF. At the start of new analyses, the saved ledger is loaded separately from the crawler resume state; media already saved are excluded from the download queue.
- A reset intentionally loses crawl position / unfinished queues / failed-media history. It does **not** delete media files or the saved-media ledger. On the next analysis the account is scanned from the start.
- This change does not retroactively recover successful-save keys already erased by older versions of cache clearing.

# ImgStalker v0.1.134 (versionCode 135)

## Priority: resumable X image/video scans (2026-10-08)
- Base: v0.1.133 (134) source.zip, not any earlier version. Unchanged applicationId `com.cmyk.imgstalker` and bundled stable signing key.
- Limit the X dated image and video search to 8 window advances PER RUN (independently for each phase). When the budget is reached, save the NEXT unvisited dated window instead of looping for up to 180 pages in one run.
- Unverified/stalled image searches now save their cursor AND continue into video search, with 'incomplete' status rather than falsely reporting success.
- Persist separate image and video pending-window cursors; while image work is deferred, persist the current in-flight video search and detail queue. Preserve previously discovered post IDs, media IDs, and unresolved media queues for deduplication.
- The UI '続きを再読込' action now hands the previous crawler's executable cursor to the new crawler, not merely previously acquired media cells.
- Before graceful Stop clears the queue/current node, capture a durable resume cursor. If a WebView detail never settles, a six-second stop deadline persists it anyway.
- Do not replace a loaded resume cursor with an empty checkpoint before crawler start. Each new run's incomplete-reason status reflects its real pending work, not stale reasons from earlier runs.
- Image probe drain is bounded to 15 seconds to avoid blocking video discovery; unresolved probes are saved for continuation.
- Does NOT claim 100% X coverage or successful video extraction in all environments; replay and downloads depend on X availability and live network conditions.

# ImgStalker v0.1.133 (134)

## v0.1.133 — X search/video recovery (2026-10-08)
- Base: v0.1.132 (versionCode 133) current source.zip; application ID and signing key unchanged.
- X search: after repeated stable same-day boundaries, move to an older dated window instead of abandoning IMAGE discovery and immediately switching to VIDEO. If discovery cannot be verified, preserve the exact image cursor as an incomplete/resumable scan.
- X normal videos: collect `video_info.variants` for regular video posts, not only animated GIFs.
- X video-detail fallback: when a WebView detail page has no usable media, query X's own public syndication tweet metadata off the UI thread; prefer the highest bitrate MP4. The endpoint is undocumented, may reject requests, and is optional.
- Retry an empty video post once, then retain its URL in the resume cursor rather than counting it as successfully downloaded. Video queue continues to the next post.
- Watchdog: do not count empty wait loops as meaningful progress; for X, preserve failed cursors/details and continue remaining work rather than indiscriminately terminating all background tasks.
- Diagnostics: include body/article counts and new fallback/retry events.

# ImgStalker v0.1.132 (133)

## Cache clearing and retained-worker recovery
- Replaces the red force-stop button with キャッシュ削除. Aligned at the bottom of the background toggle row.
- Disabled during this Activity's analysis/download and when no disposable cache exists. The exception is an Activity blocked by another retained background owner: the button remains available as a recovery action.
- Retained worker is stopped, detached and its queued writes drained, then the current URL's external SNS sidecar JSON, matching private checkpoint, thumbnail/WebView caches and app temp files are cleared without deleting downloaded media or login cookies.
- Cache operation diagnostics: CACHE_CLEAR_BEGIN / CACHE_CLEAR_RESULT; cache availability is probed in a background executor.
- APK name and signing key retained from v0.1.131; versionCode 133.

# ImgStalker v0.1.131 (132)

## v0.1.131 — X image partial completion must not block video discovery
- When image search stops at an unverified boundary, retain the image window as incomplete and continue to the separately requested X video search. Do not label the image set fully collected.
- Retry pending X image probes with a bounded drain interval; unresolved probes are checkpointed for later continuation, not treated as successful images.
- On a completed partial run, the saved crawler cursor targets the unfinished image window, with the previously discovered image/status sets retained for deduplication.
- Persist incomplete reasons and deferred image search cursors through process restart and lifecycle changes.
- Preserve fixed signing, package ID, and normal-site/Instagram logic.

# ImgStalker v0.1.128 (129)

Android 16 / SDK 36 source package for ImgStalker.

## v0.1.128 — shared background and analysis resume recovery
- Adds an internal atomic checkpoint for all analysis URLs and media types. The existing per-account X/Instagram external sidecar stays unchanged.
- Checkpoints include selected analysis options, discovered media, queued/active pages, X image/video phase, deferred detail URLs, pending image probes and visited URLs.
- After a process restart, incomplete recent checkpoints are re-opened using the ordinary crawler rather than a separate background parser. Activity recreation resumes analysis as well.
- The foreground-service heartbeat now records the actual crawler state and checkpoints it every 15 seconds; an Activity reopened during retained work shows the live worker results instead of launching a duplicate scan.
- The ordinary web/X crawler keeps a renderer-attached WebView when background processing is on, attempts bounded stall recovery, and preserves incomplete state instead of reporting a stalled phase as complete.
- The background toggle asks the OS for battery-optimization exemption when needed; the user may decline.
- Completed Instagram source-pipeline/media-resolver/SNS account/parser implementations are unchanged. Their existing account-level resume path is preserved.
- Limitations: Android may terminate the app or foreground service. Restarting requires an intact checkpoint; real device behavior, network restrictions and APK assembly still require GitHub Actions/device validation.


## v0.1.127 — X video playback + background analysis cleanup
- X video preview now starts with the actual X status URL as Referer and no synthetic Origin; it falls back to X-root browser headers only when needed, then re-resolves a fresh MP4.
- X video download uses the same request order as preview. Refreshed MP4 URLs are retried with the status Referer first and X-root Origin only as fallback.
- Stream manifests are never saved as MP4. Downloaded videos are validated with Android MediaMetadataRetriever before being published as successful files.
- `バックグラウンドでも解析` OFF no longer owns a foreground service/wake lock; when the Activity leaves the foreground, crawler WebView execution is paused and resumes on return.
- ON keeps the foreground service + partial wake lock behavior and can continue through task removal.
- Added a N-red `強制停止` button on the right of the background-analysis row. It immediately cancels preparation/crawler/download/WebView work and releases the foreground service while preserving already received media cells.


## v0.1.126 — X image-then-video search pipeline
- X profile media collection starts with `from:user filter:images` in Latest search and harvests canonical `/status/<id>` links plus direct `pbs.twimg.com/media` images.
- The old 28-pass X profile cutoff is bypassed. X search finishes only after repeated no-progress at the actual scroll boundary; a 600-pass guard is retained only as runaway protection and marks the run incomplete if hit.
- Pending maximum-resolution image probes are drained before the crawler switches to `from:user filter:native_video`.
- Video search harvests canonical status IDs first, then opens those status details to resolve `video.twimg.com` MP4/HLS resources.
- X video detail loads temporarily allow programmatic media playback so the existing warm-up path can trigger playable media requests.
- X search navigation matching keys on the search query, tolerating X redirects that rewrite auxiliary search parameters.
- Added `SNS_X_SEARCH_*` diagnostics for phase, progress, boundary/stall completion, status counts, and phase switching.


## v0.1.105 — adaptive normal-site lazy scrolling
- Replaced the fixed three-pass generic-page scroll with adaptive continuation.
- Continue while page height or image/media DOM count grows; finish after three stable checks.
- Keep an 80-pass safety ceiling to avoid endless pages.
- Maximum-resolution image probing remains unchanged.





## v0.1.104 — pagination cap removal
- Removed the fixed 30-page pagination cap from generic same-article pagination traversal.
- Same-host restriction, duplicate suppression, intelligent pagination classification, cancellation, and existing traversal safeguards remain active.
- Maximum-resolution image selection from v0.1.103 is unchanged.

## v0.1.103 — X image maximum-resolution probe
- `pbs.twimg.com/media` images no longer stop at `:large` by assumption.
- For X/Twitter image candidates, probe `orig`, `large`, the current URL, and the original page URL when distinct.
- Select the candidate with the largest decoded pixel area; use max side as the tie-breaker.
- Added `IMAGE_MAX_CANDIDATE`, `IMAGE_MAX_CANDIDATE_FAIL`, and `IMAGE_MAX_SELECTED` diagnostics.
- Site-internal article filtering is intentionally unchanged.

## v0.1.102 — paginated direct-image classification fix

- Keeps `/mirihanai` pagination at the real 7-page boundary; no synthetic `/page/8` traversal is added.
- Splits strong related/navigation context (aside/nav/header/footer, related/recommend/ranking/popular/recent/widget/sidebar/menu/breadcrumb) from generic `entry/post/article-card` ancestry.
- A thumbnail whose link resolves to the exact same direct image may pass through when the only negative signal is a generic card wrapper.
- Strong related/sidebar/navigation contexts still reject direct-image links before probing, so unrelated site-card filtering remains active.
- Adds `INTELLIGENT_DIRECT_IMAGE_ALLOW reason=card_only_same_image` diagnostics for the rescued path.
- This targets the diagnostic case where `/page/2`–`/page/7` exposed 238 valid `pbs.twimg.com/media` direct-image links that were all suppressed before `IMAGE_PROBE_QUEUE`.

## v0.1.101 — paginated main-image rescue

- Keeps v0.1.100 maximum-resolution/direct-image handling and related-card filtering.
- Stops treating the page-global `archive` class as a related-content signal, preventing `/page/N` main images from being suppressed.
- Same-article `/page/N` navigation is classified before generic related/navigation context so wrapper markup cannot downgrade it.
- Local related/recommend/sidebar/card/menu/breadcrumb filters remain active, so unrelated site-article cards stay excluded.

## v0.1.100 — large direct-image preservation / related-card filtering

- Keeps explicit `pbs.twimg.com/...jpg:large` and `:orig` hrefs as real fetch URLs instead of stripping the size suffix.
- Upgrades `:thumb` / `:small` / `:medium` image candidates to `:large`, while deduplication uses a separate size-neutral image identity.
- Direct-image detection accepts Twitter-style `:large` / `:orig` suffixes.
- Related/sidebar/recommend/ranking/recent/widget/card images are filtered by DOM ancestry even when the image has no ordinary article link.
- Related-card classification now runs before the direct-image fast path, preventing image hrefs inside related cards from leaking into results.
- Main article/content images remain eligible.

## v0.1.99 — external CDN direct-image recovery
- Thumbnail/detail links are normalized through the existing maximum-resolution image URL logic before direct-image classification.
- X/Twitter CDN image links such as `pbs.twimg.com/media/...jpg:large` are recognized as direct image assets instead of being misclassified as unrelated external navigation.
- Direct external image assets now enter the normal image probe/replacement path; unrelated external pages, advertisements, affiliate links, and related-article navigation remain filtered by the existing intelligent traversal rules.
- Adds `THUMB_LINK_IMAGE_TARGET_REWRITE` diagnostics when a linked image target is promoted to its canonical maximum-resolution URL.
- Existing in-page maximum-size UI detection, pagination/content-family traversal, SNS handling, applicationId, and stable signing key are retained.


## v0.1.97 — generic in-page maximum image size selection
- Before generic web-page media collection, ImgStalker scans image-size / resolution / quality controls and selects the maximum-looking choice when the image context is sufficiently clear.
- Supports radio groups, select menus, buttons and tabs; recognizes Japanese/English choices including 大 / 最大 / 原寸 / 高解像度 / Large / Original / Full / High and explicit pixel dimensions.
- Uses the page's normal click/input/change event path, waits 800 ms for DOM/image updates, then starts media collection.
- Adds `IMAGE_SIZE_UI_SCAN` and `IMAGE_SIZE_UI_VERIFY` diagnostics, including whether image URLs/natural dimensions actually changed.
- After a size switch, collector compares live `currentSrc` / `naturalWidth` against `srcset`, `<picture><source>`, `data-full-url`, `data-original`, and related candidates so a stale medium `srcset` cannot mask a larger selected image.
- The detector is deliberately conservative: controls must be in an image/photo size, resolution or quality context; ordinary navigation is not clicked and normal links are not followed as size controls.
- Existing intelligent content-family traversal, maximum URL normalization, SNS/X/Instagram handling, and fixed signing identity remain active.

## v0.1.96 — content-family traversal + maximum-resolution images
- Intelligent traversal now uses one canonical image identity for X/Twitter size variants, so unrelated same-site article cards suppress the matching full-size image as well as their thumbnail form.
- Page families such as `/mirihanai` + `/mirihanai/page/N` remain the pagination lane while different article slugs stay excluded.
- Generic pages expose `全N件` to diagnostics as `INTELLIGENT_CONTENT_TOTAL`; `bi-girl.net/mirihanai` is expected to report 207.
- Generic `srcset` / `data-srcset` / `<picture><source>` selection now always chooses the largest advertised candidate, not merely the first candidate meeting the resolution threshold.
- Added `data-orig-file`, `data-large-file`, and `data-full-url` as original-image candidates.
- X/Twitter `pbs.twimg.com/media` `:small/:medium/:large/:thumb` and `name=small/...` variants are rewritten to the original-size endpoint before probe/save.
- WordPress `/wp-content/uploads/` `-WIDTHxHEIGHT` derivatives are promoted to the original filename, with automatic fallback to the discovered derivative when the original cannot be probed.
- Existing SNS/X/Instagram traversal, animated-GIF behavior, ad/affiliate filtering, fixed applicationId and stable signing key are retained.

## v0.1.95 — intelligent traversal restored
- Restored the default-ON 「インテリジェント巡回」 toggle.
- Intelligent ON forces page/detail traversal ON and greys those two toggles.
- Restored link classification logs: INTELLIGENT_CLASSIFY / FOLLOW / SKIP.
- Same-site unrelated article cards are skipped and their linked thumbnail images are suppressed.
- Same-article pagination remains followable. Gallery/photo/image-detail URLs remain followable.
- Tightened image-detail classification so generic WordPress resized thumbnails alone no longer qualify as image-detail pages.
- Existing v0.1.94 SNS/X/Instagram, ad-tracker and affiliate filtering paths are retained.

## v0.1.94 — standby / forced-stop diagnostics and detail-load pressure reduction

- Android 11+ の `ApplicationExitInfo` を診断ログへ追加し、前回プロセスの終了理由・status・timestamp・importance・PSS/RSS・descriptionを最大5件記録。
- 診断レポートへ現在のバックグラウンド制限、バッテリー最適化除外状態、App Standby Bucketを追加。
- バックグラウンド解析Serviceの `onTrimMemory` / `onLowMemory` を記録。
- 実機ログで大量発生していた `ad-nex.com` 詳細リンクと `img-ad-nex.com` 広告サムネイルを詳細解析／画像probe対象から除外。
- `pics.dmm.co.jp` サムネイル＋`al.dmm.co.jp` の典型的なアフィリエイト広告ペアは詳細追跡から除外。その他の `al.dmm.co.jp` 経由リンクは `lurl` をDMM本体URLへ展開して不要なリダイレクトを削減。
- v0.1.93 のX/Twitter動画403再解決・失敗キャッシュ・animated GIF保存仕様は維持。

## v0.1.93 — X/Twitter video 403 recovery

- `video.twimg.com` MP4のHTTP 403対策を再設計。`?tag=` 除去による推測リトライは廃止。
- 403時は、まず通常ブラウザ相当のUser-Agent / X Referer / Originで同一URLを1回だけ再試行。
- それでも403なら元ページを再取得し、同一media IDの新しい `video.twimg.com` MP4候補を探索。
- 元ページ内にX/Twitter statusリンクがある場合は最大6件まで辿り、同じmedia IDの新URLを再解決。
- 解決成功URLは解析セッション内で再利用。失敗も用途別にキャッシュし、サムネイル／プレビュー／保存処理が同じ403 URLを連打しない。
- X animated GIFのGIF保存仕様は維持。GIF変換失敗時にMP4へフォールバックしない。

## v0.1.92 — X/Twitter video tag retry (superseded)

- `video.twimg.com` MP4の403時に `tag` queryだけを外す方式を試したが、実機ログでtag有無どちらも403になるケースを確認。
- v0.1.93ではこの方式を廃止。

## v0.1.91 — X GIF decoder fallback

- Xの動画GIFをGIF保存する経路で、Android標準 `MediaMetadataRetriever` がduration/frameを取得できないMP4にMedia3 Inspectorをフォールバック使用。
- durationは platform extractor → Media3 metadata の順でも補完。
- 通常動画のMP4保存経路は変更しない。
- GIF選択時にGIF変換へ失敗した場合はMP4へフォールバック保存せず、従来どおり失敗（赤チェック）として扱う。

## v0.1.90 — X GIF save conversion

- SNS設定の「リポストを取得」直下に「動画GIFをGIFとして保存」Nトグルを追加（デフォルトON）。
- Xのanimated GIF/tweet_video MP4だけを保存時に実GIFへ変換。通常動画は従来どおりMP4保存。
- 追加ネイティブ依存なしのGIF89a/LZW変換を内蔵。

## v0.1.89 — X media-candidate resolver

Based on v0.1.88 (89).

### X / Twitter video + animated GIF
- Profile/timeline harvesting still discovers canonical status URLs, but status-detail analysis is now queued only for posts that visibly contain video/GIF indicators.
- `pbs.twimg.com/tweet_video_thumb/...` is treated as an animated-GIF media signal instead of a disposable non-post image.
- For `tweet_video_thumb`, ImgStalker derives the corresponding `https://video.twimg.com/tweet_video/<id>.mp4` candidate immediately and registers it as VIDEO against the owning status.
- `ext_tw_video_thumb`, live `<video>`/`<source>` nodes, X video-player test IDs, and GIF accessibility labels also mark a status as a media candidate.
- Only candidate statuses are deferred to the existing detail resolver; ordinary text/image statuses are no longer opened one-by-one just to prove they contain no video.
- Existing v0.1.88 detail-page fallback remains for candidate posts: animated_gif / video_info.variants parsing, Performance Resource Timing, WebView network capture, and bounded late-media polling.
- Added diagnostics: `SNS_X_MEDIA_CANDIDATES`, `SNS_X_TWEET_VIDEO_DIRECT`, and `SNS_X_STATUS_DEFER reason=media_candidate`.

### Retained from v0.1.88
- X detail pages keep the primary tweet near the viewport and can wait up to five 600 ms passes for late video/GIF materialization.
- Automatic gradual SNS thumbnail sweep with visible-cell priority.
- Instagram timeline-direct media path and existing rate-limit/resume behavior.
- Saved media circular green check / selection blocked; failed media circular dark-red check / retry selectable.
- N White #A9A999 title.
- SAF-first video saving with MediaStore Movies fallback.
- Fixed applicationId and stable signing keystore for overwrite install.

Package: versionName 0.1.127 / versionCode 128.

## v0.1.113 — install versionCode correction

- Raised versionCode to 114 so this build can overwrite the previously generated 0.1.112-beta build (versionCode 113).
- No crawler, SNS search, UI, applicationId, or signing-key behavior changes from v0.1.111.

## v0.1.111 — SNS search + account identity display

- Added X / Instagram radio buttons and a keyword / hashtag search field at the bottom of the SNS section.
- X searches use the latest-search timeline while preserving the user's query; Instagram routes single-token/hashtag input to its hashtag timeline and multi-word input to the Instagram keyword-search surface.
- Search discovery remains inside each SNS dedicated lane. It never falls through to generic intelligent traversal.
- X / Instagram account rows no longer show slot labels such as `X 1` / `X 2` or the text `ログイン済み`. Logged-in rows show the N-standard green circle + white geometric check at the left and the resolved `@user_id`.
- Existing logged-in profiles with no stored user ID attempt to resolve and cache the visible account handle from their isolated WebView profile.

## v0.1.110 — Intelligent related-card suppression + dedicated SNS lanes

- Intelligent traversal now gives `strongRelatedLike` priority over direct-image allow. A real direct image URL is suppressed when DOM ownership says it belongs to related/sidebar content.
- Images inherit related ownership from another internal-article link in the same compact DOM card. This is generic DOM-based filtering, not a bi-girl.net-specific URL rule.
- Related ownership learned on a later page is applied retroactively by normalized image identity; an already displayed media cell is removed from the UI and the final image count is corrected.
- Pending image probes and late probe completions re-check suppression, so page order and network timing cannot re-introduce a rejected related image.
- X and Instagram remain isolated dedicated SNS crawler lanes. SNS routing is now explicitly registered by `DedicatedSnsLogic`; any future SNS icon must get its own dedicated traversal/collector logic before being enabled and must not fall through to generic intelligent traversal.
- Explicit page-list traversal and maximum-resolution image selection remain unchanged.

## v0.1.109 — Page-list deadlock fix

- Explicit page lists remain authoritative for normal sites; X and Instagram traversal are unchanged.
- The already-open current page is never re-enqueued from a synthesized page-list entry.
- Navigation callback matching treats only trailing-path-slash differences as equivalent, so `/name` and `/name/` cannot deadlock a load.
- Normal non-SNS page loads have bounded start/finish watchdogs; a broken callback lane is skipped so remaining queued pages continue.
- Maximum-resolution image selection and existing related-article filtering are unchanged.

## v0.1.107 — Authoritative page-list traversal

- Normal sites treat an explicit page list as authoritative and queue those page URLs directly.
- Page-list URLs bypass intelligent/SNS-style traversal decisions; X/Instagram-specific traversal is unchanged.
- Numeric pager links, rel=next, page-select options and common pager containers are detected before any generic scroll fallback.
- If the pager exposes a numeric URL family, missing page numbers inside the visible range are reconstructed and queued.



## v0.1.115 — verified SNS accounts and dedicated X search harvesting

- X / Instagram account rows now show the saved user ID and only show the N green check after both an auth cookie and the signed-in account ID are verified.
- Reserved service paths such as X `/login` can no longer be stored as user IDs; legacy invalid values are rejected automatically.
- Account identity resolution retries the SPA DOM before declaring the session unverified. Logged-out profiles are not used for SNS analysis; cookie-only legacy profiles are fallback-only until verified.
- X keyword/hashtag search harvests media per tweet card and keeps each image tied to its canonical status URL instead of treating the whole search page as the referrer.
- X search remains isolated from generic intelligent traversal and from Instagram logic.

## v0.1.121 — X account ID resolution via twid

- X account verification now reads the authenticated `twid` numeric user ID and resolves it through `https://x.com/i/user/<id>` before falling back to DOM heuristics.
- The resolver accepts only the final one-segment X profile URL as the username, with canonical/og:URL/UserName fallback restricted to the numeric-ID profile route.
- Added diagnostic events `SNS_X_ID_RESOLVE`, `SNS_X_ID_RESOLVE_NAV`, and `SNS_X_ID_RESOLVE_REDIRECT` without logging auth tokens.
- Instagram account verification is unchanged.


## v0.1.122 — Instagram search post navigation / SNS dialog stack fix

- Instagram search treats query-decorated post URLs such as `/p/<shortcode>/?q=...` as the same root post navigation.
- Post-card tapping now matches the exact `/p|reel|tv/<shortcode>/` pathname and rejects child routes such as `/liked_by/`.
- Instagram stream recovery no longer waits forever on a post/child route; it returns to the search/profile stream with a bounded recovery path.
- SNS account dialogs are single-instance. Opening an account browser dismisses the parent account dialog first, then recreates exactly one refreshed account dialog on return.

## v0.1.123 — X normal video capture

- X normal-video network candidates from `video.twimg.com` are no longer filtered out by the animated-GIF-only drain.
- Normal X video and animated GIF selection use separate paths; GIF behavior is preserved.
- When multiple X MP4 candidates are observed, the candidate with the largest URL-advertised resolution is preferred; stream is fallback when no MP4 wins.
- X detail pages keep waiting when a `<video>` element exists but the playable MP4/stream has not materialized yet, even if the poster image is already visible.
- Performance Resource Timing now observes normal `video.twimg.com` MP4/stream resources in addition to animated-GIF resources.
- Added `SNS_X_VIDEO_SELECTED`, `SNS_X_VIDEO_NETWORK_DRAIN`, and `SNS_X_VIDEO_RESOLVE` diagnostics.



## v0.1.138 Instagram-only recovery
Instagram source HTTP failures now recover via Instagram-only authenticated WebView/DOM and per-post media extraction. Empty/partial source results also recover; no NORMAL/X engine or transporter changes. Browser-grid retry bounded to two refreshes; missing login/grid produces explicit error rather than success with zero media.


## v0.1.139 — repackage Instagram recovery (2026-10-08)
- Packaging base: v0.1.138 (139) source ZIP; versionName 0.1.139 / versionCode 140.
- No change to Java source, layouts, modes, media pipeline or signing keystore relative to v0.1.138.
- This release retains Instagram-only HTTP failure -> authenticated WebView recovery introduced in v0.1.138.
- NORMAL and X acquisition logic remain untouched; verification: ModeRoutingTest, InstagramRecoveryPolicyTest, mode-locks SHA-256, ZIP CRC.
- Real APK build and on-device Instagram extraction require subsequent GitBuild/Android testing.

## 0.1.153 (versionCode 154) — Instagram browser-first timeline recovery

* Instagram mode ONLY: loads the logged-in Instagram profile in the Instagram provider's WebView, and observes the website's own first-party GraphQL responses at document start when supported by AndroidX WebKit. It also extracts visible post/reel links while scrolling, without inventing a GraphQL doc_id for the browser route.
* Direct media already present in a captured timeline response are fed into the existing Instagram media resolver; unknown media use the existing source resolver. Browser collection is bounded and source-first fallback remains available if the WebView cannot discover any post.
* Authentication challenges, spam/feedback gates, and platform access limits stop the browser route without automatic retry against another endpoint. Previously stored media and Instagram resume/saved JSON remain untouched.
* No NORMAL or X provider sources are changed. Fixed signing key, applicationId, the existing workflows, and per-mode persistence are retained.
* This package has static tests, Java compilation smoke tests, and JavaScript mock-WebView tests. A real Android APK build and live Instagram verification still require GitBuild/device testing; Instagram's server access restrictions cannot be guaranteed to clear.

## 0.1.158 (versionCode 159)
- History and bookmark list headers add NORMAL/X/Instagram single-select filters. Repeated tap resets to all URLs, alternate tap switches mode; existing order is preserved.
- NORMAL globe icon is a new VectorDrawable based on the provided globe reference; X/Instagram filter glyphs reuse the existing main-header illustrations. Selection swaps foreground/background N colors.
- Navigation site icons are downsampled and rendered with aspect-preserving center crop into a transparent circle; use fresh disk cache directory to ignore distorted thumbnails.
- Data stores, crawler/serializer modules, and verified provider pipelines remain unchanged.

## v0.1.159 (160) resource compatibility and validation hotfix
- Rebased exclusively on v0.1.158 (159); incremented only version metadata.
- Simplified NORMAL globe VectorDrawable paths and switched to literal transparent ARGB, removing its referenced color resource. Appearance and N palette preserved.
- Added isolated Android API stub `javac` checks for navigation icon, drag-to-reorder, and filter helpers.
- Acquisition, Instagram WebView recovery, X, NORMAL crawler/download pipelines, resume state and signing keystore are unchanged.
- WARNING: GitBuild failure report was not supplied and the Android SDK/Gradle are not available here. This is a defensive compatibility patch, not a verified fix of the reported GitBuild failure.

## v0.1.161 (versionCode 162) — durable cumulative discovered media links

- Keep an **append-only deduplicated discovery ledger** in private app storage,
  `files/discovered_media_v1/Normal|X|Instagram/<identity SHA-256>.json`. This is
  separate from the disposable analysis/resume checkpoint and the saved-file ledger.
- On every new image/video callback, stage its media key, kind and URL; commit batches
  via the existing serial IO executor. Flush at scan completion, failure, stop,
  Activity backgrounding, and before a new URL or cache reset clears displayed media.
  STREAM items are not part of image/video counts.
- Before starting a new scan, import recoverable earlier media lists from the old
  resume/checkpoint JSON **even when Resume is OFF**, before those files can be replaced.
  History/bookmark count refresh also migrates available legacy lists.
- The denominator is the union of all known unique image/video links for that
  URL (NORMAL) or social account (X / Instagram). Reloading a smaller range cannot
  reduce the previously discovered count. The numerator remains the existing count
  of actual saved files; deletion of files can therefore lower the numerator only.
- Legacy entries already lost from every old checkpoint cannot be reconstructed.
  If the storage backend is unreadable, the ledger does not overwrite the old file.
- Align `ic_history_stalker.xml` arc start with the arrowhead upper edge per the
  approved vector patch; preserve N White #A9A999, stroke width 4.5 and button dimensions.
- Preserve unrelated NORMAL, X, Instagram crawler/downloader/pipeline code and signing.

Android release APK was not compiled in the local environment. Run GitBuild and
confirm real-device UI/counters before accepting this version as field-tested.


## v0.1.163 (versionCode 164) — SNS saved-mark compatibility rebake

- Based solely on v0.1.162 (163) source, without touching NORMAL/X/Instagram
  crawler, downloader, preview or provider implementations.
- SnsSavedMediaIdentity now reads legacy `IG|path:` and `IG|url:`
  save-ledger keys when matching the newer cache-key based image identity.
- Existing files, checkpoint formats, fixed app ID and keystore stay unchanged.
- All source-only tests and mode/provider hash guards are run for this rebake.
- Android APK compilation and installation cannot be confirmed without Android SDK/Gradle;
  GitBuild Actions logs are the authority for any remaining build failure.

- Includes an exact copy of the existing repository `.github/workflows/ImgStalker.yml` as reference. GitHub Actions is triggered by uploading the ZIP as repository `source.zip`, with the existing workflow remaining in the repository root.
