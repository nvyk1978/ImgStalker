# ImgStalker v0.1.49 (50)

## v0.1.49
- Instagram acquisition priority is now: avoid missed posts first, preserve Continue/reload recovery second, never auto-stop third, suppress duplicates fourth.
- Instagram detail traversal no longer gives up or skips a post because of a stall/retry count. Parse/click/load/slide-change failures restart that same post from slide 1 and retry until the user stops analysis.
- A missing carousel Next control is no longer accepted as completion on first sight. Terminal state must be reproduced after a clean restart (three confirmations on slide 1, two on later slides); seeing Next again clears the terminal guess.
- Carousel slide-change waits are restored to the more conservative v0.1.43 timing: 24 polls x 250 ms, with a full post restart on timeout rather than completion/skip.
- The v0.1.43 geometry and hit-test Next-button fallbacks are restored, while previous/back/audio/mute/play/close/like/comment/share controls are excluded from fallback candidates.
- Early Instagram detail collection introduced later is disabled. Detail media traversal begins after the page-finished settle path again, using a 450 ms settle.
- `?img_index=N` remains normalized as the same Instagram post and also counts as slide progress when media was preloaded.
- Instagram video dedupe no longer uses post+slide slot keys. VIDEO/STREAM results use actual asset/path identity, so the same CDN media discovered through DOM/Network or attached to the wrong post cannot create a second result.
- Network video candidates older than the current slide start are not attached, reducing late previous-post video contamination.
- Before normal completion, every discovered Instagram post must be in the confirmed-completed set. Any unfinished post is requeued instead of ending analysis.
- Continue/reload UI behavior from v0.1.48 is retained for actual crawler errors, activity recreation, manual Stop, or genuinely incomplete terminal completion.
- versionCode 50 / versionName 0.1.49. applicationId and fixed signing are unchanged.

## v0.1.43
- Instagram still-image duplicate suppression now uses a stable image identity: `ig_cache_key` first, then the CDN filename as fallback, instead of volatile signed query parameters.
- Continue analysis seeds use the same stable Instagram image key, preventing already collected thumbnails from being re-added when `_nc_gid`, `oh`, and related CDN parameters rotate.
- Settings gear keeps its existing overall diameter and center hole, but each tooth is narrower/shallower at the root so the circular rim is visibly exposed between the teeth.
- Existing Instagram carousel/video handling, SNS thumbnail windowing, filename/resolution labels, diagnostic icon, X repost setting, SNS login/profile support and fixed signing are retained.
- versionCode 44 / versionName 0.1.43. applicationId and fixed signing are unchanged.

## v0.1.42
- SNS grids (X / Instagram) no longer eagerly prefetch every still-image thumbnail. Visible cells load normally and only a six-item margin before/after the visible range is prefetched.
- SNS thumbnail cache is trimmed to the active visible/prefetch window so distant decoded bitmaps do not accumulate. Normal website thumbnail prefetch behavior is unchanged.
- Diagnostic Log header icon is now a solid document glyph with three knockout text lines.
- Settings header icon is now a solid simplified six-tooth gear with a punched center.
- Original-image fullscreen viewer and all image-area letterbox margins use pure black (#000000).
- Existing filename/resolution labels, video frame thumbnails, duration overlay, manual-stop Continue cell, Instagram carousel/video handling, X repost setting, SNS login/profile support and fixed signing are retained.
- versionCode 43 / versionName 0.1.42. applicationId and fixed signing are unchanged.

## v0.1.41
- Media grid cells now show a single-line filename and a second-line resolution under the thumbnail.
- Video cells render a real video frame thumbnail when available, keep the centered play button, and show duration at the lower-left of the thumbnail.
- Image dimensions are carried from crawler probes; video dimensions/duration are filled from video metadata or Media3 playback metadata.
- Settings and Diagnostic Log header icons were redrawn as vector graphics based on the supplied gear/document references.
- Manual Analyze/Stop now leaves the Continue cell so the same analysis can be resumed with existing results preserved.
- Instagram video duplicate suppression now keys same-post video requests by Instagram asset id when available.
- Instagram audio-only tracks are excluded and explicit ad-tagged video encodes are skipped.
- Existing Instagram carousel traversal, X repost setting, X status detail collection, SNS login/profile support, and fixed signing are retained.
- versionCode 42 / versionName 0.1.41. applicationId and fixed signing are unchanged.
