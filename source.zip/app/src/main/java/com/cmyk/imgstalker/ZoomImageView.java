package com.cmyk.imgstalker;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;

public final class ZoomImageView extends ImageView {
    private final Matrix imageMatrixInternal = new Matrix();
    private final RectF bitmapRect = new RectF();
    private final ScaleGestureDetector scaleDetector;
    private final int touchSlop;
    private final float density;

    private Bitmap bitmap;
    private float minScale = 1f;
    private float currentScale = 1f;
    private float maxScale = 4f;
    private float lastX;
    private float lastY;
    private float downX;
    private float downY;
    private boolean moved;

    private long lastTapUpTime;
    private float lastTapX;
    private float lastTapY;
    private boolean secondTapDown;
    private boolean dragZoomActive;
    private float dragZoomStartY;
    private float dragZoomStartScale;
    private ValueAnimator zoomAnimator;

    private static final long DOUBLE_TAP_MS = 320L;
    private static final long HOLD_MS = 180L;

    private final Runnable holdRunnable = () -> {
        if (secondTapDown) {
            dragZoomActive = true;
            dragZoomStartY = lastY;
            dragZoomStartScale = currentScale;
        }
    };

    public ZoomImageView(Context context) {
        this(context, null);
    }

    public ZoomImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = getResources().getDisplayMetrics().density;
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setScaleType(ScaleType.MATRIX);
        setImageMatrix(imageMatrixInternal);
        setClickable(true);

        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector detector) {
                cancelHoldMode();
                cancelAnimator();
                return bitmap != null;
            }

            @Override public boolean onScale(ScaleGestureDetector detector) {
                float target = clamp(currentScale * detector.getScaleFactor(), minScale, maxScale);
                applyScale(target, detector.getFocusX(), detector.getFocusY());
                return true;
            }
        });
    }

    public void setBitmap(Bitmap value) {
        bitmap = value;
        setImageBitmap(value);
        if (value == null) return;
        bitmapRect.set(0f, 0f, value.getWidth(), value.getHeight());
        post(this::resetToFit);
    }

    private void resetToFit() {
        if (bitmap == null || getWidth() <= 0 || getHeight() <= 0) return;
        float sx = getWidth() / (float) bitmap.getWidth();
        float sy = getHeight() / (float) bitmap.getHeight();
        minScale = Math.min(1f, Math.min(sx, sy));
        if (minScale <= 0f) minScale = 1f;
        currentScale = minScale;
        maxScale = Math.max(4f, minScale * 8f);
        imageMatrixInternal.reset();
        imageMatrixInternal.postScale(currentScale, currentScale);
        float dx = (getWidth() - bitmap.getWidth() * currentScale) / 2f;
        float dy = (getHeight() - bitmap.getHeight() * currentScale) / 2f;
        imageMatrixInternal.postTranslate(dx, dy);
        setImageMatrix(imageMatrixInternal);
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (bitmap != null && (oldw == 0 || oldh == 0)) post(this::resetToFit);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (bitmap == null) return true;
        scaleDetector.onTouchEvent(event);

        final int action = event.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                cancelAnimator();
                downX = lastX = event.getX();
                downY = lastY = event.getY();
                moved = false;
                long now = event.getEventTime();
                float dx = downX - lastTapX;
                float dy = downY - lastTapY;
                float maxDistance = 56f * density;
                secondTapDown = lastTapUpTime > 0L
                        && now - lastTapUpTime <= DOUBLE_TAP_MS
                        && dx * dx + dy * dy <= maxDistance * maxDistance;
                dragZoomActive = false;
                removeCallbacks(holdRunnable);
                if (secondTapDown) postDelayed(holdRunnable, HOLD_MS);
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                cancelHoldMode();
                return true;
            case MotionEvent.ACTION_MOVE: {
                float x = event.getX();
                float y = event.getY();
                if (Math.abs(x - downX) > touchSlop || Math.abs(y - downY) > touchSlop) moved = true;

                if (dragZoomActive && event.getPointerCount() == 1) {
                    float distance = (dragZoomStartY - y) / (220f * density);
                    float target = clamp((float) (dragZoomStartScale * Math.exp(distance)), minScale, maxScale);
                    applyScale(target, downX, downY);
                } else if (!scaleDetector.isInProgress() && !secondTapDown && event.getPointerCount() == 1) {
                    float tx = x - lastX;
                    float ty = y - lastY;
                    imageMatrixInternal.postTranslate(tx, ty);
                    constrainTranslation();
                    setImageMatrix(imageMatrixInternal);
                }
                lastX = x;
                lastY = y;
                return true;
            }
            case MotionEvent.ACTION_UP: {
                removeCallbacks(holdRunnable);
                long now = event.getEventTime();
                if (secondTapDown) {
                    if (!dragZoomActive && !moved) {
                        animateDoubleTap(downX, downY);
                    }
                    lastTapUpTime = 0L;
                } else if (!moved && !scaleDetector.isInProgress()) {
                    lastTapUpTime = now;
                    lastTapX = event.getX();
                    lastTapY = event.getY();
                }
                secondTapDown = false;
                dragZoomActive = false;
                performClick();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                cancelHoldMode();
                return true;
            default:
                return true;
        }
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    private void animateDoubleTap(float pivotX, float pivotY) {
        float originalScale = clamp(1f, minScale, maxScale);
        float target = Math.abs(currentScale - minScale) < Math.max(0.01f, minScale * 0.08f)
                ? originalScale : minScale;
        if (Math.abs(target - currentScale) < 0.001f) return;

        cancelAnimator();
        zoomAnimator = ValueAnimator.ofFloat(currentScale, target);
        zoomAnimator.setDuration(220L);
        zoomAnimator.setInterpolator(new DecelerateInterpolator());
        zoomAnimator.addUpdateListener(animation -> {
            float value = (float) animation.getAnimatedValue();
            applyScale(value, pivotX, pivotY);
        });
        zoomAnimator.start();
    }

    private void applyScale(float targetScale, float pivotX, float pivotY) {
        targetScale = clamp(targetScale, minScale, maxScale);
        if (currentScale <= 0f) currentScale = minScale;
        float factor = targetScale / currentScale;
        imageMatrixInternal.postScale(factor, factor, pivotX, pivotY);
        currentScale = targetScale;
        constrainTranslation();
        setImageMatrix(imageMatrixInternal);
    }

    private void constrainTranslation() {
        if (bitmap == null) return;
        RectF mapped = new RectF(bitmapRect);
        imageMatrixInternal.mapRect(mapped);
        float dx = 0f;
        float dy = 0f;
        if (mapped.width() <= getWidth()) {
            dx = getWidth() / 2f - mapped.centerX();
        } else if (mapped.left > 0f) {
            dx = -mapped.left;
        } else if (mapped.right < getWidth()) {
            dx = getWidth() - mapped.right;
        }
        if (mapped.height() <= getHeight()) {
            dy = getHeight() / 2f - mapped.centerY();
        } else if (mapped.top > 0f) {
            dy = -mapped.top;
        } else if (mapped.bottom < getHeight()) {
            dy = getHeight() - mapped.bottom;
        }
        imageMatrixInternal.postTranslate(dx, dy);
    }

    private void cancelHoldMode() {
        removeCallbacks(holdRunnable);
        secondTapDown = false;
        dragZoomActive = false;
    }

    private void cancelAnimator() {
        if (zoomAnimator != null) {
            zoomAnimator.cancel();
            zoomAnimator = null;
        }
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
