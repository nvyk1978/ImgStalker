package com.cmyk.imgstalker;

import android.webkit.CookieManager;

final class SessionCookies {
    private static volatile CookieManager active = CookieManager.getInstance();

    private SessionCookies() {}

    static void use(CookieManager manager) {
        active = manager == null ? CookieManager.getInstance() : manager;
    }

    static void useDefault() {
        active = CookieManager.getInstance();
    }

    static String getCookie(String url) {
        try {
            CookieManager manager = active;
            return manager == null ? null : manager.getCookie(url);
        } catch (Throwable t) {
            DiagnosticLog.log("SESSION_COOKIE_FAIL url=" + url + " reason=" + t.getClass().getSimpleName());
            return null;
        }
    }
}
