#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/net" "$TMP/src/android/content" "$TMP/src/org/json" "$TMP/src/com/cmyk/imgstalker" "$TMP/out"
cat > "$TMP/src/android/net/Uri.java" <<'JAVA'
package android.net;
public final class Uri {
 private final java.net.URI uri;
 private Uri(String s) {uri=java.net.URI.create(s);}
 public static Uri parse(String s) {return new Uri(s);}
 public String getHost() {return uri.getHost();}
 public String getScheme() {return uri.getScheme();}
 public String getPath() {return uri.getPath();}
}
JAVA
cat > "$TMP/src/android/content/SharedPreferences.java" <<'JAVA'
package android.content;
public interface SharedPreferences {
 String getString(String key,String fallback);
 Editor edit();
 interface Editor {Editor putString(String key,String value);void apply();}
}
JAVA
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content;
public class Context {
 public static final int MODE_PRIVATE=0;
 public SharedPreferences getSharedPreferences(String key,int mode) {throw new UnsupportedOperationException();}
}
JAVA
cat > "$TMP/src/org/json/JSONArray.java" <<'JAVA'
package org.json;
public class JSONArray {
 public JSONArray() {} public JSONArray(String s) {}
 public int length(){return 0;} public JSONObject optJSONObject(int n){return null;}
 public JSONArray put(JSONObject v){return this;}
 @Override public String toString(){return "[]";}
}
JAVA
cat > "$TMP/src/org/json/JSONObject.java" <<'JAVA'
package org.json;
public class JSONObject {
 public JSONObject() {}
 public String optString(String k,String d){return d;}
 public boolean optBoolean(String k,boolean d){return d;}
 public long optLong(String k,long d){return d;}
 public JSONObject put(String k,Object v){return this;}
}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" <<'JAVA'
package com.cmyk.imgstalker;
final class DiagnosticLog {static void logException(String code,Exception error){throw new AssertionError(code,error);}}
JAVA
javac -encoding UTF-8 -d "$TMP/out" \
 "$TMP/src/android/net/Uri.java" "$TMP/src/android/content/Context.java" \
 "$TMP/src/android/content/SharedPreferences.java" "$TMP/src/org/json/JSONArray.java" \
 "$TMP/src/org/json/JSONObject.java" "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" \
 app/src/main/java/com/cmyk/imgstalker/SiteVisitStore.java tests/SiteNavigationTitleTest.java
java -cp "$TMP/out" com.cmyk.imgstalker.SiteNavigationTitleTest
python - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
m = Path('app/src/main/java/com/cmyk/imgstalker/MainActivity.java').read_text()
assert '"お気に入り"' not in m and '"お気に入り一覧"' not in m
assert 'historyNavigationFloatButton()' in m and 'R.drawable.ic_history_stalker' in m
assert 'confirmBookmarkRemoval(entry.url, entry.displayTitle(), change)' in m
assert 'if (bookmarksOnly && currentlyBookmarked)' in m
assert 'confirmBookmarkRemoval(url, SiteVisitStore.displayTitleForUrl' in m
assert m.index('window.setLayout(width, height)') < m.index('dialog.show();',m.index('private void showNavigationDialog'))
assert 'SOFT_INPUT_ADJUST_NOTHING' in m
assert 'URLを入力してください' in m
x=ET.parse('app/src/main/res/drawable/ic_history_stalker.xml')
assert x.getroot().tag.endswith('vector')
assert len(list(x.getroot()))==3
print('PASS: bookmark confirmation routing, fixed dialog geometry, vector drawable and URL entry retained')
PY
