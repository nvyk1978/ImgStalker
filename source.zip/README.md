# ImgStalker v0.1.71 (72)

## Base
- Functional base: v0.1.70 (71).
- applicationId remains `com.cmyk.imgstalker`.
- Fixed signing key is unchanged.

## Instagram architecture rebuild
- Instagram profile discovery and post-media acquisition are now separate responsibilities.
- The profile WebView remains on the profile grid during the normal acquisition path; it is no longer navigated into each post and back again.
- Visible `/p/`, `/reel/`, and `/tv/` URLs are discovered in profile order and queued one at a time.
- A dedicated `InstagramMediaResolver` resolves each canonical post URL from inside the already-authenticated Instagram WebView context using same-origin `fetch()` with the active session.
- The resolver parses post-owned image/video/stream candidates from the returned post HTML/serialized metadata and optionally the Instagram embed representation without replacing the profile document.
- Regular post/carousel images and videos are emitted directly from resolver results.
- Reel cover/poster images remain excluded as standalone IMAGE results; Reel video/stream media are retained.

## Browser fallback isolation
- The old browser-style `SPA_OPEN -> carousel traversal -> SPA_CLOSE -> profile restore` path is no longer the normal Instagram acquisition path.
- A post that cannot be resolved by the lightweight resolver is deferred.
- Deferred posts are retried through the existing browser-style detail traversal only after profile discovery has finished, so fallback navigation can no longer destroy discovery progress.
- Existing carousel traversal, network-video observation, retry diagnostics, and profile-return logic remain available only as this fallback layer.

## Discovery / continuation
- Profile scrolling proceeds without detail-page round trips, so Instagram's virtualized grid can continue materializing rows instead of being recreated after every post.
- Completed/discovered post URLs still persist across continuation reloads.
- The existing 300-post session cap remains.
- Result ordering still follows canonical profile post order and per-post media order.

## Diagnostics
- `SNS_IG_RESOLVER_START`: canonical post URL handed from discovery to the resolver.
- `SNS_IG_RESOLVER_DONE`: resolver source, candidate counts, and emitted media counts.
- `SNS_IG_RESOLVER_DEFER`: lightweight resolution failed and the post was queued for browser fallback.
- Existing `SNS_IG_STREAM_SCROLL` diagnostics now describe profile discovery without normal detail navigation.

## Package
- versionCode: 72
- versionName: 0.1.71
