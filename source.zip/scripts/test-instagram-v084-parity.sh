#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'TEST'
from pathlib import Path
import hashlib
root=Path('app/src/main/java/com/cmyk/imgstalker')
p=(root/'InstagramInstagramSourcePipeline.java').read_text().replace('InstagramInstagramSourcePipeline','InstagramSourcePipeline')
assert hashlib.sha256(p.encode()).hexdigest() == "e4584327a2a785202e3cf4b6232c5a4ecebc742719e73559a1bc555527c2f076", 'Instagram 0.1.86 GraphQL pipeline mismatch'
c=(root/'InstagramCrawlerEngine.java').read_text()
assert 'startInstagramInstagramSourcePipeline(normalized)' in c
assert 'fallback=source_only browser=false' in c
assert 'SNS_IG_086_BROWSER_PROFILE_START' not in c
assert 'if (isInstagramLikeHost(rootHost))' in c
assert 'InstagramSessionCookies.getCookie(' in c
r=(root/'InstagramInstagramMediaResolver.java').read_text().replace('InstagramInstagramMediaResolver','InstagramMediaResolver')
assert hashlib.sha256(r.encode()).hexdigest()=="c6002e65971f665e8615bac6cc24ed961d8b074073f467da00135fcebf570a39", 'Instagram 0.1.86 media resolver mismatch'
assert "versionCode 145" in Path('app/build.gradle').read_text()
assert "versionName '0.1.144'" in Path('app/build.gradle').read_text()
print('PASS: Instagram v0.1.86 source GraphQL, media resolver and browser-free route')
TEST
sha256sum -c mode-locks.sha256
