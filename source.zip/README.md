# ImgStalker v0.1.102 (103)

Android 16 / SDK 36 source package for ImgStalker.



## v0.1.102 — paginated direct-image false-positive fix

- Base: exact v0.1.101 (102) source.
- Fixes the diagnostic-confirmed case where page 2+ main `pbs.twimg.com/media` image pairs were marked `relatedLike` and discarded before the direct-image path.
- A related-marked thumbnail is allowed only when both `img` and `href` are `pbs.twimg.com` media URLs and normalize to the exact same image identity (for example `:small` -> `:large`).
- Existing related/sidebar/site-article rejection remains unchanged for non-matching images.
- Existing maximum-resolution normalization, ad filtering, pagination behavior, applicationId, and fixed signing key are unchanged.

## v0.1.100 — large direct-image preservation / related-card filtering

- Keeps explicit `pbs.twimg.com/...jpg:large` and `:orig` hrefs as real fetch URLs instead of stripping the size suffix.
- Upgrades `:thumb` / `:small` / `:medium` image candidates to `:large`, while deduplication uses a separate size-neutral image identity.
- Direct-image detection accepts Twitter-style `:large` / `:orig` suffixes.
- Related/sidebar/recommend/ranking/recent/widget/card images are filtered by DOM ancestry even when the image has no ordinary article link.
- Related-card classification now runs before the direct-image fast path, preventing image hrefs inside related cards from leaking into results.
- Main article/content images remain eligible.

## v0.1.99 — external CDN direct-image recovery
- Thumbnail/detail links are normalized through the existing maximum-resolution image URL logic before direct-image classification.
- X/Twitter CDN image links such as `pbs.twimg.com/media/...jpg:large` are recognized as direct image assets instead of being misclassified as unrelated external navigation.
- Direct external image assets now enter the normal image probe/replacement path; unrelated external pages, advertisements, affiliate links, and related-article navigation remain filtered by the existing intelligent traversal rules.
- Adds `THUMB_LINK_IMAGE_TARGET_REWRITE` diagnostics when a linked image target is promoted to its canonical maximum-resolution URL.
- Existing in-page maximum-size UI detection, pagination/content-family traversal, SNS handling, applicationId, and stable signing key are retained.


## v0.1.97 — generic in-page maximum image size selection
- Before generic web-page media collection, ImgStalker scans image-size / resolution / quality controls and selects the maximum-looking choice when the image context is sufficiently clear.
- Supports radio groups, select menus, buttons and tabs; recognizes Japanese/English choices including 大 / 最大 / 原寸 / 高解像度 / Large / Original / Full / High and explicit pixel dimensions.
- Uses the page's normal click/input/change event path, waits 800 ms for DOM/image updates, then starts media collection.
- Adds `IMAGE_SIZE_UI_SCAN` and `IMAGE_SIZE_UI_VERIFY` diagnostics, including whether image URLs/natural dimensions actually changed.
- After a size switch, collector compares live `currentSrc` / `naturalWidth` against `srcset`, `<picture><source>`, `data-full-url`, `data-original`, and related candidates so a stale medium `srcset` cannot mask a larger selected image.
- The detector is deliberately conservative: controls must be in an image/photo size, resolution or quality context; ordinary navigation is not clicked and normal links are not followed as size controls.
- Existing intelligent content-family traversal, maximum URL normalization, SNS/X/Instagram handling, and fixed signing identity remain active.

## v0.1.96 — content-family traversal + maximum-resolution images
- Intelligent traversal now uses one canonical image identity for X/Twitter size variants, so unrelated same-site article cards suppress the matching full-size image as well as their thumbnail form.
- Page families such as `/mirihanai` + `/mirihanai/page/N` remain the pagination lane while different article slugs stay excluded.
- Generic pages expose `全N件` to diagnostics as `INTELLIGENT_CONTENT_TOTAL`; `bi-girl.net/mirihanai` is expected to report 207.
- Generic `srcset` / `data-srcset` / `<picture><source>` selection now always chooses the largest advertised candidate, not merely the first candidate meeting the resolution threshold.
- Added `data-orig-file`, `data-large-file`, and `data-full-url` as original-image candidates.
- X/Twitter `pbs.twimg.com/media` `:small/:medium/:large/:thumb` and `name=small/...` variants are rewritten to the original-size endpoint before probe/save.
- WordPress `/wp-content/uploads/` `-WIDTHxHEIGHT` derivatives are promoted to the original filename, with automatic fallback to the discovered derivative when the original cannot be probed.
- Existing SNS/X/Instagram traversal, animated-GIF behavior, ad/affiliate filtering, fixed applicationId and stable signing key are retained.

## v0.1.95 — intelligent traversal restored
- Restored the default-ON 「インテリジェント巡回」 toggle.
- Intelligent ON forces page/detail traversal ON and greys those two toggles.
- Restored link classification logs: INTELLIGENT_CLASSIFY / FOLLOW / SKIP.
- Same-site unrelated article cards are skipped and their linked thumbnail images are suppressed.
- Same-article pagination remains followable. Gallery/photo/image-detail URLs remain followable.
- Tightened image-detail classification so generic WordPress resized thumbnails alone no longer qualify as image-detail pages.
- Existing v0.1.94 SNS/X/Instagram, ad-tracker and affiliate filtering paths are retained.

## v0.1.94 — standby / forced-stop diagnostics and detail-load pressure reduction

- Android 11+ の `ApplicationExitInfo` を診断ログへ追加し、前回プロセスの終了理由・status・timestamp・importance・PSS/RSS・descriptionを最大5件記録。
- 診断レポートへ現在のバックグラウンド制限、バッテリー最適化除外状態、App Standby Bucketを追加。
- バックグラウンド解析Serviceの `onTrimMemory` / `onLowMemory` を記録。
- 実機ログで大量発生していた `ad-nex.com` 詳細リンクと `img-ad-nex.com` 広告サムネイルを詳細解析／画像probe対象から除外。
- `pics.dmm.co.jp` サムネイル＋`al.dmm.co.jp` の典型的なアフィリエイト広告ペアは詳細追跡から除外。その他の `al.dmm.co.jp` 経由リンクは `lurl` をDMM本体URLへ展開して不要なリダイレクトを削減。
- v0.1.93 のX/Twitter動画403再解決・失敗キャッシュ・animated GIF保存仕様は維持。

## v0.1.93 — X/Twitter video 403 recovery

- `video.twimg.com` MP4のHTTP 403対策を再設計。`?tag=` 除去による推測リトライは廃止。
- 403時は、まず通常ブラウザ相当のUser-Agent / X Referer / Originで同一URLを1回だけ再試行。
- それでも403なら元ページを再取得し、同一media IDの新しい `video.twimg.com` MP4候補を探索。
- 元ページ内にX/Twitter statusリンクがある場合は最大6件まで辿り、同じmedia IDの新URLを再解決。
- 解決成功URLは解析セッション内で再利用。失敗も用途別にキャッシュし、サムネイル／プレビュー／保存処理が同じ403 URLを連打しない。
- X animated GIFのGIF保存仕様は維持。GIF変換失敗時にMP4へフォールバックしない。

## v0.1.92 — X/Twitter video tag retry (superseded)

- `video.twimg.com` MP4の403時に `tag` queryだけを外す方式を試したが、実機ログでtag有無どちらも403になるケースを確認。
- v0.1.93ではこの方式を廃止。

## v0.1.91 — X GIF decoder fallback

- Xの動画GIFをGIF保存する経路で、Android標準 `MediaMetadataRetriever` がduration/frameを取得できないMP4にMedia3 Inspectorをフォールバック使用。
- durationは platform extractor → Media3 metadata の順でも補完。
- 通常動画のMP4保存経路は変更しない。
- GIF選択時にGIF変換へ失敗した場合はMP4へフォールバック保存せず、従来どおり失敗（赤チェック）として扱う。

## v0.1.90 — X GIF save conversion

- SNS設定の「リポストを取得」直下に「動画GIFをGIFとして保存」Nトグルを追加（デフォルトON）。
- Xのanimated GIF/tweet_video MP4だけを保存時に実GIFへ変換。通常動画は従来どおりMP4保存。
- 追加ネイティブ依存なしのGIF89a/LZW変換を内蔵。

## v0.1.89 — X media-candidate resolver

Based on v0.1.88 (89).

### X / Twitter video + animated GIF
- Profile/timeline harvesting still discovers canonical status URLs, but status-detail analysis is now queued only for posts that visibly contain video/GIF indicators.
- `pbs.twimg.com/tweet_video_thumb/...` is treated as an animated-GIF media signal instead of a disposable non-post image.
- For `tweet_video_thumb`, ImgStalker derives the corresponding `https://video.twimg.com/tweet_video/<id>.mp4` candidate immediately and registers it as VIDEO against the owning status.
- `ext_tw_video_thumb`, live `<video>`/`<source>` nodes, X video-player test IDs, and GIF accessibility labels also mark a status as a media candidate.
- Only candidate statuses are deferred to the existing detail resolver; ordinary text/image statuses are no longer opened one-by-one just to prove they contain no video.
- Existing v0.1.88 detail-page fallback remains for candidate posts: animated_gif / video_info.variants parsing, Performance Resource Timing, WebView network capture, and bounded late-media polling.
- Added diagnostics: `SNS_X_MEDIA_CANDIDATES`, `SNS_X_TWEET_VIDEO_DIRECT`, and `SNS_X_STATUS_DEFER reason=media_candidate`.

### Retained from v0.1.88
- X detail pages keep the primary tweet near the viewport and can wait up to five 600 ms passes for late video/GIF materialization.
- Automatic gradual SNS thumbnail sweep with visible-cell priority.
- Instagram timeline-direct media path and existing rate-limit/resume behavior.
- Saved media circular green check / selection blocked; failed media circular dark-red check / retry selectable.
- N White #A9A999 title.
- SAF-first video saving with MediaStore Movies fallback.
- Fixed applicationId and stable signing keystore for overwrite install.

Package: versionName 0.1.102 / versionCode 103.
