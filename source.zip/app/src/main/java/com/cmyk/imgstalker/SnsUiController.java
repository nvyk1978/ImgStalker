package com.cmyk.imgstalker;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.IntentFilter;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.UserAgentMetadata;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.Status;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.WeakHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class SnsUiController {
    private static final int BG = 0xFF303030;
    private static final int DARK_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int BLUE = 0xFF223355;
    private static final int LIGHT_BLUE = 0xFF445577;
    private static final int ORANGE = 0xFF775500;
    private static final int DARK_RED = 0xFF441100;
    private static final int N_WHITE = 0xFFA9A999;
    private static final int TEXT_WHITE = 0xFFFFFFFF;
    private static final int GREEN = 0xFF227733;

    private final Activity activity;
    private final SnsAccountManager accounts;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final WeakHashMap<WebView, String> domChecksScheduledForUrl = new WeakHashMap<>();
    static final int SMS_CONSENT_REQUEST = 43032;
    private BroadcastReceiver smsConsentReceiver;
    private boolean smsReceiverRegistered = false;
    private ArrayList<WebView> activeLoginStack;
    private SnsAccountManager.Account activeLoginAccount;
    private AlertDialog activeLoginDialog;

    SnsUiController(Activity activity, SnsAccountManager accounts) {
        this.activity = activity;
        this.accounts = accounts;
    }

    void showAccountDialog(SnsAccountManager.Service service) {
        DiagnosticLog.log("SNS_DIALOG_OPEN service=" + service.label);
        int screenWidth = activity.getResources().getDisplayMetrics().widthPixels;
        int screenHeight = activity.getResources().getDisplayMetrics().heightPixels;
        final int dialogWidth = Math.max(dp(300), Math.min(screenWidth - dp(24), dp(520)));
        final int dialogHeight = Math.max(dp(360), Math.min(screenHeight - dp(180), dp(520)));

        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(14), dp(16), dp(14));
        panel.setBackgroundColor(Color.TRANSPARENT);
        panel.setLayoutParams(new ViewGroup.LayoutParams(dialogWidth, dialogHeight));

        TextView title = text(service.label + " アカウント", 21, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        panel.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

        TextView hint = text(accounts.supportsMultiProfile()
                ? "登録順に自動試行。閲覧できない場合は次のアカウントへ切り替えます。"
                : "このWebViewは複数プロファイル非対応のため、このSNSは1アカウント運用です。",
                12, N_WHITE);
        hint.setPadding(0, 0, 0, dp(8));
        panel.addView(hint);

        ScrollView scroll = new ScrollView(activity);
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        List<SnsAccountManager.Account> current = accounts.getAccounts(service);
        if (current.isEmpty()) {
            TextView empty = text("未登録", 14, N_WHITE);
            empty.setGravity(Gravity.CENTER);
            list.addView(empty, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        } else {
            for (SnsAccountManager.Account account : current) addAccountRow(list, account, service);
        }

        LinearLayout actions = new LinearLayout(activity);
        actions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.setPadding(0, dp(10), 0, 0);
        Button add = button("＋ ログイン追加", BLUE);
        actions.addView(add, new LinearLayout.LayoutParams(0, dp(42), 1f));
        if (service == SnsAccountManager.Service.X) {
            Button sensitive = button("センシティブ表示 一括ON", ORANGE);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(178), dp(42));
            slp.leftMargin = dp(8);
            actions.addView(sensitive, slp);
            sensitive.setOnClickListener(v -> applySensitiveForAllX());
        }
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(activity).setView(panel).create();
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        add.setOnClickListener(v -> {
            List<SnsAccountManager.Account> existing = accounts.getAccounts(service);
            if (!accounts.supportsMultiProfile() && !existing.isEmpty()) {
                Toast.makeText(activity, "この端末では複数アカウントを分離できません", Toast.LENGTH_SHORT).show();
                return;
            }
            SnsAccountManager.Account account = accounts.allocateAccount(service);
            dialog.dismiss();
            openLogin(account);
        });
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setGravity(Gravity.CENTER);
            window.setBackgroundDrawable(rounded(GRAY, 20));
            window.setLayout(dialogWidth, dialogHeight);
        }
    }

    private void addAccountRow(LinearLayout list, SnsAccountManager.Account account, SnsAccountManager.Service service) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(6), dp(8), dp(6));
        row.setBackground(rounded(DARK_GRAY, 10));
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58));
        rlp.bottomMargin = dp(6);
        list.addView(row, rlp);

        boolean loggedIn = accounts.isLoggedIn(account);
        TextView label = text(account.displayName() + (loggedIn ? "   ●ログイン済み" : "   未ログイン"), 13,
                loggedIn ? TEXT_WHITE : N_WHITE);
        row.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        Button login = button(loggedIn ? "開く" : "ログイン", BLUE);
        row.addView(login, new LinearLayout.LayoutParams(dp(76), dp(38)));
        Button remove = button("削除", DARK_RED);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(62), dp(38));
        dlp.leftMargin = dp(6);
        row.addView(remove, dlp);

        login.setOnClickListener(v -> openLogin(account));
        remove.setOnClickListener(v -> new AlertDialog.Builder(activity)
                .setMessage(account.displayName() + " を削除しますか？")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", (d, w) -> {
                    accounts.removeAccount(account);
                    DiagnosticLog.log("SNS_ACCOUNT_REMOVE service=" + service.label + " profile=" + account.profileName);
                    row.setVisibility(View.GONE);
                    Toast.makeText(activity, account.displayName() + " を削除しました", Toast.LENGTH_SHORT).show();
                }).show());
    }

    private void openLogin(SnsAccountManager.Account account) {
        DiagnosticLog.log("SNS_LOGIN_OPEN service=" + account.service.label + " profile=" + account.profileName);

        int screenWidth = activity.getResources().getDisplayMetrics().widthPixels;
        int screenHeight = activity.getResources().getDisplayMetrics().heightPixels;
        final int dialogWidth = Math.max(dp(300), Math.min(screenWidth - dp(24), dp(520)));
        final int dialogHeight = Math.max(dp(420), Math.min(screenHeight - dp(160), dp(620)));
        final int headerHeight = dp(48);
        final int actionsHeight = dp(58);
        final int webHeight = Math.max(dp(280), dialogHeight - headerHeight - actionsHeight);

        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackgroundColor(Color.TRANSPARENT);
        panel.setLayoutParams(new ViewGroup.LayoutParams(dialogWidth, dialogHeight));

        LinearLayout headerRow = new LinearLayout(activity);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        headerRow.setPadding(dp(14), 0, dp(10), 0);
        TextView header = text(account.service.label + " ログイン", 18, TEXT_WHITE);
        header.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        headerRow.addView(header, new LinearLayout.LayoutParams(0, headerHeight, 1f));
        ProgressBar progress = new ProgressBar(activity, null, android.R.attr.progressBarStyleSmall);
        progress.setIndeterminate(false);
        progress.setMax(100);
        progress.setVisibility(View.INVISIBLE);
        headerRow.addView(progress, new LinearLayout.LayoutParams(dp(28), dp(28)));
        panel.addView(headerRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, headerHeight));

        FrameLayout webHost = new FrameLayout(activity);
        webHost.setBackground(rounded(DARK_GRAY, 10));
        webHost.setClipToOutline(true);
        LinearLayout.LayoutParams whlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, webHeight);
        whlp.leftMargin = dp(10);
        whlp.rightMargin = dp(10);
        panel.addView(webHost, whlp);

        ArrayList<WebView> browserStack = new ArrayList<>();
        boolean[] authenticatedLogged = {false};
        boolean[] blankFallbackTried = {false};
        boolean[] navigationStarted = {false};
        WebView loginWebView = createLoginWebView(account, header, progress, webHost, browserStack, authenticatedLogged, blankFallbackTried);
        browserStack.add(loginWebView);
        webHost.addView(loginWebView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout actions = new LinearLayout(activity);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.setPadding(dp(10), dp(6), dp(10), dp(8));
        Button paste = button("コード貼付", ORANGE);
        Button done = button("完了", BLUE);
        Button cancel = button("閉じる", GRAY);
        actions.addView(paste, new LinearLayout.LayoutParams(dp(100), dp(42)));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(82), dp(42));
        dlp.leftMargin = dp(8);
        actions.addView(done, dlp);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(82), dp(42));
        clp.leftMargin = dp(8);
        actions.addView(cancel, clp);
        panel.addView(actions, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, actionsHeight));

        AlertDialog dialog = new AlertDialog.Builder(activity).setView(panel).create();
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        activeLoginStack = browserStack;
        activeLoginAccount = account;
        activeLoginDialog = dialog;

        View.OnClickListener finish = v -> dialog.dismiss();
        done.setOnClickListener(finish);
        cancel.setOnClickListener(finish);
        paste.setOnClickListener(v -> pasteOtpFromClipboard());

        dialog.setOnKeyListener((d, keyCode, event) -> {
            if (keyCode != KeyEvent.KEYCODE_BACK || event.getAction() != KeyEvent.ACTION_UP) return false;
            if (browserStack.isEmpty()) return false;
            WebView active = browserStack.get(browserStack.size() - 1);
            if (active.canGoBack()) {
                active.goBack();
                return true;
            }
            if (browserStack.size() > 1) {
                closeLoginWebView(active, webHost, browserStack);
                return true;
            }
            return false;
        });
        dialog.setOnDismissListener(d -> {
            stopSmsUserConsent();
            boolean loggedIn = accounts.isLoggedIn(account);
            if (loggedIn) {
                accounts.flushCookies(account.profileName);
                accounts.commitAccount(account);
                DiagnosticLog.log("SNS_LOGIN_OK service=" + account.service.label + " profile=" + account.profileName);
            } else {
                DiagnosticLog.log("SNS_LOGIN_CLOSE_NOT_AUTHENTICATED service=" + account.service.label + " profile=" + account.profileName);
            }
            destroyLoginStack(webHost, browserStack);
            if (!loggedIn) scheduleDiscardUncommitted(account, 0);
            if (activeLoginDialog == dialog) {
                activeLoginDialog = null;
                activeLoginStack = null;
                activeLoginAccount = null;
            }
            if (!activity.isFinishing() && !activity.isDestroyed()) showAccountDialog(account.service);
        });

        dialog.setOnShowListener(d -> {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setGravity(Gravity.CENTER);
                window.setBackgroundDrawable(rounded(GRAY, 20));
                window.setLayout(dialogWidth, dialogHeight);
                window.clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
                window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
                window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                        | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
            }
            loginWebView.setFocusable(true);
            loginWebView.setFocusableInTouchMode(true);
            waitForLoginLayoutReady(loginWebView, account, navigationStarted, 0);
            startSmsUserConsent();
        });
        dialog.show();
    }

    private void waitForLoginLayoutReady(WebView webView, SnsAccountManager.Account account,
                                         boolean[] navigationStarted, int attempt) {
        if (webView == null || navigationStarted[0]) return;
        int width = webView.getWidth();
        int height = webView.getHeight();
        if (width > 0 && height > 0) {
            navigationStarted[0] = true;
            DiagnosticLog.log("SNS_LOGIN_LAYOUT_READY service=" + account.service.label
                    + " profile=" + account.profileName + " size=" + width + "x" + height);
            DiagnosticLog.log("SNS_LOGIN_NAV_START service=" + account.service.label
                    + " profile=" + account.profileName + " url=" + account.service.loginUrl
                    + " size=" + width + "x" + height);
            webView.loadUrl(account.service.loginUrl);
            return;
        }
        if (attempt >= 30) {
            DiagnosticLog.log("SNS_LOGIN_LAYOUT_FAIL service=" + account.service.label
                    + " profile=" + account.profileName + " size=" + width + "x" + height);
            Toast.makeText(activity, "ログイン画面を表示できませんでした", Toast.LENGTH_SHORT).show();
            return;
        }
        handler.postDelayed(() -> waitForLoginLayoutReady(webView, account, navigationStarted, attempt + 1), 50L);
    }

    private void scheduleDiscardUncommitted(SnsAccountManager.Account account, int attempt) {
        if (account == null || accounts.isCommitted(account)) return;
        long delay = attempt == 0 ? 350L : 650L;
        handler.postDelayed(() -> {
            if (accounts.isCommitted(account)) return;
            boolean done = accounts.discardUncommitted(account);
            if (!done && attempt < 3) scheduleDiscardUncommitted(account, attempt + 1);
        }, delay);
    }

    private WebView createLoginWebView(
            SnsAccountManager.Account account,
            TextView header,
            ProgressBar progress,
            FrameLayout webHost,
            ArrayList<WebView> browserStack,
            boolean[] authenticatedLogged,
            boolean[] blankFallbackTried) {
        WebView webView = new WebView(activity);
        // MULTI_PROFILE requires setProfile before settings, navigation or script access.
        accounts.applyProfile(webView, account.profileName);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setTextZoom(100);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowContentAccess(true);

        // X/Instagram expect a normal mobile browser. Strip the Android WebView-only markers
        // while retaining the device's current Chromium version instead of hardcoding one.
        String rawUa = settings.getUserAgentString();
        String browserUa = browserLikeUserAgent(rawUa);
        if (browserUa != null && !browserUa.isEmpty()) settings.setUserAgentString(browserUa);
        DiagnosticLog.log("SNS_LOGIN_UA service=" + account.service.label
                + " webviewMarker=" + containsWebViewMarker(rawUa)
                + " browserMarker=" + containsWebViewMarker(settings.getUserAgentString()));
        applyBrowserUaMetadata(settings, settings.getUserAgentString(), account.service);

        // Keep passkey/WebAuthn behavior explicit when this WebView build exposes the API.
        // FOR_APP is safe for a normal application; unsupported builds simply retain defaults.
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_AUTHENTICATION)) {
                WebSettingsCompat.setWebAuthenticationSupport(settings, WebSettingsCompat.WEB_AUTHENTICATION_SUPPORT_FOR_APP);
                DiagnosticLog.log("SNS_LOGIN_WEBAUTHN service=" + account.service.label + " mode=app");
            }
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_LOGIN_WEBAUTHN_FAIL service=" + account.service.label
                    + " reason=" + t.getClass().getSimpleName());
        }

        webView.setBackgroundColor(Color.WHITE);
        accounts.prepareLoginCookies(webView, account.profileName);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleLoginNavigation(view, request == null ? null : request.getUrl().toString(), account);
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleLoginNavigation(view, url, account);
            }

            @Override public void onPageFinished(WebView view, String url) {
                DiagnosticLog.log("SNS_LOGIN_PAGE service=" + account.service.label + " profile=" + account.profileName + " url=" + url);
                scheduleLoginDomChecks(view, account, header, blankFallbackTried);
                if (accounts.isLoggedIn(account)) {
                    accounts.flushCookies(account.profileName);
                    accounts.commitAccount(account);
                    header.setText(account.service.label + " ログイン済み");
                    if (!authenticatedLogged[0]) {
                        authenticatedLogged[0] = true;
                        DiagnosticLog.log("SNS_LOGIN_AUTH_COOKIE service=" + account.service.label + " profile=" + account.profileName);
                        Toast.makeText(activity, account.service.label + " ログインを確認しました", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    DiagnosticLog.log("SNS_LOGIN_ERROR service=" + account.service.label
                            + " code=" + (error == null ? "?" : error.getErrorCode())
                            + " url=" + request.getUrl());
                    header.setText(account.service.label + " 読み込みエラー");
                }
            }

            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                if (request != null && request.isForMainFrame()) {
                    DiagnosticLog.log("SNS_LOGIN_HTTP service=" + account.service.label
                            + " status=" + (errorResponse == null ? "?" : errorResponse.getStatusCode())
                            + " url=" + request.getUrl());
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.INVISIBLE : View.VISIBLE);
            }

            @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                try {
                    WebView child = createLoginWebView(account, header, progress, webHost, browserStack, authenticatedLogged, blankFallbackTried);
                    browserStack.add(child);
                    webHost.addView(child, new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                    WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                    transport.setWebView(child);
                    resultMsg.sendToTarget();
                    DiagnosticLog.log("SNS_LOGIN_POPUP_OPEN service=" + account.service.label
                            + " profile=" + account.profileName + " gesture=" + isUserGesture);
                    return true;
                } catch (Throwable t) {
                    DiagnosticLog.log("SNS_LOGIN_POPUP_FAIL service=" + account.service.label
                            + " reason=" + t.getClass().getSimpleName());
                    return false;
                }
            }

            @Override public void onCloseWindow(WebView window) {
                closeLoginWebView(window, webHost, browserStack);
                DiagnosticLog.log("SNS_LOGIN_POPUP_CLOSE service=" + account.service.label);
            }

            @Override public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                if (consoleMessage != null && consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    DiagnosticLog.log("SNS_LOGIN_CONSOLE_ERROR service=" + account.service.label
                            + " line=" + consoleMessage.lineNumber() + " message=" + consoleMessage.message());
                }
                return false;
            }
        });
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setOnTouchListener((v, event) -> {
            // Do not steal focus from the HTML editor or Android Autofill. X / Instagram account
            // suggestions are owned by the page/IME and were disappearing when requestFocusFromTouch()
            // was called again immediately after the tap. Only request IME display as a fallback.
            if (event != null && event.getActionMasked() == MotionEvent.ACTION_UP) {
                handler.postDelayed(() -> showImeIfHtmlEditorFocused(webView, account), 180L);
            }
            return false;
        });
        return webView;
    }

    private void showImeIfHtmlEditorFocused(WebView webView, SnsAccountManager.Account account) {
        if (webView == null || webView.getParent() == null) return;
        final String serviceLabel = account == null ? "?" : account.service.label;
        try {
            webView.evaluateJavascript("(function(){var e=document.activeElement;if(!e)return false;var t=(e.tagName||'').toLowerCase();return t==='input'||t==='textarea'||e.isContentEditable===true;})()", raw -> {
                if (!"true".equals(raw)) return;
                try {
                    Window window = activeLoginDialog == null ? null : activeLoginDialog.getWindow();
                    if (window != null) {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
                        window.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
                    }
                    if (Build.VERSION.SDK_INT >= 30) {
                        android.view.WindowInsets insets = webView.getRootWindowInsets();
                        if (insets != null && insets.isVisible(android.view.WindowInsets.Type.ime())) {
                            DiagnosticLog.log("SNS_LOGIN_IME service=" + serviceLabel + " requested=false reason=already_visible");
                            return;
                        }
                    }
                    InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        boolean shown = imm.showSoftInput(webView, InputMethodManager.SHOW_IMPLICIT);
                        DiagnosticLog.log("SNS_LOGIN_IME service=" + serviceLabel + " requested=true shown=" + shown);
                    }
                } catch (Throwable t) {
                    DiagnosticLog.log("SNS_LOGIN_IME_FAIL service=" + serviceLabel + " reason=" + t.getClass().getSimpleName());
                }
            });
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_LOGIN_IME_CHECK_FAIL service=" + serviceLabel + " reason=" + t.getClass().getSimpleName());
        }
    }

    private void startSmsUserConsent() {
        if (activeLoginDialog == null || !activeLoginDialog.isShowing()) return;
        stopSmsUserConsent();
        smsConsentReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (intent == null || !SmsRetriever.SMS_RETRIEVED_ACTION.equals(intent.getAction())) return;
                Bundle extras = intent.getExtras();
                Status status = extras == null ? null : (Status) extras.get(SmsRetriever.EXTRA_STATUS);
                if (status == null) return;
                if (status.getStatusCode() == CommonStatusCodes.SUCCESS) {
                    Intent consent = extras.getParcelable(SmsRetriever.EXTRA_CONSENT_INTENT);
                    if (consent != null) {
                        try {
                            DiagnosticLog.log("SNS_OTP_CONSENT_PROMPT");
                            activity.startActivityForResult(consent, SMS_CONSENT_REQUEST);
                        } catch (Throwable t) {
                            DiagnosticLog.log("SNS_OTP_CONSENT_FAIL reason=" + t.getClass().getSimpleName());
                        }
                    }
                } else if (status.getStatusCode() == CommonStatusCodes.TIMEOUT) {
                    DiagnosticLog.log("SNS_OTP_LISTEN_TIMEOUT");
                    handler.postDelayed(() -> {
                        if (activeLoginDialog != null && activeLoginDialog.isShowing()) startSmsUserConsent();
                    }, 500L);
                }
            }
        };
        try {
            IntentFilter filter = new IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION);
            if (Build.VERSION.SDK_INT >= 33) {
                activity.registerReceiver(smsConsentReceiver, filter, SmsRetriever.SEND_PERMISSION, null, Context.RECEIVER_EXPORTED);
            } else {
                activity.registerReceiver(smsConsentReceiver, filter, SmsRetriever.SEND_PERMISSION, null);
            }
            smsReceiverRegistered = true;
            SmsRetriever.getClient(activity).startSmsUserConsent(null)
                    .addOnSuccessListener(unused -> DiagnosticLog.log("SNS_OTP_LISTEN_START"))
                    .addOnFailureListener(e -> DiagnosticLog.log("SNS_OTP_LISTEN_FAIL reason=" + e.getClass().getSimpleName()));
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_OTP_LISTEN_FAIL reason=" + t.getClass().getSimpleName());
            stopSmsUserConsent();
        }
    }

    private void stopSmsUserConsent() {
        if (smsReceiverRegistered && smsConsentReceiver != null) {
            try { activity.unregisterReceiver(smsConsentReceiver); } catch (Throwable ignored) {}
        }
        smsReceiverRegistered = false;
        smsConsentReceiver = null;
    }

    boolean onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != SMS_CONSENT_REQUEST) return false;
        if (resultCode == Activity.RESULT_OK && data != null) {
            String message = data.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE);
            String code = extractSixDigitCode(message);
            if (code != null) {
                DiagnosticLog.log("SNS_OTP_RECEIVED source=sms digits=6");
                injectOtpIntoActiveWebView(code, "sms");
            } else {
                DiagnosticLog.log("SNS_OTP_RECEIVED source=sms code=not_found");
            }
        } else {
            DiagnosticLog.log("SNS_OTP_CONSENT_CANCEL result=" + resultCode);
        }
        if (activeLoginDialog != null && activeLoginDialog.isShowing()) {
            handler.postDelayed(this::startSmsUserConsent, 500L);
        }
        return true;
    }

    private void pasteOtpFromClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = cm == null ? null : cm.getPrimaryClip();
            CharSequence value = clip == null || clip.getItemCount() == 0 ? null : clip.getItemAt(0).coerceToText(activity);
            String code = extractSixDigitCode(value == null ? null : value.toString());
            if (code == null) {
                Toast.makeText(activity, "クリップボードに6桁コードがありません", Toast.LENGTH_SHORT).show();
                DiagnosticLog.log("SNS_OTP_CLIPBOARD code=not_found");
                return;
            }
            DiagnosticLog.log("SNS_OTP_RECEIVED source=clipboard digits=6");
            injectOtpIntoActiveWebView(code, "clipboard");
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_OTP_CLIPBOARD_FAIL reason=" + t.getClass().getSimpleName());
            Toast.makeText(activity, "コードを貼り付けできませんでした", Toast.LENGTH_SHORT).show();
        }
    }

    private String extractSixDigitCode(String text) {
        if (text == null) return null;
        Matcher direct = Pattern.compile("(?<!\\d)(\\d{6})(?!\\d)").matcher(text);
        if (direct.find()) return direct.group(1);
        Matcher grouped = Pattern.compile("(?<!\\d)(\\d{3})[\\s\\-](\\d{3})(?!\\d)").matcher(text);
        if (grouped.find()) return grouped.group(1) + grouped.group(2);
        return null;
    }

    private WebView activeLoginWebView() {
        if (activeLoginStack == null || activeLoginStack.isEmpty()) return null;
        return activeLoginStack.get(activeLoginStack.size() - 1);
    }

    private void injectOtpIntoActiveWebView(String code, String source) {
        WebView webView = activeLoginWebView();
        if (webView == null || code == null || !code.matches("\\d{6}")) {
            DiagnosticLog.log("SNS_OTP_APPLY source=" + source + " result=no_active_webview");
            return;
        }
        String js = "(function(code){try{" +
                "var all=Array.from(document.querySelectorAll('input')).filter(function(e){var r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>1&&r.height>1&&s.display!='none'&&s.visibility!='hidden';});" +
                "function setv(e,v){var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');if(d&&d.set)d.set.call(e,v);else e.value=v;e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:v}));e.dispatchEvent(new Event('change',{bubbles:true}));}" +
                "var one=all.filter(function(e){return (e.maxLength===1)||(e.getAttribute('maxlength')==='1');});" +
                "if(one.length>=6){for(var i=0;i<6;i++)setv(one[i],code.charAt(i));one[5].focus();return 'split';}" +
                "var active=document.activeElement;if(active&&active.tagName==='INPUT'){setv(active,code);active.focus();return 'active';}" +
                "var cand=all.find(function(e){var a=((e.name||'')+' '+(e.id||'')+' '+(e.autocomplete||'')+' '+(e.placeholder||'')).toLowerCase();var ml=e.maxLength;return a.indexOf('otp')>=0||a.indexOf('code')>=0||a.indexOf('verification')>=0||a.indexOf('one-time-code')>=0||(ml>=4&&ml<=8);});" +
                "if(cand){setv(cand,code);cand.focus();return 'candidate';}return 'missing';}catch(e){return 'error';}})('" + code + "')";
        try {
            webView.evaluateJavascript(js, raw -> {
                String result = decodeJsString(raw);
                DiagnosticLog.log("SNS_OTP_APPLY source=" + source + " digits=6 result=" + result);
                if ("missing".equals(result) || "error".equals(result)) {
                    Toast.makeText(activity, "認証コード入力欄が見つかりません", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(activity, "6桁コードを入力しました", Toast.LENGTH_SHORT).show();
                    handler.postDelayed(() -> showImeIfHtmlEditorFocused(webView, activeLoginAccount), 80L);
                }
            });
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_OTP_APPLY_FAIL source=" + source + " reason=" + t.getClass().getSimpleName());
        }
    }

    private static boolean containsWebViewMarker(String ua) {
        if (ua == null) return false;
        String lower = ua.toLowerCase();
        return lower.contains("; wv)") || lower.contains(" version/4.0 ");
    }

    private static String browserLikeUserAgent(String ua) {
        if (ua == null || ua.trim().isEmpty()) return ua;
        String out = ua.replace("; wv)", ")");
        out = out.replaceAll("\\s+Version/4\\.0\\s+", " ");
        out = out.replaceAll("\\s{2,}", " ").trim();
        return out;
    }

    private void applyBrowserUaMetadata(WebSettings settings, String ua, SnsAccountManager.Service service) {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.USER_AGENT_METADATA)) {
                DiagnosticLog.log("SNS_LOGIN_UACH service=" + service.label + " supported=false");
                return;
            }
            Matcher m = Pattern.compile("Chrome/([0-9]+(?:\\.[0-9]+){0,3})").matcher(ua == null ? "" : ua);
            if (!m.find()) {
                DiagnosticLog.log("SNS_LOGIN_UACH service=" + service.label + " supported=true chromeVersion=missing");
                return;
            }
            String full = m.group(1);
            String major = full.contains(".") ? full.substring(0, full.indexOf('.')) : full;
            ArrayList<UserAgentMetadata.BrandVersion> brands = new ArrayList<>();
            brands.add(new UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Chromium").setMajorVersion(major).setFullVersion(full).build());
            brands.add(new UserAgentMetadata.BrandVersion.Builder()
                    .setBrand("Google Chrome").setMajorVersion(major).setFullVersion(full).build());
            UserAgentMetadata metadata = new UserAgentMetadata.Builder()
                    .setBrandVersionList(brands)
                    .setFullVersion(full)
                    .setPlatform("Android")
                    .setPlatformVersion(Build.VERSION.RELEASE == null ? "" : Build.VERSION.RELEASE)
                    .setModel(Build.MODEL == null ? "" : Build.MODEL)
                    .setMobile(true)
                    .build();
            WebSettingsCompat.setUserAgentMetadata(settings, metadata);
            DiagnosticLog.log("SNS_LOGIN_UACH service=" + service.label + " chrome=" + full + " platform=Android");
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_LOGIN_UACH_FAIL service=" + service.label + " reason=" + t.getClass().getSimpleName());
        }
    }

    private void scheduleLoginDomChecks(WebView view, SnsAccountManager.Account account,
                                        TextView header, boolean[] blankFallbackTried) {
        String url = view == null ? null : view.getUrl();
        String previous = domChecksScheduledForUrl.get(view);
        if (url != null && url.equals(previous)) return;
        domChecksScheduledForUrl.put(view, url == null ? "" : url);
        long[] delays = {700L, 1800L, 4000L};
        for (int i = 0; i < delays.length; i++) {
            final int pass = i + 1;
            handler.postDelayed(() -> inspectLoginDom(view, account, header, blankFallbackTried, pass), delays[i]);
        }
    }

    private void inspectLoginDom(WebView view, SnsAccountManager.Account account,
                                 TextView header, boolean[] blankFallbackTried, int pass) {
        if (view == null || view.getParent() == null) return;
        String js = "(function(){try{" +
                "var vis=function(e){try{var r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>1&&r.height>1&&s.display!='none'&&s.visibility!='hidden'&&s.opacity!='0'}catch(x){return false}};" +
                "var ins=Array.from(document.querySelectorAll('input'));" +
                "return [document.readyState,ins.length,ins.filter(vis).length,document.querySelectorAll('button,[role=button]').length,document.querySelectorAll('form').length,(document.body&&document.body.innerText?document.body.innerText.length:0),(document.documentElement?document.documentElement.scrollWidth:0),(document.documentElement?document.documentElement.scrollHeight:0)].join('|');" +
                "}catch(e){return 'error|0|0|0|0|0|0|0';}})()";
        try {
            view.evaluateJavascript(js, raw -> {
                String value = decodeJsString(raw);
                String current = view.getUrl();
                DiagnosticLog.log("SNS_LOGIN_DOM service=" + account.service.label
                        + " profile=" + account.profileName + " pass=" + pass
                        + " data=" + value + " url=" + current);
                if (accounts.isLoggedIn(account)) return;
                String[] parts = value == null ? new String[0] : value.split("\\|", -1);
                int visibleInputs = parseIntPart(parts, 2);
                int buttons = parseIntPart(parts, 3);
                int forms = parseIntPart(parts, 4);
                int bodyLength = parseIntPart(parts, 5);
                boolean looksBlank = visibleInputs == 0 && forms == 0 && buttons == 0 && bodyLength < 800;
                if (pass == 3 && looksBlank && isOwnLoginHost(account.service, current) && !blankFallbackTried[0]) {
                    blankFallbackTried[0] = true;
                    String fallback = account.service == SnsAccountManager.Service.X
                            ? "https://mobile.x.com/login"
                            : "https://www.instagram.com/accounts/login/?next=%2F&source=auth_switcher";
                    DiagnosticLog.log("SNS_LOGIN_BLANK_FALLBACK service=" + account.service.label
                            + " profile=" + account.profileName + " url=" + fallback);
                    header.setText(account.service.label + " ログイン再読込");
                    view.loadUrl(fallback);
                }
            });
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_LOGIN_DOM_FAIL service=" + account.service.label
                    + " profile=" + account.profileName + " reason=" + t.getClass().getSimpleName());
        }
    }

    private static boolean isOwnLoginHost(SnsAccountManager.Service service, String url) {
        if (url == null) return false;
        try {
            String host = Uri.parse(url).getHost();
            if (host == null) return false;
            host = host.toLowerCase();
            if (service == SnsAccountManager.Service.X) {
                return host.equals("x.com") || host.endsWith(".x.com")
                        || host.equals("twitter.com") || host.endsWith(".twitter.com");
            }
            return host.equals("instagram.com") || host.endsWith(".instagram.com");
        } catch (Throwable t) {
            return false;
        }
    }

    private static int parseIntPart(String[] parts, int index) {
        if (parts == null || index < 0 || index >= parts.length) return 0;
        try { return Integer.parseInt(parts[index]); } catch (Throwable ignored) { return 0; }
    }

    private static String decodeJsString(String raw) {
        if (raw == null || "null".equals(raw)) return "";
        String out = raw;
        if (out.length() >= 2 && out.charAt(0) == '"' && out.charAt(out.length() - 1) == '"') {
            out = out.substring(1, out.length() - 1);
            out = out.replace("\\\\", "\\").replace("\\\"", "\"");
        }
        return out;
    }

    private boolean handleLoginNavigation(WebView view, String url, SnsAccountManager.Account account) {
        if (url == null || url.trim().isEmpty()) return false;
        Uri uri;
        try {
            uri = Uri.parse(url);
        } catch (Throwable t) {
            return false;
        }
        String scheme = uri.getScheme();
        if (scheme == null || "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)
                || "about".equalsIgnoreCase(scheme) || "javascript".equalsIgnoreCase(scheme)) {
            return false;
        }

        DiagnosticLog.log("SNS_LOGIN_EXTERNAL service=" + account.service.label + " scheme=" + scheme + " url=" + url);
        if ("intent".equalsIgnoreCase(scheme)) {
            try {
                Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                String fallback = intent.getStringExtra("browser_fallback_url");
                if (fallback != null && (fallback.startsWith("https://") || fallback.startsWith("http://"))) {
                    view.loadUrl(fallback);
                    DiagnosticLog.log("SNS_LOGIN_INTENT_FALLBACK service=" + account.service.label + " url=" + fallback);
                    return true;
                }
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setComponent(null);
                intent.setSelector(null);
                activity.startActivity(intent);
                return true;
            } catch (Throwable t) {
                DiagnosticLog.log("SNS_LOGIN_INTENT_FAIL service=" + account.service.label + " reason=" + t.getClass().getSimpleName());
                return true;
            }
        }

        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_LOGIN_EXTERNAL_FAIL service=" + account.service.label
                    + " scheme=" + scheme + " reason=" + t.getClass().getSimpleName());
        }
        return true;
    }

    private void closeLoginWebView(WebView webView, FrameLayout host, ArrayList<WebView> stack) {
        if (webView == null) return;
        try { host.removeView(webView); } catch (Throwable ignored) {}
        stack.remove(webView);
        try { webView.stopLoading(); } catch (Throwable ignored) {}
        try { webView.setWebChromeClient(null); } catch (Throwable ignored) {}
        try { webView.setWebViewClient(null); } catch (Throwable ignored) {}
        domChecksScheduledForUrl.remove(webView);
        try { webView.destroy(); } catch (Throwable ignored) {}
    }

    private void destroyLoginStack(FrameLayout host, ArrayList<WebView> stack) {
        if (stack == null || stack.isEmpty()) return;
        ArrayList<WebView> copy = new ArrayList<>(stack);
        for (int i = copy.size() - 1; i >= 0; i--) closeLoginWebView(copy.get(i), host, stack);
    }

    private void applySensitiveForAllX() {
        ArrayList<SnsAccountManager.Account> list = new ArrayList<>();
        for (SnsAccountManager.Account a : accounts.getAccounts(SnsAccountManager.Service.X)) {
            if (accounts.isLoggedIn(a)) list.add(a);
        }
        if (list.isEmpty()) {
            Toast.makeText(activity, "ログイン済みXアカウントがありません", Toast.LENGTH_SHORT).show();
            return;
        }
        DiagnosticLog.log("X_SENSITIVE_ALL_START count=" + list.size());

        LinearLayout panel = new LinearLayout(activity);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(16), dp(16), dp(16));
        panel.setBackgroundColor(BG);
        TextView title = text("X センシティブ表示", 20, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView status = text("開始します…", 13, N_WHITE);
        panel.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        panel.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));
        FrameLayout webHost = new FrameLayout(activity);
        panel.addView(webHost, new LinearLayout.LayoutParams(1, 1));
        AlertDialog progress = new AlertDialog.Builder(activity).setView(panel).create();
        progress.setCanceledOnTouchOutside(false);
        progress.show();
        if (progress.getWindow() != null) progress.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        runSensitiveAccount(list, 0, status, webHost, progress, 0);
    }

    private void runSensitiveAccount(List<SnsAccountManager.Account> list, int index, TextView status,
                                     FrameLayout host, AlertDialog dialog, int okCount) {
        if (index >= list.size()) {
            DiagnosticLog.log("X_SENSITIVE_ALL_DONE success=" + okCount + " total=" + list.size());
            status.setText("完了  " + okCount + "/" + list.size());
            handler.postDelayed(() -> {
                if (dialog.isShowing()) dialog.dismiss();
                Toast.makeText(activity, "X設定 " + okCount + "/" + list.size() + " 完了", Toast.LENGTH_SHORT).show();
            }, 900L);
            return;
        }
        SnsAccountManager.Account account = list.get(index);
        status.setText(account.displayName() + "  設定中…");
        DiagnosticLog.log("X_SENSITIVE_ACCOUNT_START profile=" + account.profileName);

        WebView w = new WebView(activity);
        accounts.applyProfile(w, account.profileName);
        w.getSettings().setJavaScriptEnabled(true);
        w.getSettings().setDomStorageEnabled(true);
        w.getSettings().setDatabaseEnabled(true);
        accounts.prepareLoginCookies(w, account.profileName);
        host.removeAllViews();
        host.addView(w, new FrameLayout.LayoutParams(1, 1));
        final boolean[] contentDone = {false};
        final boolean[] searchDone = {false};
        final int[] retry = {0};

        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (url == null) return;
                if (url.contains("/settings/content_you_see") && !contentDone[0]) {
                    handler.postDelayed(() -> applyContentToggle(view, result -> {
                        if ("missing".equals(result) && retry[0]++ < 3) {
                            view.reload();
                            return;
                        }
                        contentDone[0] = true;
                        DiagnosticLog.log("X_SENSITIVE_CONTENT profile=" + account.profileName + " result=" + result);
                        retry[0] = 0;
                        view.loadUrl("https://x.com/settings/search");
                    }), 1200L);
                } else if (url.contains("/settings/search") && contentDone[0] && !searchDone[0]) {
                    handler.postDelayed(() -> applySearchToggle(view, result -> {
                        if ("missing".equals(result) && retry[0]++ < 3) {
                            view.reload();
                            return;
                        }
                        searchDone[0] = true;
                        DiagnosticLog.log("X_SENSITIVE_SEARCH profile=" + account.profileName + " result=" + result);
                        boolean success = !"missing".equals(result);
                        try { view.stopLoading(); view.destroy(); } catch (Throwable ignored) {}
                        runSensitiveAccount(list, index + 1, status, host, dialog, okCount + (success ? 1 : 0));
                    }), 1200L);
                }
            }
        });
        w.loadUrl("https://x.com/settings/content_you_see");

        handler.postDelayed(() -> {
            if (!searchDone[0] && dialog.isShowing()) {
                searchDone[0] = true;
                DiagnosticLog.log("X_SENSITIVE_TIMEOUT profile=" + account.profileName);
                try { w.stopLoading(); w.destroy(); } catch (Throwable ignored) {}
                runSensitiveAccount(list, index + 1, status, host, dialog, okCount);
            }
        }, 25000L);
    }

    private interface JsResult { void done(String result); }

    private void applyContentToggle(WebView w, JsResult callback) {
        String js = "(function(){"
                + "function txt(e){return ((e&&e.innerText)||'').toLowerCase();}"
                + "var all=[].slice.call(document.querySelectorAll('input[type=checkbox],[role=checkbox]'));"
                + "for(var i=0;i<all.length;i++){var c=all[i],p=c.closest('label,div');var t=txt(p);"
                + "if(t.indexOf('sensitive')>=0||t.indexOf('センシティブ')>=0){"
                + "var checked=(c.checked===true)||(c.getAttribute('aria-checked')==='true');"
                + "if(!checked){c.click();return 'changed';}return 'already';}}return 'missing';})()";
        w.evaluateJavascript(js, value -> callback.done(cleanJsResult(value)));
    }

    private void applySearchToggle(WebView w, JsResult callback) {
        String js = "(function(){"
                + "function txt(e){return ((e&&e.innerText)||'').toLowerCase();}"
                + "var all=[].slice.call(document.querySelectorAll('input[type=checkbox],[role=checkbox]'));"
                + "for(var i=0;i<all.length;i++){var c=all[i],p=c.closest('label,div');var t=txt(p);"
                + "if((t.indexOf('hide')>=0&&t.indexOf('sensitive')>=0)||(t.indexOf('センシティブ')>=0&&t.indexOf('表示しない')>=0)){"
                + "var checked=(c.checked===true)||(c.getAttribute('aria-checked')==='true');"
                + "if(checked){c.click();return 'changed';}return 'already';}}return 'missing';})()";
        w.evaluateJavascript(js, value -> callback.done(cleanJsResult(value)));
    }

    private String cleanJsResult(String value) {
        if (value == null) return "missing";
        String s = value.replace("\\\"", "\"").replace("\"", "").trim();
        if (s.contains("changed")) return "changed";
        if (s.contains("already")) return "already";
        return "missing";
    }

    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(activity);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        return t;
    }

    private Button button(String value, int bg) {
        Button b = new Button(activity);
        b.setText(value);
        b.setTextColor(TEXT_WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(rounded(bg, 20));
        b.setElevation(0f);
        b.setStateListAnimator(null);
        return b;
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(float value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }
}
