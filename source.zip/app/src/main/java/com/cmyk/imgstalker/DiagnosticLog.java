package com.cmyk.imgstalker;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class DiagnosticLog {
    private static final Object LOCK = new Object();
    private static final long MAX_FILE = 768L * 1024L;
    private static Context appContext;
    private static File logFile;
    private static boolean installed;

    private DiagnosticLog() {}

    public static void install(Context context) {
        synchronized (LOCK) {
            if (appContext == null) {
                appContext = context.getApplicationContext();
                logFile = new File(appContext.getFilesDir(), "imgstalker_diagnostic.log");
            }
            if (!installed) {
                installed = true;
                Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
                Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
                    logException("UNCAUGHT thread=" + thread.getName(), error);
                    if (previous != null) previous.uncaughtException(thread, error);
                });
                log("APP_PROCESS_START");
            }
        }
    }

    public static void log(String message) {
        if (message == null) message = "null";
        synchronized (LOCK) {
            if (logFile == null) return;
            try {
                if (logFile.exists() && logFile.length() > MAX_FILE) {
                    clearLocked();
                }
                String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
                String line = time + " " + message + "\n";
                try (FileOutputStream out = new FileOutputStream(logFile, true)) {
                    out.write(line.getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) {}
        }
    }

    public static void logException(String prefix, Throwable error) {
        StringBuilder b = new StringBuilder(prefix == null ? "ERROR" : prefix);
        if (error != null) {
            b.append(" | ").append(error.getClass().getSimpleName());
            if (error.getMessage() != null) b.append(": ").append(error.getMessage());
            StackTraceElement[] stack = error.getStackTrace();
            int n = Math.min(stack == null ? 0 : stack.length, 8);
            for (int i = 0; i < n; i++) b.append("\n    at ").append(stack[i]);
        }
        log(b.toString());
    }

    public static void clear() {
        synchronized (LOCK) {
            clearLocked();
        }
    }

    private static void clearLocked() {
        if (logFile == null) return;
        try (FileOutputStream out = new FileOutputStream(logFile, false)) {
            out.write(new byte[0]);
        } catch (Exception ignored) {}
    }

    public static String report(Context context) {
        install(context);
        String versionName = "?";
        long versionCode = -1;
        try {
            PackageInfo p = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            versionName = p.versionName == null ? "?" : p.versionName;
            versionCode = p.getLongVersionCode();
        } catch (Exception e) {
            logException("PACKAGE_INFO_FAIL", e);
        }

        StringBuilder out = new StringBuilder();
        out.append("ImgStalker diagnostic report\n");
        out.append("Generated: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date())).append('\n');
        out.append("Device: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n');
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("App: ").append(versionName).append(" (").append(versionCode).append(")\n\n");
        out.append("--- LOG ---\n");
        out.append(readLog());
        return out.toString();
    }

    private static String readLog() {
        synchronized (LOCK) {
            if (logFile == null || !logFile.exists()) return "(empty)\n";
            try (FileInputStream in = new FileInputStream(logFile)) {
                long length = logFile.length();
                int wanted = (int) Math.min(length, MAX_FILE);
                byte[] bytes = new byte[wanted];
                if (length > wanted) {
                    long skip = length - wanted;
                    while (skip > 0) {
                        long s = in.skip(skip);
                        if (s <= 0) break;
                        skip -= s;
                    }
                }
                int off = 0;
                while (off < bytes.length) {
                    int n = in.read(bytes, off, bytes.length - off);
                    if (n < 0) break;
                    off += n;
                }
                return new String(bytes, 0, off, StandardCharsets.UTF_8);
            } catch (Exception e) {
                return "(log read failed: " + e.getClass().getSimpleName() + ")\n";
            }
        }
    }
}
