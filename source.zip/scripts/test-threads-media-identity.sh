#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
DIR=$(mktemp -d);trap 'rm -rf "$DIR"' EXIT
javac -encoding UTF-8 -d "$DIR" app/src/main/java/com/cmyk/imgstalker/{MediaItem,ThreadsMediaIdentity}.java tests/ThreadsMediaIdentityTest.java
java -cp "$DIR" com.cmyk.imgstalker.ThreadsMediaIdentityTest
