package com.cmyk.imgstalker;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

public final class DiagnosticShareProvider extends ContentProvider {
    @Override public boolean onCreate() {
        return true;
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        if (getContext() == null) throw new FileNotFoundException("context unavailable");
        String name = uri == null ? null : uri.getLastPathSegment();
        if (name == null || name.isEmpty() || name.contains("/") || name.contains("\\") || name.contains("..")) {
            throw new FileNotFoundException("invalid diagnostic file");
        }
        File dir = new File(getContext().getCacheDir(), "diagnostic_share");
        File file = new File(dir, name);
        try {
            String dirPath = dir.getCanonicalPath() + File.separator;
            String filePath = file.getCanonicalPath();
            if (!filePath.startsWith(dirPath) || !file.isFile()) {
                throw new FileNotFoundException("diagnostic file not found");
            }
        } catch (java.io.IOException e) {
            FileNotFoundException x = new FileNotFoundException("invalid diagnostic path");
            x.initCause(e);
            throw x;
        }
        return file;
    }

    @Override public String getType(Uri uri) {
        return "text/plain";
    }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (mode == null || !mode.startsWith("r")) throw new FileNotFoundException("read only");
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection,
                                  String[] selectionArgs, String sortOrder) {
        try {
            File file = resolve(uri);
            String[] cols = projection;
            if (cols == null || cols.length == 0) {
                cols = new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
            }
            MatrixCursor cursor = new MatrixCursor(cols);
            MatrixCursor.RowBuilder row = cursor.newRow();
            for (String col : cols) {
                if (OpenableColumns.DISPLAY_NAME.equals(col)) row.add(file.getName());
                else if (OpenableColumns.SIZE.equals(col)) row.add(file.length());
                else row.add(null);
            }
            return cursor;
        } catch (Exception e) {
            return new MatrixCursor(projection == null
                    ? new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}
                    : projection);
        }
    }

    @Override public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("read only");
    }

    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }
}
