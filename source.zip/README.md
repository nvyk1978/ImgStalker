# ImgStalker v0.1.83 (84)

Android 16 / SDK 36 source package for ImgStalker.

## v0.1.83 — Instagram Web Source Pipeline v3

Instagram normal analysis no longer uses WebView navigation, profile scrolling, post tapping, carousel next-button clicks, SPA back/restore, private/mobile profile-feed discovery, or private media-info as its primary path.

Pipeline:
- Fetch profile HTML source first.
- Reuse fresh web context from the source (LSD / fb_dtsg / CSRF when supplied).
- Discover and queue any post/reel shortcodes already embedded in the profile source before requesting another page.
- Continue discovery only through the www.instagram.com Web GraphQL doc_id surface.
- Attempt to discover the profile timeline doc_id from the current profile source; use a retained web-only fallback candidate only when the source does not expose one.
- Resolve each queued post from its HTML source and current web GraphQL post metadata (PolarisPostRootQuery doc_id family).
- Keep Discovery and Resolver as separate ordered producer/consumer stages; downloading continues in discovered order through the existing UI/downloader path.

Anti-spam handling:
- `{"spam":true,"status":"fail"}`, sentry block, rate-limit error, feedback/challenge/checkpoint responses are not treated as ordinary HTTP 400 fallbacks.
- A spam gate immediately stops the Instagram pipeline instead of trying another profile-feed endpoint.
- 429 continues to honor Retry-After/shared request gating.
- Diagnostic HTTP body logging remains redacted and capped.

Resume behavior:
- Discovered posts are checkpointed as they enter the ordered queue.
- Individual non-gate post failures still defer once and then remain retryable/skippable by resume.
- A global spam/auth gate terminates the session so later resume can continue without hammering alternate endpoints.

Package: versionName 0.1.83 / versionCode 84.
