package com.cmyk.imgstalker;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;
import android.webkit.WebView;

import androidx.webkit.Profile;
import androidx.webkit.ProfileStore;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class SnsAccountManager {
    public enum Service {
        X("x", "X", "https://x.com/login", "https://x.com", "auth_token="),
        INSTAGRAM("ig", "Instagram", "https://www.instagram.com/accounts/login/?next=%2F", "https://www.instagram.com", "sessionid=");

        final String key;
        final String label;
        final String loginUrl;
        final String cookieUrl;
        final String authCookieMarker;

        Service(String key, String label, String loginUrl, String cookieUrl, String authCookieMarker) {
            this.key = key;
            this.label = label;
            this.loginUrl = loginUrl;
            this.cookieUrl = cookieUrl;
            this.authCookieMarker = authCookieMarker;
        }
    }

    public static final class Account {
        public final Service service;
        public final String profileName;
        public final int order;

        Account(Service service, String profileName, int order) {
            this.service = service;
            this.profileName = profileName;
            this.order = order;
        }

        public String displayName() {
            return service.label + " " + order;
        }
    }

    private static final String PREFS = "sns_accounts";
    private final Context appContext;
    private final SharedPreferences prefs;

    public SnsAccountManager(Context context) {
        appContext = context.getApplicationContext();
        prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean supportsMultiProfile() {
        try {
            return WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE);
        } catch (Throwable t) {
            return false;
        }
    }

    public List<Account> getAccounts(Service service) {
        String raw = prefs.getString(service.key + "_profiles", "");
        if (raw == null || raw.trim().isEmpty()) return Collections.emptyList();
        ArrayList<Account> out = new ArrayList<>();
        int order = 1;
        for (String p : raw.split("\\n")) {
            String profile = p.trim();
            if (!profile.isEmpty()) out.add(new Account(service, profile, order++));
        }
        return out;
    }

    public Account allocateAccount(Service service) {
        List<Account> current = getAccounts(service);
        if (!supportsMultiProfile() && !current.isEmpty()) return current.get(0);
        if (!supportsMultiProfile()) return new Account(service, Profile.DEFAULT_PROFILE_NAME, 1);

        // Reuse the smallest uncommitted slot. A failed login no longer leaves x_01, x_02, ...
        // profiles growing forever; once x_01 is committed, the next account becomes x_02.
        int serial = 1;
        while (true) {
            String candidate = String.format("imgstalker_%s_%02d", service.key, serial);
            boolean used = false;
            for (Account a : current) {
                if (candidate.equals(a.profileName)) { used = true; break; }
            }
            if (!used) return new Account(service, candidate, current.size() + 1);
            serial++;
        }
    }

    public boolean isCommitted(Account account) {
        if (account == null) return false;
        for (Account a : getAccounts(account.service)) {
            if (a.profileName.equals(account.profileName)) return true;
        }
        return false;
    }

    public void discardUncommitted(Account account) {
        if (account == null || isCommitted(account)) return;
        if (supportsMultiProfile() && !Profile.DEFAULT_PROFILE_NAME.equals(account.profileName)) {
            try {
                ProfileStore.getInstance().deleteProfile(account.profileName);
                DiagnosticLog.log("SNS_PROFILE_DISCARD profile=" + account.profileName);
            } catch (Throwable t) {
                DiagnosticLog.log("SNS_PROFILE_DISCARD_DEFERRED profile=" + account.profileName
                        + " reason=" + t.getClass().getSimpleName());
            }
        }
    }

    public void commitAccount(Account account) {
        List<Account> current = getAccounts(account.service);
        for (Account a : current) if (a.profileName.equals(account.profileName)) return;
        StringBuilder sb = new StringBuilder();
        for (Account a : current) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(a.profileName);
        }
        if (sb.length() > 0) sb.append('\n');
        sb.append(account.profileName);
        prefs.edit().putString(account.service.key + "_profiles", sb.toString()).apply();
    }

    public void removeAccount(Account target) {
        List<Account> current = getAccounts(target.service);
        StringBuilder sb = new StringBuilder();
        for (Account a : current) {
            if (a.profileName.equals(target.profileName)) continue;
            if (sb.length() > 0) sb.append('\n');
            sb.append(a.profileName);
        }
        prefs.edit().putString(target.service.key + "_profiles", sb.toString()).apply();
        if (supportsMultiProfile() && !Profile.DEFAULT_PROFILE_NAME.equals(target.profileName)) {
            try {
                ProfileStore.getInstance().deleteProfile(target.profileName);
            } catch (Throwable t) {
                DiagnosticLog.log("SNS_PROFILE_DELETE_DEFERRED profile=" + target.profileName + " reason=" + t.getClass().getSimpleName());
            }
        }
    }

    public void applyProfile(WebView webView, String profileName) {
        if (webView == null || profileName == null || profileName.isEmpty()) return;
        if (!supportsMultiProfile() || Profile.DEFAULT_PROFILE_NAME.equals(profileName)) return;
        WebViewCompat.setProfile(webView, profileName);
    }

    public CookieManager cookieManager(String profileName) {
        try {
            if (supportsMultiProfile() && profileName != null && !profileName.isEmpty()) {
                return ProfileStore.getInstance().getOrCreateProfile(profileName).getCookieManager();
            }
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_COOKIE_MANAGER_FALLBACK profile=" + profileName + " reason=" + t.getClass().getSimpleName());
        }
        return CookieManager.getInstance();
    }


    public void prepareLoginCookies(WebView webView, String profileName) {
        if (webView == null) return;
        try {
            CookieManager manager = cookieManager(profileName);
            manager.setAcceptCookie(true);
            manager.setAcceptThirdPartyCookies(webView, true);
            DiagnosticLog.log("SNS_COOKIE_POLICY profile=" + profileName + " accept=true thirdParty=true");
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_COOKIE_POLICY_FAIL profile=" + profileName + " reason=" + t.getClass().getSimpleName());
        }
    }

    public void flushCookies(String profileName) {
        try {
            cookieManager(profileName).flush();
            DiagnosticLog.log("SNS_COOKIE_FLUSH profile=" + profileName);
        } catch (Throwable t) {
            DiagnosticLog.log("SNS_COOKIE_FLUSH_FAIL profile=" + profileName + " reason=" + t.getClass().getSimpleName());
        }
    }

    public boolean isLoggedIn(Account account) {
        try {
            String cookies = cookieManager(account.profileName).getCookie(account.service.cookieUrl);
            return cookies != null && cookies.contains(account.service.authCookieMarker);
        } catch (Throwable t) {
            return false;
        }
    }

    public String getCookie(String profileName, String url) {
        try {
            String value = cookieManager(profileName).getCookie(url);
            return value == null ? "" : value;
        } catch (Throwable t) {
            return "";
        }
    }

    public Service serviceForUrl(String value) {
        if (value == null) return null;
        String lower = value.toLowerCase();
        if (lower.contains("x.com/") || lower.contains("twitter.com/")) return Service.X;
        if (lower.contains("instagram.com/")) return Service.INSTAGRAM;
        return null;
    }
}
