#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PY'
from pathlib import Path
root=Path('app/src/main/java/com/cmyk/imgstalker')
activity=(root/'MainActivity.java').read_text()
queue=(root/'SnsThumbnailWorkQueue.java').read_text()
policy=(root/'SnsThumbnailSweepPolicy.java').read_text()
assert 'SNS_THUMB_BACKGROUND_MAX_PENDING = 2' in activity
assert 'snsThumbnailWorkQueue.offer(key)' in activity
assert 'snsThumbnailWorkQueue.poll()' in activity
assert 'snsThumbnailWorkQueue.clear()' in activity
assert 'if (!snsThumbnailQueueSeeded) seedSnsThumbnailWorkQueue();' in activity
assert 'snsThumbnailSweepCursor' not in activity
assert 'snsThumbnailSweepPassScanned' not in activity
assert 'Math.min(snsThumbnailSweepCursor, insertIndex)' not in activity
assert 'reconcileSnsThumbnailInFlight(now)' in activity
assert 'recordResult(key, false, now)' in activity
assert 'recordResult(key, true, now)' in activity
assert 'snsThumbnailSweepPolicy.recordStart(key)' in activity
assert 'snsThumbnailSweepPolicy.canAttempt(key, now)' in activity
assert 'snsThumbnailWorkQueue.offer(key)' in activity
assert 'snsThumbnailWorkQueue.remove(thumbKey)' in activity
assert 'scheduleSnsThumbnailSweep("resume_restore")' in activity
assert 'scheduleSnsThumbnailSweep("activity_resume")' in activity
assert 'scheduleSnsThumbnailSweep("continue_reload")' in activity
assert 'prefetchSnsThumbnailWindow(firstVisibleItem, visibleItemCount)' in activity
assert 'lastFailure.put(key, now)' in policy
assert 'HashSet<String> present' in queue
assert 'ArrayDeque<String> keys' in queue
assert 'versionCode 175' in Path('app/build.gradle').read_text()
assert "versionName '0.1.174'" in Path('app/build.gradle').read_text()
print('PASS: stable-key queue integration and no cursor rewind')
PY
bash scripts/test-sns-thumbnail-runner-174.sh
