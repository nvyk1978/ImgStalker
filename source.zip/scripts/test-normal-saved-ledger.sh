#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/content" "$TMP/src/android/util" "$TMP/src/org/json" "$TMP/src/com/cmyk/imgstalker" "$TMP/classes" "$TMP/app"
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content;
import java.io.File;
public class Context {
    private final File files;
    public Context(File files) { this.files = files; files.mkdirs(); }
    public File getFilesDir() { return files; }
}
JAVA
cat > "$TMP/src/android/util/AtomicFile.java" <<'JAVA'
package android.util;
import java.io.*;
public class AtomicFile {
    private final File file;
    public AtomicFile(File file) { this.file = file; }
    public FileInputStream openRead() throws IOException { return new FileInputStream(file); }
    public FileOutputStream startWrite() throws IOException {
        File dir=file.getParentFile(); if (!dir.isDirectory()) dir.mkdirs();
        return new FileOutputStream(file);
    }
    public void finishWrite(FileOutputStream stream) throws IOException { stream.close(); }
    public void failWrite(FileOutputStream stream) throws IOException { stream.close(); }
}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" <<'JAVA'
package com.cmyk.imgstalker;
final class DiagnosticLog {
    static void log(String s) {}
    static void logException(String s, Throwable t) { throw new AssertionError(s,t); }
}
JAVA
# Minimal org.json compatibility stub for deterministic host test; Android supplies the real JSON classes.
cat > "$TMP/src/org/json/JSONArray.java" <<'JAVA'
package org.json;
import java.util.*;
public class JSONArray {
    final ArrayList<String> list = new ArrayList<>();
    public JSONArray() {}
    public JSONArray(String raw) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\\"([^\\\"]*)\\\"").matcher(raw);
        while(m.find()) list.add(m.group(1));
    }
    public JSONArray put(Object value) { list.add(value.toString()); return this; }
    public int length() { return list.size(); }
    public String optString(int i, String fallback) { return i>=0 && i<list.size()?list.get(i):fallback; }
    public String toString() {
        ArrayList<String> encoded = new ArrayList<>();
        for(String k:list)encoded.add("\""+k.replace("\\","\\\\").replace("\"","\\\"")+"\"");
        return "["+String.join(",",encoded)+"]";
    }
}
JAVA
cat > "$TMP/src/org/json/JSONObject.java" <<'JAVA'
package org.json;
import java.util.*;
public class JSONObject {
    private final LinkedHashMap<String,Object> data = new LinkedHashMap<>();
    public JSONObject() {}
    public JSONObject(String input) {
        java.util.regex.Matcher field=java.util.regex.Pattern.compile("\\\"(schema|mode|target|updated_at)\\\"\\s*:\\s*(\\\"[^\\\"]*\\\"|[0-9]+)").matcher(input);
        while(field.find()) {
            String value=field.group(2);
            if(value.startsWith("\""))data.put(field.group(1),value.substring(1,value.length()-1));
            else data.put(field.group(1),Long.parseLong(value));
        }
        java.util.regex.Matcher array=java.util.regex.Pattern.compile("\\\"saved_media_keys\\\"\\s*:\\s*(\\[[^]]*\\])").matcher(input);
        if(array.find())data.put("saved_media_keys",new JSONArray(array.group(1)));
    }
    public JSONObject put(String k,Object value) { data.put(k,value); return this; }
    public int optInt(String k,int fallback) { Object o=data.get(k); return o instanceof Number?((Number)o).intValue():fallback; }
    public String optString(String k,String fallback) { Object o=data.get(k); return o==null?fallback:o.toString(); }
    public JSONArray optJSONArray(String k) { Object o=data.get(k); return o instanceof JSONArray?(JSONArray)o:null; }
    public String toString() {
        ArrayList<String> fields=new ArrayList<>();
        for(Map.Entry<String,Object> e:data.entrySet()) {
            Object v=e.getValue();
            fields.add("\""+e.getKey()+"\":"+(v instanceof String ? "\""+v+"\"" : v.toString()));
        }
        return "{"+String.join(",",fields)+"}";
    }
}
JAVA
javac -encoding UTF-8 -d "$TMP/classes" \
    "$TMP/src/android/content/Context.java" \
    "$TMP/src/android/util/AtomicFile.java" \
    "$TMP/src/org/json/JSONObject.java" "$TMP/src/org/json/JSONArray.java" \
    "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" \
    app/src/main/java/com/cmyk/imgstalker/AnalysisModeRouter.java \
    app/src/main/java/com/cmyk/imgstalker/NormalCheckpointStore.java \
    app/src/main/java/com/cmyk/imgstalker/MediaItem.java \
    app/src/main/java/com/cmyk/imgstalker/NormalSavedLedgerStore.java \
    tests/NormalSavedLedgerTest.java
java -cp "$TMP/classes" com.cmyk.imgstalker.NormalSavedLedgerTest "$TMP/app"
