package com.cmyk.imgstalker;
import java.util.List;
import android.webkit.WebView;

/** Original v0.1.92 provider engine, confined to one host class and one WebView. */
final class NormalCrawlerAdapter implements ModeCrawler {
    private final NormalCrawlerEngine core;
    NormalCrawlerAdapter(WebView view, CrawlerEngine.Listener listener) { core = new NormalCrawlerEngine(view, listener); }
    @Override public void start(String url, boolean pages, boolean details, boolean intelligent, boolean images, boolean videos, int px) {
        if (AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.NORMAL) { core.cancel(); throw new IllegalArgumentException("NORMAL crawler refused foreign host"); }
        // v0.1.92 did not have the v0.1.135 intelligent flag; retain its original traversal semantics.
        core.start(url, pages, details, images, videos, px);
    }
    @Override public void cancel(){core.cancel();}
    @Override public void requestGracefulStop(){core.requestGracefulStop();}
    @Override public boolean recoverFromStall(){return core.recoverFromStall();}
    @Override public boolean hasPendingWork(){return core.hasPendingWork();}
    @Override public String progressSnapshot(){return core.progressSnapshot();}
    @Override public void seedExternalResumeMedia(List<MediaItem> items){core.seedExternalResumeMedia(items);}
    @Override public void seedContinuationResults(List<MediaItem> items){core.seedContinuationResults(items);}
    @Override public boolean isIncompleteCompletion(){return core.isIncompleteCompletion();}
    @Override public String getIncompleteCompletionReason(){return core.getIncompleteCompletionReason();}
}
