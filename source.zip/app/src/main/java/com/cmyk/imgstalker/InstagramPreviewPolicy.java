package com.cmyk.imgstalker;

/** Instagram-owned preview identity: no X URL rewriting or X failure cache is reachable. */
final class InstagramPreviewPolicy implements ModePreviewPolicy {
    @Override public boolean isSpecialVideo(String url) { return false; }
    @Override public boolean isKnownFailed(String url) { return false; }
    @Override public String resolvedUrl(String url) { return url; }
    @Override public String resolveFresh(String url, String referrer, String ua) { return null; }
    @Override public void markRecovered(String sourceUrl, String resolvedUrl) { }
    @Override public void markFailed(String url) { }
    @Override public void reset() { }
}
