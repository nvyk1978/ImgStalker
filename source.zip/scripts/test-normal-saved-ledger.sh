#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/android/content" "$TMP/src/android/net" "$TMP/src/android/os" "$TMP/src/android/util" "$TMP/src/org/json" "$TMP/src/com/cmyk/imgstalker" "$TMP/classes" "$TMP/app"
cat > "$TMP/src/android/content/Context.java" <<'JAVA'
package android.content;
import java.io.File;
public class Context {
    private final File files;
    public Context(File files) { this.files = files; files.mkdirs(); }
    public File getFilesDir() { return files; }
    public ContentResolver getContentResolver() { return new ContentResolver(); }
}
JAVA
cat > "$TMP/src/android/content/ContentResolver.java" <<'JAVA'
package android.content;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.*;
public class ContentResolver {
    public ParcelFileDescriptor openFileDescriptor(Uri uri,String flags) throws IOException {
        String str=uri.toString();
        if(!str.startsWith("content://test/"))throw new FileNotFoundException();
        File f=new File(str.substring("content://test/".length()));
        if(!f.exists())throw new FileNotFoundException();
        return new ParcelFileDescriptor(f.length());
    }
}
JAVA
cat > "$TMP/src/android/net/Uri.java" <<'JAVA'
package android.net;
public final class Uri {
    private final String val;
    private Uri(String s){val=s;}
    public static Uri parse(String value){return new Uri(value);}
    @Override public String toString(){return val;}
}
JAVA
cat > "$TMP/src/android/os/ParcelFileDescriptor.java" <<'JAVA'
package android.os;
public class ParcelFileDescriptor implements java.lang.AutoCloseable {
    private final long size;
    public ParcelFileDescriptor(long size){this.size=size;}
    public long getStatSize(){return size;}
    public void close(){}
}
JAVA
cat > "$TMP/src/android/util/AtomicFile.java" <<'JAVA'
package android.util;
import java.io.*;
public class AtomicFile {
    private final File file;
    public AtomicFile(File file) { this.file = file; }
    public FileInputStream openRead() throws IOException { return new FileInputStream(file); }
    public FileOutputStream startWrite() throws IOException {
        File dir=file.getParentFile(); if (!dir.isDirectory()) dir.mkdirs();
        return new FileOutputStream(file);
    }
    public void finishWrite(FileOutputStream stream) throws IOException { stream.close(); }
    public void failWrite(FileOutputStream stream) throws IOException { stream.close(); }
}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" <<'JAVA'
package com.cmyk.imgstalker;
final class DiagnosticLog {
    static void log(String s) {}
    static void logException(String s, Throwable t) { throw new AssertionError(s,t); }
}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/SavePrefs.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.content.Context;
final class SavePrefs {static boolean hasTreeAccess(Context ctx){return false;}}
JAVA
cat > "$TMP/src/com/cmyk/imgstalker/NormalSavedLedgerMirror.java" <<'JAVA'
package com.cmyk.imgstalker;
import android.content.Context;
final class NormalSavedLedgerMirror {
    static boolean write(Context c,String url,byte[] data){return false;}
    static boolean exists(Context c,String url){return false;}
}
JAVA
cat > "$TMP/src/org/json/JSONArray.java" <<'JAVA'
package org.json;
import java.util.*;
public class JSONArray {
    private final ArrayList<Object> list=new ArrayList<>();
    public JSONArray(){}
    JSONArray(String raw) {
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\{[^{}]*\\}").matcher(raw);
        while(m.find())list.add(new JSONObject(m.group()));
    }
    public JSONArray put(Object v){list.add(v);return this;}
    public int length(){return list.size();}
    public JSONObject optJSONObject(int i){return list.get(i) instanceof JSONObject?(JSONObject)list.get(i):null;}
    public String toString(){ArrayList<String> a=new ArrayList<>();for(Object o:list)a.add(o.toString());return "["+String.join(",",a)+"]";}
}
JAVA
cat > "$TMP/src/org/json/JSONObject.java" <<'JAVA'
package org.json;
import java.util.*;
public class JSONObject {
    private final LinkedHashMap<String,Object> fields=new LinkedHashMap<>();
    public JSONObject(){}
    public JSONObject(String s){
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\\"([^\\\"]+)\\\"\\s*:\\s*(\\\"[^\\\"]*\\\"|[0-9]+|true|false)").matcher(s);
        while(m.find()){
            String k=m.group(1),v=m.group(2);
            fields.put(k,v.startsWith("\"")?v.substring(1,v.length()-1):
                v.equals("true")?true:v.equals("false")?false:Long.valueOf(v));
        }
        int start=s.indexOf("\"saved_files\"");
        if(start>=0){int b=s.indexOf('[',start),e=s.indexOf(']',b);if(b>=0&&e>=b)fields.put("saved_files",new JSONArray(s.substring(b,e+1)));}
    }
    public JSONObject put(String k,Object v){fields.put(k,v);return this;}
    public int optInt(String k,int d){Object v=fields.get(k);return v instanceof Number?((Number)v).intValue():d;}
    public String optString(String k,String d){Object v=fields.get(k);return v==null?d:v.toString();}
    public boolean optBoolean(String k,boolean d){Object v=fields.get(k);return v instanceof Boolean?(Boolean)v:d;}
    public JSONArray optJSONArray(String k){Object v=fields.get(k);return v instanceof JSONArray?(JSONArray)v:null;}
    public String toString(){ArrayList<String> a=new ArrayList<>();for(Map.Entry<String,Object> e:fields.entrySet()){
        Object v=e.getValue();a.add("\""+e.getKey()+"\":"+(v instanceof String?"\""+v+"\"":v));
    }return "{"+String.join(",",a)+"}";}
}
JAVA
javac -encoding UTF-8 -d "$TMP/classes" \
    "$TMP/src/android/content/Context.java" \
    "$TMP/src/android/content/ContentResolver.java" \
    "$TMP/src/android/net/Uri.java" "$TMP/src/android/os/ParcelFileDescriptor.java" \
    "$TMP/src/android/util/AtomicFile.java" \
    "$TMP/src/org/json/JSONObject.java" "$TMP/src/org/json/JSONArray.java" \
    "$TMP/src/com/cmyk/imgstalker/DiagnosticLog.java" \
    "$TMP/src/com/cmyk/imgstalker/SavePrefs.java" \
    "$TMP/src/com/cmyk/imgstalker/NormalSavedLedgerMirror.java" \
    app/src/main/java/com/cmyk/imgstalker/AnalysisModeRouter.java \
    app/src/main/java/com/cmyk/imgstalker/NormalCheckpointStore.java \
    app/src/main/java/com/cmyk/imgstalker/MediaItem.java \
    app/src/main/java/com/cmyk/imgstalker/NormalSavedLedgerStore.java \
    tests/NormalSavedLedgerTest.java
java -cp "$TMP/classes" com.cmyk.imgstalker.NormalSavedLedgerTest "$TMP/app"
