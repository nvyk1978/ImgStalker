package com.cmyk.imgstalker;

/** Plain-Java regression to protect Normal/Instagram independent legacy recovery state. */
public final class ModeVideoIsolationTest {
    private static int checks;
    private static void eq(String actual, String expected) {
        if (expected == null ? actual != null : !expected.equals(actual))
            throw new AssertionError("Expected " + expected + " but got " + actual);
        checks++;
    }
    public static void main(String[] args) {
        String original = "https://video.twimg.com/ext_tw_video/123/pu/vid/avc1/720x720/a.mp4?foo=1&tag=12&bar=2#frag";
        String stripped = "https://video.twimg.com/ext_tw_video/123/pu/vid/avc1/720x720/a.mp4?foo=1&bar=2#frag";
        eq(NormalVideoUrl.stripTag(original), stripped);
        eq(InstagramVideoUrl.stripTag(original), stripped);
        eq(NormalVideoUrl.stripTag("https://video.twimg.com/a.mp4?tag=12"), "https://video.twimg.com/a.mp4");
        eq(InstagramVideoUrl.stripTag("https://video.twimg.com/a.mp4?Tag=12&tag=13"), "https://video.twimg.com/a.mp4");
        eq(NormalVideoUrl.stripTag("https://video.twimg.com/a.mp4?size=100"), "https://video.twimg.com/a.mp4?size=100");
        eq(NormalVideoUrl.stripTag("https://video.twimg.com/a.m3u8?tag=12"), "https://video.twimg.com/a.m3u8?tag=12");
        eq(NormalVideoUrl.stripTag("https://video.twimg.com.evil.test/a.mp4?tag=12"), "https://video.twimg.com.evil.test/a.mp4?tag=12");
        eq(InstagramVideoUrl.stripTag("https://scontent.cdninstagram.com/a.mp4?tag=token"), "https://scontent.cdninstagram.com/a.mp4?tag=token");
        eq(NormalVideoUrl.stripTag(null), null);
        eq(InstagramVideoUrl.stripTag(""), "");
        NormalVideoUrl.resetSession();
        InstagramVideoUrl.resetSession();
        NormalVideoUrl.markRecovered(original, stripped);
        eq(NormalVideoUrl.resolvedOrOriginal(original), stripped);
        eq(InstagramVideoUrl.resolvedOrOriginal(original), original);
        InstagramVideoUrl.markRecovered(original, "https://example.test/instagram.mp4");
        eq(InstagramVideoUrl.resolvedOrOriginal(original), "https://example.test/instagram.mp4");
        NormalVideoUrl.resetSession();
        eq(NormalVideoUrl.resolvedOrOriginal(original), original);
        eq(InstagramVideoUrl.resolvedOrOriginal(original), "https://example.test/instagram.mp4");
        InstagramVideoUrl.resetSession();
        eq(InstagramVideoUrl.resolvedOrOriginal(original), original);
        System.out.println("PASS: " + checks + " video recovery isolation cases");
    }
}
