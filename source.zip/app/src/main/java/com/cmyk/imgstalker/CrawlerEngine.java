package com.cmyk.imgstalker;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class CrawlerEngine {
    public interface Listener {
        void onStatus(String text);
        void onProgressPulse(String stage);
        void onItem(MediaItem item);
        void onDone(String title, int visitedPages, int imageCount, int videoCount, int streamCount);
        void onError(String message);
    }

    private static final class Node {
        final String url;
        final int depth;
        final boolean detail;
        Node(String url, int depth, boolean detail) {
            this.url = url;
            this.depth = depth;
            this.detail = detail;
        }
    }

    private static final class ImageCandidate {
        final String url;
        final String referrer;
        final String sourceLogPrefix;
        ImageCandidate(String url, String referrer, String sourceLogPrefix) {
            this.url = url;
            this.referrer = referrer;
            this.sourceLogPrefix = sourceLogPrefix;
        }
    }

    private static final class DeferredDetail {
        final String url;
        final LinkedHashSet<String> thumbKeys = new LinkedHashSet<>();
        DeferredDetail(String url) {
            this.url = url;
        }
    }

    private final WebView webView;
    private final Listener listener;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Node> queue = new ArrayDeque<>();
    private final Set<String> queuedOrVisited = new HashSet<>();
    private final Set<String> mediaSeen = new HashSet<>();
    private final Set<String> imageCandidateSeen = new HashSet<>();
    private final Map<String, ImageCandidate> provisionalImages = new LinkedHashMap<>();
    private final Map<String, int[]> acceptedProvisionalSizes = new LinkedHashMap<>();
    private final Set<String> unresolvedProvisionalThumbs = new HashSet<>();
    private final Map<String, DeferredDetail> deferredDetails = new LinkedHashMap<>();
    private final Map<String, Set<String>> detailToProvisionalThumbs = new HashMap<>();
    private final Map<String, Set<String>> replacementToProvisionalThumbs = new HashMap<>();
    private final Set<String> suppressedProvisionalThumbs = new HashSet<>();
    private final Set<String> simpleGateAttemptedUrls = new HashSet<>();
    private final ExecutorService imageProbeExecutor = Executors.newFixedThreadPool(3);

    private boolean followPagination = true;
    private boolean followDetails = true;
    private boolean wantImages = true;
    private boolean wantVideos = true;
    private boolean cancelled = true;
    private long generation = 0L;
    private String rootHost = "";
    private String pageTitle = "ImgStalker";
    private int pageCount = 0;
    private int detailCount = 0;
    private int imageCount = 0;
    private int videoCount = 0;
    private int streamCount = 0;
    private int maxPages = 30;
    private int maxDetails = 120;
    private static final long DETAIL_LOAD_TIMEOUT_MS = 18000L;
    private static final long DETAIL_DOM_TIMEOUT_MS = 10000L;
    private static final long DETAIL_PHASE_BUDGET_MS = 90000L;
    private int targetImagePx = 640;
    private int pendingImageProbes = 0;
    private boolean traversalDone = false;
    private boolean baseTraversalDone = false;
    private boolean detailPhaseStarted = false;
    private boolean detailTraversalDone = false;
    private boolean provisionalPhaseStarted = false;
    private boolean doneEmitted = false;
    private long detailPhaseStartedAt = 0L;
    private String imageProbeUserAgent = "";
    private Node current;
    private long loadSequence = 0L;
    private long activeLoadSequence = 0L;
    private long activeNavigationSequence = 0L;
    private boolean activeLoadStarted = false;
    private boolean activePageFinished = false;
    private long activeStartedGeneration = -1L;
    private String activeRequestedUrl = "";
    private String activeStartedUrl = "";
    private String pendingSimpleGateSourceUrl = "";

    public CrawlerEngine(WebView webView, Listener listener) {
        this.webView = webView;
        this.listener = listener;
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString() + " ImgStalker/0.1.22");
        imageProbeUserAgent = s.getUserAgentString();
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (cancelled || current == null) {
                    DiagnosticLog.log("WEB_PAGE_STARTED_STALE reason=no_active_node url=" + url
                            + " generation=" + generation);
                    return;
                }

                String started = stripFragment(url);
                if (!activeLoadStarted) {
                    // Bind this callback lane only after WebView confirms that the URL requested by
                    // the current Node actually started. A late onPageFinished/onPageStarted from
                    // the previous analysis must never be allowed to arm DOM collection.
                    if (!sameNavigationUrl(started, activeRequestedUrl)) {
                        DiagnosticLog.log("WEB_PAGE_STARTED_STALE reason=request_mismatch url=" + url
                                + " expected=" + activeRequestedUrl
                                + " generation=" + generation
                                + " load=" + activeLoadSequence);
                        return;
                    }
                    activeLoadStarted = true;
                    activePageFinished = false;
                    activeStartedGeneration = generation;
                    activeStartedUrl = started;
                    activeNavigationSequence++;
                    DiagnosticLog.log("WEB_PAGE_STARTED generation=" + generation
                            + " load=" + activeLoadSequence
                            + " nav=" + activeNavigationSequence
                            + " url=" + url);
                    listener.onProgressPulse("WEB_PAGE_STARTED");
                    return;
                }

                if (activeStartedGeneration != generation) {
                    DiagnosticLog.log("WEB_PAGE_STARTED_STALE reason=generation_mismatch url=" + url
                            + " started_generation=" + activeStartedGeneration
                            + " current_generation=" + generation
                            + " load=" + activeLoadSequence);
                    return;
                }

                // A main-frame redirect belongs to the already bound current load. Keep the final
                // started URL so onPageFinished must correspond to the same navigation.
                activeStartedUrl = started;
                activePageFinished = false;
                activeNavigationSequence++;
                DiagnosticLog.log("WEB_PAGE_STARTED_REDIRECT generation=" + generation
                        + " load=" + activeLoadSequence
                        + " nav=" + activeNavigationSequence
                        + " url=" + url);
                listener.onProgressPulse("WEB_PAGE_STARTED_REDIRECT");
            }

            @Override public void onPageFinished(WebView view, String url) {
                if (cancelled || current == null) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_STALE reason=no_active_node url=" + url
                            + " generation=" + generation);
                    return;
                }
                if (!activeLoadStarted) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_STALE reason=no_matching_start url=" + url
                            + " expected=" + activeRequestedUrl
                            + " generation=" + generation
                            + " load=" + activeLoadSequence);
                    return;
                }
                if (activeStartedGeneration != generation) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_STALE reason=generation_mismatch url=" + url
                            + " started_generation=" + activeStartedGeneration
                            + " current_generation=" + generation
                            + " load=" + activeLoadSequence);
                    return;
                }
                if (!sameNavigationUrl(url, activeStartedUrl)) {
                    DiagnosticLog.log("WEB_PAGE_FINISHED_STALE reason=url_mismatch url=" + url
                            + " started=" + activeStartedUrl
                            + " expected=" + activeRequestedUrl
                            + " generation=" + generation
                            + " load=" + activeLoadSequence);
                    return;
                }

                activePageFinished = true;
                final long run = generation;
                final long load = activeLoadSequence;
                final long nav = activeNavigationSequence;
                final Node node = current;
                DiagnosticLog.log("WEB_PAGE_FINISHED generation=" + run
                        + " load=" + load
                        + " nav=" + nav
                        + " url=" + url
                        + " node=" + node.url);
                listener.onProgressPulse("WEB_PAGE_FINISHED");
                handler.postDelayed(() -> inspectSimpleGateThenContinue(run, load, nav, node), 450);
            }

            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                                                  android.webkit.WebResourceError error) {
                if (cancelled || request == null || !request.isForMainFrame()) return;
                String errorUrl = request.getUrl() == null ? "" : request.getUrl().toString();
                if (current == null || !activeLoadStarted
                        || activeStartedGeneration != generation
                        || !sameNavigationUrl(errorUrl, activeStartedUrl)) {
                    DiagnosticLog.log("WEB_MAIN_ERROR_STALE url=" + errorUrl
                            + " generation=" + generation
                            + " load=" + activeLoadSequence
                            + " error=" + error);
                    return;
                }
                DiagnosticLog.log("WEB_MAIN_ERROR url=" + errorUrl + " error=" + error);
                listener.onProgressPulse("WEB_MAIN_ERROR");
                listener.onStatus("読込失敗: " + errorUrl);
                if (current != null && current.detail) {
                    Node failedNode = current;
                    long failedLoad = activeLoadSequence;
                    handler.post(() -> skipCurrentDetail(failedNode, failedLoad, "web_error", 0L));
                }
            }
        });
    }

    public void start(String startUrl, boolean followPagination, boolean followDetails,
                      boolean wantImages, boolean wantVideos, int targetImagePx) {
        cancel();
        cancelled = false;
        queue.clear();
        queuedOrVisited.clear();
        mediaSeen.clear();
        imageCandidateSeen.clear();
        provisionalImages.clear();
        acceptedProvisionalSizes.clear();
        unresolvedProvisionalThumbs.clear();
        deferredDetails.clear();
        detailToProvisionalThumbs.clear();
        replacementToProvisionalThumbs.clear();
        suppressedProvisionalThumbs.clear();
        simpleGateAttemptedUrls.clear();
        pendingSimpleGateSourceUrl = "";
        pendingImageProbes = 0;
        traversalDone = false;
        baseTraversalDone = false;
        detailPhaseStarted = false;
        detailTraversalDone = false;
        provisionalPhaseStarted = false;
        doneEmitted = false;
        detailPhaseStartedAt = 0L;
        pageCount = detailCount = imageCount = videoCount = streamCount = 0;
        pageTitle = "ImgStalker";
        this.followPagination = followPagination;
        this.followDetails = followDetails;
        this.wantImages = wantImages;
        this.wantVideos = wantVideos;
        this.targetImagePx = Math.max(64, Math.min(8192, targetImagePx));
        DiagnosticLog.log("CRAWLER_START generation=" + generation + " url=" + startUrl
                + " pagination=" + followPagination
                + " details=" + followDetails
                + " images=" + wantImages
                + " videos=" + wantVideos
                + " targetImagePx=" + this.targetImagePx);

        String normalized = normalizeInputUrl(startUrl);
        try {
            rootHost = new URI(normalized).getHost();
            if (rootHost == null) rootHost = "";
        } catch (Exception e) {
            DiagnosticLog.logException("CRAWLER_BAD_URL " + normalized, e);
            listener.onError("URLを確認してください");
            return;
        }
        enqueue(new Node(normalized, 0, false));
        loadNext();
    }

    public void cancel() {
        generation++;
        if (!cancelled) DiagnosticLog.log("CRAWLER_CANCEL generation=" + generation);
        cancelled = true;
        current = null;
        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = "";
        activeStartedUrl = "";
        try { webView.stopLoading(); } catch (Exception ignored) {}
        handler.removeCallbacksAndMessages(null);
    }

    private boolean isActive(long run, long load, long nav, Node node) {
        return !cancelled
                && generation == run
                && activeStartedGeneration == run
                && activeLoadSequence == load
                && activeNavigationSequence == nav
                && activeLoadStarted
                && current == node;
    }

    private void inspectSimpleGateThenContinue(long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        String liveUrl = webView.getUrl();
        if (!sameNavigationUrl(liveUrl, activeStartedUrl)) {
            DiagnosticLog.log("PASS_GATE_SKIP reason=live_url_mismatch generation=" + run
                    + " load=" + load + " nav=" + nav
                    + " started=" + activeStartedUrl + " live=" + liveUrl);
            return;
        }

        final String gateUrl = stripFragment(liveUrl == null ? node.url : liveUrl);
        final boolean allowClick = !simpleGateAttemptedUrls.contains(gateUrl);
        webView.evaluateJavascript(buildSimpleGateScript(allowClick), raw -> {
            if (!isActive(run, load, nav, node)) return;

            boolean continueNormally = true;
            try {
                JSONObject gate = new JSONObject(unquoteJsResult(raw));
                boolean found = gate.optBoolean("found", false);
                boolean clicked = gate.optBoolean("clicked", false);
                String accept = gate.optString("accept", "").trim();
                String reject = gate.optString("reject", "").trim();

                if (found) {
                    DiagnosticLog.log("PASS_GATE_FOUND type=simple_confirmation url=" + gateUrl
                            + " accept=" + accept + " reject=" + reject);
                    if (clicked) {
                        simpleGateAttemptedUrls.add(gateUrl);
                        pendingSimpleGateSourceUrl = gateUrl;
                        DiagnosticLog.log("PASS_GATE_ACCEPT text=" + accept + " url=" + gateUrl);
                        continueNormally = false;

                        // If the gate changes only the DOM and does not navigate, inspect it once
                        // more after the click. If it navigates, the old nav sequence goes stale
                        // and the new onPageFinished path takes over automatically.
                        handler.postDelayed(() -> {
                            if (isActive(run, load, nav, node)) {
                                inspectSimpleGateThenContinue(run, load, nav, node);
                            }
                        }, 900);
                    } else if (!allowClick) {
                        DiagnosticLog.log("PASS_GATE_FAILED reason=already_attempted_still_present url=" + gateUrl);
                    } else {
                        DiagnosticLog.log("PASS_GATE_FAILED reason=no_clickable_accept url=" + gateUrl);
                    }
                } else if (!pendingSimpleGateSourceUrl.isEmpty()) {
                    DiagnosticLog.log("PASS_GATE_RESOLVED source=" + pendingSimpleGateSourceUrl
                            + " url=" + gateUrl);
                    pendingSimpleGateSourceUrl = "";
                }
            } catch (Exception e) {
                DiagnosticLog.logException("PASS_GATE_PARSE_FAIL url=" + gateUrl, e);
            }

            if (continueNormally && isActive(run, load, nav, node)) {
                autoScroll(0, run, load, nav, node);
            }
        });
    }

    private void autoScroll(int pass, long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        if (pass >= 3) {
            collectDom(run, load, nav, node);
            return;
        }
        webView.evaluateJavascript(
                "(function(){try{window.scrollTo(0,document.body.scrollHeight);return String(document.body.scrollHeight)}catch(e){return '0'}})()",
                value -> {
                    if (!isActive(run, load, nav, node)) return;
                    handler.postDelayed(() -> autoScroll(pass + 1, run, load, nav, node), 350);
                });
    }

    private void collectDom(long run, long load, long nav, Node node) {
        if (!isActive(run, load, nav, node)) return;
        String liveUrl = webView.getUrl();
        if (!sameNavigationUrl(liveUrl, activeStartedUrl)) {
            DiagnosticLog.log("DOM_COLLECT_SKIP reason=live_url_mismatch generation=" + run
                    + " load=" + load
                    + " node=" + node.url
                    + " started=" + activeStartedUrl
                    + " live=" + liveUrl);
            return;
        }
        DiagnosticLog.log("DOM_COLLECT generation=" + run + " load=" + load + " nav=" + nav + " url=" + node.url + " detail=" + node.detail + " depth=" + node.depth
                + " live=" + liveUrl
                + " targetImagePx=" + targetImagePx);
        listener.onProgressPulse("DOM_COLLECT");
        listener.onStatus("解析中 " + (pageCount + detailCount + 1) + "ページ目");
        if (node.detail) {
            handler.postDelayed(() -> {
                if (isActive(run, load, nav, node)) {
                    skipCurrentDetail(node, load, "dom_timeout", DETAIL_DOM_TIMEOUT_MS);
                }
            }, DETAIL_DOM_TIMEOUT_MS);
        }
        webView.evaluateJavascript(buildCollectorScript(targetImagePx), raw -> {
            if (!isActive(run, load, nav, node)) {
                DiagnosticLog.log("DOM_CALLBACK_SKIP stale_generation=" + run
                        + " current_generation=" + generation
                        + " stale_load=" + load
                        + " current_load=" + activeLoadSequence
                        + " stale_nav=" + nav
                        + " current_nav=" + activeNavigationSequence
                        + " url=" + node.url);
                return;
            }
            try {
                String jsonText = unquoteJsResult(raw);
                JSONObject obj = new JSONObject(jsonText);
                String title = obj.optString("title", "").trim();
                if (!title.isEmpty() && pageCount == 0 && detailCount == 0) pageTitle = title;
                processThumbnailLinks(obj.optJSONArray("thumbLinks"), node, liveUrl);
                processMediaArray(obj.optJSONArray("images"), MediaItem.Kind.IMAGE, liveUrl, node.detail);
                processMediaArray(obj.optJSONArray("videos"), MediaItem.Kind.VIDEO, liveUrl, node.detail);
                processMediaArray(obj.optJSONArray("streams"), MediaItem.Kind.STREAM, liveUrl, node.detail);
                processLinks(obj.optJSONArray("links"), node);
            } catch (Exception e) {
                DiagnosticLog.logException("DOM_PARSE_FAIL url=" + node.url, e);
                listener.onStatus("ページ解析を一部スキップ: " + e.getClass().getSimpleName());
            }

            if (!isActive(run, load, nav, node)) return;
            listener.onProgressPulse("DOM_CALLBACK");
            if (node.detail) detailCount++; else pageCount++;
            current = null;
            loadNext();
        });
    }

    private void processMediaArray(JSONArray array, MediaItem.Kind kind, String referrer, boolean fromDetail) throws JSONException {
        if (array == null) return;
        if (kind == MediaItem.Kind.IMAGE && !wantImages) return;
        if ((kind == MediaItem.Kind.VIDEO || kind == MediaItem.Kind.STREAM) && !wantVideos) return;
        for (int i = 0; i < array.length(); i++) {
            String raw = array.optString(i, "");
            if (kind == MediaItem.Kind.IMAGE && !fromDetail) {
                String k = imageKey(raw);
                if (!k.isEmpty() && provisionalImages.containsKey(k)) {
                    DiagnosticLog.log("IMAGE_PROVISIONAL_PROBE url=" + cleanUrl(raw) + " ref=" + referrer);
                }
            }
            addMediaUrl(raw, kind, referrer, null);
        }
    }

    private boolean addMediaUrl(String rawUrl, MediaItem.Kind kind, String referrer, String sourceLogPrefix) {
        String u = cleanUrl(rawUrl);
        if (!isHttp(u)) return false;
        if (kind == MediaItem.Kind.IMAGE && !wantImages) return false;
        if ((kind == MediaItem.Kind.VIDEO || kind == MediaItem.Kind.STREAM) && !wantVideos) return false;
        if (kind == MediaItem.Kind.IMAGE) {
            if (isLikelyTrackingImage(u)) {
                DiagnosticLog.log("MEDIA_SKIP_TRACKER url=" + u);
                return false;
            }
            return queueImageCandidate(u, referrer, sourceLogPrefix);
        }

        String key = kind.name() + "|" + stripFragment(u);
        if (!mediaSeen.add(key)) return false;
        MediaItem item = new MediaItem(u, referrer, kind, false);
        DiagnosticLog.log("MEDIA_FOUND kind=" + kind.name() + " url=" + u + " ref=" + referrer);
        if (kind == MediaItem.Kind.VIDEO) videoCount++; else streamCount++;
        listener.onItem(item);
        return true;
    }

    private void holdProvisionalImage(String rawUrl, String referrer) {
        String u = cleanUrl(rawUrl);
        String key = imageKey(u);
        if (key.isEmpty() || isLikelyTrackingImage(u)) return;
        if (!provisionalImages.containsKey(key)) {
            provisionalImages.put(key, new ImageCandidate(u, referrer, "IMAGE_PROVISIONAL_FALLBACK"));
            DiagnosticLog.log("IMAGE_PROVISIONAL_ADD url=" + u + " ref=" + referrer);
        }
    }

    private void mapReplacement(Map<String, Set<String>> map, String replacementKey, String thumbKey) {
        if (replacementKey == null || replacementKey.isEmpty() || thumbKey == null || thumbKey.isEmpty()) return;
        Set<String> values = map.get(replacementKey);
        if (values == null) {
            values = new HashSet<>();
            map.put(replacementKey, values);
        }
        values.add(thumbKey);
    }

    private boolean queueImageCandidate(String rawUrl, String referrer, String sourceLogPrefix) {
        String u = cleanUrl(rawUrl);
        String key = imageKey(u);
        if (key.isEmpty()) return false;
        if (isLikelyTrackingImage(u)) {
            DiagnosticLog.log("MEDIA_SKIP_TRACKER url=" + u);
            return false;
        }
        if (!imageCandidateSeen.add(key)) return false;

        final long run = generation;
        final String cookie;
        try {
            cookie = CookieManager.getInstance().getCookie(u);
        } catch (Exception e) {
            DiagnosticLog.log("IMAGE_PROBE_COOKIE_FAIL url=" + u + " error=" + e.getClass().getSimpleName());
            pendingImageProbes++;
            imageProbeExecutor.submit(() -> runImageProbe(run, u, referrer, sourceLogPrefix, null));
            return true;
        }
        pendingImageProbes++;
        DiagnosticLog.log("IMAGE_PROBE_QUEUE target=" + targetImagePx + " url=" + u + " ref=" + referrer);
        listener.onProgressPulse("IMAGE_PROBE_QUEUE");
        imageProbeExecutor.submit(() -> runImageProbe(run, u, referrer, sourceLogPrefix, cookie));
        return true;
    }

    private void runImageProbe(long run, String u, String referrer, String sourceLogPrefix, String cookie) {
        int[] size = null;
        Exception failure = null;
        try {
            size = probeImageSize(u, referrer, cookie);
        } catch (Exception e) {
            failure = e;
        }
        final int[] result = size;
        final Exception error = failure;
        handler.post(() -> {
            if (cancelled || generation != run) return;
            pendingImageProbes = Math.max(0, pendingImageProbes - 1);
            listener.onProgressPulse("IMAGE_PROBE_DONE");
            String candidateKey = imageKey(u);
            boolean provisional = !candidateKey.isEmpty() && provisionalImages.containsKey(candidateKey);
            if (error != null || result == null || result[0] <= 0 || result[1] <= 0) {
                DiagnosticLog.log("IMAGE_REJECT_PROBE_FAIL target=" + targetImagePx + " url=" + u
                        + " error=" + (error == null ? "unknown_size" : error.getClass().getSimpleName()));
                if (provisional) unresolvedProvisionalThumbs.add(candidateKey);
            } else {
                int w = result[0], h = result[1];
                if (Math.max(w, h) < targetImagePx) {
                    DiagnosticLog.log("IMAGE_REJECT_LOW_RES size=" + w + "x" + h
                            + " target=" + targetImagePx + " url=" + u);
                    if (provisional) unresolvedProvisionalThumbs.add(candidateKey);
                } else if (provisional) {
                    acceptedProvisionalSizes.put(candidateKey, new int[]{w, h});
                    DiagnosticLog.log("IMAGE_PROVISIONAL_READY size=" + w + "x" + h
                            + " target=" + targetImagePx + " url=" + u);
                } else {
                    emitAcceptedImage(u, referrer, sourceLogPrefix, w, h);
                }
            }
            maybeFinishAfterImageProbes();
        });
    }

    private void emitAcceptedImage(String url, String referrer, String sourceLogPrefix, int width, int height) {
        String mediaKey = MediaItem.Kind.IMAGE.name() + "|" + stripFragment(url);
        if (!mediaSeen.add(mediaKey)) return;
        suppressReplacedThumbnails(url, referrer);
        MediaItem item = new MediaItem(url, referrer, MediaItem.Kind.IMAGE, false);
        DiagnosticLog.log("MEDIA_FOUND kind=IMAGE size=" + width + "x" + height + " url=" + url + " ref=" + referrer);
        if (sourceLogPrefix != null && !sourceLogPrefix.isEmpty()) {
            DiagnosticLog.log(sourceLogPrefix + " image=" + url + " size=" + width + "x" + height);
        }
        imageCount++;
        listener.onItem(item);
    }

    private void suppressReplacedThumbnails(String acceptedUrl, String referrer) {
        Set<String> direct = replacementToProvisionalThumbs.get(imageKey(acceptedUrl));
        if (direct != null) suppressedProvisionalThumbs.addAll(direct);
        Set<String> detail = detailToProvisionalThumbs.get(stripFragment(cleanUrl(referrer)));
        if (detail != null) suppressedProvisionalThumbs.addAll(detail);
    }

    private void maybeFinishAfterImageProbes() {
        if (cancelled || doneEmitted || pendingImageProbes > 0 || current != null || !queue.isEmpty()) return;

        if (baseTraversalDone && !detailPhaseStarted) {
            startDeferredDetailPhase();
            return;
        }

        if (detailPhaseStarted && detailTraversalDone) {
            finalizeProvisionalImages();
            if (pendingImageProbes == 0) emitDone();
        }
    }

    private void startDeferredDetailPhase() {
        if (detailPhaseStarted || cancelled) return;
        detailPhaseStarted = true;
        detailPhaseStartedAt = System.currentTimeMillis();

        int queued = 0;
        int skippedResolved = 0;
        int skippedLimit = 0;
        if (followDetails) {
            for (DeferredDetail d : deferredDetails.values()) {
                boolean needsDetail = d.thumbKeys.isEmpty();
                if (!needsDetail) {
                    for (String thumbKey : d.thumbKeys) {
                        if (suppressedProvisionalThumbs.contains(thumbKey)) continue;
                        if (unresolvedProvisionalThumbs.contains(thumbKey)
                                || !acceptedProvisionalSizes.containsKey(thumbKey)) {
                            needsDetail = true;
                            break;
                        }
                    }
                }
                if (!needsDetail) {
                    skippedResolved++;
                    DiagnosticLog.log("THUMB_DETAIL_SKIP reason=thumb_meets_target href=" + d.url);
                    continue;
                }
                if (queued >= maxDetails) {
                    skippedLimit++;
                    DiagnosticLog.log("THUMB_DETAIL_SKIP reason=detail_limit href=" + d.url);
                    continue;
                }
                if (enqueue(new Node(d.url, 1, true))) {
                    queued++;
                    DiagnosticLog.log("THUMB_DETAIL_QUEUE href=" + d.url);
                }
            }
        }

        DiagnosticLog.log("DETAIL_PHASE_START queued=" + queued
                + " deferred=" + deferredDetails.size()
                + " skippedResolved=" + skippedResolved
                + " skippedLimit=" + skippedLimit
                + " budgetMs=" + DETAIL_PHASE_BUDGET_MS
                + " timeoutMs=" + DETAIL_LOAD_TIMEOUT_MS);

        if (queue.isEmpty()) {
            detailTraversalDone = true;
            traversalDone = true;
            DiagnosticLog.log("DETAIL_PHASE_DONE details=" + detailCount + " reason=no_pending_detail");
            maybeFinishAfterImageProbes();
        } else {
            listener.onStatus("必要なサムネイル先だけ追跡中…");
            loadNext();
        }
    }

    private void finalizeProvisionalImages() {
        if (provisionalPhaseStarted) return;
        provisionalPhaseStarted = true;
        for (Map.Entry<String, ImageCandidate> entry : provisionalImages.entrySet()) {
            String key = entry.getKey();
            ImageCandidate c = entry.getValue();
            if (suppressedProvisionalThumbs.contains(key)) {
                DiagnosticLog.log("IMAGE_PROVISIONAL_REPLACED url=" + c.url);
                continue;
            }
            int[] size = acceptedProvisionalSizes.get(key);
            if (size == null || size.length < 2) continue;
            emitAcceptedImage(c.url, c.referrer, c.sourceLogPrefix, size[0], size[1]);
        }
    }

    private void emitDone() {
        if (doneEmitted || cancelled) return;
        doneEmitted = true;
        int visited = pageCount + detailCount;
        DiagnosticLog.log("CRAWLER_DONE pages=" + pageCount + " details=" + detailCount + " visited=" + visited
                + " images=" + imageCount + " videos=" + videoCount + " streams=" + streamCount);
        listener.onDone(pageTitle, visited, imageCount, videoCount, streamCount);
    }

    private int[] probeImageSize(String imageUrl, String referrer, String cookie) throws Exception {
        Exception last = null;
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(imageUrl).openConnection();
                con.setInstanceFollowRedirects(true);
                con.setConnectTimeout(10000);
                con.setReadTimeout(16000);
                con.setRequestProperty("User-Agent", imageProbeUserAgent == null || imageProbeUserAgent.isEmpty()
                        ? "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Mobile Safari/537.36 ImgStalker/0.1.22"
                        : imageProbeUserAgent);
                con.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8");
                con.setRequestProperty("Accept-Encoding", "identity");
                con.setRequestProperty("Sec-Fetch-Dest", "image");
                con.setRequestProperty("Sec-Fetch-Mode", "no-cors");
                if (referrer != null && !referrer.isEmpty()) con.setRequestProperty("Referer", referrer);
                if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
                con.connect();
                int code = con.getResponseCode();
                if (code < 200 || code >= 300) throw new FileNotFoundException("HTTP " + code);
                String type = con.getContentType();
                if (type != null && !type.toLowerCase(Locale.ROOT).startsWith("image/")) {
                    throw new IOException("not image: " + type);
                }
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inJustDecodeBounds = true;
                try (BufferedInputStream in = new BufferedInputStream(con.getInputStream())) {
                    BitmapFactory.decodeStream(in, null, opts);
                }
                if (opts.outWidth <= 0 || opts.outHeight <= 0) throw new IOException("image bounds unavailable");
                return new int[]{opts.outWidth, opts.outHeight};
            } catch (Exception e) {
                last = e;
                if (attempt == 0) {
                    try { Thread.sleep(150L); } catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        throw interrupted;
                    }
                }
            } finally {
                if (con != null) con.disconnect();
            }
        }
        throw last == null ? new IOException("image size probe failed") : last;
    }

    private static String imageKey(String rawUrl) {
        String u = cleanUrl(rawUrl);
        return isHttp(u) ? stripFragment(u) : "";
    }

    private void processThumbnailLinks(JSONArray thumbLinks, Node from, String pageUrl) throws JSONException {
        if (!followDetails || thumbLinks == null) return;
        // Base/pagination pages only. Parent pages are deferred until base traversal and
        // image-size probes finish, so we only open detail pages for unresolved thumbnails.
        if (from.detail || from.depth != 0) return;

        for (int i = 0; i < thumbLinks.length(); i++) {
            JSONObject entry = thumbLinks.optJSONObject(i);
            if (entry == null) continue;
            String img = cleanUrl(entry.optString("img", ""));
            String href = cleanUrl(entry.optString("href", ""));
            if (!isHttp(href)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=non_http href=" + href);
                continue;
            }

            DiagnosticLog.log("THUMB_LINK_FOUND img=" + img + " href=" + href);
            String normalizedHref = stripFragment(href);
            String normalizedImg = stripFragment(img);
            if (!normalizedImg.isEmpty() && normalizedHref.equals(normalizedImg)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=same_image href=" + href);
                continue;
            }

            String thumbKey = imageKey(img);
            if (!thumbKey.isEmpty()) holdProvisionalImage(img, pageUrl);

            if (looksDirectImage(href)) {
                mapReplacement(replacementToProvisionalThumbs, imageKey(href), thumbKey);
                boolean queued = addMediaUrl(href, MediaItem.Kind.IMAGE, pageUrl, "THUMB_LINK_RESOLVED");
                if (!queued) DiagnosticLog.log("THUMB_LINK_SKIP reason=duplicate_or_filtered href=" + href);
                continue;
            }

            if (looksDirectMedia(href)) {
                DiagnosticLog.log("THUMB_LINK_SKIP reason=non_image_media href=" + href);
                continue;
            }

            DeferredDetail d = deferredDetails.get(normalizedHref);
            if (d == null) {
                d = new DeferredDetail(href);
                deferredDetails.put(normalizedHref, d);
                DiagnosticLog.log("THUMB_LINK_DEFER href=" + href);
            }
            if (!thumbKey.isEmpty()) d.thumbKeys.add(thumbKey);
            mapReplacement(detailToProvisionalThumbs, normalizedHref, thumbKey);
        }
    }

    private void processLinks(JSONArray links, Node from) throws JSONException {
        if (links == null) return;
        for (int i = 0; i < links.length(); i++) {
            JSONObject link = links.optJSONObject(i);
            if (link == null) continue;
            String u = cleanUrl(link.optString("url", ""));
            if (!isHttp(u) || !sameHost(u)) continue;
            if (looksDirectMedia(u)) continue;
            boolean pagination = link.optBoolean("pagination", false);
            String paginationKind = link.optString("paginationKind", "");

            // Pagination is always a depth=0 lane. Detail pages never fan out to pagination/detail pages.
            if (!from.detail && from.depth == 0 && pagination && followPagination
                    && pageCount + countQueued(false) < maxPages) {
                if (enqueue(new Node(u, 0, false))) {
                    DiagnosticLog.log("QUEUE_PAGE kind=" + (paginationKind.isEmpty() ? "unknown" : paginationKind) + " url=" + u);
                } else {
                    DiagnosticLog.log("PAGE_LINK_SKIP reason=duplicate kind=" + (paginationKind.isEmpty() ? "unknown" : paginationKind) + " url=" + u);
                }
            }
        }
    }

    private int countQueued(boolean detail) {
        int n = 0;
        for (Node q : queue) if (q.detail == detail) n++;
        return n;
    }

    private boolean enqueue(Node node) {
        String key = stripFragment(node.url);
        if (!queuedOrVisited.add(key)) return false;
        queue.add(node);
        return true;
    }

    private void loadNext() {
        if (cancelled) return;

        if (detailPhaseStarted && !detailTraversalDone && detailPhaseStartedAt > 0L
                && System.currentTimeMillis() - detailPhaseStartedAt >= DETAIL_PHASE_BUDGET_MS) {
            int remaining = queue.size();
            queue.clear();
            current = null;
            detailTraversalDone = true;
            traversalDone = true;
            DiagnosticLog.log("DETAIL_PHASE_BUDGET_END remaining=" + remaining
                    + " elapsedMs=" + (System.currentTimeMillis() - detailPhaseStartedAt));
            listener.onProgressPulse("DETAIL_PHASE_BUDGET_END");
            listener.onStatus("詳細追跡を時間上限で終了");
            maybeFinishAfterImageProbes();
            return;
        }

        current = queue.poll();
        if (current == null) {
            if (!baseTraversalDone) {
                baseTraversalDone = true;
                DiagnosticLog.log("BASE_TRAVERSAL_DONE pages=" + pageCount
                        + " pendingImageProbes=" + pendingImageProbes
                        + " deferredDetails=" + deferredDetails.size());
                if (pendingImageProbes > 0) listener.onStatus("本画像候補を確認中…");
                maybeFinishAfterImageProbes();
                return;
            }

            if (detailPhaseStarted && !detailTraversalDone) {
                detailTraversalDone = true;
                traversalDone = true;
                DiagnosticLog.log("DETAIL_PHASE_DONE details=" + detailCount
                        + " pendingImageProbes=" + pendingImageProbes);
                if (pendingImageProbes > 0) listener.onStatus("本画像の解像度を確認中…");
                maybeFinishAfterImageProbes();
                return;
            }

            traversalDone = true;
            maybeFinishAfterImageProbes();
            return;
        }

        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = stripFragment(current.url);
        activeStartedUrl = "";
        final Node loadNode = current;
        final long loadId = activeLoadSequence;

        DiagnosticLog.log("WEB_LOAD generation=" + generation
                + " load=" + activeLoadSequence
                + " detail=" + current.detail
                + " depth=" + current.depth
                + " url=" + current.url);
        listener.onProgressPulse(current.detail ? "DETAIL_LOAD" : "PAGE_LOAD");
        listener.onStatus((current.detail ? "詳細追跡  " : "ページ追跡  ") + current.url);
        webView.loadUrl(current.url);

        if (loadNode.detail) {
            handler.postDelayed(() -> {
                if (cancelled || current != loadNode || activeLoadSequence != loadId) return;
                if (activePageFinished) return;
                skipCurrentDetail(loadNode, loadId, "load_timeout", DETAIL_LOAD_TIMEOUT_MS);
            }, DETAIL_LOAD_TIMEOUT_MS);
        }
    }

    private void skipCurrentDetail(Node node, long expectedLoad, String reason, long timeoutMs) {
        if (cancelled || node == null || !node.detail || current != node || activeLoadSequence != expectedLoad) return;
        DiagnosticLog.log("DETAIL_TIMEOUT_SKIP reason=" + reason
                + " timeoutMs=" + timeoutMs + " url=" + node.url);
        listener.onProgressPulse("DETAIL_TIMEOUT_SKIP");
        listener.onStatus("詳細追跡をスキップ  " + node.url);
        try { webView.stopLoading(); } catch (Exception ignored) {}
        activeLoadSequence = ++loadSequence;
        activeNavigationSequence = 0L;
        activeLoadStarted = false;
        activePageFinished = false;
        activeStartedGeneration = -1L;
        activeRequestedUrl = "";
        activeStartedUrl = "";
        detailCount++;
        current = null;
        loadNext();
    }

    public boolean hasPendingWork() {
        return !cancelled && !doneEmitted
                && (current != null || !queue.isEmpty() || pendingImageProbes > 0
                || !baseTraversalDone || !detailTraversalDone || !traversalDone);
    }

    public String progressSnapshot() {
        String currentUrl = current == null ? "none" : current.url;
        return "current=" + currentUrl
                + ",queue=" + queue.size()
                + ",pendingImageProbes=" + pendingImageProbes
                + ",activePageFinished=" + activePageFinished
                + ",deferredDetails=" + deferredDetails.size()
                + ",baseTraversalDone=" + baseTraversalDone
                + ",detailPhaseStarted=" + detailPhaseStarted
                + ",detailTraversalDone=" + detailTraversalDone
                + ",traversalDone=" + traversalDone
                + ",pages=" + pageCount
                + ",details=" + detailCount;
    }

    private static boolean sameNavigationUrl(String a, String b) {
        if (a == null || b == null) return false;
        try {
            URI ua = new URI(stripFragment(a));
            URI ub = new URI(stripFragment(b));
            String sa = ua.getScheme() == null ? "" : ua.getScheme();
            String sb = ub.getScheme() == null ? "" : ub.getScheme();
            String ha = ua.getHost() == null ? "" : ua.getHost();
            String hb = ub.getHost() == null ? "" : ub.getHost();
            String pa = ua.getPath() == null || ua.getPath().isEmpty() ? "/" : ua.getPath();
            String pb = ub.getPath() == null || ub.getPath().isEmpty() ? "/" : ub.getPath();
            return sa.equalsIgnoreCase(sb)
                    && ha.equalsIgnoreCase(hb)
                    && effectivePort(ua) == effectivePort(ub)
                    && pa.equals(pb)
                    && safeEquals(ua.getRawQuery(), ub.getRawQuery());
        } catch (Exception e) {
            return stripFragment(a).equals(stripFragment(b));
        }
    }

    private static int effectivePort(URI uri) {
        int port = uri.getPort();
        if (port >= 0) return port;
        String scheme = uri.getScheme();
        if (scheme != null && scheme.equalsIgnoreCase("https")) return 443;
        if (scheme != null && scheme.equalsIgnoreCase("http")) return 80;
        return -1;
    }

    private boolean sameHost(String url) {
        try {
            String h = new URI(url).getHost();
            if (h == null) return false;
            if (h.equalsIgnoreCase(rootHost)) return true;
            return h.toLowerCase(Locale.ROOT).endsWith("." + rootHost.toLowerCase(Locale.ROOT));
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isDetailCandidate(String url, String fromUrl) {
        try {
            URI target = new URI(stripFragment(url));
            URI from = new URI(stripFragment(fromUrl));
            String targetPath = target.getPath() == null ? "/" : target.getPath();
            String fromPath = from.getPath() == null ? "/" : from.getPath();
            if (targetPath.equals(fromPath) && safeEquals(target.getQuery(), from.getQuery())) return false;

            String path = targetPath.toLowerCase(Locale.ROOT);
            if (path.isEmpty() || "/".equals(path)) return false;
            if (path.matches("^/(page/\\d+/?|tag/.*|tags/.*|category/.*|categories/.*|author/.*|search/?.*|feed/?.*|wp-.*)$")) {
                return false;
            }
            if (path.contains("/login") || path.contains("/register") || path.contains("/privacy")
                    || path.contains("/contact") || path.contains("/about")) {
                return false;
            }

            String[] segments = path.split("/");
            int useful = 0;
            for (String segment : segments) if (!segment.isEmpty()) useful++;
            boolean contentLike = path.matches(".*\\.(html?|php)(/\\d+)?$")
                    || path.matches(".*/\\d{3,}([./].*)?$")
                    || useful >= 2;
            return contentLike;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean safeEquals(String a, String b) {
        return a == null ? b == null : a.equals(b);
    }

    private static boolean isLikelyTrackingImage(String url) {
        try {
            URI u = new URI(url);
            String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            String path = u.getPath() == null ? "" : u.getPath().toLowerCase(Locale.ROOT);
            String query = u.getQuery() == null ? "" : u.getQuery().toLowerCase(Locale.ROOT);
            String all = host + path + "?" + query;
            if (host.contains("ad-stir") || host.contains("shinobi") || host.contains("jp1media")
                    || host.contains("doubleclick") || host.contains("googlesyndication")
                    || host.contains("adservice") || host.contains("adnxs") || host.contains("criteo")
                    || host.contains("rubiconproject") || host.contains("openx") || host.contains("bance")) {
                return true;
            }
            if (!looksDirectMedia(url) && (all.contains("/sync") || all.contains("push_sync")
                    || all.contains("/pixel") || all.contains("/beacon") || all.contains("/track"))) {
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static String normalizeInputUrl(String s) {
        s = s == null ? "" : s.trim();
        if (!s.matches("(?i)^https?://.*")) s = "https://" + s;
        return s;
    }

    private static boolean looksDirectImage(String u) {
        String x = u.toLowerCase(Locale.ROOT).split("\\?")[0];
        return x.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif)$");
    }

    private static boolean looksDirectMedia(String u) {
        String x = u.toLowerCase(Locale.ROOT).split("\\?")[0];
        return x.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif|mp4|webm|mov|m4v|3gp|m3u8|mpd)$");
    }

    private static boolean isHttp(String u) {
        return u != null && (u.startsWith("http://") || u.startsWith("https://"));
    }

    private static String cleanUrl(String s) {
        if (s == null) return "";
        return s.trim().replace("&amp;", "&");
    }

    private static String stripFragment(String s) {
        int i = s.indexOf('#');
        return i >= 0 ? s.substring(0, i) : s;
    }

    private static String unquoteJsResult(String raw) throws JSONException {
        if (raw == null || raw.equals("null")) return "{}";
        if (raw.startsWith("\"") && raw.endsWith("\"")) {
            return new JSONArray("[" + raw + "]").getString(0);
        }
        return raw;
    }

    private static String buildSimpleGateScript(boolean allowClick) {
        String click = allowClick ? "true" : "false";
        return "(function(){try{" +
                "const allowClick=" + click + ";" +
                "const clean=s=>(s||'').replace(/\\s+/g,' ').trim();" +
                "const label=e=>clean((e.tagName==='INPUT'?(e.value||''):(e.innerText||e.textContent||''))||e.getAttribute('aria-label')||e.getAttribute('title')||'');" +
                "const gateRe=/(18\\s*(?:\\u6b73|\\u624d)|18\\s*\\+|\\u6210\\u4eba|\\u672a\\u6210\\u5e74|\\u5e74\\u9f62|\\u30bb\\u30f3\\u30b7\\u30c6\\u30a3\\u30d6|\\u95b2\\u89a7.{0,24}(?:\\u78ba\\u8a8d|\\u3057\\u307e\\u3059\\u304b|\\u3088\\u308d\\u3057\\u3044)|\\u5165\\u5834.{0,24}(?:\\u78ba\\u8a8d|\\u3057\\u307e\\u3059\\u304b|\\u3088\\u308d\\u3057\\u3044)|age\\s*(?:verification|check)|adult|mature|sensitive\\s*content|are\\s*you.{0,16}(?:18|legal\\s*age)|over\\s*18|under\\s*18)/i;" +
                "const yesRe=/(?:^|[\\uff08(\\s])(\\u306f\\u3044|yes|18\\s*(?:\\u6b73|\\u624d)\\u4ee5\\u4e0a|\\u6210\\u4eba(?:\\u3067\\u3059)?|\\u95b2\\u89a7(?:\\u3059\\u308b|\\u3057\\u307e\\u3059)|\\u5165\\u5834(?:\\u3059\\u308b|\\u3057\\u307e\\u3059)|\\u540c\\u610f(?:\\u3059\\u308b|\\u3057\\u307e\\u3059)|\\u7d9a\\u3051\\u308b|continue|enter|accept|agree|over\\s*18|i\\s*(?:am|'m)\\s*18)(?:$|[\\uff09)\\s])/i;" +
                "const noRe=/(?:^|[\\uff08(\\s])(\\u3044\\u3044\\u3048|no|18\\s*(?:\\u6b73|\\u624d)\\u672a\\u6e80|\\u672a\\u6210\\u5e74|\\u623b\\u308b|\\u9000\\u5834|exit|leave|under\\s*18|decline)(?:$|[\\uff09)\\s])/i;" +
                "const all=Array.from(document.querySelectorAll('a[href],button,input[type=submit],input[type=button],[role=button]')).filter(e=>!e.disabled&&e.getClientRects().length>0);" +
                "let pos=null,neg=null;for(const e of all){let t=label(e);if(!pos&&yesRe.test(t))pos=e;if(!neg&&noRe.test(t))neg=e;if(pos&&neg)break;}" +
                "if(!pos||!neg)return JSON.stringify({found:false,clicked:false,accept:'',reject:''});" +
                "let ctx=null;let p=pos;for(let i=0;p&&i<6;i++,p=p.parentElement){if(p.contains(neg)){let tx=clean(p.innerText||p.textContent||'');if(tx.length<=5000&&gateRe.test(tx)){ctx=p;break;}}}" +
                "if(!ctx){let body=clean((document.body&&(document.body.innerText||document.body.textContent))||'');if(body.length<=5000&&gateRe.test(body))ctx=document.body;}" +
                "if(!ctx)return JSON.stringify({found:false,clicked:false,accept:'',reject:''});" +
                "let a=label(pos),n=label(neg);if(allowClick){setTimeout(()=>{try{pos.click()}catch(e){}},0);}" +
                "return JSON.stringify({found:true,clicked:allowClick,accept:a,reject:n});" +
                "}catch(e){return JSON.stringify({found:false,clicked:false,accept:'',reject:'',error:String(e)});}})()";
    }

    private static String buildCollectorScript(int targetPx) {
        return "(function(){" +
                "const target=" + targetPx + ";" +
                "const abs=(u)=>{try{if(!u||/^(data:|blob:|javascript:|#)/i.test(u))return '';return new URL(u,document.baseURI).href}catch(e){return ''}};" +
                "const uniq=(a)=>Array.from(new Set(a.filter(Boolean)));" +
                "const chooseSrcset=(img)=>{" +
                " let rows=[]; let ss=img.getAttribute('srcset')||img.getAttribute('data-srcset')||'';" +
                " if(ss){ss.split(',').forEach(part=>{let p=part.trim().split(/\\s+/);let u=abs(p[0]);if(!u)return;let d=p[1]||'';let w=0;" +
                "  if(/^[0-9.]+w$/i.test(d))w=parseFloat(d);" +
                "  else if(/^[0-9.]+x$/i.test(d)){let base=img.clientWidth||img.width||target;w=base*parseFloat(d);}" +
                "  rows.push({u:u,w:w});});}" +
                " let known=rows.filter(x=>x.w>0).sort((a,b)=>a.w-b.w);" +
                " if(known.length){let hit=known.find(x=>x.w>=target);return (hit||known[known.length-1]).u;}" +
                " return rows.length?rows[rows.length-1].u:'';" +
                "};" +
                "let images=[],videos=[],streams=[],links=[],thumbLinks=[];" +
                "document.querySelectorAll('img').forEach(i=>{" +
                " let iw=i.naturalWidth||i.width||i.clientWidth||0, ih=i.naturalHeight||i.height||i.clientHeight||0;if(iw>0&&ih>0&&(iw<=2||ih<=2))return;" +
                " let chosen=chooseSrcset(i);" +
                " if(!chosen){let c=[i.getAttribute('data-original'),i.getAttribute('data-src'),i.getAttribute('data-lazy-src'),i.currentSrc,i.src];chosen=c.map(abs).find(Boolean)||'';}" +
                " if(chosen){images.push(chosen);let a=i.closest('a[href]');if(a){let href=abs(a.getAttribute('href')||a.href);if(href)thumbLinks.push({img:chosen,href:href});}}" +
                "});" +
                "document.querySelectorAll('meta[property=\"og:image\"],meta[name=\"twitter:image\"],link[rel=\"image_src\"]').forEach(m=>images.push(abs(m.content||m.href)));" +
                "document.querySelectorAll('video').forEach(v=>{[v.currentSrc,v.src,v.getAttribute('data-src')].map(abs).filter(Boolean).forEach(x=>{if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)})});" +
                "document.querySelectorAll('video source,source[type^=\"video/\"]').forEach(s=>{let x=abs(s.src||s.getAttribute('src'));if(x){if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)}});" +
                "document.querySelectorAll('meta[property=\"og:video\"],meta[property=\"og:video:url\"],meta[property=\"og:video:secure_url\"]').forEach(m=>{let x=abs(m.content);if(x){if(/\\.(m3u8|mpd)(\\?|$)/i.test(x))streams.push(x);else videos.push(x)}});" +
                "let allAnchors=Array.from(document.querySelectorAll('a[href]'));" +
                "let pageNumText=t=>{let x=(t||'').replace(/\\xA0/g,' ').trim();let m=x.match(/^[\\[\\(（\\{<＜【［]?\\s*(\\d{1,4})\\s*[\\]\\)）\\}>＞】］]?$/);return m?m[1]:'';};" +
                "let bracketPageNum=t=>/^[\\[\\(（\\{<＜【［]\\s*\\d{1,4}\\s*[\\]\\)）\\}>＞】］]$/.test((t||'').trim());" +
                "let pageParam=/^(page|paged|page_no|pageno|pageindex|page_index|pg|p|start|offset)$/i;" +
                "let hrefPageKind=(u,t,rel)=>{try{let here=new URL(location.href),x=new URL(u,document.baseURI);if(x.origin!==here.origin||x.pathname!==here.pathname)return '';let keys=new Set([...here.searchParams.keys(),...x.searchParams.keys()]);let changed=[],otherChanged=false;keys.forEach(k=>{let av=JSON.stringify(here.searchParams.getAll(k)),bv=JSON.stringify(x.searchParams.getAll(k));if(av!==bv){if(pageParam.test(k))changed.push(k);else otherChanged=true;}});if(!changed.length||otherChanged)return '';if(!changed.every(k=>/^\\d+$/.test(x.searchParams.get(k)||'')))return '';let tx=(t||'').trim();let nav=!!pageNumText(tx)||/^(next|next page|prev|previous|previous page|次へ|次のページ|前へ|前のページ|›|»|‹|«|>|<|→|←)$/i.test(tx)||(rel||'').toLowerCase().includes('next')||(rel||'').toLowerCase().includes('prev');return nav?'href_param':'';}catch(e){return '';}};" +
                "let groupedPageLinks=new Set();" +
                "allAnchors.forEach(a=>{if(!pageNumText(a.textContent))return;let e=a.parentElement;for(let level=0;e&&level<5;level++,e=e.parentElement){let aa=Array.from(e.querySelectorAll('a[href]'));if(aa.length<1||aa.length>40)continue;let nums=aa.filter(x=>pageNumText(x.textContent));let txt=(e.textContent||'').trim();let bt=txt.match(/[\\[\\(（\\{<＜【［]\\s*\\d{1,4}\\s*[\\]\\)）\\}>＞】］]/g)||[];let compact=txt.length<=180;let strong=nums.length>=3||(nums.length>=2&&nums.length/aa.length>=0.55&&(bt.length>=2||nums.every(x=>bracketPageNum(x.textContent))))||(nums.length>=1&&bt.length>=3&&compact);if(strong){nums.forEach(x=>groupedPageLinks.add(x));break;}}});" +
                "allAnchors.forEach(a=>{" +
                " let u=abs(a.href);if(!u)return;" +
                " if(/\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif)(\\?|$)/i.test(u)&&!a.querySelector('img'))images.push(u);" +
                " if(/\\.(mp4|webm|mov|m4v|3gp)(\\?|$)/i.test(u))videos.push(u);" +
                " if(/\\.(m3u8|mpd)(\\?|$)/i.test(u))streams.push(u);" +
                " let t=(a.textContent||'').trim(); let rel=(a.rel||'').toLowerCase();" +
                " let ctx=((a.className||'')+' '+(a.id||'')+' '+((a.parentElement&&(a.parentElement.className||''))||'')).toLowerCase();" +
                " let numeric=!!pageNumText(t);" +
                " let next=/^(next|next page|次へ|次のページ|›|»|>|→)$/i.test(t);" +
                " let pageClass=/(pagination|pager|paging|page-numbers|pagenavi)/i.test(ctx);" +
                " let groupedNumeric=groupedPageLinks.has(a);" +
                " let hrefKind=hrefPageKind(u,t,rel);" +
                " let pagination=!!hrefKind||rel.includes('next')||next||(numeric&&pageClass)||groupedNumeric;" +
                " links.push({url:u,pagination:pagination,paginationKind:(hrefKind||(groupedNumeric?'numeric_group':((numeric&&pageClass)?'numeric_class':((rel.includes('next')||next)?'next':''))))});" +
                "});" +
                "document.querySelectorAll('[style]').forEach(e=>{let b=getComputedStyle(e).backgroundImage||'';let m=b.match(/url\\([\"']?([^\"')]+)[\"']?\\)/i);if(m)images.push(abs(m[1]))});" +
                "return JSON.stringify({title:document.title||'',images:uniq(images),videos:uniq(videos),streams:uniq(streams),links:links,thumbLinks:thumbLinks});" +
                "})()";
    }
}
