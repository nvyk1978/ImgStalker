package com.cmyk.imgstalker;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * UI-only history and favorites. This store has no dependency on crawler, downloader,
 * resume or saved-media ledgers; it cannot mutate an X, Instagram or NORMAL session.
 */
final class SiteVisitStore {
    private static final String PREF = "imgstalker_site_navigation_v1";
    private static final String KEY = "entries";
    private static final String BOOKMARK_ORDER = "bookmark_order_v1";
    private static final int MAX_ENTRIES = 250;

    static final class Entry {
        final String url;
        final String title;
        final boolean favorite;
        final long visitedAt;
        final long updatedAt;
        Entry(String url, String title, boolean favorite, long visitedAt, long updatedAt) {
            this.url = url; this.title = title; this.favorite = favorite;
            this.visitedAt = visitedAt; this.updatedAt = updatedAt;
        }
        String displayTitle() {
            return displayTitleForUrl(url, title);
        }
    }
    private SiteVisitStore() {}

    static String normalize(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        if (value.length() < 8 || value.length() > 4096) return "";
        try {
            Uri parsed = Uri.parse(value);
            String scheme = parsed.getScheme();
            String host = parsed.getHost();
            if (scheme == null || !(scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http"))
                    || host == null || host.trim().isEmpty() || value.indexOf(' ') >= 0) return "";
            int fragment = value.indexOf('#');
            if (fragment >= 0) value = value.substring(0, fragment);
            // Scheme and host are only used to validate; preserve the exact navigable URL,
            // including its case-sensitive path and query parameters.
            return value;
        } catch (RuntimeException invalid) {
            return "";
        }
    }

    static String host(String url) {
        try {
            String host = Uri.parse(url).getHost();
            return host == null || host.isEmpty() ? url : host.toLowerCase(Locale.ROOT);
        } catch (RuntimeException invalid) { return url; }
    }

    /**
     * Navigation labels only: never call an SNS crawler or touch its cookies/saved ledgers.
     * The URL remains the persistent navigation identity; the display name may change.
     */
    static String socialHandleForUrl(String url) {
        String normalized = normalize(url);
        if (normalized.isEmpty()) return "";
        try {
            Uri uri = Uri.parse(normalized);
            String domain = uri.getHost().toLowerCase(Locale.ROOT);
            boolean instagram = domain.equals("instagram.com") || domain.equals("www.instagram.com")
                    || domain.equals("m.instagram.com");
            boolean x = domain.equals("x.com") || domain.equals("www.x.com")
                    || domain.equals("twitter.com") || domain.equals("www.twitter.com")
                    || domain.equals("mobile.twitter.com");
            boolean threads = (domain.equals("threads.com") || domain.endsWith(".threads.com")
                    || domain.equals("threads.net") || domain.endsWith(".threads.net"));
            if (!instagram && !x && !threads) return "";
            String path = uri.getPath();
            if (path == null) return "";
            String segment = path.startsWith("/") ? path.substring(1) : path;
            int slash = segment.indexOf('/');
            if (slash >= 0) segment = segment.substring(0, slash);
            if (segment.isEmpty()) return "";
            String lower = segment.toLowerCase(Locale.ROOT);
            if (instagram && (lower.equals("p") || lower.equals("reel") || lower.equals("reels")
                    || lower.equals("tv") || lower.equals("stories") || lower.equals("explore")
                    || lower.equals("accounts") || lower.equals("direct") || lower.equals("about"))) return "";
            if (x && (lower.equals("i") || lower.equals("home") || lower.equals("search")
                    || lower.equals("explore") || lower.equals("notifications") || lower.equals("messages")
                    || lower.equals("settings") || lower.equals("login") || lower.equals("intent")
                    || lower.equals("compose"))) return "";
            if (threads) {
                if (!segment.startsWith("@") || !segment.substring(1).matches("[A-Za-z0-9._]{1,64}")) return "";
                return segment;
            }
            if (instagram && !segment.matches("[A-Za-z0-9._]{1,30}")) return "";
            if (x && !segment.matches("[A-Za-z0-9_]{1,15}")) return "";
            return "@" + segment;
        } catch (RuntimeException invalid) {
            return "";
        }
    }

    static String displayTitleForUrl(String url, String rawTitle) {
        String handle = socialHandleForUrl(url);
        String clean = rawTitle == null ? "" : rawTitle.trim();
        if (!handle.isEmpty()) {
            // The profile's HTML title commonly reads "Display Name (@handle) • Instagram".
            // Use a human name only when the title actually references this target account;
            // otherwise use @handle instead of an unrelated page or signed-in account.
            Pattern verifiedName = Pattern.compile("^(.{1,100}?)\\s*\\(\\s*" +
                    Pattern.quote(handle) + "\\s*\\)", Pattern.CASE_INSENSITIVE);
            Matcher match = verifiedName.matcher(clean);
            if (match.find()) {
                String name = match.group(1).trim();
                if (!name.isEmpty() && !isGenericSocialTitle(name)) return name;
            }
            return handle;
        }
        if (clean.isEmpty() || clean.equalsIgnoreCase("ImgStalker")) return host(url);
        return clean.length() > 100 ? clean.substring(0, 100) : clean;
    }

    private static boolean isGenericSocialTitle(String name) {
        String text = name.trim().toLowerCase(Locale.ROOT);
        return text.equals("instagram") || text.equals("threads") || text.equals("x") || text.equals("twitter")
                || text.equals("log in") || text.equals("login");
    }

    static void recordVisit(Context context, String url) {
        String key = normalize(url);
        if (key.isEmpty()) return;
        LinkedHashMap<String, Entry> map = load(context);
        Entry old = map.get(key);
        long now = System.currentTimeMillis();
        map.put(key, new Entry(key, old == null ? "" : old.title,
                old != null && old.favorite, now, now));
        save(context, map);
    }

    static void recordTitle(Context context, String url, String title) {
        String key = normalize(url);
        if (key.isEmpty() || title == null) return;
        String clean = title.trim();
        if (clean.isEmpty() || "ImgStalker".equals(clean)) return;
        if (clean.length() > 100) clean = clean.substring(0, 100);
        LinkedHashMap<String, Entry> map = load(context);
        Entry old = map.get(key);
        if (old == null || old.visitedAt <= 0L) return;
        map.put(key, new Entry(key, clean, old.favorite, old.visitedAt, old.updatedAt));
        save(context, map);
    }

    static boolean isFavorite(Context context, String url) {
        String key = normalize(url);
        if (key.isEmpty()) return false;
        Entry e = load(context).get(key);
        return e != null && e.favorite;
    }

    static boolean toggleFavorite(Context context, String url) {
        String key = normalize(url);
        if (key.isEmpty()) return false;
        LinkedHashMap<String, Entry> map = load(context);
        Entry old = map.get(key);
        boolean selected = old == null || !old.favorite;
        map.put(key, new Entry(key, old == null ? "" : old.title,
                selected, old == null ? 0L : old.visitedAt, System.currentTimeMillis()));
        save(context, map);
        // Ordering is independent of the visit timestamp and stored favorite records.
        // A newly bookmarked URL is inserted at the start, never silently reordered by a visit.
        List<String> order = bookmarkOrder(context);
        order.remove(key);
        if (selected) order.add(0, key);
        setBookmarkOrder(context, order);
        return selected;
    }

    /** Remove browsing history without affecting a bookmark for the same URL. */
    static boolean removeHistory(Context context, String url) {
        String key = normalize(url);
        if (key.isEmpty()) return false;
        LinkedHashMap<String, Entry> map = load(context);
        if (!removeHistoryFromEntries(map, key)) return false;
        save(context, map);
        return true;
    }

    // Package-visible pure operation for regression testing; no crawler/session dependencies.
    static boolean removeHistoryFromEntries(LinkedHashMap<String, Entry> map, String key) {
        Entry old = map.get(key);
        if (old == null || old.visitedAt <= 0L) return false;
        if (old.favorite) {
            map.put(key, new Entry(old.url, old.title, true, 0L, old.updatedAt));
        } else {
            map.remove(key);
        }
        return true;
    }

    static List<Entry> entries(Context context, boolean favoritesOnly) {
        List<Entry> out = new ArrayList<>();
        for (Entry e : load(context).values()) {
            if (favoritesOnly ? e.favorite : e.visitedAt > 0L) out.add(e);
        }
        Collections.sort(out, (a, b) -> Long.compare(
                favoritesOnly ? b.updatedAt : b.visitedAt,
                favoritesOnly ? a.updatedAt : a.visitedAt));
        if (favoritesOnly) {
            List<String> saved = bookmarkOrder(context);
            if (!saved.isEmpty()) {
                java.util.HashMap<String, Integer> ranks = new java.util.HashMap<>();
                for (int i = 0; i < saved.size(); i++) ranks.put(saved.get(i), i);
                // Stable sort: preexisting records absent from the order key retain legacy recency.
                Collections.sort(out, (a, b) -> Integer.compare(
                        ranks.containsKey(a.url) ? ranks.get(a.url) : Integer.MAX_VALUE,
                        ranks.containsKey(b.url) ? ranks.get(b.url) : Integer.MAX_VALUE));
            }
        }
        return out;
    }

    private static List<String> bookmarkOrder(Context context) {
        ArrayList<String> out = new ArrayList<>();
        try {
            JSONArray saved = new JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .getString(BOOKMARK_ORDER, "[]"));
            for (int i = 0; i < saved.length(); i++) {
                String url = normalize(saved.optString(i, ""));
                if (!url.isEmpty() && !out.contains(url)) out.add(url);
            }
        } catch (Exception e) { DiagnosticLog.logException("BOOKMARK_ORDER_READ_FAIL", e); }
        return out;
    }

    /** Called only after a drag-and-drop completes. Never edits timestamps or media ledgers. */
    static void setBookmarkOrder(Context context, List<String> requested) {
        LinkedHashMap<String, Entry> records = load(context);
        java.util.LinkedHashSet<String> order = new java.util.LinkedHashSet<>();
        if (requested != null) for (String raw : requested) {
            String key = normalize(raw);
            Entry entry = records.get(key);
            if (entry != null && entry.favorite) order.add(key);
        }
        // Retain bookmarks added concurrently while the dialog was showing.
        for (Entry entry : entriesWithoutCustomOrder(records)) {
            if (entry.favorite) order.add(entry.url);
        }
        JSONArray json = new JSONArray();
        for (String url : order) json.put(url);
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(BOOKMARK_ORDER, json.toString()).apply();
    }

    private static List<Entry> entriesWithoutCustomOrder(LinkedHashMap<String, Entry> records) {
        List<Entry> all = new ArrayList<>(records.values());
        Collections.sort(all, (a, b) -> Long.compare(b.updatedAt, a.updatedAt));
        return all;
    }

    private static LinkedHashMap<String, Entry> load(Context context) {
        LinkedHashMap<String, Entry> result = new LinkedHashMap<>();
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            JSONArray array = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject json = array.optJSONObject(i);
                if (json == null) continue;
                String url = normalize(json.optString("url", ""));
                if (url.isEmpty()) continue;
                result.put(url, new Entry(url, json.optString("title", ""),
                        json.optBoolean("favorite", false), json.optLong("visitedAt", 0),
                        json.optLong("updatedAt", 0)));
            }
        } catch (Exception e) { DiagnosticLog.logException("SITE_NAVIGATION_LOAD_FAIL", e); }
        return result;
    }

    private static void save(Context context, LinkedHashMap<String, Entry> entries) {
        try {
            ArrayList<Entry> all = new ArrayList<>(entries.values());
            Collections.sort(all, (a, b) -> Long.compare(b.updatedAt, a.updatedAt));
            JSONArray array = new JSONArray();
            int count = 0;
            for (Entry entry : all) {
                // Favorite entries are never discarded just because the history filled up.
                if (count >= MAX_ENTRIES && !entry.favorite) continue;
                JSONObject json = new JSONObject();
                json.put("url", entry.url);
                json.put("title", entry.title);
                json.put("favorite", entry.favorite);
                json.put("visitedAt", entry.visitedAt);
                json.put("updatedAt", entry.updatedAt);
                array.put(json);
                count++;
            }
            context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putString(KEY, array.toString()).apply();
        } catch (Exception e) { DiagnosticLog.logException("SITE_NAVIGATION_SAVE_FAIL", e); }
    }
}
