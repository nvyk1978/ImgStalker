package com.cmyk.imgstalker;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class MediaDownloader {
    public interface Listener {
        void onProgress(int done, int total, String message);
        void onFinished(String folderName, int success, int failed);
    }

    private final Context context;
    private final Listener listener;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final AtomicBoolean cancelled = new AtomicBoolean(false);

    public MediaDownloader(Context context, Listener listener) {
        this.context = context.getApplicationContext();
        this.listener = listener;
    }

    public void cancel() {
        DiagnosticLog.log("DOWNLOADER_CANCEL");
        cancelled.set(true);
        pool.shutdownNow();
    }

    public void download(List<MediaItem> source, String pageTitle) {
        ArrayList<MediaItem> items = new ArrayList<>();
        for (MediaItem i : source) if (i.selected && i.kind != MediaItem.Kind.STREAM) items.add(i);
        final int total = items.size();
        DiagnosticLog.log("DOWNLOADER_BEGIN total=" + total + " title=" + pageTitle);
        if (total == 0) {
            listener.onFinished("", 0, 0);
            return;
        }
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.JAPAN).format(new Date());
        String base = sanitize(pageTitle);
        if (base.isEmpty()) base = "WebMedia";
        final String folder = base + "_" + stamp;
        AtomicInteger done = new AtomicInteger();
        AtomicInteger ok = new AtomicInteger();
        AtomicInteger ng = new AtomicInteger();

        for (int idx = 0; idx < items.size(); idx++) {
            final int index = idx + 1;
            final MediaItem item = items.get(idx);
            pool.submit(() -> {
                if (!cancelled.get()) {
                    try {
                        downloadOne(item, folder, index);
                        ok.incrementAndGet();
                        DiagnosticLog.log("DOWNLOAD_OK kind=" + item.kind + " url=" + item.url);
                    } catch (Exception e) {
                        ng.incrementAndGet();
                        DiagnosticLog.logException("DOWNLOAD_FAIL kind=" + item.kind + " url=" + item.url, e);
                    }
                } else {
                    ng.incrementAndGet();
                }
                int d = done.incrementAndGet();
                listener.onProgress(d, total, item.url);
                if (d == total) listener.onFinished(folder, ok.get(), ng.get());
            });
        }
    }

    private void downloadOne(MediaItem item, String folder, int index) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(item.url).openConnection();
        con.setInstanceFollowRedirects(true);
        con.setConnectTimeout(15000);
        con.setReadTimeout(30000);
        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/140 Mobile Safari/537.36 ImgStalker/0.1.2");
        con.setRequestProperty("Accept", item.kind == MediaItem.Kind.IMAGE ? "image/avif,image/webp,image/*,*/*;q=0.8" : "video/*,*/*;q=0.8");
        if (item.referrer != null && !item.referrer.isEmpty()) con.setRequestProperty("Referer", item.referrer);
        String cookie = CookieManager.getInstance().getCookie(item.url);
        if (cookie != null && !cookie.isEmpty()) con.setRequestProperty("Cookie", cookie);
        DiagnosticLog.log("DOWNLOAD_HTTP_BEGIN url=" + item.url + " ref=" + item.referrer);
        con.connect();
        int code = con.getResponseCode();
        DiagnosticLog.log("DOWNLOAD_HTTP_RESPONSE code=" + code + " type=" + con.getContentType() + " length=" + con.getContentLengthLong() + " url=" + item.url);
        if (code < 200 || code >= 400) throw new FileNotFoundException("HTTP " + code);

        String contentType = con.getContentType();
        if (contentType != null) {
            int semi = contentType.indexOf(';');
            if (semi >= 0) contentType = contentType.substring(0, semi).trim();
        }
        String original = filenameFromUrl(con.getURL().toString());
        String ext = extension(original);
        if (ext.isEmpty()) ext = extensionForMime(contentType, item.kind);
        if (original.isEmpty() || extension(original).isEmpty()) {
            original = (item.kind == MediaItem.Kind.IMAGE ? "image" : "video") + "_" + String.format(Locale.US, "%03d", index) + ext;
        }
        original = sanitizeFilename(original);
        String displayName = String.format(Locale.US, "%03d_", index) + original;
        String sub = item.kind == MediaItem.Kind.IMAGE ? "images" : "videos";
        String relPath = Environment.DIRECTORY_DOWNLOADS + "/ImgStalker/" + folder + "/" + sub + "/";

        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, contentType != null ? contentType : fallbackMime(item.kind, ext));
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, relPath);
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        ContentResolver resolver = context.getContentResolver();
        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new FileNotFoundException("MediaStore insert failed");

        boolean success = false;
        try (BufferedInputStream in = new BufferedInputStream(con.getInputStream());
             OutputStream raw = resolver.openOutputStream(uri, "w");
             BufferedOutputStream out = new BufferedOutputStream(raw)) {
            byte[] buf = new byte[128 * 1024];
            int n;
            while (!cancelled.get() && (n = in.read(buf)) >= 0) out.write(buf, 0, n);
            out.flush();
            if (cancelled.get()) throw new InterruptedException("cancelled");
            success = true;
        } finally {
            con.disconnect();
            if (success) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
            } else {
                resolver.delete(uri, null, null);
            }
        }
    }

    private static String filenameFromUrl(String s) {
        try {
            String p = new URL(s).getPath();
            int slash = p.lastIndexOf('/');
            String f = slash >= 0 ? p.substring(slash + 1) : p;
            return URLDecoder.decode(f, StandardCharsets.UTF_8.name());
        } catch (Exception e) { return ""; }
    }

    private static String extension(String f) {
        if (f == null) return "";
        int dot = f.lastIndexOf('.');
        if (dot < 0 || dot < f.length() - 8) return "";
        String e = f.substring(dot).toLowerCase(Locale.ROOT);
        return e.matches("\\.(jpg|jpeg|png|gif|webp|bmp|avif|heic|heif|mp4|webm|mov|m4v|3gp)") ? e : "";
    }

    private static String extensionForMime(String mime, MediaItem.Kind kind) {
        if (mime == null) return kind == MediaItem.Kind.IMAGE ? ".jpg" : ".mp4";
        switch (mime.toLowerCase(Locale.ROOT)) {
            case "image/jpeg": return ".jpg";
            case "image/png": return ".png";
            case "image/gif": return ".gif";
            case "image/webp": return ".webp";
            case "image/avif": return ".avif";
            case "video/webm": return ".webm";
            case "video/quicktime": return ".mov";
            case "video/3gpp": return ".3gp";
            default: return kind == MediaItem.Kind.IMAGE ? ".jpg" : ".mp4";
        }
    }

    private static String fallbackMime(MediaItem.Kind kind, String ext) {
        if (kind == MediaItem.Kind.IMAGE) {
            if (".png".equals(ext)) return "image/png";
            if (".gif".equals(ext)) return "image/gif";
            if (".webp".equals(ext)) return "image/webp";
            if (".avif".equals(ext)) return "image/avif";
            return "image/jpeg";
        }
        if (".webm".equals(ext)) return "video/webm";
        if (".mov".equals(ext)) return "video/quicktime";
        return "video/mp4";
    }

    private static String sanitize(String s) {
        if (s == null) return "";
        s = s.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (s.length() > 60) s = s.substring(0, 60).trim();
        return s;
    }

    private static String sanitizeFilename(String s) {
        String x = sanitize(s);
        return x.isEmpty() ? "media" : x;
    }
}
