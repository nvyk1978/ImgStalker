
## 0.1.53
- バックグラウンド解析の保持を強化。Foreground Serviceが実行中のCrawler/WebViewセッションを保持する。
- 通常URL解析 / X / Instagram などCrawlerEngineを使う解析全体で「バックグラウンドでも解析」を共通利用する。
- ActivityがonStopへ入った時点で、バックグラウンド解析ONならCrawler/WebViewを停止せずService側の非表示ホストへWebViewを退避し、画面復帰時は同じWebViewをActivityへ再接続する。
- Activity破棄時もバックグラウンド解析ONならCrawler/WebViewを停止・破棄しない。
- ServiceはPARTIAL_WAKE_LOCKに加えてWebView rendererをIMPORTANTとして維持し、task removed/trim memory時にも解析セッションを保持する。
- `android:stopWithTask=false` とし、タスクを外しても解析中Serviceを即停止しない。
- Instagram/XのCrawlerEngine巡回ロジック自体は0.1.52から変更しない。

# ImgStalker v0.1.53 (54)

## v0.1.52
- Added a leading N-toggle `バックグラウンドでも解析` directly below the image/video/stream/selection summary. Default OFF; ON color is N Orange `#775500`.
- The toggle can be changed while analysis is running. ON starts a foreground `dataSync` keep-alive service with a partial wake lock; OFF stops it immediately. The service also stops automatically when analysis completes, errors, is manually stopped, or is cancelled for download.
- The existing crawler/WebView traversal and Instagram retry/loading logic from v0.1.51 is unchanged.
- Changed the bottom `選択` button from N Orange to N Light Blue `#445577`.

# ImgStalker v0.1.51 (52)

## v0.1.51
- Instagram Networkで検出済みの動画候補を、DOM詳細収集開始時刻より前という理由だけで破棄しないよう修正。ReelのMP4本体をVIDEOとして一覧へ渡す。
- Instagramの `video_default_cover_frame` は動画サムネイルとして判定し、独立IMAGEとして一覧へ追加しない。
- Instagram VIDEO登録時に `MEDIA_QUEUED kind=VIDEO` を診断ログへ記録。
- v0.1.50で改善したInstagram巡回・再試行・カルーセル読み込みロジックは変更なし。

## v0.1.50
- Instagram detail traversal no longer lets one failed post block the whole profile.
- A failed carousel/detail load is moved to the back of the detail queue and retried from slide 1 after other queued posts get a turn.
- Instagram retry has no completion/skip cap; the crawler continues cycling unfinished posts until they complete or the user presses Stop.
- Empty-media/reel waits are bounded per visit, then deferred instead of ending analysis.
- Missing/un-clickable Next and slide-change failures get short in-page recovery, then defer/retry rather than completion.
- A first-slide terminal state with multiple loaded media items is treated as ambiguous carousel state and is never accepted as completed; it is retried later.
- Normal single-media/final-slide terminal confirmation uses the v0.1.43-style grace period without a full reload.
- Existing Instagram image/video de-duplication remains based on actual CDN image identity and video asset/path identity, not only slide number.
- Header gear and diagnostic icons retain the slightly reduced visual size while keeping the same 44dp touch targets.

## Package
- versionCode 54 / versionName 0.1.53.
- applicationId and fixed signing key are unchanged.
- applicationId and fixed signing key are unchanged.
