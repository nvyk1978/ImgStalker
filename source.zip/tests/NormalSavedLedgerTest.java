package com.cmyk.imgstalker;

import android.content.Context;
import java.io.File;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.Map;

/** Simulates a file manager deleting downloaded data or a resume checkpoint. */
public final class NormalSavedLedgerTest {
    private static void check(boolean okay, String message) {
        if (!okay) throw new AssertionError(message);
    }
    private static String uri(File file) { return "content://test/"+file.getAbsolutePath(); }
    public static void main(String[] args) throws Exception {
        File data = new File(args[0]);
        Context context = new Context(data);
        String a0 = "https://legmemory.com/bbs/alpha/joyfulyy.cgi?page=0";
        String a15 = "https://legmemory.com/bbs/alpha/joyfulyy.cgi?page=15";
        String b = "https://legmemory.com/bbs/beta/joyfulyy.cgi?page=0";
        String other = "https://example.com/page?page=0";
        String x = "https://x.com/other";
        String ig = "https://instagram.com/other";
        String one = NormalSavedLedgerStore.mediaKey(new MediaItem("https://cdn.example/a.jpg", a0, MediaItem.Kind.IMAGE, false));
        String two = NormalSavedLedgerStore.mediaKey(new MediaItem("https://cdn.example/b.jpg", a0, MediaItem.Kind.IMAGE, false));
        check(NormalSavedLedgerStore.key(a0).equals(NormalSavedLedgerStore.key(a15)), "pagination shares target");
        check(NormalSavedLedgerStore.key(x).isEmpty() && NormalSavedLedgerStore.key(ig).isEmpty(), "SNS forbidden");
        File fileA = new File(data, "a.jpg"); File fileB = new File(data, "b.jpg");
        Files.write(fileA.toPath(), new byte[] {1,2,3});
        Files.write(fileB.toPath(), new byte[] {4,5,6});
        Map<String,String> initial = new LinkedHashMap<>();
        initial.put(one,uri(fileA)); initial.put(two,uri(fileB));
        check(NormalSavedLedgerStore.load(context, a0).isEmpty(), "fresh ledger empty");
        check(NormalSavedLedgerStore.save(context,a0,initial),"save location inventory");
        check(NormalSavedLedgerStore.load(context,a15).size()==2,"restore same site target");
        check(NormalSavedLedgerStore.load(context,b).isEmpty(),"other board separate");
        check(NormalSavedLedgerStore.load(context,other).isEmpty(),"other site separate");
        check(!NormalSavedLedgerStore.save(context,x,initial),"X write refused");
        check(!NormalSavedLedgerStore.save(context,ig,initial),"Instagram write refused");
        File progress=NormalCheckpointStore.checkpoint(context,a0);progress.getParentFile().mkdirs();progress.createNewFile();
        check(progress.delete(),"delete disposable progress json");
        check(NormalSavedLedgerStore.load(context,a0).size()==2,"cache deletion keeps existing real files checked");
        check(fileA.delete(),"delete downloaded image");
        Map<String,String> checked = NormalSavedLedgerStore.load(context,a0);
        check(!checked.containsKey(one) && checked.containsKey(two),"missing media loses green check, existing retained");
        check(NormalSavedLedgerStore.save(context,a0,checked),"persist cleaned inventory");
        check(!NormalSavedLedgerStore.load(context,a0).containsKey(one),"deleted file can re-download");
        // v1 cannot prove file existence and must not block repopulation.
        System.out.println("PASS NORMAL URI verification, removed-file re-download, cache behavior, mode separation");
    }
}
