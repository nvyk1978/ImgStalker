package com.cmyk.imgstalker;
import android.content.Context;
import java.util.List;
final class XDownloaderAdapter implements ModeDownloader {
    private final MediaDownloader core;
    XDownloaderAdapter(Context context, boolean xGif, MediaDownloader.Listener listener) {core=new MediaDownloader(context, xGif, listener);}
    @Override public void download(List<MediaItem> items, String title, String category, String account) {
        core.download(items, title, category, account);
    }
    @Override public void cancel(){core.cancel();}
}
