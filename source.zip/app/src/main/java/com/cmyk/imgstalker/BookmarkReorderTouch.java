package com.cmyk.imgstalker;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import java.util.ArrayList;

/** Long-press, drag-to-insert ordering for bookmark rows only. No handles. */
final class BookmarkReorderTouch {
    private final Context context;
    private final ScrollView scroller;
    private final LinearLayout container;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private View active;
    private float downY;
    private float lastY;
    private int startScroll;
    private int from;
    private int to;
    private boolean dragging;

    BookmarkReorderTouch(Context context, ScrollView scroll, LinearLayout content) {
        this.context = context; scroller = scroll; container = content;
    }

    void bind(View touchTarget, View group) {
        // Explicitly trigger exactly one haptic on the transition into drag mode.
        touchTarget.setHapticFeedbackEnabled(false);
        touchTarget.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downY = lastY = event.getRawY();
                    startScroll = scroller.getScrollY();
                    return false; // Android still performs normal tap and long-press detection.
                case MotionEvent.ACTION_MOVE:
                    lastY = event.getRawY();
                    if (dragging && active == group) { update(); return true; }
                    return false;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (dragging && active == group) {
                        finish(event.getActionMasked() == MotionEvent.ACTION_UP);
                        return true;
                    }
                    return false;
                default: return false;
            }
        });
        touchTarget.setOnLongClickListener(v -> {
            if (dragging || group.getParent() != container
                    || group.getVisibility() != View.VISIBLE) return true;
            active = group;
            from = container.indexOfChild(group);
            to = from;
            dragging = true;
            lastY = downY;
            active.setElevation(dp(15));
            scroller.requestDisallowInterceptTouchEvent(true);
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS,
                    HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);
            handler.post(autoScroll);
            return true;
        });
    }

    private int dp(float amount) { return (int) (amount * context.getResources().getDisplayMetrics().density + .5f); }

    private final Runnable autoScroll = new Runnable() {
        @Override public void run() {
            if (!dragging || active == null) return;
            int[] point = new int[2];
            scroller.getLocationOnScreen(point);
            int top = point[1];
            int bottom = top + scroller.getHeight();
            int delta = lastY < top + dp(44) ? -dp(9) : lastY > bottom - dp(44) ? dp(9) : 0;
            if (delta != 0) {
                int previous = scroller.getScrollY();
                scroller.scrollBy(0, delta);
                if (previous != scroller.getScrollY()) update();
            }
            handler.postDelayed(this, 24);
        }
    };

    private void update() {
        if (active == null) return;
        float dy = lastY - downY + scroller.getScrollY() - startScroll;
        active.setTranslationY(dy);
        float center = active.getTop() + dy + active.getHeight() / 2f;
        int target = from;
        for (int index = 0; index < container.getChildCount(); index++) {
            if (index == from) continue;
            View candidate = container.getChildAt(index);
            if (candidate.getVisibility() != View.VISIBLE || !(candidate.getTag() instanceof String)) continue;
            float midpoint = candidate.getTop() + candidate.getHeight() / 2f;
            if (index > from && center > midpoint) target = index;
            if (index < from && center < midpoint) { target = index; break; }
        }
        if (target != to) {
            to = target;
            for (int i = 0; i < container.getChildCount(); i++) {
                View v = container.getChildAt(i);
                if (v == active || v.getVisibility() != View.VISIBLE) continue;
                float offset = i > from && i <= to ? -active.getHeight()
                        : i < from && i >= to ? active.getHeight() : 0;
                v.animate().translationY(offset).setDuration(145).start();
            }
        }
    }

    void cancel() {
        handler.removeCallbacks(autoScroll);
        if (dragging) finish(false);
    }

    private void finish(boolean commit) {
        handler.removeCallbacks(autoScroll);
        dragging = false;
        View dragged = active;
        active = null;
        if (dragged == null) return;
        int destination = commit ? to : from;
        float visualTop = dragged.getTop() + dragged.getTranslationY();
        if (destination != from) {
            container.removeViewAt(from);
            container.addView(dragged, destination);
        }
        for (int i = 0; i < container.getChildCount(); i++) {
            View row = container.getChildAt(i);
            row.animate().cancel();
            if (row != dragged) row.setTranslationY(0);
        }
        // Row height is fixed, so place the dragged row at its old visual position
        // until LinearLayout applies the new child order in the same frame.
        float futureTop = dragged.getTop() + (destination - from) * dragged.getHeight();
        dragged.setTranslationY(visualTop - futureTop);
        dragged.animate().translationY(0).setDuration(165)
                .withEndAction(() -> dragged.setElevation(0)).start();
        if (commit && destination != from) {
            ArrayList<String> visibleOrder = new ArrayList<>();
            for (int i = 0; i < container.getChildCount(); i++) {
                View row = container.getChildAt(i);
                Object tag = row.getTag();
                if (row.getVisibility() == View.VISIBLE && tag instanceof String)
                    visibleOrder.add((String) tag);
            }
            ArrayList<String> allOrder = new ArrayList<>();
            for (SiteVisitStore.Entry item : SiteVisitStore.entries(context, true))
                allOrder.add(item.url);
            SiteVisitStore.setBookmarkOrder(context,
                    NavigationBookmarkOrder.merge(allOrder, visibleOrder));
        }
        scroller.requestDisallowInterceptTouchEvent(false);
    }
}
