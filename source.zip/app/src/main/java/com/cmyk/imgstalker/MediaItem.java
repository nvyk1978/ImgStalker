package com.cmyk.imgstalker;

public final class MediaItem {
    public enum Kind { IMAGE, VIDEO, STREAM }

    public final String url;
    public final String referrer;
    public final Kind kind;
    public boolean selected;

    public MediaItem(String url, String referrer, Kind kind, boolean selected) {
        this.url = url;
        this.referrer = referrer;
        this.kind = kind;
        this.selected = selected;
    }

    public String kindLabel() {
        if (kind == Kind.IMAGE) return "画像";
        if (kind == Kind.VIDEO) return "動画";
        return "ストリーム";
    }
}
