#!/usr/bin/env python3
"""Fail the build on accidental mode mixing. Runs without Android SDK/network."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent.parent
src = root / 'app/src/main/java/com/cmyk/imgstalker'
def require(cond, message):
    if not cond: raise AssertionError('MODE FIREWALL: ' + message)
def source(name): return (src/name).read_text(encoding='utf-8')

core = source('ModeCrawler.java')
require(not re.search(r'Instagram|\bXSearch\b|XReposts|checkpointCursor|seedQueueCursor', core),
        'generic ModeCrawler interface must never expose provider-only hooks')
for name,marker in [('InstagramCrawlerSession.java', 'Instagram'), ('XCrawlerSession.java', 'X')]:
    require((src/name).exists(), f'missing exclusive {marker} interface')

# Build-time negative imports/references: provider and its adapter must own one backend.
allowed = {
 'Normal': ['NormalCrawlerAdapter', 'NormalThumbnailAdapter', 'NormalDownloaderAdapter',
            'NormalOriginalImageLoader', 'NormalSessionCookies', 'NormalPreviewPolicy'],
 'Instagram': ['InstagramCrawlerAdapter', 'InstagramThumbnailAdapter', 'InstagramDownloaderAdapter',
               'InstagramOriginalImageLoader', 'InstagramSessionCookies', 'InstagramPreviewPolicy'],
 'X': ['XCrawlerAdapter', 'XThumbnailAdapter', 'XDownloaderAdapter',
       'OriginalImageLoader', 'SessionCookies', 'XPreviewPolicy'],
}
for mode,names in allowed.items():
    name = mode+'ModeProvider.java'
    data = source(name)
    for own in names:
        require(re.search(r'\b'+own+r'\b',data) is not None, f'{name} does not bind {own}')
    for other,foreign in allowed.items():
        if other == mode: continue
        for forbidden in foreign:
            require(not re.search(r'\b'+forbidden+r'\b',data), f'{name} refers to foreign {forbidden}')

require('new NormalModeProvider()' in source('ModeProviders.java'), 'normal factory unavailable')
require('new XModeProvider()' in source('ModeProviders.java'), 'X factory unavailable')
require('new InstagramModeProvider()' in source('ModeProviders.java'), 'Instagram factory unavailable')

for mode,adapter in [('Normal','NormalCrawlerAdapter.java'), ('Instagram','InstagramCrawlerAdapter.java'), ('X','XCrawlerAdapter.java')]:
    data=source(adapter)
    require('AnalysisModeRouter.fromUrl(url) != AnalysisModeRouter.Mode.'+mode.upper() in data,
            f'{adapter} lost start URL ownership guard')
    if mode == 'Normal':
        require('implements ModeCrawler {' in data, 'normal unexpectedly implements a foreign continuation API')
        require('seedInstagramContinuationState' not in data and 'setIncludeXReposts' not in data,
                'normal adapter inherited a foreign continuation API')
    if mode == 'Instagram':
        require('implements ModeCrawler, InstagramCrawlerSession' in data,'IG must implement only IG continuation')
        require('setIncludeXReposts' not in data and 'seedQueueCursor' not in data,
                'IG adapter exposes X state')
    if mode == 'X':
        require('implements ModeCrawler, XCrawlerSession' in data,'X must implement only X continuation')
        require('seedInstagramContinuationState' not in data,'X adapter exposes Instagram state')

activity=source('MainActivity.java')
require('modeProvider.crawler(webView, guardedListener)' not in activity or 'provider.crawler(webView, guardedListener)' in activity,
        'crawler construction bypassed bound provider')
require('crawler = provider.crawler(webView, guardedListener)' in activity, 'crawler must originate from current provider')
require('thumbnailLoader = provider.thumbnails(this, metadataChanged)' in activity, 'thumbnails must originate from provider')
require('downloader = modeProvider.downloader(this,' in activity,'downloader must originate from current provider')
require('modeProvider.cookieFor(requestUrl)' in activity,'media cookies must originate from provider')
require('imageProvider.original(MainActivity.this, item)' in activity,'original loader must originate from captured provider')
require('modeProvider.preview().isSpecialVideo(' in activity,'preview must use current provider policy')
require('downloadEpoch != crawlerGeneration || downloadMode != activeCrawlerMode' in activity,
        'late download callback generation guard missing')
for foreign in [*allowed['Normal'], *allowed['Instagram'], *allowed['X'], 'TwitterVideoUrl']:
    require(not re.search(r'\b'+foreign+r'\b', activity),f'MainActivity directly refers to concrete provider: {foreign}')
print('PASS: mode backend interfaces, provider construction, UI call sites and callback epoch protected')
