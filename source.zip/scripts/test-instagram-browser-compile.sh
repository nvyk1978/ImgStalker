#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
mkdir -p "$T/src/android/os" "$T/src/android/webkit" "$T/src/android/content/res" "$T/src/android/content" "$T/src/androidx/webkit" "$T/src/org/json" "$T/src/com/cmyk/imgstalker" "$T/classes"
cat > "$T/src/android/os/Looper.java" <<'JAVA'
package android.os; public class Looper {public static Looper getMainLooper(){return new Looper();}}
JAVA
cat > "$T/src/android/os/Handler.java" <<'JAVA'
package android.os; public class Handler { public Handler(Looper l){} public boolean post(Runnable r){r.run();return true;} }
JAVA
cat > "$T/src/android/webkit/ValueCallback.java" <<'JAVA'
package android.webkit; public interface ValueCallback<T> {void onReceiveValue(T v);}
JAVA
cat > "$T/src/android/webkit/WebView.java" <<'JAVA'
package android.webkit; public class WebView {public android.content.Context getContext(){return new android.content.Context();} public void loadUrl(String url){} public void stopLoading(){} public void evaluateJavascript(String code,ValueCallback<String> cb){} }
JAVA
cat > "$T/src/android/content/Context.java" <<'JAVA'
package android.content; public class Context {public static final int MODE_PRIVATE=0;public android.content.res.AssetManager getAssets(){return new android.content.res.AssetManager();}public Context getApplicationContext(){return this;}public SharedPreferences getSharedPreferences(String name,int mode){return new SharedPreferences();}}
JAVA
cat > "$T/src/android/content/SharedPreferences.java" <<'JAVA'
package android.content;public class SharedPreferences {public long getLong(String key,long d){return d;}public Editor edit(){return new Editor();}public static class Editor{public Editor putLong(String k,long v){return this;}public void apply(){}}}
JAVA
cat > "$T/src/android/content/res/AssetManager.java" <<'JAVA'
package android.content.res; public class AssetManager {public java.io.InputStream open(String name)throws java.io.IOException{return null;}}
JAVA
cat > "$T/src/androidx/webkit/ScriptHandler.java" <<'JAVA'
package androidx.webkit; public interface ScriptHandler {void remove();}
JAVA
cat > "$T/src/androidx/webkit/WebViewFeature.java" <<'JAVA'
package androidx.webkit; public final class WebViewFeature {public static final String DOCUMENT_START_SCRIPT="DOCUMENT_START_SCRIPT"; public static boolean isFeatureSupported(String x){return true;}}
JAVA
cat > "$T/src/androidx/webkit/WebViewCompat.java" <<'JAVA'
package androidx.webkit; public class WebViewCompat {public static ScriptHandler addDocumentStartJavaScript(android.webkit.WebView view,String source,java.util.Set<String> origins){return ()->{};}}
JAVA
cat > "$T/src/org/json/JSONObject.java" <<'JAVA'
package org.json; public class JSONObject {public static final Object NULL=new Object();public JSONObject(String s){} public String optString(String key,String d){return d;} public long optLong(String key,long d){return d;} public JSONArray optJSONArray(String key){return null;}public Object opt(String key){return null;}public boolean has(String key){return false;}public JSONArray names(){return null;}}
JAVA
cat > "$T/src/org/json/JSONArray.java" <<'JAVA'
package org.json; public class JSONArray {public JSONArray(String s){} public int length(){return 0;}public String optString(int i,String d){return d;}public String optString(int i){return "";}public Object opt(int i){return null;}}
JAVA
cat > "$T/src/com/cmyk/imgstalker/MediaItem.java" <<'JAVA'
package com.cmyk.imgstalker;public final class MediaItem{public String url="",referrer="";}
JAVA
cat > "$T/src/com/cmyk/imgstalker/DiagnosticLog.java" <<'JAVA'
package com.cmyk.imgstalker; public final class DiagnosticLog {public static void log(String msg){}}
JAVA
javac -encoding UTF-8 -d "$T/classes" $(find "$T/src" -name '*.java') \
  app/src/main/java/com/cmyk/imgstalker/InstagramBrowserFeed.java \
  app/src/main/java/com/cmyk/imgstalker/PostPublicationDates.java
node --check app/src/main/assets/instagram_browser_feed.js
node tests/instagram_browser_feed_js_test.cjs
printf 'PASS: Instagram browser collector javac + JavaScript syntax and fake browser events\n'
