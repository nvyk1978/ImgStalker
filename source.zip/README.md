# ImgStalker 0.1.29 (30)

## 0.1.28 SNSログイン修正

- X / Instagram のログインWebViewを実用ブラウザ構成へ更新。
- ログインWebViewでCookieとサードパーティCookieを明示的に許可。
- AndroidX WebKitのProfileはWebView設定・遷移より先に適用。
- `target=_blank` / `window.open()` の子WebViewを同一SNS Profileで開く。
- HTTP(S)はWebView内、`intent://`はbrowser fallbackを優先し、それ以外の外部schemeは安全に外部Intentへ委譲。
- 読み込み進捗、main-frame HTTP/ロードエラー、JS console errorを診断ログへ記録。
- 認証Cookie検出時にCookieをflushし、アカウント登録状態へ即時反映。
- Android戻るキーはWebView履歴 / popup履歴を優先。
- ログイン画面では独自UAサフィックスを外し、system WebView UAをそのまま使用。
- Xのセンシティブ設定用WebViewにも同一ProfileのCookie受け入れ設定を適用。
- versionCodeを29へ更新し、過去のv0.1.27 (28)より単調増加。

## 0.1.29 修正

- 動画プレビューのCookie取得で、独自 `SessionCookies` を誤って `android.webkit.SessionCookies` と参照していたコンパイルエラーを修正。
- HTTP取得系のUser-Agentサフィックスを `ImgStalker/0.1.29` に統一。
- 保存キャンセル後に旧ダウンロードワーカーの進捗通知がUIへ戻り、キャンセル表示を上書きする競合を抑止。
- versionCode 30 / versionName 0.1.29 / applicationId `com.cmyk.imgstalker` / 固定署名を維持。


WebページをWebViewで実際に読み込み、画像・動画・ページ送り・画像付き詳細リンクを追跡して一括保存する個人用Androidアプリ。

## 初回実装
- URL直接入力
- Android共有メニューからURL受け取り
- JavaScript実行後DOMを解析
- img/currentSrc/src/srcset/data-src/data-original/data-lazy-src
- CSS background-image
- og:image / twitter:image
- video/source / og:video
- MP4 / WebM / MOV / M4V / 3GP直接ファイル
- HLS(.m3u8) / DASH(.mpd)は検出表示のみ（0.1.2では結合保存しない）
- rel=next、Next/次へ、pagination内数字リンクを追跡
- 画像を含むリンク先を詳細ページ候補として追跡
- lazy-load対策としてページを複数回自動スクロール
- 同一ホスト内のみ自動巡回
- URL重複除外
- 画像・動画の選択保存
- 画像は Downloads/ImgStalker/<ページタイトル_日時>/ 直下、動画は /videos に一括保存
- Cookie / Referer / User-Agentを引き継いで直接ファイルを取得

## N規格
- BG #303030
- D.Gray #252020
- Gray #454040
- L.Gray #656060
- Blue #223355
- L.Blue #445577
- Orange #775500
- N White #A9A999（非テキストUI）
- 通常テキスト #FFFFFF
- NToggleSwitch同系統のカプセル型トグル

## ビルド
リポジトリ直下に `source.zip` を置き、`.github/workflows/ImgStalker.yml` として同梱のworkflowを配置する。
workflow_dispatch または source.zip 更新でビルドされる。

APK出力名: `ImgStalker-v0.1.29.apk`

## 署名
`keystore/imgstalker.jks` を固定署名として使用する。今後の上書きインストールのため、このkeystoreを変更・紛失しないこと。

## 0.1.5の制限
- DRM保護コンテンツの回避は行わない。
- blob: URL、MediaSource、暗号化ストリームは直接保存対象外。
- HLS/DASHは検出のみ。
- onclickだけで遷移しhrefを持たない独自ギャラリーはサイト依存で未検出の場合がある。
- ログイン済みCookieはWebViewから直接ファイル取得時に引き継ぐが、サイト固有の追加認証ヘッダが必要な場合は失敗することがある。


## 0.1.1 修正
- Android ListViewに存在しない setDividerColor(int) 呼び出しを修正。ColorDrawableを setDivider() へ渡す実装に変更。


## 0.1.2 追加
- 解析結果の画像行にサムネイル表示を追加。Cookie / Referer / User-Agentを引き継いで非同期読込し、メモリキャッシュする。
- 動画・ストリーム行では画像サムネイル欄を表示しない。
- 右上の三点メニューから「診断ログ」を表示可能。
- 診断ログにアプリ起動、解析条件、ページ巡回、DOM解析、メディア検出、追跡キュー、WebView読込エラー、ダウンロードHTTP応答、保存成否、サムネイル失敗、未処理例外を記録。
- 診断ログはコピー／共有可能。端末・Android・アプリバージョンをレポート先頭に付加。


## 0.1.3 変更
- 題字と三点メニューを従来位置から200dp下へ移動。三点メニューは44dpの丸型アイコン化。
- URL入力欄右端に×アイコンを追加し、タップでURL全文をクリア。
- 取得画像解像度フィールドを追加。小=640px / 中=1280px / 大=1920px のプリセットと64〜8192pxの直接入力に対応。
- srcset/data-srcsetの候補から、指定解像度以上で最小の候補を優先し、無ければ最大候補を採用。
- 画像サムネイルタップで元画像をWebView表示。選択/解除はチェックボックスのタップだけに限定。
- 診断ログ画面をPriceRec系の「ログ消去 / コピー / 閉じる」構成へ変更。
- ダウンロード処理を強化。WebView相当User-Agent、Cookie、Refererを利用し、リダイレクト追従、Content-Type検査、MediaStore URI、書込バイト数、公開結果まで診断ログへ記録。

## 0.1.4 変更
- 題字と丸型三点メニューの縦位置を再調整。元位置から100dp下（0.1.3より100dp上）へ変更。
- 診断ログ下部の「ログ消去 / コピー / 閉じる」をPriceRec 0.1.81と同じ48dp操作スロット＋26dp極薄カプセル描画へ移植。左端ログ消去、右側コピー/閉じるの配置も同一化。
- 新しいURLで解析を開始する際、前回の診断ログを一度消去してから新URL分のログを記録。再解析でURLが同一なら既存ログを継続。
- 詳細リンク追跡でサイトトップ、ナビ系URL、重複URLを誤って大量キュー投入しにくいよう候補判定を強化。キューログは実際に追加された場合だけ記録。
- 広告/同期/トラッキング系の画像URLを検出結果から除外し、1〜2px級トラッカーもDOM収集時に除外。
- 解析途中でも選択済みメディアがあれば保存可能。保存開始時はクローラを停止して、その時点までの選択項目を保存する。
- サムネイル取得ログを強化。HTTPコード、Content-Type、Content-Length、最終URL、Referer、Cookie有無、例外メッセージ、デコード結果を記録。
- サムネイル取得上限を12MBから32MBへ拡張し、WebView相当User-Agentと画像向けHTTPヘッダを利用。


## 0.1.5 変更

- 画像保存時のHTTP取得条件を、実機で200取得できているサムネイル取得と同じ条件へ統一。画像保存だけは従来の追加ヘッダー／手動リダイレクト処理を使わない。
- 画像保存がHTTP 403になった場合は同条件で1回だけ再試行し、`DOWNLOAD_RETRY` と再試行結果を診断ログへ記録。
- 診断ログ画面に「.txtを共有」を追加。左端は「ログ消去」、右端に「.txtを共有 / コピー / 閉じる」を詰めて配置。
- 診断ログ全文は `ImgStalker_diagnostic_yyyyMMdd_HHmmss.txt` としてキャッシュへ書き出し、read-onlyのcontent URIでAndroid共有シートへ渡す。


## 0.1.6 変更

- メイン画面全体を0.1.5から50dp上へ移動。上部オフセットを100dpから50dpへ変更。
- 解析開始時にURL/解像度入力欄のフォーカスを解除し、ソフトウェアキーボードを閉じる。空白部タップでも同様に解除。初期表示時は入力欄へ自動フォーカスしない。
- 元画像ビューアの「元画像」題字を削除し、「閉じる」を右下へ移動。診断ログと同じ極薄カプセル型操作ボタンを使用。
- 元画像ビューアを原寸倍率制御対応ビューへ変更。ダブルタップで100%へアニメーション拡大、再ダブルタップで全体表示へ戻る。ダブルタップ2回目を保持して上下ドラッグすると連続ズーム。通常ドラッグ移動とピンチズームにも対応。
- 画像保存時の `images/` サブフォルダを廃止し、取得フォルダ直下へ画像を保存。動画は従来どおり `videos/` 配下。

## 0.1.17 変更

- 単純なワンクッション確認ページをWebView内で自動通過する処理を追加。年齢/成人/18歳/センシティブ/閲覧確認等の文脈があり、肯定・否定の両方の操作要素が同じ確認領域にある場合だけ対象にする。
- 通過時はURLを推測・書換えせず、実ページ上の肯定要素をWebView上で1回クリック。サイト本来のForm/JavaScript/Cookie処理を維持する。
- 同一URLの確認ゲートは1解析につき1回だけ自動承認し、失敗時の無限クリックを防止。
- 診断ログへ `PASS_GATE_FOUND` / `PASS_GATE_ACCEPT` / `PASS_GATE_RESOLVED` / `PASS_GATE_FAILED` を追加。
- 解析結果グリッドの実サムネイルに、待機中の代替スクエアと同じ7dp角丸クリップを適用。

## 0.1.18 変更

- 解析結果グリッドの動画直リンク（VIDEO）を、正方形サムネイル領域内でミュート・ループ再生するプレビュー機能を追加。
- 通常モードでは動画セル／ファイル名タップで再生・停止。別動画を再生すると前のプレビューは自動停止し、同時再生は1本だけ。
- 選択モードでは通常タップを選択操作のまま維持し、左上の目アイコンから動画プレビューを開始・停止。
- 画面外スクロール、解析開始、保存開始、Activity一時停止／終了等でプレビューを自動停止。
- VIDEO直リンクのみ対象。HLS/DASHのSTREAM項目は対象外。

## 0.1.19 変更

- 「サムネイル先を追跡」の初期値をONへ変更。
- 「取得解像度」の表示名を「解像度下限」へ変更。初期値は従来どおり小=640pxで、最終画像の長辺を下限判定に利用。
- 解析ボタンを状態連動化。待機中は「解析」(Nオレンジ)、解析中は「停止」(Nダークレッド #441100)。押すたびに解析開始／ユーザー停止を切替。
- 解析進捗の2行表示（ページ/詳細追跡URL、画像/動画/ストリーム件数）の右端にインジケータ領域を追加。解析中はシークサークルを表示。
- 45秒以上進捗イベントがなく、Crawler内部に未処理が残る場合は「解析中断の可能性」としてシークサークルを丸型「!」へ置換。進捗が復帰すればシークサークルへ自動復帰。
- 診断ログへ `ANALYSIS_INTERRUPTED suspected=true ...` と `ANALYSIS_INTERRUPTED_CLEAR ...` を追加。「!」タップで診断ログを開ける。
- WebViewページ開始/完了、DOM収集/完了、画像実寸probe開始/完了を進捗パルスとして監視し、単なる低速ページとの誤判定を減らす。
- 解析開始時はURLが同一でも毎回前回の診断ログを全消去し、`LOG_RESET analyze_start ...` から新規ログを開始。
- 項目名タップで各トグルON/OFF、入力欄外タップ/長押しでURL/解像度欄のフォーカス解除・キーボード格納、最終実寸での低解像度除外など0.1.18以前の仕様を維持。
- 0.1.18の動画プレビュー実装は今回変更していない。動画タップ時クラッシュの原因特定には実機診断ログが必要。

## 0.1.20 変更

- サムネイル先追跡を二段階化。通常ページ／ページネーションと画像実寸probeを先に完了し、解像度下限を満たせなかった・実寸取得できなかったサムネイルだけ親リンクをdepth=1で後追いする。
- `THUMB_LINK_QUEUE` の即時大量投入を廃止し、`THUMB_LINK_DEFER` → `DETAIL_PHASE_START` → 必要な `THUMB_DETAIL_QUEUE` の順で処理。解像度下限を満たすサムネイルは `THUMB_DETAIL_SKIP reason=thumb_meets_target` で詳細追跡を省略。
- 詳細ページ1件の読込上限18秒、DOM処理上限10秒、詳細追跡フェーズ全体90秒の安全上限を追加。失敗した詳細1件で解析全体が止まり続けない。
- 詳細追跡中のmain-frame読込エラーはその詳細だけスキップして次へ進む。時間上限到達時は `DETAIL_PHASE_BUDGET_END` を記録して残りを切り上げる。
- 低解像度サムネイルは結果へ即追加せず一時候補として実寸確認し、本画像が採用された場合は置換。本画像が無い場合でも解像度下限を満たした一時候補だけ最終結果へ追加。
- 動画セル内プレビューを Android標準MediaPlayer/TextureView の手組み実装から AndroidX Media3 ExoPlayer 1.11.1 + PlayerView へ置換。Cookie / Referer / User-Agentを付与し、ミュート・ループ・同時再生1本・画面外停止を維持。失敗時は `VIDEO_PREVIEW_ERROR engine=media3` を記録。
- GridView標準fast-scrollを無効化し、右端のスクロールカーソル本体だけを掴める独自グリップへ変更。バーの空き領域では高速スクロールを開始しない。通常スクロール停止後は自然にフェードアウト。

## 0.1.21 変更

- タスク移動中にActivityが再生成されても、解析結果一覧・各項目の選択状態・選択モード・選択アンカー・グリッドのスクロール位置をSavedStateから復元する。
- `STATE_SAVE` / `STATE_RESTORE` を診断ログへ追加。解析中にActivity再生成が発生した場合は、その解析は再開せず「解析中断（画面再生成）」として結果を復元する。
- 画像サムネイル取得をGridViewセルの初回表示から切り離し、画像項目が解析結果へ追加された時点で `ThumbnailLoader.prefetch()` を開始する。
- 先読みは既存の3ワーカー・同一URL in-flight共有・LRUキャッシュ・解析開始時キャンセルをそのまま利用。表示時はキャッシュ即表示、取得中なら既存リクエストへJOINする。
- 診断ログへ `THUMB_PREFETCH` を追加。スクロールして待機スクエアが表示されるまでサムネイル取得が始まらない挙動を解消する。


## 0.1.28 変更

- 上部丸アイコンを4個へ拡張し、左から「設定 / X / Instagram / 診断ログ」に変更。XとInstagramは独立したベクター風丸アイコン。
- X / Instagramそれぞれにアカウント管理ダイアログを追加。アプリ内WebViewでログインし、パスワード自体はImgStalkerで保存しない。
- AndroidX WebKit 1.17.0のMulti Profile対応WebViewでは、SNSアカウントごとにCookie / WebStorageを独立Profileへ分離。非対応WebViewでは各SNS 1アカウント運用へフォールバック。
- 登録済みSNSアカウントは登録順で自動試行。SNS URL解析でCrawlerエラー、または取得メディア0件の場合は次アカウントへ自動フォールバックし、`X_ACCOUNT_FALLBACK` / `Instagram_ACCOUNT_FALLBACK` を診断ログへ記録。
- 選択中SNS ProfileのCookieをCrawler画像probe、サムネイル取得、原寸表示、動画プレビュー、保存処理にも共有。ログインWebViewだけ別セッションになる問題を防止。
- Xアカウントダイアログに「センシティブ表示 一括ON」を追加。ログイン済み全X Profileへ順番に `Content you see` のセンシティブメディア表示ONと、Search settingsのセンシティブ非表示OFFを試行。
- 一括設定は `X_SENSITIVE_ALL_START / X_SENSITIVE_CONTENT / X_SENSITIVE_SEARCH / X_SENSITIVE_ALL_DONE` を診断ログへ記録。X側の年齢・地域・ポリシー強制制限は変更対象外。
- 0.1.21のSavedState選択復元、自動サムネイルprefetch、0.1.20の遅延詳細追跡/Media3動画プレビュー/独自スクロールグリップを維持。
