/* Threads-only DOM reader. This asset never runs in Instagram, X or NORMAL. */
(function () {
  'use strict';
  function abs(raw) {
    try {
      if (!raw || /^blob:|^data:|^javascript:/i.test(raw)) return '';
      var u = new URL(raw, location.href);
      return /^https?:$/.test(u.protocol) ? u.href : '';
    } catch (e) { return ''; }
  }
  function bestImage(img) {
    var selected = img.currentSrc || img.getAttribute('src') || '';
    var bestWeight = 0;
    var set = img.getAttribute('srcset') || '';
    if (set) set.split(/,\s*(?=https?:|\/)/).forEach(function (part) {
      var m = part.trim().match(/^(\S+)\s+(\d+)(w|x)$/);
      if (!m) return;
      var weight = +m[2] * (m[3] === 'x' ? 2000 : 1);
      if (weight > bestWeight) { bestWeight = weight; selected = m[1]; }
    });
    return abs(selected);
  }
  function findPostUrl(anchor) {
    try {
      var u = new URL(anchor.href, location.href);
      if (!/(^|\.)threads\.(?:com|net)$/.test(u.hostname)) return '';
      if (/\/@[\w.]+\/post\/[\w-]+/.test(u.pathname)) return u.origin + u.pathname;
      if (/\/post\/[\w-]+/.test(u.pathname)) return u.origin + u.pathname;
    } catch (e) {}
    return '';
  }
  var output = { href:location.href, title:document.title, bodyLength:(document.body && document.body.innerText || '').length,
                 blocked:false, posts:[], images:[], videos:[], height:0, scrollY:0, account:'' };
  try {
    var path = location.pathname;
    var mm = path.match(/^\/@([a-z0-9._]+)/i);
    output.account = mm ? mm[1] : '';
    output.scrollY = window.scrollY || 0;
    output.height = Math.max(document.documentElement.scrollHeight || 0,document.body && document.body.scrollHeight || 0);
    var body = (document.body && document.body.innerText || '').slice(0,5000);
    output.blocked = /log in to threads|login to threads|このコンテンツは利用できません|ログインして|content isn't available|page isn't available/i.test(body)
                     && !document.querySelector('a[href*="/post/"]');

    var candidates = [], seenCards = new Set();
    var articles = document.querySelectorAll('article,[role="article"]');
    for (var ai=0; ai<articles.length; ai++) { if (ai < 1200) { candidates.push(articles[ai]); seenCards.add(articles[ai]); } }
    var links = document.querySelectorAll('a[href*="/post/"]');
    for (var li=0; li<links.length && li<1200;li++) {
      var a = links[li], ref = findPostUrl(a); if (!ref) continue;
      var root = a, level = 0;
      while (root.parentElement && level++ < 7) {
        if (root.matches && (root.matches('article') || root.getAttribute('role') === 'article')) break;
        if (root.querySelectorAll && root.querySelectorAll('img,video').length >= 1 && level >= 3) break;
        root = root.parentElement;
      }
      if (!seenCards.has(root)) { candidates.push(root); seenCards.add(root); }
    }
    var seen = new Set();
    function add(kind, mediaUrl, postUrl, order) {
      mediaUrl = abs(mediaUrl); if (!mediaUrl || !/^https?:\/\//.test(mediaUrl)) return;
      if (/\/(?:static|rsrc)\//.test(mediaUrl) || /(?:favicon|sprite|avatar|profile_pic)/i.test(mediaUrl.split('?')[0])) return;
      var key = kind + '|' + mediaUrl.split('?')[0] + '|' + postUrl;
      if (seen.has(key)) return;
      seen.add(key);
      var entry = {kind:kind, url:mediaUrl, post:postUrl || location.href, order:order};
      if (kind === 'image') output.images.push(entry); else output.videos.push(entry);
    }
    function collect(root, postUrl, groupIndex) {
      if (!root || !root.querySelectorAll) return;
      var media = root.querySelectorAll('img,video,video source');
      for (var j=0;j<media.length && j<150;j++) {
        var n=media[j];
        if (n.tagName.toLowerCase() === 'img') {
          var alt=(n.getAttribute('alt')||'').toLowerCase();
          var box = n.getBoundingClientRect();
          var width = n.naturalWidth || n.width || box.width;
          var height = n.naturalHeight || n.height || box.height;
          if (/profile picture|profile photo|avatar|プロフィール画像|プロフィール写真|アバター/.test(alt)) continue;
          if (width > 0 && height > 0 && Math.max(width,height) < 135) continue;
          if (box.width > 0 && box.height > 0 && Math.max(box.width,box.height) < 90) continue;
          if (n.closest('header,nav,[role="navigation"]')) continue;
          add('image', bestImage(n), postUrl, groupIndex*1000+j);
        } else {
          add('video', n.currentSrc || n.src || n.getAttribute('src'),postUrl,groupIndex*1000+j);
        }
      }
    }
    for (var ci=0; ci<candidates.length && ci<1200;ci++) {
      var card=candidates[ci], postUrl='';
      var cardsLinks=card.querySelectorAll('a[href*="/post/"]');
      for (var k=0;k<cardsLinks.length;k++) { postUrl=findPostUrl(cardsLinks[k]); if(postUrl)break; }
      if (postUrl) { output.posts.push(postUrl); collect(card,postUrl,ci); }
    }
    // Single-post documents sometimes expose media without article roles.
    if (output.posts.length === 0 && /\/post\//.test(location.pathname)) collect(document.body,location.origin+location.pathname,0);
    output.posts = Array.from(new Set(output.posts));
  } catch (e) { output.error = String(e); }
  return JSON.stringify(output);
})()
