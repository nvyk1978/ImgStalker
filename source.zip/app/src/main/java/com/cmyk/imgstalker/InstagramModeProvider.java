package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.webkit.CookieManager;
import android.webkit.WebView;

/** Dedicated INSTAGRAM backend; all classes referenced here belong to INSTAGRAM. */
final class InstagramModeProvider implements ModeProvider {
    @Override public AnalysisModeRouter.Mode mode() { return AnalysisModeRouter.Mode.INSTAGRAM; }
    @Override public void useCookies(CookieManager cookies) { InstagramSessionCookies.use(cookies); }
    @Override public String cookieFor(String url) { return InstagramSessionCookies.getCookie(url); }
    @Override public ModeCrawler crawler(WebView view, CrawlerEngine.Listener listener) {
        return new InstagramCrawlerAdapter(view, listener);
    }
    @Override public ModeThumbnailLoader thumbnails(Context context, Runnable onMetadata) {
        return new InstagramThumbnailAdapter(context, onMetadata);
    }
    @Override public ModeDownloader downloader(Context context, boolean saveXGifAsGif, MediaDownloader.Listener listener) {
        return new InstagramDownloaderAdapter(context, saveXGifAsGif, listener);
    }
    private final ModePreviewPolicy preview = new InstagramPreviewPolicy();
    @Override public ModePreviewPolicy preview() { return preview; }
    @Override public Bitmap original(Context context, MediaItem item) throws Exception {
        return InstagramOriginalImageLoader.load(context, item);
    }
}
