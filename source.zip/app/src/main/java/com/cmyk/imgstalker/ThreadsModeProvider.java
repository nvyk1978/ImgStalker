package com.cmyk.imgstalker;
import android.content.Context;
import android.graphics.Bitmap;
import android.webkit.CookieManager;
import android.webkit.WebView;
/** Threads owns its crawler, session, downloader and image transport. */
final class ThreadsModeProvider implements ModeProvider {
    private final ModePreviewPolicy preview = new ThreadsPreviewPolicy();
    @Override public AnalysisModeRouter.Mode mode() { return AnalysisModeRouter.Mode.THREADS; }
    @Override public void useCookies(CookieManager cookies) { ThreadsSessionCookies.use(cookies); }
    @Override public String cookieFor(String url) { return ThreadsSessionCookies.getCookie(url); }
    @Override public ModeCrawler crawler(WebView view, CrawlerEngine.Listener listener) { return new ThreadsCrawlerAdapter(view, listener); }
    @Override public ModeThumbnailLoader thumbnails(Context c, Runnable callback) { return new ThreadsThumbnailAdapter(c, callback); }
    @Override public ModeDownloader downloader(Context c, boolean ignored, MediaDownloader.Listener listener) { return new ThreadsDownloaderAdapter(c, ignored, listener); }
    @Override public Bitmap original(Context c, MediaItem item) throws Exception { return ThreadsOriginalImageLoader.load(c, item); }
    @Override public ModePreviewPolicy preview() { return preview; }
}
