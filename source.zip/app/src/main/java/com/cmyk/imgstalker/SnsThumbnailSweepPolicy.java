package com.cmyk.imgstalker;

import java.util.HashMap;
import java.util.HashSet;

/** Main-thread-only scheduler state. Does not fetch any network resource. */
final class SnsThumbnailSweepPolicy {
    private static final int MAX_ATTEMPTS = 4;
    private static final long[] RETRY_DELAY_MS = {3500L, 14000L, 60000L, 180000L};
    private final HashMap<String, Integer> attempts = new HashMap<>();
    private final HashMap<String, Long> latestAttempt = new HashMap<>();
    private final HashSet<String> finished = new HashSet<>();

    void reset() {
        attempts.clear();
        latestAttempt.clear();
        finished.clear();
    }

    boolean isFinished(String key) { return finished.contains(key); }
    void finish(String key) { finished.add(key); }
    boolean attempted(String key) { return attempts.containsKey(key); }
    int attempts(String key) { return attempts.getOrDefault(key, 0); }

    boolean canAttempt(String key, long now) {
        if (finished.contains(key)) return false;
        int count = attempts(key);
        if (count >= MAX_ATTEMPTS) return false;
        if (count == 0) return true;
        return now >= retryAt(key);
    }

    long retryAt(String key) {
        int count = attempts(key);
        if (count == 0) return 0L;
        long time = latestAttempt.getOrDefault(key, 0L);
        return time + RETRY_DELAY_MS[Math.min(count - 1, RETRY_DELAY_MS.length - 1)];
    }

    void recordAttempt(String key, long now) {
        int count = attempts(key);
        if (count >= MAX_ATTEMPTS) return;
        attempts.put(key, count + 1);
        latestAttempt.put(key, now);
    }

    /** Check only after a previous attempt had time to finish. */
    boolean mayFinalize(String key, long now) {
        return attempted(key) && now >= retryAt(key);
    }

    boolean exhausted(String key) {
        return attempts(key) >= MAX_ATTEMPTS;
    }
}
