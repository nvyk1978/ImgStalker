package com.cmyk.imgstalker;
public final class SiteNavigationTitleTest {
 private static void eq(String expected,String actual) {
   if (!expected.equals(actual)) throw new AssertionError("wanted="+expected+" got="+actual);
 }
 public static void main(String[] args) {
  eq("@jiee_wen",SiteVisitStore.displayTitleForUrl("https://www.instagram.com/jiee_wen?vrfl=abcdef", ""));
  eq("Jie Wen",SiteVisitStore.displayTitleForUrl("https://www.instagram.com/jiee_wen/", "Jie Wen (@jiee_wen) • Instagram photos and videos"));
  eq("@jiee_wen",SiteVisitStore.displayTitleForUrl("https://www.instagram.com/jiee_wen/", "Instagram"));
  eq("@abc",SiteVisitStore.displayTitleForUrl("https://x.com/abc/status/123", "X"));
  eq("Alex Example",SiteVisitStore.displayTitleForUrl("https://x.com/abc", "Alex Example (@abc) / X"));
  eq("@somebody",SiteVisitStore.displayTitleForUrl("https://mobile.twitter.com/somebody/", ""));
  eq("www.instagram.com",SiteVisitStore.displayTitleForUrl("https://www.instagram.com/p/xyz", ""));
  eq("x.com",SiteVisitStore.displayTitleForUrl("https://x.com/i/user/1", ""));
  eq("Gallery",SiteVisitStore.displayTitleForUrl("https://example.com/gallery", "Gallery"));
  eq("example.com",SiteVisitStore.displayTitleForUrl("https://example.com/gallery", ""));
  System.out.println("PASS: 10 navigation display-name cases (social title + @ fallback + ordinary sites)");
 }
}
