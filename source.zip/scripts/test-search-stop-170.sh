#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 - <<'PYTEST'
from pathlib import Path
import re
root=Path('app/src/main/java/com/cmyk/imgstalker')
ui=(root/'MainActivity.java').read_text()
icon=(root/'NavigationIconLoader.java').read_text()
router=(root/'AnalysisModeRouter.java').read_text()
threads=(root/'ThreadsCrawlerEngine.java').read_text()
threadjs=Path('app/src/main/assets/threads_feed.js').read_text()
assert "versionCode 171" in Path('app/build.gradle').read_text()
assert "versionName '0.1.170'" in Path('app/build.gradle').read_text()
# Three radio buttons in one group, state persisted across rotation, and a
# dedicated Threads URL, never stealing either X or Instagram query semantics.
for name in ('snsSearchXRadio','snsSearchInstagramRadio','snsSearchThreadsRadio'):
    assert f'snsSearchService.addView({name}' in ui
assert 'SnsAccountManager.Service.THREADS' in ui[ui.index('private void startSnsKeywordSearch()'):ui.index('private void startAnalysisFromUrlIme()')]
search=ui[ui.index('private String buildSnsSearchUrl('):ui.index('private void startAnalysisFromUrlIme()')]
assert '"https://x.com/search?q=" + Uri.encode(query) + "&src=typed_query&f=live"' in search
assert '"https://www.threads.com/search?q=" + Uri.encode(query) + "&serp_type=default"' in search
assert '"https://www.instagram.com/explore/search/keyword/?q="' in search
assert search.index('service == SnsAccountManager.Service.THREADS') < search.index('while (tag.startsWith("#")')
assert '"threads" : snsSearchInstagramRadio' in ui
assert 'snsSearchThreadsRadio.setChecked("threads".equals(snsSearchService))' in ui
# Search navigation icons use the built-in platform logo even if the old
# domain favicon was already cached. All three view types use bind().
assert 'if (isProviderSearchUrl(url)) return;' in icon
assert icon.index('if (isProviderSearchUrl(url)) return;') < icon.index('Bitmap cached = memory.get(key);')
assert 'mode == AnalysisModeRouter.Mode.X.ordinal()) view.setImageResource(R.drawable.ic_nav_x)' in icon
assert 'path.equals("/search") || path.equals("/search/")' in icon
assert 'navigationIconLoader.bind(urlSiteIcon' in ui and 'navigationIconLoader.bind(favicon' in ui
# Keep existing independent Threads crawler able to process post cards on
# search pages: it is selected by host and accepts non-profile URLs.
assert 'Mode.THREADS' in router
assert 'void start(String url' in threads
assert "document.querySelectorAll('article,[role=\"article\"]')" in threadjs
assert 'a[href*="/post/"]' in threadjs
# Manual stop uses a bounded UI deadline only after requesting safe stop;
# capture all media and continuation cursor BEFORE engine cancellation.
assert 'SAFE_STOP_UI_LIMIT_MS = 1400L' in ui
stop=ui[ui.index('private void stopAnalysisByUser('):ui.index('private void updateForceStopButtonState()')]
assert 'crawler.requestGracefulStop()' in stop
assert 'safeStopHandler.postDelayed(safeStopDeadline, SAFE_STOP_UI_LIMIT_MS)' in stop
assert stop.index('writeResumeCheckpoint(false, "bounded_user_stop_before_cancel");') < stop.index('crawler.cancel();')
assert 'setContinuationCell(true, "bounded_user_stop")' in stop
assert 'activeResumeComplete = false' in stop
assert 'safeStopHandler.removeCallbacks(safeStopDeadline);' in ui[ui.index('onDone(String title, int visitedPages'):ui.index('@Override public void onInstagramManualTapReady()', ui.index('onDone(String title, int visitedPages'))]
assert 'safeStopHandler.removeCallbacks(safeStopDeadline);' in ui[ui.index('onDestroy()'):]
print('PASS: three provider search choices; existing # semantics; search icons; bounded checkpoint-before-cancel stop')
PYTEST
