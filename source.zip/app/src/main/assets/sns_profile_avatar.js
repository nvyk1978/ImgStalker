/* Passive profile chrome observer. Never visits posts, writes page state, or reads cookies. */
(function () {
  'use strict';
  var target = __ACCOUNT_HANDLE__;
  var result = {url:'', reason:'unknown', method:'', candidates:0, data:''};
  try {
    var path = decodeURIComponent(location.pathname || '').replace(/\/+$/, '');
    if (path.toLowerCase() !== ('/' + target).toLowerCase()
        && path.toLowerCase() !== ('/@' + target).toLowerCase()) {
      result.reason = 'not_target_profile'; return JSON.stringify(result);
    }
    var main = document.querySelector('main,[role="main"]');
    // Threads sometimes renders the profile header outside <main>; only consider
    // such headers if the DOM itself identifies this exact account. Never search
    // the global navigation area for a signed-in user's unrelated avatar.
    var roots = main ? [main] : [];
    if (document.querySelectorAll) {
      Array.from(document.querySelectorAll('header')).slice(0, 30).forEach(function(header) {
        if (header.closest && header.closest('nav,[role="navigation"]')) return;
        var ownerText = (header.innerText || header.textContent || '').toLowerCase();
        if (ownerText.indexOf(target.toLowerCase()) !== -1 && roots.indexOf(header) === -1)
          roots.push(header);
      });
    }
    if (!roots.length) { result.reason = 'no_verified_profile_container'; return JSON.stringify(result); }
    var firstArticle = main && main.querySelector ? main.querySelector('article,[role="article"]') : null;
    var firstTop = firstArticle ? firstArticle.getBoundingClientRect().top : 100000;
    var matches = [], seen = new Set();
    var selectors = 'img,[role="img"],[style*="background-image"]';
    var elements = [];
    roots.forEach(function(root) {
      if (root.querySelectorAll) elements.push.apply(elements, Array.from(root.querySelectorAll(selectors)).slice(0, 400));
    });
    function imageUrl(element) {
      var url = '';
      if (element.tagName && element.tagName.toLowerCase() === 'img') {
        url = element.currentSrc || element.getAttribute('src') || element.getAttribute('data-src') || '';
      } else {
        var css = window.getComputedStyle(element).backgroundImage || '';
        var m = css.match(/^url\(["']?(.*?)["']?\)$/i);
        if (m) url = m[1];
      }
      try {
        var normalized = new URL(url, location.href);
        if (normalized.protocol !== 'https:') return '';
        if (!/(?:^|\.)(?:fbcdn\.net|cdninstagram\.com|instagram\.com|threads\.com|threads\.net)$/.test(normalized.hostname)) return '';
        return normalized.href;
      } catch (e) { return ''; }
    }
    elements.forEach(function (node) {
      if (node.closest('article,[role="article"],nav,[role="navigation"]')) return;
      var box = node.getBoundingClientRect();
      if (box.width < 24 || box.height < 24 || box.width > 250 || box.height > 250) return;
      if (Math.max(box.width / box.height, box.height / box.width) > 1.5) return;
      if (box.top > firstTop - 5) return;
      if (box.top > 900) return;
      var url = imageUrl(node);
      if (!url || seen.has(url)) return;
      seen.add(url);
      var alt = (node.getAttribute('alt') || node.getAttribute('aria-label') || '').toLowerCase();
      var parent = node.parentElement;
      var radius = (window.getComputedStyle(node).borderRadius || '');
      if (parent) radius += ' ' + (window.getComputedStyle(parent).borderRadius || '');
      var inHeader = !!node.closest('header');
      var profileWord = /profile|avatar|portrait|プロフィール|头像|頭像/.test(alt);
      var circle = /50%|999|100%/.test(radius);
      var score = 0;
      if (alt.indexOf(target.toLowerCase()) !== -1 && profileWord) score += 13;
      else if (alt.indexOf(target.toLowerCase()) !== -1) score += 6;
      else if (profileWord) score += 7;
      if (inHeader && main) score += 6;
      else if (inHeader && (alt.indexOf(target.toLowerCase()) !== -1 || profileWord)) score += 6;
      if (circle) score += 4;
      if (box.top < firstTop) score += 2;
      if (!main && !profileWord && alt.indexOf(target.toLowerCase()) === -1) return;
      if (box.width <= 160) score++;
      if (box.top < 350) score++;
      matches.push({url:url, score:score, method:(inHeader?'header':'profile_top')
                                + (profileWord?'+alt':'') + (circle?'+circle':'')});
    });
    result.candidates = matches.length;
    matches.sort(function(a,b) { return b.score-a.score; });
    if (!matches.length || matches[0].score < 7) {
      result.reason = 'no_verified_header_avatar'; return JSON.stringify(result);
    }
    result.url = matches[0].url;
    result.method = matches[0].method;
    result.reason = 'found';
    // CORS-permitting CDN images can additionally be passed to Android as a small
    // same-page canvas PNG. If the CDN rejects CORS, the native downloader is used.
    var key = '__imgstalker_profile_avatar_v168';
    var state = window[key];
    if (!state || state.url !== result.url) {
      state = {url:result.url, data:'', error:'', ready:false};
      window[key] = state;
      var img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = function () {
        try {
          var c = document.createElement('canvas'); c.width=96; c.height=96;
          c.getContext('2d').drawImage(img, 0, 0, 96, 96);
          state.data = c.toDataURL('image/png');
        } catch(e) { state.error='canvas_cors'; }
        state.ready=true;
      };
      img.onerror = function() { state.error='image_cors'; state.ready=true; };
      img.src=result.url;
    }
    if (state.data && state.data.length < 350000) result.data = state.data;
  } catch(e) { result.reason = 'probe_error:' + String(e).slice(0,100); }
  return JSON.stringify(result);
})()
