package com.cmyk.imgstalker;

import java.net.URI;
import java.util.Locale;

/**
 * Hard dispatch boundary for NORMAL, X and INSTAGRAM.  Never match a provider's
 * name in the query, path, credentials or a look-alike host.  The host alone
 * determines which provider is allowed to configure the crawler's session.
 * This class has no Android or network dependencies and is regression-testable.
 */
final class AnalysisModeRouter {
    enum Mode { NORMAL, X, INSTAGRAM }

    private AnalysisModeRouter() { }

    static Mode fromUrl(String raw) {
        if (raw == null || raw.trim().isEmpty()) return Mode.NORMAL;
        String url = raw.trim();
        if (!url.matches("(?i)^https?://.*")) url = "https://" + url;
        try {
            URI parsed = new URI(url);
            String scheme = parsed.getScheme();
            if (scheme == null || (!"https".equalsIgnoreCase(scheme)
                    && !"http".equalsIgnoreCase(scheme))) return Mode.NORMAL;
            return fromHost(parsed.getHost());
        } catch (Exception e) {
            return Mode.NORMAL;
        }
    }

    static Mode fromHost(String host) {
        if (host == null) return Mode.NORMAL;
        String h = host.toLowerCase(Locale.ROOT);
        if (h.endsWith(".")) h = h.substring(0, h.length() - 1);
        if (isHost(h, "x.com") || isHost(h, "twitter.com")) return Mode.X;
        if (isHost(h, "instagram.com")) return Mode.INSTAGRAM;
        return Mode.NORMAL;
    }

    private static boolean isHost(String host, String domain) {
        return host.equals(domain) || host.endsWith("." + domain);
    }
}
