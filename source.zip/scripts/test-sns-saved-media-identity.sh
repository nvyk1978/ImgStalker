#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -encoding UTF-8 -d "$TMP" \
  app/src/main/java/com/cmyk/imgstalker/MediaItem.java \
  app/src/main/java/com/cmyk/imgstalker/SnsSavedMediaIdentity.java \
  tests/SnsSavedMediaIdentityTest.java
java -cp "$TMP" com.cmyk.imgstalker.SnsSavedMediaIdentityTest
