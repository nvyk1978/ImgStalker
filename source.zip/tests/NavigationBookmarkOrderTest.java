package com.cmyk.imgstalker;
import java.util.Arrays;
import java.util.List;
public final class NavigationBookmarkOrderTest {
    private static void eq(List<String> result, String... expected) {
        if (!result.equals(Arrays.asList(expected))) throw new AssertionError(result + " != " + Arrays.asList(expected));
    }
    public static void main(String[] args) {
        List<String> original=Arrays.asList("a","x","b","ig","c");
        eq(NavigationBookmarkOrder.merge(original, Arrays.asList("c","a","b")),"c","x","a","ig","b");
        eq(NavigationBookmarkOrder.merge(original, original),"a","x","b","ig","c");
        eq(NavigationBookmarkOrder.merge(original, Arrays.asList("b","a","b","c","unknown")),"b","x","a","ig","c");
        eq(NavigationBookmarkOrder.merge(original, Arrays.asList("c")),"a","x","b","ig","c");
        System.out.println("PASS: filtered reorder retains hidden URLs and their slots");
    }
}
