package com.cmyk.imgstalker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Navigation artwork only. No crawler WebView, login cookies or provider session access. */
final class NavigationIconLoader {
    private static final int MAX_BYTES = 450_000;
    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final LruCache<String, Bitmap> memory = new LruCache<>(64);
    private final Set<String> inProgress = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final Map<String, Long> failed = new ConcurrentHashMap<>();
    private final Map<String, ArrayList<ImageView>> listeners = new ConcurrentHashMap<>();
    private static final Pattern TAG = Pattern.compile("<(?:link|meta)\\b[^>]*>", Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR = Pattern.compile("([\\w:-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");

    NavigationIconLoader(Context ctx) {
        context = ctx.getApplicationContext();
        // v0.1.157 cached square-stretched images. Never reuse those corrupted previews.
        // Delete the obsolete directory off the UI thread; new circular previews live in v2.
        try {
            io.execute(() -> {
                File obsolete = new File(context.getCacheDir(), "navigation_icons");
                File[] oldFiles = obsolete.listFiles();
                if (oldFiles != null) for (File old : oldFiles) if (old.isFile()) old.delete();
                obsolete.delete();
            });
        } catch (RuntimeException ignored) { }
    }

    static String iconIdentity(String url) {
        String normalized = SiteVisitStore.normalize(url);
        if (normalized.isEmpty()) return "";
        try {
            URI uri = URI.create(normalized);
            String host = uri.getHost();
            if (host == null) return "";
            String social = SiteVisitStore.socialHandleForUrl(normalized);
            if (!social.isEmpty()) {
                AnalysisModeRouter.Mode socialMode = AnalysisModeRouter.fromUrl(normalized);
                String canonical = socialMode == AnalysisModeRouter.Mode.INSTAGRAM ? "instagram"
                        : socialMode == AnalysisModeRouter.Mode.THREADS ? "threads" : "x";
                return canonical + ":" + social.toLowerCase(java.util.Locale.ROOT);
            }
            return uri.getScheme().toLowerCase(java.util.Locale.ROOT) + "://" + host.toLowerCase(java.util.Locale.ROOT);
        } catch (RuntimeException e) { return ""; }
    }

    void bind(ImageView view, String url) {
        String key = iconIdentity(url);
        view.setTag(key);
        int mode = AnalysisModeRouter.fromUrl(url).ordinal();
        if (url == null || url.trim().isEmpty()) view.setImageResource(R.drawable.ic_nav_normal);
        else if (mode == AnalysisModeRouter.Mode.X.ordinal()) view.setImageResource(R.drawable.ic_nav_x);
        else if (mode == AnalysisModeRouter.Mode.INSTAGRAM.ordinal()) view.setImageResource(R.drawable.ic_nav_normal);
        else if (mode == AnalysisModeRouter.Mode.THREADS.ordinal()) view.setImageResource(R.drawable.ic_nav_normal);
        else view.setImageResource(R.drawable.ic_nav_normal);
        if (key.isEmpty()) return;
        Bitmap cached = memory.get(key);
        if (cached != null) { view.setImageBitmap(cached); return; }
        File file = cacheFile(key);
        if (file.isFile()) {
            Bitmap disk = BitmapFactory.decodeFile(file.getAbsolutePath());
            if (disk != null) { memory.put(key, disk); view.setImageBitmap(disk); return; }
            file.delete();
        }
        long now = System.currentTimeMillis();
        Long retryAt = failed.get(key);
        if (retryAt != null && now < retryAt) return;
        synchronized (listeners) {
            ArrayList<ImageView> views = listeners.get(key);
            if (views == null) { views = new ArrayList<>(); listeners.put(key, views); }
            views.add(view);
        }
        if (!inProgress.add(key)) return;
        try {
            io.execute(() -> {
                Bitmap found = null;
                try { found = loadRemote(url); }
                catch (Throwable e) { DiagnosticLog.logException("NAVIGATION_ICON_FETCH_FAIL", e); }
                if (found != null) {
                    memory.put(key, found);
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        found.compress(Bitmap.CompressFormat.PNG, 95, out);
                    } catch (Exception ignored) { }
                } else failed.put(key, System.currentTimeMillis() + 60L * 60_000L);
                final Bitmap result = found;
                main.post(() -> {
                    ArrayList<ImageView> waiters;
                    synchronized (listeners) { waiters = listeners.remove(key); }
                    inProgress.remove(key);
                    if (waiters != null && result != null) for (ImageView image : waiters) {
                        if (key.equals(image.getTag())) image.setImageBitmap(result);
                    }
                });
            });
        } catch (RuntimeException rejected) {
            inProgress.remove(key);
            synchronized (listeners) { listeners.remove(key); }
        }
    }

    private Bitmap loadRemote(String url) throws Exception {
        URI original = URI.create(url);
        String host = original.getHost();
        if (host == null) return null;
        boolean social = !SiteVisitStore.socialHandleForUrl(url).isEmpty();
        String origin = original.getScheme() + "://" + host;
        // Threads requires the @ prefix; Instagram and X use bare handles.
        String handle = SiteVisitStore.socialHandleForUrl(url);
        String page = social ? origin + "/" +
                (AnalysisModeRouter.fromUrl(url) == AnalysisModeRouter.Mode.THREADS ? handle : handle.substring(1)) + "/" : origin + "/";
        String html = downloadText(page);
        if (html != null) {
            String meta = findMetaImage(html, social);
            if (meta != null) {
                Bitmap bitmap = downloadBitmap(resolve(page, meta));
                if (bitmap != null) return bitmap;
            }
        }
        // An account icon must be the account's own photo, never Instagram/Threads site branding.
        if (social) return null;
        for (String candidate : new String[]{origin + "/apple-touch-icon.png", origin + "/favicon.png", origin + "/favicon.ico"}) {
            Bitmap bitmap = downloadBitmap(candidate);
            if (bitmap != null) return bitmap;
        }
        return null;
    }

    static String findMetaImage(String html, boolean social) {
        if (html == null) return null;
        Matcher tags = TAG.matcher(html);
        String favicon = null;
        while (tags.find()) {
            String tag = tags.group();
            java.util.HashMap<String, String> a = new java.util.HashMap<>();
            Matcher attrs = ATTR.matcher(tag);
            while (attrs.find()) {
                String value = attrs.group(2) != null ? attrs.group(2) : attrs.group(3) != null ? attrs.group(3) : attrs.group(4);
                a.put(attrs.group(1).toLowerCase(java.util.Locale.ROOT), value);
            }
            String rel = a.get("rel");
            String property = a.containsKey("property") ? a.get("property") : a.get("name");
            if (social && property != null && (property.equalsIgnoreCase("og:image") || property.equalsIgnoreCase("twitter:image"))) {
                String content = a.get("content");
                if (content != null && !content.isEmpty()) return unescape(content);
            }
            if (rel != null && rel.toLowerCase(java.util.Locale.ROOT).contains("icon") && favicon == null)
                favicon = unescape(a.get("href"));
        }
        // A social-account icon cannot silently degrade to a site favicon/logo.
        return social ? null : favicon;
    }

    private static String unescape(String s) { return s == null ? null : s.replace("&amp;", "&").replace("&#38;", "&"); }
    private static String resolve(String base, String value) {
        try {
            URI u = URI.create(base).resolve(value);
            if (!"https".equalsIgnoreCase(u.getScheme()) && !"http".equalsIgnoreCase(u.getScheme())) return null;
            return u.toString();
        } catch (Exception ignored) { return null; }
    }

    private String downloadText(String url) {
        try {
            byte[] data = get(url, 160_000, "text/html");
            return data == null ? null : new String(data, StandardCharsets.UTF_8);
        } catch (Exception ignored) { return null; }
    }
    private Bitmap downloadBitmap(String url) {
        try {
            byte[] data = get(url, MAX_BYTES, "image/*");
            if (data == null) return null;
            // Decode large images down to a modest working size before cropping.
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            while (Math.max(bounds.outWidth / options.inSampleSize,
                    bounds.outHeight / options.inSampleSize) > 256) options.inSampleSize *= 2;
            Bitmap source = BitmapFactory.decodeByteArray(data, 0, data.length, options);
            if (source == null) return null; // Unsupported ICO or invalid image.
            try { return circleCrop(source); }
            finally { source.recycle(); }
        } catch (Exception ignored) { return null; }
    }
    /** Aspect-preserving center crop into a transparent circular bitmap (never stretches). */
    static Bitmap circleCrop(Bitmap source) {
        final int size = 96;
        Bitmap result = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Path circle = new Path();
        circle.addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW);
        canvas.clipPath(circle);
        float sw = source.getWidth(), sh = source.getHeight();
        float crop = Math.min(sw, sh);
        Rect src = new Rect(Math.round((sw - crop) / 2f), Math.round((sh - crop) / 2f),
                Math.round((sw + crop) / 2f), Math.round((sh + crop) / 2f));
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        canvas.drawBitmap(source, src, new RectF(0, 0, size, size), paint);
        return result;
    }

    private static byte[] get(String source, int cap, String accept) throws Exception {
        if (source == null) return null;
        URL url = new URL(source);
        if (!"https".equalsIgnoreCase(url.getProtocol()) && !"http".equalsIgnoreCase(url.getProtocol())) return null;
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(4000);
        connection.setReadTimeout(4500);
        connection.setRequestProperty("Accept", accept);
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) ImgStalker/Navigation");
        connection.setInstanceFollowRedirects(true);
        try {
            if (connection.getResponseCode() != 200 || connection.getContentLengthLong() > cap) return null;
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                int n;
                while ((n = input.read(buffer)) != -1) {
                    if (out.size() + n > cap) return null;
                    out.write(buffer, 0, n);
                }
                return out.toByteArray();
            }
        } finally { connection.disconnect(); }
    }

    private File cacheFile(String key) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(key.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : hash) out.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
            File root = new File(context.getCacheDir(), "navigation_icons_circle_v2");
            if (!root.exists()) root.mkdirs();
            return new File(root, out + ".png");
        } catch (Exception e) { return new File(context.getCacheDir(), "nav_icon_failure.png"); }
    }

    void shutdown() { io.shutdownNow(); }
}
