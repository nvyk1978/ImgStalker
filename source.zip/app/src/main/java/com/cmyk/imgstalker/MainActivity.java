package com.cmyk.imgstalker;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.EditorInfo;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.GridView;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private enum HeaderIconKind { SETTINGS, DIAGNOSTIC }

    private static final int BG = 0xFF303030;
    private static final int DARK_GRAY = 0xFF252020;
    private static final int GRAY = 0xFF454040;
    private static final int LIGHT_GRAY = 0xFF656060;
    private static final int BLUE = 0xFF223355;
    private static final int LIGHT_BLUE = 0xFF445577;
    private static final int ORANGE = 0xFF775500;
    private static final int N_WHITE = 0xFFA9A999;
    private static final int TEXT_WHITE = 0xFFFFFFFF;

    private EditText urlInput;
    private EditText resolutionInput;
    private Button resolutionSmall;
    private Button resolutionMedium;
    private Button resolutionLarge;
    private Button selectedResolutionPreset;
    private boolean applyingResolutionPreset;
    private TextView status;
    private TextView summary;
    private Button analyzeButton;
    private Button selectAllButton;
    private Button cancelButton;
    private Button saveButton;
    private LinearLayout settingsPanel;
    private ValueAnimator settingsAnimator;
    private boolean settingsExpanded = true;
    private NToggleSwitch pageToggle;
    private NToggleSwitch detailToggle;
    private NToggleSwitch imageToggle;
    private NToggleSwitch videoToggle;
    private WebView webView;
    private CrawlerEngine crawler;
    private MediaDownloader downloader;
    private ThumbnailLoader thumbnailLoader;
    private final ArrayList<MediaItem> items = new ArrayList<>();
    private MediaAdapter adapter;
    private String pageTitle = "ImgStalker";
    private boolean analyzing = false;
    private boolean downloading = false;
    private boolean selectionMode = false;
    private int selectionAnchorPosition = -1;
    private String lastAnalyzedUrl = null;

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (event != null && event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            boolean inputFocused = (urlInput != null && urlInput.hasFocus())
                    || (resolutionInput != null && resolutionInput.hasFocus());
            if (inputFocused && !isTouchInside(event, urlInput) && !isTouchInside(event, resolutionInput)) {
                dismissKeyboardAndFocus();
            }
        }
        return super.dispatchTouchEvent(event);
    }

    private boolean isTouchInside(MotionEvent event, View view) {
        if (event == null || view == null || !view.isShown()) return false;
        Rect rect = new Rect();
        if (!view.getGlobalVisibleRect(rect)) return false;
        return rect.contains((int) event.getRawX(), (int) event.getRawY());
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DiagnosticLog.install(this);
        DiagnosticLog.log("ACTIVITY onCreate");
        setTitle("ImgStalker");
        buildUi();
        handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        DiagnosticLog.log("ACTIVITY onNewIntent action=" + (intent == null ? "null" : intent.getAction()));
        setIntent(intent);
        handleIntent(intent);
    }

    private void buildUi() {
        getWindow().setStatusBarColor(DARK_GRAY);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundColor(BG);
        root.setFocusableInTouchMode(true);
        root.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        root.requestFocus();
        root.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) dismissKeyboardAndFocus();
            return false;
        });

        Space topOffset = new Space(this);
        root.addView(topOffset, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("ImgStalker", 24, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1f));
        HeaderIconView settingsIcon = new HeaderIconView(this, HeaderIconKind.SETTINGS);
        settingsIcon.setContentDescription("設定");
        HeaderIconView diagnosticIcon = new HeaderIconView(this, HeaderIconKind.DIAGNOSTIC);
        diagnosticIcon.setContentDescription("診断ログ");
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        LinearLayout.LayoutParams diagnosticLp = new LinearLayout.LayoutParams(dp(44), dp(44));
        diagnosticLp.leftMargin = dp(6);
        titleRow.addView(settingsIcon, iconLp);
        titleRow.addView(diagnosticIcon, diagnosticLp);
        root.addView(titleRow, lpMatchWrap(0, 0, dp(12)));
        settingsIcon.setOnClickListener(v -> toggleSettingsPanel());
        diagnosticIcon.setOnClickListener(v -> showDiagnosticLog());

        LinearLayout urlRow = new LinearLayout(this);
        urlRow.setOrientation(LinearLayout.HORIZONTAL);
        urlRow.setGravity(Gravity.CENTER_VERTICAL);

        FrameLayout urlBox = new FrameLayout(this);
        urlBox.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextColor(TEXT_WHITE);
        urlInput.setHintTextColor(N_WHITE);
        urlInput.setHint("https://example.com/gallery");
        urlInput.setTextSize(14);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        urlInput.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        urlInput.setAutofillHints((String[]) null);
        urlInput.setSaveEnabled(false);
        urlInput.setImeOptions(EditorInfo.IME_ACTION_GO | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        urlInput.setPrivateImeOptions("com.google.android.inputmethod.latin.noMicrophoneKey;disableLearning=true");
        urlInput.setPadding(dp(12), 0, dp(44), 0);
        urlInput.setBackground(rounded(DARK_GRAY, 23));
        urlBox.addView(urlInput, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        TextView clearUrl = text("×", 26, N_WHITE);
        clearUrl.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams clearParams = new FrameLayout.LayoutParams(dp(44), dp(46), Gravity.END | Gravity.CENTER_VERTICAL);
        urlBox.addView(clearUrl, clearParams);
        clearUrl.setVisibility(View.GONE);
        clearUrl.setOnClickListener(v -> {
            if (urlInput.length() > 0) {
                DiagnosticLog.log("URL_CLEAR");
                urlInput.setText("");
            }
        });
        urlInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                clearUrl.setVisibility(s != null && s.length() > 0 ? View.VISIBLE : View.GONE);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        urlRow.addView(urlBox, new LinearLayout.LayoutParams(0, dp(46), 1f));
        analyzeButton = button("解析", ORANGE);
        LinearLayout.LayoutParams abp = new LinearLayout.LayoutParams(dp(78), dp(46));
        abp.leftMargin = dp(10);
        urlRow.addView(analyzeButton, abp);
        root.addView(urlRow, lpMatchWrap(0, 0, dp(10)));

        settingsPanel = new LinearLayout(this);
        settingsPanel.setOrientation(LinearLayout.VERTICAL);
        settingsPanel.setClipChildren(true);

        LinearLayout resolutionRow = new LinearLayout(this);
        resolutionRow.setOrientation(LinearLayout.HORIZONTAL);
        resolutionRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView resolutionLabel = text("取得解像度", 13, TEXT_WHITE);
        resolutionRow.addView(resolutionLabel, new LinearLayout.LayoutParams(0, dp(42), 1f));

        resolutionSmall = presetButton("小");
        resolutionMedium = presetButton("中");
        resolutionLarge = presetButton("大");
        LinearLayout.LayoutParams presetLp = new LinearLayout.LayoutParams(dp(42), dp(36));
        resolutionRow.addView(resolutionSmall, cloneParams(presetLp, 0, 0, dp(5), 0));
        resolutionRow.addView(resolutionMedium, cloneParams(presetLp, 0, 0, dp(5), 0));
        resolutionRow.addView(resolutionLarge, cloneParams(presetLp, 0, 0, dp(8), 0));

        resolutionInput = new EditText(this);
        resolutionInput.setSingleLine(true);
        resolutionInput.setGravity(Gravity.CENTER);
        resolutionInput.setTextColor(TEXT_WHITE);
        resolutionInput.setHintTextColor(N_WHITE);
        resolutionInput.setHint("px");
        resolutionInput.setTextSize(13);
        resolutionInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        resolutionInput.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        resolutionInput.setAutofillHints((String[]) null);
        resolutionInput.setSaveEnabled(false);
        resolutionInput.setImeOptions(EditorInfo.IME_ACTION_DONE | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        resolutionInput.setPrivateImeOptions("disableLearning=true");
        resolutionInput.setPadding(dp(6), 0, dp(6), 0);
        resolutionInput.setBackground(rounded(DARK_GRAY, 18));
        resolutionRow.addView(resolutionInput, new LinearLayout.LayoutParams(dp(76), dp(36)));
        settingsPanel.addView(resolutionRow, lpMatchWrap(0, 0, dp(10)));

        resolutionSmall.setOnClickListener(v -> applyResolutionPreset(640, resolutionSmall));
        resolutionMedium.setOnClickListener(v -> applyResolutionPreset(1280, resolutionMedium));
        resolutionLarge.setOnClickListener(v -> applyResolutionPreset(1920, resolutionLarge));
        resolutionInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!applyingResolutionPreset) {
                    selectedResolutionPreset = null;
                    updateResolutionPresetStyles();
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        applyResolutionPreset(640, resolutionSmall);

        LinearLayout toggles = new LinearLayout(this);
        toggles.setOrientation(LinearLayout.VERTICAL);
        toggles.setPadding(dp(12), dp(8), dp(12), dp(8));
        toggles.setBackground(rounded(DARK_GRAY, 12));
        pageToggle = addToggleRow(toggles, "ページ送りを追跡", true);
        detailToggle = addToggleRow(toggles, "サムネイル先を追跡", false);
        imageToggle = addToggleRow(toggles, "画像を取得", true);
        videoToggle = addToggleRow(toggles, "動画を取得", true);
        settingsPanel.addView(toggles, lpMatchWrap(0, 0, dp(12)));
        root.addView(settingsPanel, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = text("URLを入力して解析", 13, N_WHITE);
        status.setMaxLines(2);
        root.addView(status, lpMatchWrap(0, 0, dp(4)));
        summary = text("画像 0   動画 0   ストリーム 0", 14, TEXT_WHITE);
        root.addView(summary, lpMatchWrap(0, 0, dp(10)));

        thumbnailLoader = new ThumbnailLoader(this);
        adapter = new MediaAdapter(this, items);
        GridView grid = new GridView(this);
        grid.setAdapter(adapter);
        grid.setNumColumns(3);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(dp(6));
        grid.setVerticalSpacing(dp(8));
        grid.setPadding(0, 0, 0, 0);
        grid.setClipToPadding(false);
        grid.setBackgroundColor(BG);
        grid.setFastScrollEnabled(true);
        root.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        selectAllButton = button("選択", ORANGE);
        cancelButton = button("キャンセル", GRAY);
        saveButton = button("一括保存", BLUE);
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(46), 1f);
        buttons.addView(selectAllButton, cloneParams(bp, 0, 0, dp(8), 0));
        buttons.addView(cancelButton, cloneParams(bp, 0, 0, dp(8), 0));
        buttons.addView(saveButton, bp);
        root.addView(buttons, lpMatchWrap(dp(8), 0, 0));

        webView = new WebView(this);
        webView.setAlpha(0.01f);
        root.addView(webView, new LinearLayout.LayoutParams(1, 1));

        setContentView(root);

        analyzeButton.setOnClickListener(v -> startAnalysis());
        selectAllButton.setOnClickListener(v -> handleSelectionButton());
        cancelButton.setOnClickListener(v -> cancelCurrent());
        saveButton.setOnClickListener(v -> startDownload());

        crawler = new CrawlerEngine(webView, new CrawlerEngine.Listener() {
            @Override public void onStatus(String text) {
                runOnUiThread(() -> status.setText(text));
            }

            @Override public void onItem(MediaItem item) {
                runOnUiThread(() -> {
                    items.add(item);
                    adapter.notifyDataSetChanged();
                    updateSummary();
                });
            }

            @Override public void onDone(String title, int visitedPages, int imageCount, int videoCount, int streamCount) {
                runOnUiThread(() -> {
                    analyzing = false;
                    DiagnosticLog.log("ANALYZE_DONE pages=" + visitedPages + " images=" + imageCount + " videos=" + videoCount + " streams=" + streamCount);
                    pageTitle = title == null || title.trim().isEmpty() ? hostFromUrl(urlInput.getText().toString()) : title.trim();
                    status.setText("解析完了  " + visitedPages + "ページ");
                    analyzeButton.setText("解析");
                    saveButton.setEnabled(countSelectedDownloadable() > 0);
                    applyButtonEnabledStyle(saveButton);
                    updateSummary();
                });
            }

            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    analyzing = false;
                    DiagnosticLog.log("ANALYZE_ERROR " + message);
                    status.setText(message);
                    analyzeButton.setText("解析");
                });
            }
        });
    }

    private Button presetButton(String label) {
        Button b = button(label, DARK_GRAY);
        b.setTextSize(13);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(rounded(DARK_GRAY, 18));
        return b;
    }

    private void applyResolutionPreset(int px, Button source) {
        selectedResolutionPreset = source;
        applyingResolutionPreset = true;
        resolutionInput.setText(String.valueOf(px));
        resolutionInput.setSelection(resolutionInput.length());
        applyingResolutionPreset = false;
        updateResolutionPresetStyles();
        DiagnosticLog.log("RESOLUTION_PRESET value=" + px);
    }

    private void updateResolutionPresetStyles() {
        styleResolutionPreset(resolutionSmall, selectedResolutionPreset == resolutionSmall);
        styleResolutionPreset(resolutionMedium, selectedResolutionPreset == resolutionMedium);
        styleResolutionPreset(resolutionLarge, selectedResolutionPreset == resolutionLarge);
    }

    private void styleResolutionPreset(Button button, boolean selected) {
        if (button == null) return;
        button.setTextColor(TEXT_WHITE);
        button.setBackground(rounded(selected ? LIGHT_BLUE : DARK_GRAY, 18));
    }

    private int getTargetResolution() {
        try {
            int px = Integer.parseInt(resolutionInput.getText().toString().trim());
            if (px < 64 || px > 8192) return -1;
            return px;
        } catch (Exception e) {
            return -1;
        }
    }

    private NToggleSwitch addToggleRow(LinearLayout parent, String label, boolean checked) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(label, 14, TEXT_WHITE);
        row.addView(t, new LinearLayout.LayoutParams(0, dp(42), 1f));
        NToggleSwitch sw = new NToggleSwitch(this);
        sw.setChecked(checked);
        row.addView(sw, new LinearLayout.LayoutParams(dp(48), dp(26)));
        View.OnClickListener toggleFromLabel = v -> sw.setChecked(!sw.isChecked());
        t.setClickable(true);
        t.setOnClickListener(toggleFromLabel);
        row.setOnClickListener(toggleFromLabel);
        parent.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));
        return sw;
    }

    private void startAnalysis() {
        // Snapshot the currently visible EditText value before focus/IME teardown. This keeps
        // re-analysis bound to exactly what the user has entered, even with composing IMEs.
        String url = urlInput.getText().toString().trim();
        dismissKeyboardAndFocus();
        if (url.isEmpty()) {
            Toast.makeText(this, "URLを入力してください", Toast.LENGTH_SHORT).show();
            return;
        }
        int targetPx = getTargetResolution();
        if (targetPx < 0) {
            Toast.makeText(this, "取得解像度は64〜8192pxで入力してください", Toast.LENGTH_SHORT).show();
            return;
        }
        if (downloading) return;
        setSettingsExpanded(false, true);
        if (lastAnalyzedUrl == null || !lastAnalyzedUrl.equals(url)) {
            DiagnosticLog.clear();
            DiagnosticLog.log("LOG_RESET new_url=" + url);
            lastAnalyzedUrl = url;
        }
        if (analyzing) crawler.cancel();
        thumbnailLoader.cancelPending();
        DiagnosticLog.log("ANALYZE_START url=" + url
                + " pagination=" + pageToggle.isChecked()
                + " details=" + detailToggle.isChecked()
                + " images=" + imageToggle.isChecked()
                + " videos=" + videoToggle.isChecked()
                + " targetImagePx=" + targetPx);
        items.clear();
        selectionMode = false;
        selectionAnchorPosition = -1;
        updateSelectionControls();
        adapter.notifyDataSetChanged();
        pageTitle = "ImgStalker";
        analyzing = true;
        status.setText("解析開始");
        summary.setText("画像 0   動画 0   ストリーム 0");
        analyzeButton.setText("再解析");
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        crawler.start(url, pageToggle.isChecked(), detailToggle.isChecked(), imageToggle.isChecked(), videoToggle.isChecked(), targetPx);
    }

    private void startDownload() {
        if (downloading) return;
        int selected = countSelectedDownloadable();
        if (selected == 0) {
            Toast.makeText(this, "保存する画像・動画を選択してください", Toast.LENGTH_SHORT).show();
            return;
        }
        if (analyzing) {
            crawler.cancel();
            analyzing = false;
            analyzeButton.setText("解析");
            DiagnosticLog.log("ANALYZE_CANCEL_FOR_DOWNLOAD selected=" + selected);
            if ("ImgStalker".equals(pageTitle)) {
                String host = hostFromUrl(urlInput.getText().toString());
                if (host != null && !host.trim().isEmpty()) pageTitle = host;
            }
        }
        downloading = true;
        DiagnosticLog.log("DOWNLOAD_START selected=" + selected + " title=" + pageTitle);
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
        status.setText("保存開始  " + selected + "ファイル");
        downloader = new MediaDownloader(this, new MediaDownloader.Listener() {
            @Override public void onProgress(int done, int total, String message) {
                runOnUiThread(() -> status.setText("保存中  " + done + " / " + total));
            }

            @Override public void onFinished(String folderName, int success, int failed) {
                runOnUiThread(() -> {
                    downloading = false;
                    DiagnosticLog.log("DOWNLOAD_DONE folder=" + folderName + " success=" + success + " failed=" + failed);
                    saveButton.setEnabled(countSelectedDownloadable() > 0);
                    applyButtonEnabledStyle(saveButton);
                    if (folderName.isEmpty()) {
                        status.setText("保存対象がありません");
                    } else {
                        status.setText("保存完了  " + success + "件 / 失敗 " + failed + "件\nDownloads/ImgStalker/" + folderName);
                    }
                });
            }
        });
        downloader.download(items, pageTitle);
    }

    private void cancelCurrent() {
        if (selectionMode) {
            exitSelectionMode(true, "cancel_button");
            return;
        }
        if (analyzing) {
            crawler.cancel();
            DiagnosticLog.log("ANALYZE_CANCEL");
            analyzing = false;
            analyzeButton.setText("解析");
            status.setText("解析をキャンセル");
            saveButton.setEnabled(countSelectedDownloadable() > 0);
            applyButtonEnabledStyle(saveButton);
            return;
        }
        if (downloading && downloader != null) {
            downloader.cancel();
            DiagnosticLog.log("DOWNLOAD_CANCEL");
            downloading = false;
            status.setText("保存をキャンセル");
            saveButton.setEnabled(countSelectedDownloadable() > 0);
            applyButtonEnabledStyle(saveButton);
            return;
        }
        items.clear();
        adapter.notifyDataSetChanged();
        updateSummary();
        status.setText("結果をクリア");
        saveButton.setEnabled(false);
        applyButtonEnabledStyle(saveButton);
    }

    private void handleSelectionButton() {
        if (!selectionMode) {
            enterSelectionMode();
            return;
        }
        if (areAllDownloadableSelected()) {
            exitSelectionMode(true, "select_all_toggle_clear");
            return;
        }
        selectAllDownloadable();
    }

    private void enterSelectionMode() {
        if (selectionMode) return;
        selectionMode = true;
        selectionAnchorPosition = -1;
        DiagnosticLog.log("SELECTION_MODE_ENTER");
        updateSelectionControls();
        adapter.notifyDataSetChanged();
    }

    private void exitSelectionMode(boolean clearSelection, String reason) {
        if (clearSelection) {
            for (MediaItem i : items) {
                if (i.kind != MediaItem.Kind.STREAM) i.selected = false;
            }
        }
        boolean wasSelectionMode = selectionMode;
        selectionMode = false;
        selectionAnchorPosition = -1;
        if (wasSelectionMode) {
            DiagnosticLog.log("SELECTION_MODE_EXIT reason=" + reason + " clear=" + clearSelection);
        }
        updateSelectionControls();
        adapter.notifyDataSetChanged();
        updateSummary();
    }

    private void selectAllDownloadable() {
        int changed = 0;
        for (MediaItem i : items) {
            if (i.kind != MediaItem.Kind.STREAM && !i.selected) {
                i.selected = true;
                changed++;
            }
        }
        DiagnosticLog.log("SELECT_ALL changed=" + changed + " count=" + countSelectedDownloadable());
        adapter.notifyDataSetChanged();
        updateSummary();
    }

    private void toggleSelectionAt(int position) {
        if (position < 0 || position >= items.size()) return;
        MediaItem item = items.get(position);
        if (item.kind == MediaItem.Kind.STREAM) return;

        item.selected = !item.selected;
        if (item.selected) {
            selectionAnchorPosition = position;
        } else if (selectionAnchorPosition == position) {
            selectionAnchorPosition = -1;
        }
        DiagnosticLog.log("ITEM_SELECT position=" + position + " selected=" + item.selected
                + " kind=" + item.kind + " url=" + item.url);
        adapter.notifyDataSetChanged();
        updateSummary();

        if (selectionMode && countSelectedDownloadable() == 0) {
            exitSelectionMode(false, "all_deselected_by_tap");
        }
    }

    private void enterSelectionModeWithItem(int position) {
        if (position < 0 || position >= items.size()) return;
        MediaItem item = items.get(position);
        if (item.kind == MediaItem.Kind.STREAM) return;
        if (!selectionMode) {
            selectionMode = true;
            DiagnosticLog.log("SELECTION_MODE_ENTER source=long_press position=" + position);
        }
        item.selected = true;
        selectionAnchorPosition = position;
        updateSelectionControls();
        adapter.notifyDataSetChanged();
        updateSummary();
    }

    private boolean selectRangeFromAnchor(int position) {
        if (!selectionMode || selectionAnchorPosition < 0 || position < 0 || position >= items.size()) {
            return false;
        }
        int anchor = selectionAnchorPosition;
        if (anchor == position || anchor >= items.size()) return false;
        MediaItem anchorItem = items.get(anchor);
        if (anchorItem.kind == MediaItem.Kind.STREAM || !anchorItem.selected) return false;

        int from = Math.min(anchor, position);
        int to = Math.max(anchor, position);
        for (int i = from + 1; i < to; i++) {
            MediaItem middle = items.get(i);
            if (middle.kind != MediaItem.Kind.STREAM && middle.selected) {
                DiagnosticLog.log("RANGE_SELECT_SKIP anchor=" + anchor + " target=" + position
                        + " reason=middle_selected position=" + i);
                return false;
            }
        }

        int selectedCount = 0;
        for (int i = from; i <= to; i++) {
            MediaItem candidate = items.get(i);
            if (candidate.kind != MediaItem.Kind.STREAM) {
                candidate.selected = true;
                selectedCount++;
            }
        }
        selectionAnchorPosition = position;
        DiagnosticLog.log("RANGE_SELECT anchor=" + anchor + " target=" + position
                + " range=" + from + "-" + to + " selected=" + selectedCount);
        adapter.notifyDataSetChanged();
        updateSummary();
        return true;
    }

    private boolean areAllDownloadableSelected() {
        int selectable = 0;
        int selected = 0;
        for (MediaItem i : items) {
            if (i.kind == MediaItem.Kind.STREAM) continue;
            selectable++;
            if (i.selected) selected++;
        }
        return selectable > 0 && selected == selectable;
    }

    private void updateSelectionControls() {
        if (selectAllButton != null) {
            if (!selectionMode) {
                selectAllButton.setText("選択");
            } else {
                selectAllButton.setText(areAllDownloadableSelected() ? "全解除" : "全選択");
            }
        }
    }

    private void updateSummary() {
        int images = 0, videos = 0, streams = 0;
        int selectable = 0, selected = 0;
        for (MediaItem i : items) {
            if (i.kind == MediaItem.Kind.IMAGE) images++;
            else if (i.kind == MediaItem.Kind.VIDEO) videos++;
            else streams++;
            if (i.kind != MediaItem.Kind.STREAM) {
                selectable++;
                if (i.selected) selected++;
            }
        }
        summary.setText("画像 " + images + "   動画 " + videos + "   ストリーム " + streams + "   選択 " + selected);
        updateSelectionControls();
        if (!downloading) {
            saveButton.setEnabled(selected > 0);
            applyButtonEnabledStyle(saveButton);
        }
    }

    private int countSelectedDownloadable() {
        int n = 0;
        for (MediaItem i : items) if (i.selected && i.kind != MediaItem.Kind.STREAM) n++;
        return n;
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (sharedText != null) {
                String url = firstHttpUrl(sharedText);
                if (!url.isEmpty()) {
                    urlInput.setText(url);
                    DiagnosticLog.log("SHARE_URL " + url);
                }
            }
        }
    }

    private static String firstHttpUrl(String value) {
        if (value == null) return "";
        for (String p : value.split("\\s+")) if (p.startsWith("http://") || p.startsWith("https://")) return p;
        return "";
    }

    private static String hostFromUrl(String value) {
        try {
            String x = value.trim();
            if (!x.matches("(?i)^https?://.*")) x = "https://" + x;
            String h = new URI(x).getHost();
            return h == null ? "WebMedia" : h;
        } catch (Exception e) {
            return "WebMedia";
        }
    }

    private void toggleSettingsPanel() {
        setSettingsExpanded(!settingsExpanded, true);
    }

    private void setSettingsExpanded(boolean expanded, boolean animate) {
        if (settingsPanel == null) return;
        if (settingsAnimator != null) {
            settingsAnimator.cancel();
            settingsAnimator = null;
        }
        settingsExpanded = expanded;

        if (!animate) {
            ViewGroup.LayoutParams lp = settingsPanel.getLayoutParams();
            lp.height = expanded ? ViewGroup.LayoutParams.WRAP_CONTENT : 0;
            settingsPanel.setLayoutParams(lp);
            settingsPanel.setAlpha(expanded ? 1f : 0f);
            settingsPanel.setTranslationY(0f);
            settingsPanel.setVisibility(expanded ? View.VISIBLE : View.GONE);
            return;
        }

        if (expanded) {
            settingsPanel.setVisibility(View.VISIBLE);
            settingsPanel.setAlpha(0f);
            settingsPanel.setTranslationY(-dp(18));
            int width = settingsPanel.getWidth();
            if (width <= 0 && settingsPanel.getParent() instanceof View) {
                width = ((View) settingsPanel.getParent()).getWidth();
            }
            int widthSpec = View.MeasureSpec.makeMeasureSpec(Math.max(1, width), View.MeasureSpec.EXACTLY);
            int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
            ViewGroup.LayoutParams lp = settingsPanel.getLayoutParams();
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            settingsPanel.setLayoutParams(lp);
            settingsPanel.measure(widthSpec, heightSpec);
            final int targetHeight = settingsPanel.getMeasuredHeight();
            lp.height = 0;
            settingsPanel.setLayoutParams(lp);

            settingsAnimator = ValueAnimator.ofInt(0, targetHeight);
            settingsAnimator.setDuration(190L);
            settingsAnimator.addUpdateListener(a -> {
                float f = a.getAnimatedFraction();
                ViewGroup.LayoutParams p = settingsPanel.getLayoutParams();
                p.height = (Integer) a.getAnimatedValue();
                settingsPanel.setLayoutParams(p);
                settingsPanel.setAlpha(f);
                settingsPanel.setTranslationY(-dp(18) * (1f - f));
            });
            settingsAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    ViewGroup.LayoutParams p = settingsPanel.getLayoutParams();
                    p.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    settingsPanel.setLayoutParams(p);
                    settingsPanel.setAlpha(1f);
                    settingsPanel.setTranslationY(0f);
                    settingsAnimator = null;
                    DiagnosticLog.log("SETTINGS_EXPAND");
                }
            });
            settingsAnimator.start();
        } else {
            final int startHeight = settingsPanel.getHeight();
            if (startHeight <= 0) {
                settingsPanel.setVisibility(View.GONE);
                return;
            }
            settingsAnimator = ValueAnimator.ofInt(startHeight, 0);
            settingsAnimator.setDuration(170L);
            settingsAnimator.addUpdateListener(a -> {
                float f = a.getAnimatedFraction();
                ViewGroup.LayoutParams p = settingsPanel.getLayoutParams();
                p.height = (Integer) a.getAnimatedValue();
                settingsPanel.setLayoutParams(p);
                settingsPanel.setAlpha(1f - f);
                settingsPanel.setTranslationY(-dp(18) * f);
            });
            settingsAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    settingsPanel.setVisibility(View.GONE);
                    settingsPanel.setAlpha(0f);
                    settingsPanel.setTranslationY(0f);
                    ViewGroup.LayoutParams p = settingsPanel.getLayoutParams();
                    p.height = 0;
                    settingsPanel.setLayoutParams(p);
                    settingsAnimator = null;
                    DiagnosticLog.log("SETTINGS_COLLAPSE");
                }
            });
            settingsAnimator.start();
        }
    }

    private void showDiagnosticLog() {
        DiagnosticLog.log("DIAGNOSTIC_OPEN");

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView title = text("診断ログ", 21, TEXT_WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        panel.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setScrollbarFadingEnabled(true);
        TextView body = text(DiagnosticLog.report(this), 11, TEXT_WHITE);
        body.setTypeface(Typeface.MONOSPACE);
        body.setTextIsSelectable(true);
        body.setGravity(Gravity.TOP | Gravity.START);
        body.setPadding(dp(10), dp(8), dp(10), dp(8));
        body.setBackground(rounded(DARK_GRAY, 10));
        scroll.addView(body, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(430)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.setPadding(0, dp(8), 0, 0);

        TextView clearAction = makeDialogAction("ログ消去");
        TextView shareAction = makeDialogAction(".txtを共有");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        shareAction.setGravity(Gravity.CENTER);
        copyAction.setGravity(Gravity.CENTER);
        closeAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);

        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(shareAction, new LinearLayout.LayoutParams(dp(108), dp(48)));
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(78), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(78), dp(48)));

        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        panel.addView(actions);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .create();

        clearAction.setOnClickListener(v -> {
            DiagnosticLog.clear();
            body.setText(DiagnosticLog.report(this));
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        shareAction.setOnClickListener(v -> {
            try {
                File reportFile = DiagnosticLog.exportReportFile(this);
                Uri uri = Uri.parse("content://" + getPackageName() + ".diagnostic/" + Uri.encode(reportFile.getName()));
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_STREAM, uri);
                share.putExtra(Intent.EXTRA_SUBJECT, reportFile.getName());
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                share.setClipData(ClipData.newRawUri("ImgStalker diagnostic", uri));
                DiagnosticLog.log("DIAGNOSTIC_SHARE file=" + reportFile.getName() + " bytes=" + reportFile.length());
                startActivity(Intent.createChooser(share, "診断ログを共有"));
            } catch (Exception e) {
                DiagnosticLog.logException("DIAGNOSTIC_SHARE_FAIL", e);
                Toast.makeText(this, "診断ログの共有に失敗しました", Toast.LENGTH_SHORT).show();
            }
        });
        copyAction.setOnClickListener(v -> {
            String report = DiagnosticLog.report(this);
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("ImgStalker diagnostic", report));
            Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
        });
        closeAction.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(rounded(GRAY, 20));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    private TextView makeDialogAction(String value) {
        TextView t = text(value, 14, TEXT_WHITE);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setPadding(dp(8), 0, dp(8), 0);
        t.setBackground(new LinkCapsuleDrawable(t, LIGHT_BLUE));
        return t;
    }

    private final class LinkCapsuleDrawable extends Drawable {
        private final TextView host;
        private final int enabledColor;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        LinkCapsuleDrawable(TextView host, int enabledColor) {
            this.host = host;
            this.enabledColor = enabledColor;
            paint.setStyle(Paint.Style.FILL);
        }

        @Override public void draw(Canvas canvas) {
            if (host == null) return;
            paint.setColor(host.isEnabled() ? enabledColor : DARK_GRAY);
            CharSequence textValue = host.getText();
            float textWidth = host.getPaint().measureText(textValue == null ? "" : textValue.toString());
            float visualWidth = Math.max(dp(24), textWidth + dp(14));
            float visualHeight = dp(26);
            android.graphics.Rect bounds = getBounds();
            float textLeft;
            int absoluteGravity = Gravity.getAbsoluteGravity(host.getGravity(), host.getLayoutDirection());
            int horizontal = absoluteGravity & Gravity.HORIZONTAL_GRAVITY_MASK;
            float contentLeft = bounds.left + host.getPaddingLeft();
            float contentRight = bounds.right - host.getPaddingRight();
            if (horizontal == Gravity.RIGHT) {
                float textRight = contentRight;
                textLeft = textRight - textWidth;
            } else if (horizontal == Gravity.CENTER_HORIZONTAL) {
                textLeft = (contentLeft + contentRight - textWidth) / 2f;
            } else {
                textLeft = contentLeft;
            }
            float left = textLeft - dp(7);
            float right = textLeft + textWidth + dp(7);
            if (left < bounds.left) {
                right += bounds.left - left;
                left = bounds.left;
            }
            if (right > bounds.right) {
                left -= right - bounds.right;
                right = bounds.right;
            }
            if (right - left < visualWidth) {
                float cx = (left + right) / 2f;
                left = Math.max(bounds.left, cx - visualWidth / 2f);
                right = Math.min(bounds.right, cx + visualWidth / 2f);
            }
            float cy = bounds.exactCenterY();
            float top = cy - visualHeight / 2f;
            float bottom = cy + visualHeight / 2f;
            canvas.drawRoundRect(left, top, right, bottom, visualHeight / 2f, visualHeight / 2f, paint);
        }

        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(android.graphics.ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private void showOriginalImage(MediaItem item) {
        if (item == null || item.kind != MediaItem.Kind.IMAGE) return;
        dismissKeyboardAndFocus();
        DiagnosticLog.log("ORIGINAL_OPEN url=" + item.url + " ref=" + item.referrer);

        Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        // Keep the bottom action row clear of gesture/navigation insets while retaining a full-screen dialog.
        root.setPadding(0, 0, 0, dp(16));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int bottomInset = insets.getSystemWindowInsetBottom();
            v.setPadding(0, 0, 0, Math.max(dp(16), bottomInset));
            return insets;
        });
        root.setBackgroundColor(BG);

        FrameLayout viewerFrame = new FrameLayout(this);
        viewerFrame.setBackgroundColor(Color.BLACK);
        ZoomImageView viewer = new ZoomImageView(this);
        viewer.setBackgroundColor(Color.BLACK);
        viewerFrame.addView(viewer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView loading = text("読み込み中…", 14, N_WHITE);
        loading.setGravity(Gravity.CENTER);
        viewerFrame.addView(loading, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(viewerFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.setPadding(dp(12), dp(4), dp(12), dp(4));
        TextView closeAction = makeDialogAction("閉じる");
        closeAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        actions.addView(new Space(this), new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(closeAction, new LinearLayout.LayoutParams(dp(78), dp(48)));
        root.addView(actions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        final ExecutorService originalLoader = Executors.newSingleThreadExecutor();
        final Bitmap[] loadedBitmap = new Bitmap[1];
        final boolean[] disposed = new boolean[]{false};

        closeAction.setOnClickListener(v -> dialog.dismiss());
        dialog.setOnDismissListener(d -> {
            disposed[0] = true;
            originalLoader.shutdownNow();
            viewer.setBitmap(null);
            if (loadedBitmap[0] != null && !loadedBitmap[0].isRecycled()) {
                loadedBitmap[0].recycle();
                loadedBitmap[0] = null;
            }
        });
        dialog.setContentView(root);
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(BG));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        originalLoader.submit(() -> {
            try {
                Bitmap bitmap = OriginalImageLoader.load(MainActivity.this, item);
                runOnUiThread(() -> {
                    if (disposed[0] || !dialog.isShowing()) {
                        if (!bitmap.isRecycled()) bitmap.recycle();
                        return;
                    }
                    loadedBitmap[0] = bitmap;
                    loading.setVisibility(View.GONE);
                    viewer.setBitmap(bitmap);
                    DiagnosticLog.log("ORIGINAL_LOADED url=" + item.url
                            + " size=" + bitmap.getWidth() + "x" + bitmap.getHeight());
                });
            } catch (Exception e) {
                DiagnosticLog.logException("ORIGINAL_ERROR url=" + item.url, e);
                runOnUiThread(() -> {
                    if (disposed[0] || !dialog.isShowing()) return;
                    loading.setText("画像を開けませんでした");
                    Toast.makeText(MainActivity.this, "元画像を開けませんでした", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void dismissKeyboardAndFocus() {
        View focused = getCurrentFocus();
        if (urlInput != null) urlInput.clearFocus();
        if (resolutionInput != null) resolutionInput.clearFocus();
        if (focused != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        }
        View content = findViewById(android.R.id.content);
        if (content != null) {
            content.setFocusableInTouchMode(true);
            content.requestFocus();
        }
    }

    private TextView text(String value, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(TEXT_WHITE);
        b.setAllCaps(false);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setElevation(0f);
        b.setStateListAnimator(null);
        b.setBackground(rounded(color, 12));
        return b;
    }

    private void applyButtonEnabledStyle(Button b) {
        if (b.isEnabled()) {
            b.setTextColor(TEXT_WHITE);
            b.setBackground(rounded(BLUE, 12));
        } else {
            b.setTextColor(N_WHITE);
            b.setBackground(rounded(GRAY, 12));
        }
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams lpMatchWrap(int top, int left, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(left, top, 0, bottom);
        return p;
    }

    private LinearLayout.LayoutParams cloneParams(LinearLayout.LayoutParams src, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(src.width, src.height, src.weight);
        p.setMargins(left, top, right, bottom);
        return p;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override protected void onDestroy() {
        DiagnosticLog.log("ACTIVITY onDestroy");
        if (settingsAnimator != null) settingsAnimator.cancel();
        if (crawler != null) crawler.cancel();
        if (downloader != null) downloader.cancel();
        if (thumbnailLoader != null) thumbnailLoader.shutdown();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private final class HeaderIconView extends View {
        private final HeaderIconKind kind;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        HeaderIconView(Context context, HeaderIconKind kind) {
            super(context);
            this.kind = kind;
            setClickable(true);
            setFocusable(true);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(DARK_GRAY);
            canvas.drawCircle(cx, cy, Math.min(getWidth(), getHeight()) / 2f, paint);

            paint.setColor(N_WHITE);
            paint.setStrokeWidth(dp(2.2f));
            paint.setStrokeCap(Paint.Cap.SQUARE);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStyle(Paint.Style.STROKE);

            if (kind == HeaderIconKind.SETTINGS) {
                float outer = dp(8.0f);
                float toothStart = dp(9.5f);
                float toothEnd = dp(12.0f);
                canvas.drawCircle(cx, cy, outer, paint);
                canvas.drawCircle(cx, cy, dp(3.2f), paint);
                for (int i = 0; i < 8; i++) {
                    double a = Math.PI * 2.0 * i / 8.0;
                    float x1 = cx + (float) Math.cos(a) * toothStart;
                    float y1 = cy + (float) Math.sin(a) * toothStart;
                    float x2 = cx + (float) Math.cos(a) * toothEnd;
                    float y2 = cy + (float) Math.sin(a) * toothEnd;
                    canvas.drawLine(x1, y1, x2, y2, paint);
                }
            } else {
                RectF back = new RectF(cx - dp(6), cy - dp(11), cx + dp(11), cy + dp(7));
                RectF front = new RectF(cx - dp(11), cy - dp(6), cx + dp(6), cy + dp(11));
                canvas.drawRect(back, paint);
                canvas.drawRect(front, paint);
                float left = front.left + dp(4);
                float right = front.right - dp(3);
                canvas.drawLine(left, front.top + dp(7), right, front.top + dp(7), paint);
                canvas.drawLine(left, front.top + dp(11), right, front.top + dp(11), paint);
                canvas.drawLine(left, front.top + dp(15), right - dp(2), front.top + dp(15), paint);
                path.reset();
                path.moveTo(front.right - dp(5), front.top);
                path.lineTo(front.right, front.top + dp(5));
                path.lineTo(front.right - dp(5), front.top + dp(5));
                path.close();
                canvas.drawPath(path, paint);
            }
        }
    }

    private final class MediaAdapter extends ArrayAdapter<MediaItem> {
        MediaAdapter(Context context, ArrayList<MediaItem> data) {
            super(context, 0, data);
        }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            CellHolder h;
            if (convertView == null) {
                LinearLayout cell = new LinearLayout(MainActivity.this);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER_HORIZONTAL);
                cell.setPadding(dp(4), dp(4), dp(4), dp(5));
                cell.setBackgroundColor(BG);

                SquareFrameLayout thumbFrame = new SquareFrameLayout(MainActivity.this);
                thumbFrame.setBackground(rounded(DARK_GRAY, 7));

                ImageView thumb = new ImageView(MainActivity.this);
                thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                thumb.setBackground(rounded(DARK_GRAY, 7));
                thumbFrame.addView(thumb, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                EyeIconView eye = new EyeIconView(MainActivity.this);
                eye.setContentDescription("画像を表示");
                FrameLayout.LayoutParams eyeLp = new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP | Gravity.START);
                eyeLp.setMargins(dp(4), dp(4), 0, 0);
                thumbFrame.addView(eye, eyeLp);

                cell.addView(thumbFrame, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

                TextView fileName = text("", 12, N_WHITE);
                fileName.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
                fileName.setMaxLines(2);
                fileName.setEllipsize(TextUtils.TruncateAt.END);
                fileName.setPadding(dp(3), dp(5), dp(3), dp(3));
                LinearLayout.LayoutParams fileNameLp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
                fileNameLp.setMargins(dp(2), dp(4), dp(2), 0);
                cell.addView(fileName, fileNameLp);

                h = new CellHolder(thumbFrame, thumb, eye, fileName);
                cell.setTag(h);
                convertView = cell;
            } else {
                h = (CellHolder) convertView.getTag();
            }

            MediaItem item = getItem(position);
            LinearLayout cell = (LinearLayout) convertView;
            cell.setBackgroundColor(BG);
            h.fileName.setText(fileNameFromUrl(item.url));
            h.fileName.setTextColor(item.kind == MediaItem.Kind.STREAM ? LIGHT_GRAY : (item.selected ? TEXT_WHITE : N_WHITE));
            h.fileName.setBackground(rounded(selectionMode && item.selected ? LIGHT_BLUE : BG, 6));
            h.eye.setVisibility(selectionMode && item.kind == MediaItem.Kind.IMAGE ? View.VISIBLE : View.GONE);
            thumbnailLoader.load(h.thumb, item);

            View.OnClickListener itemTap = v -> {
                if (selectionMode) {
                    toggleSelectionAt(position);
                    return;
                }
                if (item.kind == MediaItem.Kind.IMAGE) {
                    showOriginalImage(item);
                }
            };

            View.OnLongClickListener itemLongPress = v -> {
                if (item.kind == MediaItem.Kind.STREAM) return true;
                if (!selectionMode) {
                    enterSelectionModeWithItem(position);
                    return true;
                }
                if (selectRangeFromAnchor(position)) return true;
                if (!item.selected) {
                    item.selected = true;
                    selectionAnchorPosition = position;
                    DiagnosticLog.log("ITEM_SELECT_LONG position=" + position + " url=" + item.url);
                    notifyDataSetChanged();
                    updateSummary();
                }
                return true;
            };

            h.thumbFrame.setOnClickListener(itemTap);
            h.thumbFrame.setOnLongClickListener(itemLongPress);
            h.fileName.setOnClickListener(v -> {
                if (selectionMode) toggleSelectionAt(position);
                else if (item.kind == MediaItem.Kind.IMAGE) showOriginalImage(item);
            });
            h.fileName.setOnLongClickListener(itemLongPress);
            h.eye.setOnClickListener(v -> {
                if (item.kind == MediaItem.Kind.IMAGE) {
                    DiagnosticLog.log("ITEM_PREVIEW_EYE position=" + position + " url=" + item.url);
                    showOriginalImage(item);
                }
            });
            h.eye.setOnLongClickListener(v -> true);
            return convertView;
        }
    }

    private static String fileNameFromUrl(String value) {
        try {
            Uri uri = Uri.parse(value == null ? "" : value);
            String last = uri.getLastPathSegment();
            if (last != null && !last.trim().isEmpty()) return Uri.decode(last.trim());
        } catch (Exception ignored) {}
        return value == null || value.trim().isEmpty() ? "(名称不明)" : value.trim();
    }

    private final class CellHolder {
        final SquareFrameLayout thumbFrame;
        final ImageView thumb;
        final EyeIconView eye;
        final TextView fileName;

        CellHolder(SquareFrameLayout thumbFrame, ImageView thumb, EyeIconView eye, TextView fileName) {
            this.thumbFrame = thumbFrame;
            this.thumb = thumb;
            this.eye = eye;
            this.fileName = fileName;
        }
    }

    private static final class SquareFrameLayout extends FrameLayout {
        SquareFrameLayout(Context context) {
            super(context);
        }

        @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = View.MeasureSpec.getSize(widthMeasureSpec);
            if (width <= 0) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec);
                width = getMeasuredWidth();
            }
            int square = View.MeasureSpec.makeMeasureSpec(Math.max(1, width), View.MeasureSpec.EXACTLY);
            super.onMeasure(square, square);
            setMeasuredDimension(Math.max(1, width), Math.max(1, width));
        }
    }

    private final class EyeIconView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval = new RectF();

        EyeIconView(Context context) {
            super(context);
            setClickable(true);
            setFocusable(true);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float radius = Math.min(getWidth(), getHeight()) / 2f;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(DARK_GRAY);
            canvas.drawCircle(cx, cy, radius, paint);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1.8f));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(N_WHITE);
            oval.set(cx - dp(8), cy - dp(5), cx + dp(8), cy + dp(5));
            canvas.drawOval(oval, paint);

            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(cx, cy, dp(2.5f), paint);
        }
    }

}
