package com.cmyk.imgstalker;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * X/Twitter CDN transport helpers.
 *
 * v0.1.93 deliberately stops guessing that the legacy `tag` query parameter is
 * the reason for HTTP 403.  A failed CDN URL is retried with browser-like
 * request headers, then (once per analysis) the media is re-resolved from its
 * source/referrer page and any X/Twitter status links found there.  Recovery
 * and terminal failures are cached so thumbnail/preview loops cannot hammer the
 * same dead URL repeatedly.
 */
public final class TwitterVideoUrl {
    private static final int MAX_SOURCE_BYTES = 2 * 1024 * 1024;
    private static final int MAX_STATUS_PAGES = 6;

    private static final Pattern VIDEO_URL = Pattern.compile(
            "https?://video\\.twimg\\.com/[^\\s\\\"'<>]+?\\.mp4(?:\\?[^\\s\\\"'<>]*)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern STATUS_URL = Pattern.compile(
            "https?://(?:www\\.)?(?:x\\.com|twitter\\.com)/[A-Za-z0-9_]+/status/\\d+(?:\\?[^\\s\\\"'<>]*)?",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern MEDIA_ID = Pattern.compile(
            "/(?:ext_tw_video|amplify_video|dm_video)/(\\d+)(?:/|$)", Pattern.CASE_INSENSITIVE);
    private static final Pattern TWEET_VIDEO_ID = Pattern.compile(
            "/tweet_video/([^/?#]+?)\\.mp4(?:$|[?#])", Pattern.CASE_INSENSITIVE);
    private static final Pattern RESOLUTION = Pattern.compile(
            "/vid/(?:avc1/)?(\\d+)x(\\d+)/", Pattern.CASE_INSENSITIVE);

    private static final ConcurrentHashMap<String, String> RECOVERED = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, String> REFRESH_RESULT = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, Boolean> FAILED_MODES = new ConcurrentHashMap<>();
    private static final ConcurrentHashMap<String, Object> REFRESH_LOCKS = new ConcurrentHashMap<>();

    private TwitterVideoUrl() {}

    /** Clear per-analysis recovery/failure state. */
    public static void resetSession() {
        RECOVERED.clear();
        REFRESH_RESULT.clear();
        FAILED_MODES.clear();
        REFRESH_LOCKS.clear();
        DiagnosticLog.log("TW_VIDEO_SESSION_RESET");
    }

    /** Reuse a URL that was freshly resolved and proved usable earlier in this analysis. */
    public static String resolvedOrOriginal(String raw) {
        if (raw == null) return null;
        String recovered = RECOVERED.get(raw);
        return recovered == null || recovered.isEmpty() ? raw : recovered;
    }

    public static void markRecovered(String original, String recovered) {
        if (original == null || recovered == null || recovered.trim().isEmpty()) return;
        RECOVERED.put(original, recovered);
        clearFailures(original);
    }

    public static boolean isKnownFailed(String original, String mode) {
        if (original == null) return false;
        return FAILED_MODES.containsKey(modeKey(original, mode));
    }

    public static void markFailed(String original, String mode) {
        if (original == null) return;
        FAILED_MODES.put(modeKey(original, mode), Boolean.TRUE);
    }

    public static void clearFailures(String original) {
        if (original == null) return;
        String prefix = original + "\n";
        for (String key : new ArrayList<>(FAILED_MODES.keySet())) {
            if (key.startsWith(prefix)) FAILED_MODES.remove(key);
        }
    }

    private static String modeKey(String original, String mode) {
        return original + "\n" + (mode == null ? "" : mode);
    }

    public static boolean isTwitterVideoMp4(String raw) {
        if (raw == null || raw.trim().isEmpty()) return false;
        try {
            URL url = new URL(raw);
            String host = url.getHost() == null ? "" : url.getHost().toLowerCase(Locale.ROOT);
            String path = url.getPath() == null ? "" : url.getPath().toLowerCase(Locale.ROOT);
            return (host.equals("video.twimg.com") || host.endsWith(".video.twimg.com"))
                    && path.endsWith(".mp4");
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * Resolve a fresh CDN variant from the source/referrer page.  The referrer is fetched once;
     * any X/Twitter status links in that page are then fetched (bounded) and scanned for the same
     * media identity.  A miss is cached for the rest of the analysis to avoid repeated network work.
     */
    public static String resolveFresh(String original, String referrer, String browserUserAgent) {
        if (!isTwitterVideoMp4(original)) return "";
        String recovered = RECOVERED.get(original);
        if (recovered != null && !recovered.isEmpty()) return recovered;
        if (REFRESH_RESULT.containsKey(original)) return REFRESH_RESULT.get(original);

        Object lock = REFRESH_LOCKS.computeIfAbsent(original, k -> new Object());
        synchronized (lock) {
            if (REFRESH_RESULT.containsKey(original)) return REFRESH_RESULT.get(original);
            String identity = mediaIdentity(original);
            if (identity.isEmpty() || referrer == null || referrer.trim().isEmpty()) {
                REFRESH_RESULT.put(original, "");
                DiagnosticLog.log("TW_VIDEO_REFRESH_MISS reason=no_identity_or_ref url=" + original
                        + " ref=" + String.valueOf(referrer));
                return "";
            }

            DiagnosticLog.log("TW_VIDEO_REFRESH_BEGIN identity=" + identity
                    + " url=" + original + " ref=" + referrer);
            try {
                String source = fetchText(referrer, browserUserAgent);
                if (!source.isEmpty()) {
                    String candidate = bestMatchingVideo(source, identity, original);
                    DiagnosticLog.log("TW_VIDEO_REFRESH_SOURCE_SCAN identity=" + identity
                            + " candidate=" + (candidate.isEmpty() ? "none" : candidate));
                    if (!candidate.isEmpty()) {
                        RECOVERED.put(original, candidate);
                        REFRESH_RESULT.put(original, candidate);
                        DiagnosticLog.log("TW_VIDEO_REFRESH_RESOLVED source=referrer identity="
                                + identity + " url=" + candidate);
                        return candidate;
                    }

                    Set<String> statusLinks = extractStatusLinks(source);
                    int checked = 0;
                    for (String status : statusLinks) {
                        if (checked++ >= MAX_STATUS_PAGES) break;
                        try {
                            String xSource = fetchText(status, browserUserAgent);
                            String xCandidate = bestMatchingVideo(xSource, identity, original);
                            DiagnosticLog.log("TW_VIDEO_REFRESH_X_SCAN identity=" + identity
                                    + " status=" + status
                                    + " candidate=" + (xCandidate.isEmpty() ? "none" : xCandidate));
                            if (!xCandidate.isEmpty()) {
                                RECOVERED.put(original, xCandidate);
                                REFRESH_RESULT.put(original, xCandidate);
                                DiagnosticLog.log("TW_VIDEO_REFRESH_RESOLVED source=x_status identity="
                                        + identity + " url=" + xCandidate);
                                return xCandidate;
                            }
                        } catch (Throwable statusError) {
                            DiagnosticLog.log("TW_VIDEO_REFRESH_X_FAIL status=" + status
                                    + " reason=" + statusError.getClass().getSimpleName());
                        }
                    }
                }
            } catch (Throwable error) {
                DiagnosticLog.log("TW_VIDEO_REFRESH_FAIL identity=" + identity
                        + " reason=" + error.getClass().getSimpleName()
                        + " message=" + String.valueOf(error.getMessage()));
            }

            REFRESH_RESULT.put(original, "");
            DiagnosticLog.log("TW_VIDEO_REFRESH_MISS identity=" + identity + " url=" + original);
            return "";
        }
    }

    private static String fetchText(String rawUrl, String browserUserAgent) throws Exception {
        URL current = new URL(rawUrl);
        for (int hop = 0; hop <= 5; hop++) {
            HttpURLConnection con = (HttpURLConnection) current.openConnection();
            con.setInstanceFollowRedirects(false);
            con.setConnectTimeout(12000);
            con.setReadTimeout(18000);
            con.setRequestProperty("User-Agent", safeUa(browserUserAgent));
            con.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.7");
            con.setRequestProperty("Accept-Language", Locale.getDefault().toLanguageTag() + ",ja;q=0.9,en;q=0.7");
            con.setRequestProperty("Accept-Encoding", "identity");
            String cookie = SessionCookies.getCookie(current.toString());
            if (cookie != null && !cookie.trim().isEmpty()) con.setRequestProperty("Cookie", cookie);
            try {
                int code = con.getResponseCode();
                if (code >= 300 && code < 400) {
                    String location = con.getHeaderField("Location");
                    if (location == null || location.trim().isEmpty()) return "";
                    current = new URL(current, location);
                    continue;
                }
                if (code < 200 || code >= 300) {
                    throw new java.io.IOException("HTTP " + code);
                }
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                try (InputStream in = con.getInputStream()) {
                    byte[] buf = new byte[32 * 1024];
                    int total = 0;
                    int n;
                    while ((n = in.read(buf)) >= 0) {
                        if (n == 0) continue;
                        int keep = Math.min(n, MAX_SOURCE_BYTES - total);
                        if (keep > 0) out.write(buf, 0, keep);
                        total += keep;
                        if (total >= MAX_SOURCE_BYTES) break;
                    }
                }
                String charset = "UTF-8";
                String ct = con.getContentType();
                if (ct != null) {
                    Matcher m = Pattern.compile("charset=([^;\\s]+)", Pattern.CASE_INSENSITIVE).matcher(ct);
                    if (m.find()) charset = m.group(1).replace("\"", "").trim();
                }
                try { return out.toString(charset); }
                catch (Exception ignored) { return out.toString("UTF-8"); }
            } finally {
                con.disconnect();
            }
        }
        return "";
    }

    private static String safeUa(String ua) {
        if (ua != null && !ua.trim().isEmpty()) return ua;
        return "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 Chrome/140.0 Mobile Safari/537.36";
    }

    private static String bestMatchingVideo(String source, String identity, String original) {
        if (source == null || source.isEmpty()) return "";
        String normalized = decodeEscapes(source);
        LinkedHashSet<String> matches = new LinkedHashSet<>();
        Matcher m = VIDEO_URL.matcher(normalized);
        while (m.find()) {
            String candidate = cleanupUrl(m.group());
            if (!isTwitterVideoMp4(candidate)) continue;
            if (!identity.equals(mediaIdentity(candidate))) continue;
            if (sameTransport(candidate, original)) continue;
            matches.add(candidate);
        }
        if (matches.isEmpty()) return "";
        List<String> ranked = new ArrayList<>(matches);
        Collections.sort(ranked, Comparator.comparingLong(TwitterVideoUrl::resolutionArea).reversed());
        return ranked.get(0);
    }

    private static Set<String> extractStatusLinks(String source) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (source == null || source.isEmpty()) return out;
        String normalized = decodeEscapes(source);
        Matcher m = STATUS_URL.matcher(normalized);
        while (m.find()) {
            String status = cleanupUrl(m.group());
            int q = status.indexOf('?');
            if (q >= 0) status = status.substring(0, q);
            out.add(status);
        }
        return out;
    }

    private static String decodeEscapes(String raw) {
        String out = raw
                .replace("\\u002F", "/").replace("\\u002f", "/")
                .replace("\\u003A", ":").replace("\\u003a", ":")
                .replace("\\u003F", "?").replace("\\u003f", "?")
                .replace("\\u0026", "&")
                .replace("&amp;", "&")
                .replace("&#38;", "&");
        // HTML/JSON seen in WebView sources may be escaped once or twice (\/ or \\/).
        // Repeat a few times so nested JSON strings normalize without using a full JSON parser.
        for (int i = 0; i < 3 && out.contains("\\/"); i++) out = out.replace("\\/", "/");
        return out;
    }

    private static String cleanupUrl(String raw) {
        if (raw == null) return "";
        String out = raw.trim();
        while (out.endsWith(",") || out.endsWith(")") || out.endsWith("]") || out.endsWith("}")
                || out.endsWith("\\") || out.endsWith(";")) {
            out = out.substring(0, out.length() - 1);
        }
        return out;
    }

    private static boolean sameTransport(String a, String b) {
        return stripFragment(a).equals(stripFragment(b));
    }

    private static String stripFragment(String raw) {
        if (raw == null) return "";
        int hash = raw.indexOf('#');
        return hash >= 0 ? raw.substring(0, hash) : raw;
    }

    private static String mediaIdentity(String raw) {
        if (!isTwitterVideoMp4(raw)) return "";
        try {
            URI uri = new URI(raw);
            String path = uri.getPath() == null ? "" : uri.getPath();
            Matcher id = MEDIA_ID.matcher(path);
            if (id.find()) return "media:" + id.group(1);
            Matcher tweet = TWEET_VIDEO_ID.matcher(path);
            if (tweet.find()) return "tweet_video:" + tweet.group(1);
            return "path:" + path;
        } catch (Exception ignored) {
            return "";
        }
    }

    private static long resolutionArea(String raw) {
        try {
            URI uri = new URI(raw);
            String path = uri.getPath() == null ? "" : uri.getPath();
            Matcher m = RESOLUTION.matcher(path);
            if (m.find()) {
                long w = Long.parseLong(m.group(1));
                long h = Long.parseLong(m.group(2));
                return w * h;
            }
        } catch (Exception ignored) {}
        return 0L;
    }
}
