# ImgStalker v0.1.39 (40)

## v0.1.39
- Fix Instagram readiness regression from v0.1.38: profile/story/media chrome no longer counts as a ready post grid. Instagram readiness now requires at least one canonical /p/, /reel/ or /tv/ link.
- Instagram readiness waits up to 8 probe passes before falling back to scrolling, instead of starting immediately when generic CDN media appears.
- SNS scrolling now treats document-height growth as progress, so bottom=true does not increment the stall counter while React is still appending rows.
- Instagram completion with zero discovered posts is explicitly incomplete (`instagram_posts_not_found`), so the trailing 「続き」 reload cell is shown instead of reporting a false clean completion.
- v0.1.38 carousel, DOM-known image acceptance, video range normalization, audio-only filtering, network quiet completion, and continuation behavior are retained.
- versionCode 40 / versionName 0.1.39. applicationId and fixed signing are unchanged.
