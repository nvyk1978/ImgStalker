#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
src="$tmp/src"; mkdir -p "$src/android/content" "$src/android/database" "$src/android/net" "$src/android/provider" "$src/org/json" "$src/com/cmyk/imgstalker"
cat > "$src/android/net/Uri.java" <<'JAVA'
package android.net;public class Uri {public String toString(){return "";}}
JAVA
cat > "$src/android/content/Context.java" <<'JAVA'
package android.content;public class Context {public ContentResolver getContentResolver(){return null;}}
JAVA
cat > "$src/android/content/ContentResolver.java" <<'JAVA'
package android.content;public class ContentResolver {
 public android.database.Cursor query(android.net.Uri u,String[] p,String s,String[] a,String o){return null;}
 public java.io.InputStream openInputStream(android.net.Uri u){return null;}
 public java.io.OutputStream openOutputStream(android.net.Uri u,String m){return null;}
}
JAVA
cat > "$src/android/database/Cursor.java" <<'JAVA'
package android.database;public interface Cursor extends java.lang.AutoCloseable {int getColumnIndex(String k);String getString(int i);boolean moveToNext();void close();}
JAVA
cat > "$src/android/provider/DocumentsContract.java" <<'JAVA'
package android.provider;public class DocumentsContract {
 public static class Document {public static final String MIME_TYPE_DIR="dir",COLUMN_DOCUMENT_ID="id",COLUMN_DISPLAY_NAME="name",COLUMN_MIME_TYPE="mime";}
 public static String getTreeDocumentId(android.net.Uri u){return "";}
 public static String getDocumentId(android.net.Uri u){return "";}
 public static android.net.Uri buildDocumentUriUsingTree(android.net.Uri u,String id){return null;}
 public static android.net.Uri buildChildDocumentsUriUsingTree(android.net.Uri u,String id){return null;}
 public static android.net.Uri createDocument(android.content.ContentResolver r,android.net.Uri p,String mime,String n){return null;}
 public static boolean deleteDocument(android.content.ContentResolver r,android.net.Uri u){return false;}
 public static android.net.Uri renameDocument(android.content.ContentResolver r,android.net.Uri u,String n){return null;}
}
JAVA
cat > "$src/org/json/JSONArray.java" <<'JAVA'
package org.json;public class JSONArray {public JSONArray(){}public int length(){return 0;}public String optString(int k,String d){return d;}public JSONObject optJSONObject(int i){return null;}public JSONArray put(Object o){return this;}}
JAVA
cat > "$src/org/json/JSONObject.java" <<'JAVA'
package org.json;public class JSONObject {public JSONObject(){}public JSONObject(String s){}public JSONObject put(String k,Object v){return this;}public String toString(int i){return "";}public int optInt(String k,int v){return v;}public boolean optBoolean(String k,boolean v){return v;}public long optLong(String k,long v){return v;}public String optString(String k,String v){return v;}public JSONArray optJSONArray(String k){return null;}public boolean has(String k){return false;}}
JAVA
cat > "$src/com/cmyk/imgstalker/Stubs.java" <<'JAVA'
package com.cmyk.imgstalker;
class DiagnosticLog {static void log(String t){}static void logException(String s,Throwable t){}}
class SavePrefs {static boolean hasTreeAccess(android.content.Context c){return false;}static android.net.Uri treeUri(android.content.Context c){return null;}static java.io.File fileFromTreeUri(android.net.Uri u){return null;}static java.io.File directory(android.content.Context c){return new java.io.File("/");}}
class SnsAccountManager {enum Service{INSTAGRAM,THREADS,X}}
JAVA
javac -encoding UTF-8 -d "$tmp/classes" $(find "$src" -name '*.java') \
 app/src/main/java/com/cmyk/imgstalker/MediaItem.java \
 app/src/main/java/com/cmyk/imgstalker/SnsResumeStore.java
printf '%s\n' 'PASS: SNS SAF resume store Java compilation'
