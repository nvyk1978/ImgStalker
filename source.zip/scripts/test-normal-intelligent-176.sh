#!/usr/bin/env bash
set -euo pipefail
W="$(cd "$(dirname "$0")/.." && pwd)"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/com/cmyk/imgstalker"
cat > "$TMP/com/cmyk/imgstalker/TestNormalIntelligent.java" <<'JAVA'
package com.cmyk.imgstalker;
public class TestNormalIntelligent {
  public static void main(String[] args) {
    String root="https://coserslove.com/ja/album/790512fb-d877-416e-b3d6-2dadbd8244f4";
    if(!NormalIntelligentTraversal.isCosersAlbum(root))throw new AssertionError("base");
    String page2=NormalIntelligentTraversal.nextAlbumPage(root,root);
    if(!page2.equals(root+"/2"))throw new AssertionError(page2);
    if(!NormalIntelligentTraversal.sameAlbum(root, page2))throw new AssertionError("same album");
    if(!NormalIntelligentTraversal.nextAlbumPage(root,page2).equals(root+"/3"))throw new AssertionError("next from page 2");
    if(NormalIntelligentTraversal.sameAlbum(root,"https://coserslove.com/ja/album/390512fb-d877-416e-b3d6-2dadbd8244f4/2"))throw new AssertionError("other album");
    if(NormalIntelligentTraversal.sameAlbum(root,"https://evil.com/ja/album/790512fb-d877-416e-b3d6-2dadbd8244f4/2"))throw new AssertionError("external site");
    if(NormalIntelligentTraversal.isCosersAlbum("https://coserslove.com/ja/album/790512fb-d877-416e-b3d6-2dadbd8244f4/../../bad"))throw new AssertionError("bad path");
    if(!NormalIntelligentTraversal.isAlbumAsset("https://img.coserslove.com/a.avif"))throw new AssertionError("avif");
    if(NormalIntelligentTraversal.isAlbumAsset("https://img.coserslove.com/a.svg"))throw new AssertionError("svg excluded");
    if(NormalIntelligentTraversal.isAlbumAsset("https://evil-img.coserslove.com/a.jpg"))throw new AssertionError("fake CDN");
    if(NormalIntelligentTraversal.isAlbumAsset("https://img.coserslove.com.evil.com/a.jpg"))throw new AssertionError("evil suffix");
    System.out.println("PASS: CosersLove same-album URL, next page, scheme/host, asset checks");
    System.out.print("JS_START\n");
    System.out.print(NormalIntelligentTraversal.supplementalJavascript());
  }
}
JAVA
javac -d "$TMP" "$W/app/src/main/java/com/cmyk/imgstalker/NormalIntelligentTraversal.java" "$TMP/com/cmyk/imgstalker/TestNormalIntelligent.java"
java -cp "$TMP" com.cmyk.imgstalker.TestNormalIntelligent > "$TMP/out"
head -1 "$TMP/out"
sed '1,2d' "$TMP/out" > "$TMP/extra.js"
cat > "$TMP/check.cjs" <<'NODE'
const fs=require('fs'),vm=require('vm');
const js=fs.readFileSync(process.argv[2],'utf8');
new Function('const abs=u=>u;let images=[],videos=[],streams=[];'+js); // syntax
const elements={
 'img,picture source,[data-src],[data-original],[data-full],[data-image],[data-background]':[
  {src:'https://img.coserslove.com/aa.avif',getAttribute:k=> k==='data-full'?'https://img.coserslove.com/bb.webp':null}
 ],
 '[style],[data-bg],[data-background-image]': [],
 'script[type="application/ld+json"],script#__NEXT_DATA__,script#__NUXT_DATA__,script[type="application/json"]':[
  {textContent:JSON.stringify({images:[{url:'https://img.coserslove.com/cc.avif'}]})}
 ],
 '[role="group"] img,[data-testid*="carousel"] img,[class*="carousel"] img':[]
};
const context={
  document:{querySelectorAll:s=>elements[s]||[]},performance:{getEntriesByType:()=>[]},
  abs: u=>u,images:[],videos:[],streams:[],getComputedStyle:()=>({backgroundImage:''})
};
vm.runInNewContext(js,context,{timeout:2000});
for(const i of ['aa.avif','bb.webp','cc.avif'])if(!context.images.some(x=>x.endsWith(i)))throw new Error('missed '+i+' '+context.images);
console.log('PASS: runtime DOM lazy attributes, embedded JSON and JS parse, candidates='+context.images.length);
NODE
node "$TMP/check.cjs" "$TMP/extra.js"
