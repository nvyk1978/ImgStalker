package com.cmyk.imgstalker;

import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Converts the MP4 representation used by X for animated GIF posts back into
 * an actual looping GIF.  This intentionally has no native/FFmpeg dependency
 * so the normal ImgStalker APK stays self-contained.
 */
final class XGifTranscoder {
    private static final int MAX_DIMENSION = 1920;
    private static final int MAX_FPS = 20;
    private static final int DEFAULT_FPS = 15;
    private static final int MAX_FRAMES = 400;

    private XGifTranscoder() {}

    static long transcode(File sourceMp4, OutputStream rawOut, AtomicCancel cancel) throws Exception {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(sourceMp4.getAbsolutePath());
            long durationMs = parseLong(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION), 0L);
            if (durationMs <= 0L) throw new IOException("GIF source duration unavailable");

            int fps = chooseFps(retriever, durationMs);
            int frameCount = Math.max(1, (int) Math.ceil(durationMs * fps / 1000.0));
            if (frameCount > MAX_FRAMES) {
                frameCount = MAX_FRAMES;
                fps = Math.max(1, (int) Math.floor(frameCount * 1000.0 / durationMs));
            }
            int delayCs = Math.max(2, Math.round(durationMs / (float) frameCount / 10f));

            Bitmap first = frameAt(retriever, 0L);
            if (first == null) throw new IOException("GIF source first frame unavailable");
            int[] outSize = boundedSize(first.getWidth(), first.getHeight(), MAX_DIMENSION);
            int width = outSize[0];
            int height = outSize[1];
            Bitmap firstPrepared = prepare(first, width, height);

            CountingOutputStream counted = new CountingOutputStream(new BufferedOutputStream(rawOut, 128 * 1024));
            Gif332Encoder encoder = new Gif332Encoder(counted, width, height, delayCs);
            encoder.start();
            encoder.addFrame(firstPrepared);
            recyclePrepared(first, firstPrepared);

            DiagnosticLog.log("SNS_X_GIF_TRANSCODE_BEGIN durationMs=" + durationMs
                    + " fps=" + fps + " frames=" + frameCount
                    + " size=" + width + "x" + height);

            for (int i = 1; i < frameCount; i++) {
                if (cancel != null && cancel.isCancelled()) throw new InterruptedException("cancelled");
                long timeUs = Math.min(durationMs * 1000L - 1L,
                        Math.round(i * durationMs * 1000.0 / frameCount));
                Bitmap frame = frameAt(retriever, Math.max(0L, timeUs));
                if (frame == null) {
                    DiagnosticLog.log("SNS_X_GIF_FRAME_SKIP index=" + i + " timeUs=" + timeUs);
                    continue;
                }
                Bitmap prepared = prepare(frame, width, height);
                encoder.addFrame(prepared);
                recyclePrepared(frame, prepared);
                if (i % 20 == 0 || i + 1 == frameCount) {
                    DiagnosticLog.log("SNS_X_GIF_TRANSCODE_PROGRESS frame=" + (i + 1) + "/" + frameCount);
                }
            }
            encoder.finish();
            counted.flush();
            DiagnosticLog.log("SNS_X_GIF_TRANSCODE_DONE bytes=" + counted.count());
            return counted.count();
        } finally {
            try { retriever.release(); } catch (Throwable ignored) {}
        }
    }

    private static Bitmap frameAt(MediaMetadataRetriever retriever, long timeUs) {
        try {
            return retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST);
        } catch (Throwable error) {
            DiagnosticLog.logException("SNS_X_GIF_FRAME_FAIL timeUs=" + timeUs, error);
            return null;
        }
    }

    private static int chooseFps(MediaMetadataRetriever retriever, long durationMs) {
        float fps = parseFloat(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE), 0f);
        int out = fps > 0f ? Math.round(fps) : DEFAULT_FPS;
        out = Math.max(5, Math.min(MAX_FPS, out));
        long frames = Math.max(1L, Math.round(durationMs * out / 1000.0));
        if (frames > MAX_FRAMES) {
            out = Math.max(1, (int) Math.floor(MAX_FRAMES * 1000.0 / durationMs));
        }
        return Math.max(1, out);
    }

    private static int[] boundedSize(int width, int height, int maxDimension) {
        width = Math.max(1, width);
        height = Math.max(1, height);
        int largest = Math.max(width, height);
        if (largest <= maxDimension) return new int[]{width, height};
        float scale = maxDimension / (float) largest;
        return new int[]{Math.max(1, Math.round(width * scale)), Math.max(1, Math.round(height * scale))};
    }

    private static Bitmap prepare(Bitmap source, int width, int height) {
        if (source.getWidth() == width && source.getHeight() == height) return source;
        return Bitmap.createScaledBitmap(source, width, height, true);
    }

    private static void recyclePrepared(Bitmap source, Bitmap prepared) {
        if (prepared != null && prepared != source && !prepared.isRecycled()) prepared.recycle();
        if (source != null && !source.isRecycled()) source.recycle();
    }

    private static long parseLong(String value, long fallback) {
        try { return Long.parseLong(value == null ? "" : value.trim()); }
        catch (Throwable ignored) { return fallback; }
    }

    private static float parseFloat(String value, float fallback) {
        try { return Float.parseFloat(value == null ? "" : value.trim()); }
        catch (Throwable ignored) { return fallback; }
    }

    interface AtomicCancel {
        boolean isCancelled();
    }

    /** GIF89a encoder using a fixed 3-3-2 global palette and standard GIF LZW. */
    private static final class Gif332Encoder {
        private final OutputStream out;
        private final int width;
        private final int height;
        private final int delayCs;
        private boolean started;
        private boolean finished;

        Gif332Encoder(OutputStream out, int width, int height, int delayCs) {
            this.out = out;
            this.width = width;
            this.height = height;
            this.delayCs = Math.max(1, delayCs);
        }

        void start() throws IOException {
            if (started) return;
            started = true;
            writeAscii("GIF89a");
            writeShort(width);
            writeShort(height);
            out.write(0xF7); // global palette, 8-bit color resolution, 256 entries
            out.write(0);    // background index
            out.write(0);    // pixel aspect ratio
            writePalette332();
            // Infinite loop extension.
            out.write(0x21); out.write(0xFF); out.write(0x0B);
            writeAscii("NETSCAPE2.0");
            out.write(0x03); out.write(0x01); writeShort(0); out.write(0x00);
        }

        void addFrame(Bitmap bitmap) throws IOException {
            if (!started || finished) throw new IOException("GIF encoder not active");
            if (bitmap == null || bitmap.getWidth() != width || bitmap.getHeight() != height) {
                throw new IOException("GIF frame size mismatch");
            }
            // Graphic Control Extension.
            out.write(0x21); out.write(0xF9); out.write(0x04);
            out.write(0x00); // no transparency/disposal; every frame covers the whole canvas
            writeShort(delayCs);
            out.write(0x00); out.write(0x00);

            // Image Descriptor.
            out.write(0x2C);
            writeShort(0); writeShort(0); writeShort(width); writeShort(height);
            out.write(0x00); // use global palette

            byte[] indexed = quantize332(bitmap);
            writeLzw(indexed);
        }

        void finish() throws IOException {
            if (!started || finished) return;
            finished = true;
            out.write(0x3B);
        }

        private byte[] quantize332(Bitmap bitmap) {
            int pixels = width * height;
            int[] argb = new int[pixels];
            byte[] indexed = new byte[pixels];
            bitmap.getPixels(argb, 0, width, 0, 0, width, height);
            for (int i = 0; i < pixels; i++) {
                int c = argb[i];
                int r = (c >>> 16) & 0xFF;
                int g = (c >>> 8) & 0xFF;
                int b = c & 0xFF;
                indexed[i] = (byte) (((r >>> 5) << 5) | ((g >>> 5) << 2) | (b >>> 6));
            }
            return indexed;
        }

        private void writePalette332() throws IOException {
            for (int i = 0; i < 256; i++) {
                int r = ((i >>> 5) & 0x07) * 255 / 7;
                int g = ((i >>> 2) & 0x07) * 255 / 7;
                int b = (i & 0x03) * 255 / 3;
                out.write(r); out.write(g); out.write(b);
            }
        }

        private void writeLzw(byte[] pixels) throws IOException {
            out.write(8); // minimum LZW code size
            GifBitWriter bits = new GifBitWriter(out);
            final int clear = 256;
            final int eoi = 257;
            int nextCode = 258;
            int codeSize = 9;
            Map<Integer, Integer> dict = new HashMap<>(4096);
            bits.write(clear, codeSize);
            if (pixels.length == 0) {
                bits.write(eoi, codeSize);
                bits.finish();
                return;
            }

            int prefix = pixels[0] & 0xFF;
            for (int i = 1; i < pixels.length; i++) {
                int suffix = pixels[i] & 0xFF;
                int key = (prefix << 8) | suffix;
                Integer found = dict.get(key);
                if (found != null) {
                    prefix = found;
                    continue;
                }

                bits.write(prefix, codeSize);
                if (nextCode < 4096) {
                    dict.put(key, nextCode++);
                    // The decoder dictionary trails the encoder by one entry, so switch
                    // code width only after the next free code moves past the boundary.
                    if (nextCode > (1 << codeSize) && codeSize < 12) codeSize++;
                } else {
                    bits.write(clear, codeSize);
                    dict.clear();
                    nextCode = 258;
                    codeSize = 9;
                }
                prefix = suffix;
            }
            bits.write(prefix, codeSize);
            bits.write(eoi, codeSize);
            bits.finish();
        }

        private void writeShort(int value) throws IOException {
            out.write(value & 0xFF);
            out.write((value >>> 8) & 0xFF);
        }

        private void writeAscii(String value) throws IOException {
            out.write(value.getBytes(StandardCharsets.US_ASCII));
        }
    }

    /** LSB-first GIF code writer that emits 255-byte data sub-blocks. */
    private static final class GifBitWriter {
        private final OutputStream out;
        private final byte[] block = new byte[255];
        private int blockSize;
        private long bitBuffer;
        private int bitCount;

        GifBitWriter(OutputStream out) {
            this.out = out;
        }

        void write(int code, int bits) throws IOException {
            bitBuffer |= ((long) code) << bitCount;
            bitCount += bits;
            while (bitCount >= 8) {
                putByte((int) (bitBuffer & 0xFF));
                bitBuffer >>>= 8;
                bitCount -= 8;
            }
        }

        void finish() throws IOException {
            if (bitCount > 0) putByte((int) (bitBuffer & 0xFF));
            flushBlock();
            out.write(0x00); // data sub-block terminator
            bitBuffer = 0L;
            bitCount = 0;
        }

        private void putByte(int value) throws IOException {
            block[blockSize++] = (byte) value;
            if (blockSize == block.length) flushBlock();
        }

        private void flushBlock() throws IOException {
            if (blockSize <= 0) return;
            out.write(blockSize);
            out.write(block, 0, blockSize);
            blockSize = 0;
        }
    }

    private static final class CountingOutputStream extends OutputStream {
        private final OutputStream delegate;
        private long count;

        CountingOutputStream(OutputStream delegate) {
            this.delegate = delegate;
        }

        long count() { return count; }

        @Override public void write(int b) throws IOException {
            delegate.write(b);
            count++;
        }

        @Override public void write(byte[] b, int off, int len) throws IOException {
            delegate.write(b, off, len);
            count += len;
        }

        @Override public void flush() throws IOException { delegate.flush(); }
        @Override public void close() throws IOException { delegate.close(); }
    }
}
