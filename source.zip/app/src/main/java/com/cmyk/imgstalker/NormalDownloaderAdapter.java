package com.cmyk.imgstalker;
import android.content.Context;
import java.util.List;
final class NormalDownloaderAdapter implements ModeDownloader {
    private final NormalMediaDownloader core;
    NormalDownloaderAdapter(Context context, boolean xGif, MediaDownloader.Listener listener) {core=new NormalMediaDownloader(context, xGif, listener);}
    @Override public void download(List<MediaItem> items, String title, String category, String account) {
        core.download(items, title, category, account);
    }
    @Override public void cancel(){core.cancel();}
}
