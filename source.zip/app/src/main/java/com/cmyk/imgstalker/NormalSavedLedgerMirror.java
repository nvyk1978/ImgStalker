package com.cmyk.imgstalker;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.OutputStream;

/** User-visible NORMAL-only saved inventory. Never accesses SNS folders. */
final class NormalSavedLedgerMirror {
    private NormalSavedLedgerMirror() { }
    private static Uri child(ContentResolver resolver, Uri tree, Uri parent, String name) {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getDocumentId(parent));
        try (Cursor c = resolver.query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (c == null) return null;
            while (c.moveToNext()) {
                if (name.equals(c.getString(1)))
                    return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0));
            }
        } catch (Throwable ignored) { }
        return null;
    }
    private static Uri folder(Context context, Uri tree, String url, boolean create) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        Uri dir = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
        String host = NormalCheckpointStore.checkpoint(context, url).getParentFile().getName();
        for (String segment : new String[]{"Normal", host}) {
            Uri next = child(resolver, tree, dir, segment);
            if (next == null && create) next = DocumentsContract.createDocument(resolver, dir,
                    DocumentsContract.Document.MIME_TYPE_DIR, segment);
            if (next == null) return null;
            dir = next;
        }
        return dir;
    }
    private static String name(Context c, String url) {
        String checkpoint = NormalCheckpointStore.checkpoint(c, url).getName();
        return checkpoint.substring(0, checkpoint.length() - 5) + ".saved.json";
    }
    static boolean exists(Context context, String url) {
        if (!SavePrefs.hasTreeAccess(context) || NormalCheckpointStore.key(url).isEmpty()) return false;
        try {
            Uri tree = SavePrefs.treeUri(context);
            Uri dir = folder(context, tree, url, false);
            return dir != null && child(context.getContentResolver(), tree, dir, name(context, url)) != null;
        } catch (Throwable e) {
            DiagnosticLog.logException("NORMAL_SAVED_MIRROR_PROBE_FAIL", e);
            return false;
        }
    }
    static boolean write(Context context, String url, byte[] bytes) {
        if (!SavePrefs.hasTreeAccess(context) || NormalCheckpointStore.key(url).isEmpty()) return false;
        try {
            Uri tree = SavePrefs.treeUri(context);
            ContentResolver resolver = context.getContentResolver();
            Uri dir = folder(context, tree, url, true);
            if (dir == null) return false;
            String filename = name(context, url);
            Uri target = child(resolver, tree, dir, filename);
            if (target == null)
                target = DocumentsContract.createDocument(resolver, dir, "application/json", filename);
            if (target == null) return false;
            try (OutputStream out = resolver.openOutputStream(target, "wt")) {
                if (out == null) return false;
                out.write(bytes);
                out.flush();
            }
            DiagnosticLog.log("NORMAL_SAVED_MIRROR_WRITE file=" + filename);
            return true;
        } catch (Throwable error) {
            DiagnosticLog.logException("NORMAL_SAVED_MIRROR_WRITE_FAIL", error);
            return false;
        }
    }
}
