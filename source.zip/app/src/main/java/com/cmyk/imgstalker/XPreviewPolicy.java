package com.cmyk.imgstalker;

/** X preview rewrites and retry cache are available ONLY from the X provider. */
final class XPreviewPolicy implements ModePreviewPolicy {
    @Override public boolean isSpecialVideo(String url) { return TwitterVideoUrl.isTwitterVideoMp4(url); }
    @Override public boolean isKnownFailed(String url) { return TwitterVideoUrl.isKnownFailed(url, "preview"); }
    @Override public String resolvedUrl(String url) { return TwitterVideoUrl.resolvedOrOriginal(url); }
    @Override public String resolveFresh(String url, String referrer, String ua) { return TwitterVideoUrl.resolveFresh(url, referrer, ua); }
    @Override public void markRecovered(String sourceUrl, String resolvedUrl) { TwitterVideoUrl.markRecovered(sourceUrl, resolvedUrl); }
    @Override public void markFailed(String url) { TwitterVideoUrl.markFailed(url, "preview"); }
    @Override public void reset() { TwitterVideoUrl.resetSession(); }
}
