package com.cmyk.imgstalker;

import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Network-free regression tests for the new Instagram-only profile policy. */
public final class Instagram429RecoveryTest {
    static void check(boolean ok, String msg) {
        if (!ok) throw new AssertionError(msg);
    }

    static class Listener implements InstagramInstagramSourcePipeline.Listener {
        final List<String> discovered = new ArrayList<>();
        final List<String> limited = new ArrayList<>();
        public void onProfileMeta(String name, int expected) {}
        public void onPostDiscovered(int index, String url) { discovered.add(url); }
        public void onPostResolved(String url, List<InstagramInstagramSourcePipeline.ResolvedMedia> media) {}
        public void onPostRetry(String url, int attempt, String reason, long delay) {}
        public void onPostSkipped(String url, String reason) {}
        public void onRateLimited(String scope, int code, long wait) {
            limited.add(scope + ":" + code + ":" + wait);
        }
        public void onComplete(int a, int b, int c, int d, boolean e) {}
        public void onFatal(String msg) {}
    }

    public static void main(String[] args) throws Exception {
        Listener listener = new Listener();
        InstagramInstagramSourcePipeline p = new InstagramInstagramSourcePipeline("", "test", listener);
        Method discover = InstagramInstagramSourcePipeline.class.getDeclaredMethod("discoverProfileSourcePosts", String.class);
        discover.setAccessible(true);
        int num = (Integer)discover.invoke(p, "{\"shortcode\":\"ABCde1234\"} /reel/ZZZZZ9876/");
        check(num == 2, "HTML source can discover media before a profile ID is known");
        check(listener.discovered.size() == 2, "source queue receives both posts");
        check((Integer)discover.invoke(p, "/reel/ZZZZZ9876/") == 0, "re-reading HTML does not duplicate URLs");

        Class<?> http = Class.forName("com.cmyk.imgstalker.InstagramInstagramSourcePipeline$HttpResult");
        Constructor<?> ctor = http.getDeclaredConstructor(int.class, String.class, long.class);
        ctor.setAccessible(true);
        Class<?> request = Class.forName("com.cmyk.imgstalker.InstagramInstagramSourcePipeline$ProfileRequest");
        Method attempt = InstagramInstagramSourcePipeline.class.getDeclaredMethod("profileRequestWithBackoff", String.class, request);
        attempt.setAccessible(true);
        AtomicInteger calls = new AtomicInteger();
        Object firstOk = Proxy.newProxyInstance(request.getClassLoader(), new Class<?>[]{request}, (proxy, method, argv) -> {
            calls.incrementAndGet();
            return ctor.newInstance(200, "{}", 0L);
        });
        attempt.invoke(p, "profile_source", firstOk);
        check(calls.get() == 1 && listener.limited.isEmpty(), "HTTP 200 never retries");

        AtomicInteger throttledCalls = new AtomicInteger();
        Object longWait = Proxy.newProxyInstance(request.getClassLoader(), new Class<?>[]{request}, (proxy, method, argv) -> {
            throttledCalls.incrementAndGet();
            return ctor.newInstance(429, "", 125000L);
        });
        try {
            attempt.invoke(p, "profile_info_v1", longWait);
            throw new AssertionError("429 requiring >120s must pause rather than immediately retry");
        } catch (InvocationTargetException e) {
            check(e.getCause().getClass().getSimpleName().equals("ProfileRateLimitedException"), "typed 429 pause exception");
        }
        check(throttledCalls.get() == 1, "server Retry-After >120s is never violated by early retry");
        check(listener.limited.size() == 1 && listener.limited.get(0).startsWith("profile_info_v1:429:"), "429 is observable");
        System.out.println("PASS: Instagram 429 profile policy (source-first, dedup, 200, long Retry-After)");
    }
}
