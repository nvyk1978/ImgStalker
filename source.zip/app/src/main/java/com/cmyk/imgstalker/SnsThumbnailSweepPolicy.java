package com.cmyk.imgstalker;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/** Main-thread-only SNS thumbnail retry state; a dispatch is NOT a failure. */
final class SnsThumbnailSweepPolicy {
    private static final int MAX_FAILURES = 4;
    private static final long[] RETRY_DELAY_MS = {3500L, 14000L, 60000L, 180000L};
    private final HashMap<String, Integer> failures = new HashMap<>();
    private final HashMap<String, Long> lastFailure = new HashMap<>();
    private final HashSet<String> inFlight = new HashSet<>();
    private final HashSet<String> finished = new HashSet<>();

    void reset() {
        failures.clear();
        lastFailure.clear();
        inFlight.clear();
        finished.clear();
    }

    /** A cancelled reload must not strand keys in the in-flight state. */
    void abandonInFlight() { inFlight.clear(); }

    boolean isFinished(String key) { return finished.contains(key); }
    int finishedCount() { return finished.size(); }
    int exhaustedCount() {
        int result = 0;
        for (String key : failures.keySet()) if (exhausted(key) && !finished.contains(key)) result++;
        return result;
    }
    boolean isInFlight(String key) { return inFlight.contains(key); }
    void finish(String key) { inFlight.remove(key); finished.add(key); }
    int attempts(String key) { return failures.getOrDefault(key, 0); }

    /** Call when a transport is actually working, whether from viewport or sweep. */
    void recordStart(String key) { if (!finished.contains(key)) inFlight.add(key); }

    /** Count ONLY confirmed failed requests, never queued or pending requests. */
    void recordResult(String key, boolean success, long now) {
        if (success) { finish(key); return; }
        if (!inFlight.remove(key) || finished.contains(key)) return;
        failures.put(key, attempts(key) + 1);
        lastFailure.put(key, now);
    }

    boolean exhausted(String key) { return attempts(key) >= MAX_FAILURES; }

    long retryAt(String key) {
        int count = attempts(key);
        if (count == 0) return 0L;
        return lastFailure.getOrDefault(key, 0L)
                + RETRY_DELAY_MS[Math.min(count - 1, RETRY_DELAY_MS.length - 1)];
    }

    boolean canAttempt(String key, long now) {
        return !finished.contains(key) && !inFlight.contains(key)
                && !exhausted(key) && now >= retryAt(key);
    }

    boolean hasRetryableFailures() {
        for (Map.Entry<String, Integer> entry : failures.entrySet()) {
            String key = entry.getKey();
            if (!finished.contains(key) && !inFlight.contains(key)
                    && entry.getValue() < MAX_FAILURES) return true;
        }
        return false;
    }

    long earliestRetryAt() {
        long next = Long.MAX_VALUE;
        for (String key : failures.keySet()) {
            if (finished.contains(key) || inFlight.contains(key) || exhausted(key)) continue;
            next = Math.min(next, retryAt(key));
        }
        return next;
    }
}
